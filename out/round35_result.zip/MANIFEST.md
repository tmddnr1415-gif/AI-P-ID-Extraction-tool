# MANIFEST — 35회차 출력

담긴 파일 23개

* 0_요약.md
* 1_보고서.md
* 2_progress.md
* 3_strip_list.md
* 4_replay.md
* 5_classified.md
* 6_remaining.md
* 7_human_vs_rule.md
* 8_regression_4p.json
* 8_regression_4p_start.json
* 기록/groups.json
* 기록/moved.json
* 기록/replay_late_pass1.json
* 기록/replay_pass2_final.json
* 기록/replay_probe.json
* 기록/pass2_prerestored.json
* 기록/strip_keys.json
* 기록/judgements.json
* 기록/lists.json
* 기록/full58.json
* 기록/overlay.json
* worktree.diff
* 9_캡처/README.md

## 뺀 것

* 행 덤프 (`out/round35/rows_*.json`) — 행 좌표·판정 전문이라 뺀다 (필요하면 저장소에 있다)
* 탐침 PDF (`/tmp/r35_probe.pdf`) 와 발주처 도면·리스트 (`data/`, `app/_data/`)
* worktree 자체 (`/tmp/r35_strip`) — 남겨 두었고 diff 만 담는다
