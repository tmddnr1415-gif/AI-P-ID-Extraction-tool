@echo off
rem Virtual plaza server for the department dashboard (port 8100).
rem Keeps running: if the server stops it starts again after 10 seconds.
rem Close this window to stop it.  Never kill python by name - the dashboard is python too.
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
set PORT=8100
if not "%~1"=="" set PORT=%~1
title Plaza server - port %PORT%
:loop
echo [%date% %time%] Starting plaza server on port %PORT% (log: plaza\logs\plaza_server.log)
python "%~dp0plaza_server.py" --port %PORT% --data "%~dp0plaza_data" --log "%~dp0logs\plaza_server.log"
echo [%date% %time%] Plaza server stopped. Restarting in 10 seconds...
timeout /t 10 /nobreak >nul
goto loop
