@echo off
rem Restart the plaza server after applying an update.
rem Stops only the program listening on port 8100 (by PID).  run_plaza_server.bat brings it back.
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
python "%~dp0plaza_restart.py" 8100
pause
