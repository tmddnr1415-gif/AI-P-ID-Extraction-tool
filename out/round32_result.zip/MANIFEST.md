# MANIFEST — 32회차 출력

담긴 파일 107개 (캡처 95장)

* 0_요약.md
* 1_결론.md
* 2_progress.md
* 3_display.md
* 4_audit.md
* 5_synthetic.md
* 6_regression_4p.json

## 뺀 것

* 합성 PDF (`tests/data/synthetic/*.pdf`) — 발주처 도면의 쪽을 재료로 쓴다
* 발주처 도면·리스트 (`data/`, `app/_data/`)
* 네 프로젝트 결과 json 전문 (`out/regression_3p/*.json`) — 행 내용이 들어 있다
