# MANIFEST — 33회차 출력

담긴 파일 131개 (캡처 115장)

* 0_요약.md
* 1_보고서.md
* 2_progress.md
* 3_죽는버그.md
* 4_색.md
* 5_메모리.md
* 6_regression_4p.json

## 뺀 것

* 메모리 실측 json (`out/round33/mem_*.json`) — 보고서 표에 옮겨 적었다
* 합성 PDF (`tests/data/synthetic/*.pdf`) — 발주처 도면의 쪽을 재료로 쓴다
* 발주처 도면·리스트 (`data/`, `app/_data/`)
* 네 프로젝트 결과 json 전문 (`out/regression_3p/*.json`) — 행 내용이 들어 있다
