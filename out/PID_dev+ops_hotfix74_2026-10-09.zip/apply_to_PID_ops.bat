@echo off
rem Apply this update to the OPERATING folder C:\Claude\PID (the server the dashboard shows).
rem Only the files the server runs (app\...).  If any of them was changed in that folder,
rem nothing is changed at all.  Then only the server on port 8000 is restarted.
cd /d "%~dp0"
set PYTHONUTF8=1
set "TARGET=C:\Claude\PID"
if not "%~1"=="" set "TARGET=%~1"
set "PY=%TARGET%\.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" apply_delta.py "%TARGET%" --ops --runtime --all-or-nothing
if errorlevel 1 goto end
"%PY%" restart_pid_server.py 8000
:end
pause
