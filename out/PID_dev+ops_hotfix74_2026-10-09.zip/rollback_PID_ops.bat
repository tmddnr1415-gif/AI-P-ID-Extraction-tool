@echo off
rem Undo this update in the OPERATING folder C:\Claude\PID and restart the port 8000 server.
cd /d "%~dp0"
set PYTHONUTF8=1
set "TARGET=C:\Claude\PID"
if not "%~1"=="" set "TARGET=%~1"
set "PY=%TARGET%\.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" apply_delta.py "%TARGET%" --ops --restore
if errorlevel 1 goto end
"%PY%" restart_pid_server.py 8000
:end
pause
