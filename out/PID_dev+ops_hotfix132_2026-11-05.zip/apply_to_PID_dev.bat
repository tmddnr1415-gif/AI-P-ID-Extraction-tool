@echo off
rem Apply this delta to C:\Claude\PID_dev (never to the operating folder).
rem   apply_to_PID_dev.bat                   -> C:\Claude\PID_dev
rem   apply_to_PID_dev.bat D:\x\PID_dev       -> that folder (it must hold app\main.py)
rem   add --dry-run to see what would change without changing anything
rem Unpack the whole zip first; this does not work from inside the zip.
cd /d "%~dp0"
setlocal enabledelayedexpansion
set PYTHONUTF8=1
set "TARGET=C:\Claude\PID_dev"
set "FIRST="
if exist "%~1\app\main.py" (set "TARGET=%~1"& set "FIRST=%~1")
set "REST="
for %%a in (%*) do if not "%%~a"=="!FIRST!" set "REST=!REST! %%a"
set "PY=%TARGET%\.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" apply_delta.py "%TARGET%" !REST!
pause
