@echo off
rem Apply this delta to C:\Claude\PID_dev (never to the operating folder).
cd /d "%~dp0"
set PYTHONUTF8=1
set "PY=C:\Claude\PID_dev\.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" apply_delta.py C:\Claude\PID_dev %*
pause
