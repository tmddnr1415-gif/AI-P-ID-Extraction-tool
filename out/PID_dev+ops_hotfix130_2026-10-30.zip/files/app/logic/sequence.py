"""L32 — 순차 동작 시뮬레이션: START · STOP · RUN · OPEN · CLOSE · TRIP 한 동작을 조건부터 차례로.

두 가지를 낸다.
  * commands(sheets) — 묶음의 출력 행 가운데 동작 행(`… MOV 1 OP CMD` · `START COMMAND` · `… OP REQ` · `RUNNING`)을
    장비마다 모은 목록.  장비 이름은 그 행 설명에서 동작 낱말 · 꼬리 낱말(CMD · REQ)을 뗀 나머지다 (지어내지 않는다).
    낱말은 config/logic_sequence.yaml (계장 영어 · 약어) — 코드에 낱말 목록을 두지 않는다.
  * plan(sheets, page, row) — 그 출력이 서려면 무엇이 필요한지 **조건 나무**.  범례 G003 정의를 거꾸로 읽는 길은
    시뮬레이터가 쓰는 것과 같다 (`sim._back_options` — AND 는 모두 · OR 는 하나 · NOT 은 반대 · 메모리 Q=1 은 SET 하나 +
    RESET 0 · 타이머는 유지 · 매크로는 그 Typical 시트의 입력 단자).  고르지 않는다 — OR 는 '하나를 고르세요' 로 남긴다.
    다른 시트에서 오는 입력 행은 그 자리에 `ref`(시트 · 행)를 달아 두고, 사람이 '그 시트 조건부터' 를 고르면 같은 함수로
    그 시트의 나무를 만든다 (묶음 전체를 한 번에 펼치면 846쪽에서 나무가 폭발한다).
    from-to 가 어긋난 입력 행에는 `ft` 를 달아 화면이 그 단계에서 '어떻게 할지' 를 묻는다.

판정 0줄 — 나무는 묻는 순서일 뿐이고, 답은 화면이 강제 신호로 주며 결과는 늘 같은 시뮬레이터가 낸다.
"""
from __future__ import annotations

import re

from . import macro as _MC
from functools import lru_cache
from pathlib import Path

import yaml

from . import sim

ALIGN_TRIES = 48        # L50 — 권하는 갈래가 안 설 때 시뮬레이터 조합을 찾는 상한 (scenario limit · 한 번 0.1~0.3초)
NODE_LIMIT = 700        # 한 시트 나무의 마디 상한 — 넘으면 그 아래는 '더 깊다' 로 남긴다 (화면이 그 선을 직접 묻는다)
DEPTH_LIMIT = 160       # L50 — 여러 장에 걸친 매크로(PS3 · 4장) 안쪽 조건이 90 을 넘겼다 (실측 최대 54 단계 · 시간 같음)


@lru_cache(maxsize=1)
def vocab():
    p = Path(__file__).resolve().parent.parent.parent / "config" / "logic_sequence.yaml"
    try:
        from app import paths
        p2 = paths.resource("config", "logic_sequence.yaml")
        if p2.exists():
            p = p2
    except Exception:
        pass
    v = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    word_act = {}
    for act, ws in (v.get("actions") or {}).items():
        for w in ws or []:
            word_act[str(w).upper()] = act
    kinds = {}
    for k, ws in (v.get("kinds") or {}).items():
        for w in ws or []:
            kinds[str(w).upper()] = k
    return {"act": word_act, "kind": kinds, "exclude": {str(x).upper() for x in v.get("exclude") or []},
            "status": {str(x).upper() for x in v.get("status_words") or []},
            "negation": {str(x).upper() for x in v.get("negation") or []},
            "order": list((v.get("actions") or {}).keys()),
            "opposites": [tuple(x) for x in v.get("opposites") or [] if isinstance(x, (list, tuple)) and len(x) == 2]}


def _words(t):
    return re.findall(r"[A-Z0-9][A-Z0-9#&./()\-]*", (t or "").upper())


def classify(desc):
    """행 설명 → (동작, 종류, 장비 이름) | None.  동작 낱말이 하나뿐일 때만 (`OPEN/CLOSE` 처럼 둘이면 고르지 않는다)."""
    V = vocab()
    ws = _words(desc)
    if not ws or any(w.strip("()") in V["exclude"] for w in ws):
        return None
    acts = [(i, V["act"][w]) for i, w in enumerate(ws) if w in V["act"]]
    if len({a for _, a in acts}) != 1:
        return None
    act = acts[0][1]
    # L35 — `NO TRIP` · `NOT OPEN` 은 그 동작이 아니라 '그 동작이 없음' 이라는 상태다 (1A1Y `#11 HRSG NO TRIP`: 트립 조건이
    # 하나라도 들어오면 꺼지는 건강 신호 — 동작 학습이 그렇게 읽었다)
    if any(i > 0 and ws[i - 1] in V["negation"] for i, _ in acts):
        return None
    kind = next((V["kind"][w] for w in ws if w in V["kind"]), None)
    if kind is None:
        kind = "state" if any(w in V["status"] for w in ws) else "action"
    drop = {i for i, _ in acts} | {i for i, w in enumerate(ws) if w in V["kind"]}
    equip = " ".join(w for i, w in enumerate(ws) if i not in drop).strip(" -/")
    return act, kind, equip


KIND_RANK = {"command": 0, "request": 1, "action": 2, "state": 3}


def commands(sheets):
    """묶음의 동작 행을 장비마다.  Typical 시트(매크로 안쪽)는 뺀다 — 그 행은 어느 장비의 것도 아니다."""
    typical = {(b.get("macro") or {}).get("page") for s in sheets for b in s["blocks"].values() if b.get("func") == "MACRO"}
    typical |= {pg for s in sheets for b in s["blocks"].values() if b.get("func") == "MACRO" for pg in ((b.get("macro") or {}).get("parts") or [])}
    eq = {}
    for s in sheets:
        if s["page"] in typical or s.get("library"):
            continue
        for r in s["rows"]:
            if r["side"] != "R" or r.get("net") is None or not r.get("desc"):
                continue
            c = classify(r["desc"])
            if not c:
                continue
            act, kind, name = c
            name = name or (s.get("title") or s.get("sheet_no") or "")
            key = re.sub(r"[^A-Z0-9]", "", name.upper())
            if not key:
                continue
            e = eq.setdefault(key, {"equip": name, "titles": [], "actions": {}})
            t = s.get("title") or ""
            if t and t not in e["titles"]:
                e["titles"].append(t)
            e["actions"].setdefault(act, []).append({"page": s["page"], "sheet": s.get("sheet_no"), "row": r["n"],
                                                      "desc": r["desc"], "kind": kind, "title": t})
    order = vocab()["order"]
    out = []
    for e in eq.values():
        acts = []
        for a in order:
            items = e["actions"].get(a)
            if items:
                own = lambda x: 0 if re.sub(r"[^A-Z0-9]", "", e["equip"].upper()) in re.sub(
                    r"[^A-Z0-9]", "", (x.get("title") or "").upper()) else 1
                items.sort(key=lambda x: (KIND_RANK.get(x["kind"], 9), own(x), str(x["sheet"]), x["row"]))
                acts.append({"action": a, "rows": items})
        out.append({"equip": e["equip"], "titles": e["titles"][:3], "actions": acts})
    out.sort(key=lambda e: e["equip"])
    return out


def outputs(sheets, q="", limit=60):
    """L70 — 출력 행(오른쪽 표) 아무것이나 찾기 — 동작 낱말이 없는 출력(OUTPUT · 허가 · 알림 …)도 거슬러 올라가 볼 수 있게.
    q 의 낱말이 모두 설명 · 시트 이름 · TO 에 들어 있는 행만.  Typical 시트(매크로 안쪽)는 뒤로 · 설명 없는 행은 뺀다."""
    typical = {(b.get("macro") or {}).get("page") for s in sheets for b in s["blocks"].values() if b.get("func") == "MACRO"}
    words = [w for w in re.split(r"\s+", (q or "").upper().strip()) if w]
    out, total = [], 0
    for s in sheets:
        if s.get("library"):
            continue
        for r in s["rows"]:
            if r["side"] != "R" or r.get("net") is None or not r.get("desc"):
                continue
            hay = " ".join(str(x or "") for x in (r.get("desc"), s.get("sheet_no"), r.get("to"), r.get("kks"))).upper()
            toks = set(_words(hay))
            # 한두 글자 낱말(A · B · #1)은 낱말 통째로 — 'A' 가 SPRAY 의 A 에 맞지 않게
            if words and not all((w in toks) if len(w) <= 2 else (w in hay) for w in words):
                continue
            total += 1
            c = classify(r["desc"])
            out.append({"page": s["page"], "sheet": s.get("sheet_no"), "row": r["n"], "desc": r["desc"], "to": r.get("to") or "",
                        "title": s.get("title") or "", "typical": s["page"] in typical, "action": c[0] if c else None})
    out.sort(key=lambda x: (x["typical"], x["action"] is None, str(x["sheet"]), x["row"]))
    return {"items": out[:limit], "total": total}


VOTE_KO = {"ge": "{a}개 이상", "gt": "{a}개보다 많이", "le": "{a}개 이하", "lt": "{a}개 미만", "eq": "정확히 {a}개", "ne": "{a}개가 아닐 때"}
GATE_KO = {"and": "AND — 모두 만족", "nand": "NAND", "or": "OR — 하나만 만족하면 됨", "nor": "NOR", "not": "NOT — 반대",
           "memory": "메모리(래치)", "delay_on": "켜짐 지연", "delay_off": "꺼짐 지연", "pulse": "펄스",
           "step": "STEP", "connector": "연결 기호"}


def _row(s, side, n):
    return next((r for r in s["rows"] if r["side"] == side and r["n"] == n), None)


def plan(sheets, page, row, value=1, timers=None, cache=None):
    """그 시트 그 출력 행이 value 가 되기 위한 조건 나무.

    매크로 상자(MOV · SOV · MOTOR 블록)의 출력은 그 Typical 시트 안의 조건으로 들어가 읽는다 — Typical 의 입력 행은
    상자 입력 단자로 이어져 다시 이 시트의 조건이 되고, Typical 안 누름단추는 펼친 이름(`상자/블록`)으로 강제한다
    (묶음 시뮬레이션이 매크로를 그 이름으로 펼쳐 돌린다 — sim._bundle_run inlined)."""
    by_page = {s["page"]: s for s in sheets}
    s = by_page.get(page)
    if s is None:
        return {"ok": False, "why": "그 쪽은 Logic 표 시트가 아닙니다"}
    r = _row(s, "R", row)
    if r is None or r.get("net") is None:
        return {"ok": False, "why": f"{s.get('sheet_no')} {row}행에 읽힌 출력 선이 없습니다"}
    return _plan_net(sheets, page, r["net"], value, timers, {"row": row, "desc": r.get("desc"), "cache": cache})


def _plan_net(sheets, page, net, value=1, timers=None, meta=None):
    """그 시트의 선(net)이 value 가 되기 위한 조건 나무 — plan(출력 행) 과 needs(게이트 · 매크로 출력) 가 같이 쓴다 (L49)."""
    by_page = {s["page"]: s for s in sheets}
    s = by_page.get(page)
    if s is None:
        return {"ok": False, "why": "그 쪽은 Logic 표 시트가 아닙니다"}
    known = {str(k) for k in (s.get("order") or {})} | {str(k) for k in (s.get("nets") or {})}
    if net is None or (known and str(net) not in known):
        return {"ok": False, "why": f"{s.get('sheet_no')} 에 그 선이 없습니다"}
    meta = meta or {}
    row = meta.get("row")
    seq = [0]
    count = [0]
    zero_mode = [False]
    inverted = [False]
    timers = timers or {}
    top = {"s": s, "idx": sim._index(s), "prefix": "", "rowmap": None, "parent": None, "macro": None}
    ctx = {"by_page": by_page}

    def nid():
        seq[0] += 1
        return f"n{page}_{seq[0]}"

    def base(kind, want, text, **kw):
        return {"t": "leaf", "id": nid(), "page": page, "kind": kind, "want": int(want), "text": text, **kw}

    def leaf_of(C, k, w, depth, path):
        sc = C["s"]
        if k.startswith("row:"):
            n = int(k[4:])
            rr = _row(sc, "L", n) or {}
            if C["rowmap"] is not None:
                # Typical 의 입력 행 — 상자의 그 입력 단자 선으로 나가 이 시트의 조건이 된다
                pnet = C["rowmap"].get(n)
                if pnet is None:
                    # 상자에 이 입력의 단자가 없다(그리지 않았거나 못 읽음) — 펼친 매크로 안에서 그 Typical 행의 선은 몰이가
                    # 없는 선이라 직접 답할 수 있다 (L33).  지어낸 연결이 아니라 '사람이 답한 값' 으로 남는다.
                    if rr.get("net") is not None:
                        key = "net:" + C["prefix"] + str(rr["net"])
                        # L50 — 그 Typical 행의 선이 출력 행과 한 선이면(RUNNING STATUS 입력 = RUN FEED BACK 출력) 펼친 장에서는
                        # 그 선이 상자 출력 단자 선으로 이름이 바뀐다 — 안쪽 이름으로 주면 아무것도 안 바뀐다 (실측 HRSG G063)
                        mb = (C["parent"]["s"]["blocks"].get(C["macro"].split("/")[-1]) or {}) if C.get("parent") else {}
                        for o in (mb.get("macro") or {}).get("outputs") or []:
                            orow = _row(sc, "R", o.get("row")) if o.get("row") is not None else None
                            if orow and orow.get("net") == rr["net"] and o.get("net") is not None:
                                key = "net:" + C["parent"]["prefix"] + str(o["net"])
                                break
                        return base("terminal", w, f"매크로 입력 '{rr.get('desc') or n}' — 상자에 이 단자가 없습니다 (직접 답함)",
                                    key=key, block=C["macro"],
                                    at=(top["s"]["blocks"].get(C["macro"].split("/")[0]) or {}).get("at"))
                    return base("stuck", w, f"매크로 입력 '{rr.get('desc') or n}' 에 닿는 상자 단자를 읽지 못했습니다",
                                block=C["macro"], at=(C["parent"]["s"]["blocks"].get(C["macro"]) or {}).get("at"))
                sub = expand(C["parent"], ("net", pnet, int(w)), depth + 1, path)
                return {"t": "all", "id": nid(), "page": page, "kids": [sub],
                        "via": {"text": f"매크로 입력 {rr.get('desc') or n}", "want": int(w)}}
            node = base("row", w, rr.get("desc") or f"{n}행", key=k, n=n, fm=rr.get("fm") or "", at=rr.get("at"),
                        kks=rr.get("kks") or "")
            ref = rr.get("ref")
            if ref:
                node["ref"] = {"sheet": ref.get("sheet"), "row": ref.get("src_row") or ref.get("row"),
                               "page": ref.get("page"), "other": bool(ref.get("other_bundle"))}
            ft = rr.get("ft")
            if ft and ft.get("ok") is False:
                node["ft"] = {"why": ft.get("why") or [], "peer": ft.get("peer")}
            elif ref and not ref.get("other_bundle") and ref.get("page") is None:
                node["ft"] = {"why": [f"묶음에 {ref.get('sheet')} 장이 없습니다"], "peer": f"{ref.get('sheet')}-{ref.get('row')}"}
            return node
        if k.startswith("block:"):
            bid = k[6:]
            b = sc["blocks"].get(bid, {})
            at = b.get("at") if not C["prefix"] else (top["s"]["blocks"].get(C["macro"]) or {}).get("at")
            lab = b.get("label") or b.get("func") or bid
            func = (b.get("func") or "").upper()
            kind = "button"
            if "MONITOR" in func:
                kind = "monitor"
                lab = f"감시 블록 {lab} — 아날로그 값이 설정값을 넘으면 1"
            elif "PUSH" in func or "P/B" in func:
                lab = f"누름단추 {lab}"
            elif func:
                lab = f"{lab} ({b.get('func')})" if lab != b.get("func") else lab
            if C["prefix"]:
                lab = f"{lab} (매크로 {C['macro']} 안쪽)"
            return base(kind, w, lab, key="block:" + C["prefix"] + bid, block=C["prefix"] + bid, at=at, func=b.get("func"))
        net = k[4:]
        if C["prefix"] or "/" in net:
            return base("held", w, f"매크로 안쪽 선 — 몰이를 도면에서 읽지 못했습니다 (매크로 {C['macro'] or ''} 의 Typical)",
                        key="net:" + C["prefix"] + net)
        return base("net", w, "도면에서 몰이를 읽지 못한 선", key=k, net=net)

    def gate_label(C, x):
        b = C["s"]["blocks"].get(x, {})
        lg = b.get("logic")
        lab = GATE_KO.get(lg) or (b.get("func") or "블록")
        if lg in ("delay_on", "delay_off", "pulse"):
            t = sim.timer_seconds(b, (timers.get(str(page)) or {}).get(C["prefix"] + x))
            lab = f"{lab} {t:g}초"
        vote = sim._vote_of(b)
        if vote:
            lab = f"투표 {vote[0]}/{vote[1]} — {VOTE_KO.get(sim._vote_op(b), '{a}개 이상').format(a=vote[0])}"
        if C["prefix"]:
            lab += " (매크로 안쪽)"
        return lab, b

    def macro_node(C, x, want, onet, depth, path):
        b = C["s"]["blocks"][x]
        m = b.get("macro") or {}
        ts = _MC.body(by_page, m)                       # L38 — 여러 장 매크로는 합친 본문
        out = next((o for o in m.get("outputs", []) if o.get("net") == onet and o.get("row") is not None), None)
        direct = "net:" + C["prefix"] + str(onet)      # 매크로 안을 못 읽으면 그 출력 단자 선에 직접 답한다 (몰이가 없는 선)
        if ts is None or out is None:
            return base("stuck", want, "이 매크로 출력의 Typical 시트를 잇지 못했습니다 — 매크로 출력에 직접 답합니다",
                        block=C["prefix"] + x, at=b.get("at"), key=direct)
        rowmap = {i["row"]: i["net"] for i in m.get("inputs", []) if i.get("row") is not None and i.get("net") is not None}
        tr = _row(ts, "R", out["row"])
        if tr is None or tr.get("net") is None:
            return base("stuck", want, f"Typical {m.get('sheet')} {out['row']}행에 출력 선이 없습니다 — 매크로 출력에 직접 답합니다",
                        block=C["prefix"] + x, at=b.get("at"), key=direct)
        IC = {"s": ts, "idx": sim._index(ts), "prefix": C["prefix"] + x + "/", "rowmap": rowmap, "parent": C, "macro": x}
        inner = expand(IC, ("net", tr["net"], int(want)), depth + 1, path)
        return {"t": "all", "id": nid(), "page": page, "kids": [inner],
                "gate": {"block": C["prefix"] + x, "label": f"매크로 {m.get('title') or ''} — Typical {m.get('sheet') or '?'} "
                         f"'{out.get('desc') or out.get('pin')}' 의 조건", "func": "MACRO", "logic": None,
                         "at": b.get("at") if not C["prefix"] else None, "want": int(want)}}

    memo = {}

    def expand(C, goal, depth, path):
        # 같은 선 · 같은 값은 나무의 다른 자리에 또 나와도 한 마디다 (같은 id — 한 번 답하면 그 자리 모두 답한 것).
        # 메모리 · OR 가 같은 조건을 여러 갈래에서 다시 부르는 Typical 에서 나무가 폭발하지 않게.
        if goal[0] == "net":
            mk = (C["prefix"], goal[1], int(goal[2]), zero_mode[0])
            if mk in memo:
                return memo[mk]
            node = _expand(C, goal, depth, path)
            memo[mk] = node
            return node
        return _expand(C, goal, depth, path)

    def _expand(C, goal, depth, path):
        count[0] += 1
        want = int(goal[2])
        if count[0] > NODE_LIMIT or depth > DEPTH_LIMIT:
            return base("deep", want, "조건이 너무 깊습니다 — 여기부터는 도면에서 확인")
        if goal[0] == "net":
            key = (C["prefix"], goal[1], want)
            if key in path:
                return base("loop", want, "되먹임 — 앞 단계에서 정해집니다", auto=True)
            path = path | {key}
            if want == 0 and not zero_mode[0] and not sim._inverting(C["s"], C["idx"], goal[1]):
                # 0 이어야 하는 자리 (고장 없음 · 트립 없음 · 반대 명령 없음) — 아무것도 주지 않으면 0 이다.
                # 하나씩 묻지 않고 '이 신호들이 없어야 합니다' 한 단계로 접는다 (시뮬레이터 _solutions 와 같은 생각)
                zero_mode[0] = True
                inverted[0] = False
                try:
                    sub = expand(C, goal, depth, path - {key})
                finally:
                    zero_mode[0] = False
                if inverted[0]:
                    # 그 아래에 NOT · NOR · NAND 가 있으면 '아무것도 주지 않으면 0' 이 아니다 — 접지 않고 하나씩 묻는다
                    return sub
                items, seen_k = [], set()
                for lf in _first_leaves(sub):
                    if lf.get("key") and lf.get("kind") in ("row", "button", "monitor", "net", "terminal") and lf["key"] not in seen_k:
                        seen_k.add(lf["key"])
                        items.append({k: lf.get(k) for k in ("key", "text", "want", "at", "fm", "ref", "ft", "n", "block")})
                return base("zero", 0, "이 신호들이 없어야 합니다 (아무것도 주지 않으면 0)", items=items, auto=not items,
                            net="net:" + C["prefix"] + goal[1])
        gate = goal[1][1] if goal[0] == "drv" and goal[1][0] == "block" else None
        if gate and zero_mode[0]:
            gl = C["s"]["blocks"].get(gate, {}).get("logic")
            if gl in ("not", "nor", "nand") or (gl == "memory" and goal[1][2] == "qn"):
                inverted[0] = True
        if gate and C["s"]["blocks"].get(gate, {}).get("func") == "MACRO":
            if want == 0:
                return base("default0", 0, "아무것도 주지 않으면 0 입니다", auto=True)
            return macro_node(C, gate, want, goal[3], depth, path)
        if gate and want == 0 and C["s"]["blocks"].get(gate, {}).get("logic") == "pulse":
            # L50 — 펄스는 가만히 있으면 0 이다 (오르는 변에서만 잠깐 1).  '펄스 = 0' 을 입력 = 0 으로 거꾸로 풀면
            # 그 입력(예: NOT STOPPED)을 0 으로 요구해 앞 단계가 1 로 켠 신호와 어긋났다 (HRSG G009 STOP CMD).
            return base("default0", 0, "펄스 — 가만히 있으면 0 입니다", auto=True)
        try:
            opts = sim._back_options(C["s"], C["idx"], goal, True, {**ctx, "rows_only": False})
        except Exception:
            opts = []
        if not opts:
            onet = goal[1] if goal[0] == "net" else goal[3]
            gb = C["s"]["blocks"].get(gate, {}) if gate else {}
            short_gate = gb.get("logic") in sim.MIN_INPUTS or bool(sim._vote_of(gb))
            judged = bool(gate) and gb.get("logic") not in (None, "", "unknown")
            an = _analog_text(gb) if gate else None
            what = (f"{GATE_KO.get(gb.get('logic')) or gb.get('func') or '게이트'} 의 입력선을 도면에서 다 읽지 못했습니다"
                    if short_gate else an if an
                    else _missing_inputs_text(C["s"], gate, gb)
                    if judged else f"판정 못 한 블록 '{gb.get('label') or gb.get('func') or '?'}' 이 이 값을 냅니다"
                    if gate else "이 값을 내는 조건을 범례 정의로 찾지 못했습니다")
            # 짧은 게이트는 'hold:' — 읽힌 입력이 출력을 정하면 게이트가 이긴다 (sim L32) · 판정 못 한 블록은 그 선을 직접
            n = base("stuck", want, what, key=("hold:" if short_gate else "net:") + C["prefix"] + str(onet))
            if gate:
                n["block"] = C["prefix"] + gate
                n["at"] = C["s"]["blocks"].get(gate, {}).get("at") if not C["prefix"] else None
            return n
        kids = []
        for add, sub in opts:
            parts = [leaf_of(C, k, w, depth, path) for k, w in add.items()]
            parts += [expand(C, g, depth + 1, path) for g in sub]
            if not parts:
                continue
            kids.append(parts[0] if len(parts) == 1 else {"t": "all", "id": nid(), "page": page, "kids": _order(parts)})
        if not kids:
            node = base("const", want, "언제나 만족 (조건 없음)", auto=True)
        elif len(kids) == 1:
            node = kids[0]
        elif want == 0 and all(_all_want0(k) for k in kids):
            # 0 이 되면 되는 자리 (AND=0 — 하나만 0) — 아무것도 주지 않으면 대개 0 이다.  묻지 않는다.
            node = base("default0", 0, "아무것도 주지 않으면 0 입니다", auto=True)
        else:
            node = {"t": "any", "id": nid(), "page": page, "kids": kids}
        if gate and C["s"]["blocks"].get(gate, {}).get("logic") != "source":
            lab, b = gate_label(C, gate)
            wrap = node if node["t"] != "leaf" and "gate" not in node else {"t": "all", "id": nid(), "page": page, "kids": [node]}
            wrap["gate"] = {"block": C["prefix"] + gate, "label": lab, "func": b.get("func"), "logic": b.get("logic"),
                            "at": b.get("at") if not C["prefix"] else None, "want": want}
            node = wrap
        return node

    tree = expand(top, ("net", net, int(value)), 0, frozenset())
    _finish(tree)
    _resolve_picks(tree)
    tested = _align_picks(tree, sheets, s, net, int(value), timers, (meta or {}).get("cache")) if (meta or {}).get("align", True) else None
    flat = {}

    def flatten(n):
        if n["id"] in flat:
            return n["id"]
        d = {k: v for k, v in n.items() if k != "kids"}
        flat[n["id"]] = d
        if "kids" in n:
            d["kids"] = [flatten(k) for k in n["kids"]]
        return n["id"]
    root = flatten(tree)
    # 같은 마디가 여러 자리에 나오므로 나무를 펼쳐 보내지 않고 마디 표 + id 로 보낸다 (화면이 다시 잇는다)
    return {"ok": True, "page": page, "sheet": s.get("sheet_no"), "row": row, "desc": meta.get("desc"), "net": net,
            "value": int(value), "title": s.get("title"), "root": root, "nodes": flat, "size": count[0],
            "truncated": count[0] > NODE_LIMIT, "signals": dict(_signals(tree), tested=tested)}


def _analog_text(gb):
    """L50 — 아날로그 연산자 · 감시 블록은 '판정 못 한 블록' 이 아니다 — 값(mA · 설정값)으로 정해지는 자리라 그렇게 말한다."""
    from . import analog
    label = " ".join(str(gb.get("label") or gb.get("func") or "?").split())[:24]
    if analog.monitor_kind(gb):
        return f"감시 블록 '{label}' — 입력 값(mA)과 설정값으로 정해집니다 (아날로그 입력에 값을 주세요)"
    if gb.get("aop") or analog.is_analog_block(gb):
        return f"아날로그 연산 '{label}' — 연산자 판에서 입력 값을 넣으면 정해집니다"
    return None


def _missing_inputs_text(s, gate, gb):
    """L50 — 판정은 됐는데(메모리 · 타이머 · STEP …) 들어오는 선을 못 읽어 조건을 세울 수 없는 블록.
    '판정 못 한 블록' 과 가른다 — 고칠 자리가 다르다 (종류 정하기 ↔ 마크업으로 선 잇기)."""
    label = GATE_KO.get(gb.get("logic")) or gb.get("label") or gb.get("func") or "블록"
    ins = {str(pt.get("role") or "") for pt in s.get("ports") or [] if pt.get("block") == gate and pt.get("dir") == "in"}
    if gb.get("logic") == "memory":
        miss = [r for r in ("set", "reset") if r not in ins]
        if miss:
            return f"{label} 의 {' · '.join(x.upper() for x in miss)} 입력선을 도면에서 읽지 못했습니다"
    if not ins:
        return f"{label} 의 입력선을 도면에서 읽지 못했습니다"
    return f"{label} 의 입력 조건을 범례 정의로 찾지 못했습니다"


def link(p):
    """마디 표 → 나무 (같은 id 는 같은 객체).  시험 · 도구용."""
    if not p.get("ok"):
        return None
    N = {k: dict(v) for k, v in p["nodes"].items()}
    for v in N.values():
        if "kids" in v:
            v["kids"] = [N[i] for i in v["kids"]]
    return N[p["root"]]


ASK = ("row", "button", "monitor", "net", "held", "terminal", "stuck", "zero", "deep")


# ---------------------------------------------------------------- L49 — 게이트 · 매크로를 누르면: 이 출력이 켜지려면
def _signals(tree):
    """나무를 '권하는 갈래' 로 접어 한 줄 요약 — 꼭 필요한 신호(1) · 없어야 하는 신호(0) · 갈래 수 · 읽기 빈틈.
    화면이 나무를 그대로 그리고, 이 요약은 머리줄과 주황 점등에 쓴다 (판정 0줄)."""
    need, zero, gaps, seen = [], [], [], set()
    forks = [0]

    def walk(n):
        if n["t"] == "leaf":
            k = n.get("kind")
            if k == "zero":
                for it in n.get("items") or []:
                    if it.get("key") and it["key"] not in seen:
                        seen.add(it["key"]); zero.append(it)
            elif k in ("stuck", "deep", "held"):
                gaps.append({"text": n.get("text"), "block": n.get("block"), "at": n.get("at"), "key": n.get("key")})
            elif n.get("key") and not n.get("auto") and n["key"] not in seen:
                seen.add(n["key"])
                d = {x: n.get(x) for x in ("key", "text", "want", "at", "fm", "ref", "ft", "n", "block", "kind", "page", "kks")}
                m = re.match(r"([01]) \(", n.get("text") or "")
                if m and n.get("kind") == "button":
                    # 범례 FORCED INPUT `0`/`1` — 도면이 그 값으로 묶어 둔 자리 (L35 '상수로 묶인 길').  켤 수 없는 신호다
                    d["const"] = int(m.group(1))
                (need if n.get("want") == 1 else zero).append(d)
            return
        kids = n.get("kids") or []
        if n["t"] == "any":
            forks[0] += 1
            if n.get("conflict"):
                gaps.append({"text": "서로 어긋나는 조건 — 어느 갈래를 골라도 앞 조건과 반대 값을 요구합니다: " + " · ".join(str(x) for x in n["conflict"][:3]),
                             "block": (n.get("gate") or {}).get("block"), "at": (n.get("gate") or {}).get("at"), "key": None})
            kids = kids[n.get("pick", 0):n.get("pick", 0) + 1]
        for k in kids:
            walk(k)
    walk(tree)
    return {"need": need, "zero": zero, "gaps": gaps, "forks": forks[0], "asks": tree.get("asks", 0), "viable": tree.get("viable", False)}


def needs(sheets, page, target, value=1, timers=None, cache=None):
    """블록(게이트 · 매크로 · 신호원) 또는 선을 누르면 — 그 출력이 value 가 되려면 앞쪽 어떤 신호가 켜져야 하는지.

    target `block:<id>` 는 그 블록의 출력 선마다(매크로는 출력 단자마다) 나무 하나 · `net:<id>` 는 그 선 하나.
    나무는 plan 과 같은 길(_plan_net) 이라 순차 동작 · 동작 예시와 같은 조건을 말한다."""
    by_page = {s["page"]: s for s in sheets}
    s = by_page.get(page)
    if s is None:
        return {"ok": False, "why": "그 쪽은 Logic 표 시트가 아닙니다"}
    t = str(target or "")
    if t.startswith("net:"):
        net = t[4:]
        p = _plan_net(sheets, page, net, value, timers, {"cache": cache})
        return {"ok": p.get("ok", False), "why": p.get("why"), "kind": "net", "page": page, "sheet": s.get("sheet_no"),
                "label": "선 " + net, "value": int(value), "outputs": [{"net": net, "desc": "", "plan": p}] if p.get("ok") else []}
    if not t.startswith("block:"):
        return {"ok": False, "why": "target 은 block:<id> · net:<id> 입니다"}
    bid = t[6:]
    b = s["blocks"].get(bid)
    if b is None:
        return {"ok": False, "why": f"{s.get('sheet_no')} 에 블록 {bid} 가 없습니다"}
    outs = []
    if b.get("func") == "MACRO":
        m = b.get("macro") or {}
        for o in m.get("outputs") or []:
            if o.get("net") is None:
                outs.append({"pin": o.get("pin"), "desc": o.get("desc") or "", "row": o.get("row"), "net": None,
                             "plan": {"ok": False, "why": "이 출력 단자에 닿는 선을 도면에서 읽지 못했습니다"}})
                continue
            p = _plan_net(sheets, page, o["net"], value, timers, {"desc": o.get("desc") or o.get("pin"), "cache": cache})
            outs.append({"pin": o.get("pin"), "desc": o.get("desc") or "", "row": o.get("row"), "net": o["net"], "plan": p})
        kind, label = "macro", (m.get("title") or b.get("caption") or "매크로 블록")
        if not outs:
            return {"ok": False, "why": m.get("why") or "이 매크로의 출력 단자를 읽지 못했습니다", "kind": kind, "label": label}
    else:
        nets = []
        for pt in s.get("ports") or []:
            if pt.get("block") == bid and pt.get("dir") == "out" and pt.get("net") is not None and pt["net"] not in nets:
                nets.append(pt["net"])
        if not nets:
            return {"ok": False, "why": "이 블록에서 나가는 선을 도면에서 읽지 못했습니다", "kind": "gate",
                    "label": b.get("label") or b.get("func") or bid}
        for n in nets:
            # 이 선을 받는 자리 — 출력 행 · 다음 블록 (어디로 가는지 한 줄)
            to = [f"출력 {r['n']}행" + (f" · {r['desc']}" if r.get("desc") else "") for r in s["rows"] if r["side"] == "R" and r.get("net") == n]
            to += [_block_short(s["blocks"].get(pt["block"]) or {}, pt["block"])
                   for pt in s.get("ports") or [] if pt.get("net") == n and pt.get("dir") == "in" and pt.get("block") != bid]
            outs.append({"pin": None, "desc": " · ".join(x for x in to if x)[:120], "row": None, "net": n,
                         "plan": _plan_net(sheets, page, n, value, timers, {"cache": cache})})
        kind = "gate"
        lg = b.get("logic")
        label = GATE_KO.get(lg) or b.get("label") or b.get("func") or bid
        vote = sim._vote_of(b)
        if vote:
            label = f"투표 {vote[0]}/{vote[1]}"
    # L50 — 아무것도 주지 않은 상태(이 시트만 · 다른 시트 입력 0)에서 그 선이 지금 몇인가.  조건이 비어 있는데 이미
    # 그 값이면 "아무것도 주지 않아도 켜져 있다" 고 말할 수 있다 (NOT 앞의 AND 가 0 인 자리).  판정은 시뮬레이터 그대로
    now = _default_values(s, timers)
    for o in outs:
        v = now.get(str(o.get("net"))) if o.get("net") is not None else None
        o["now"] = int(v) if v in (0, 1, True, False) else None
        sg = (o.get("plan") or {}).get("signals")
        if sg is not None:
            sg["already"] = bool(o["now"] == int(value) and not sg.get("need") and not sg.get("zero") and not sg.get("gaps"))
    return {"ok": True, "kind": kind, "page": page, "sheet": s.get("sheet_no"), "block": bid, "label": label,
            "func": b.get("func"), "logic": b.get("logic"), "value": int(value), "outputs": outs}


def _block_short(b, bid):
    """다음 블록을 한 마디로 — 매크로는 제목 첫 줄, 글자가 길면 자른다 (어디로 가는지 한 줄에 여럿이 선다)."""
    if b.get("func") == "MACRO":
        x = ((b.get("macro") or {}).get("title") or b.get("caption") or b.get("label") or "매크로").split("\n")[0]
    else:
        x = b.get("label") or b.get("func") or bid
    x = " ".join(str(x).split())
    return x if len(x) <= 28 else x[:27] + "…"


def _default_values(s, timers):
    """이 시트만 · 아무 강제도 없이 한 번 돌린 마지막 틀의 선 값 (`{선: 0|1}`).  못 돌리면 빈 사전."""
    try:
        r = sim.simulate(s, {}, None, 0.0, timers or {})
        fr = (r.get("frames") or [{}])[-1]
        return {str(k): v for k, v in (fr.get("values") or {}).items()}
    except Exception:
        return {}


def _first_leaves(n):
    """나무의 잎 — ANY 는 첫 갈래만."""
    if n["t"] == "leaf":
        return [n]
    kids = n.get("kids") or []
    if n["t"] == "any":
        kids = kids[:1]
    return [x for k in kids for x in _first_leaves(k)]


def _finish(n):
    """마디마다 — 갈 수 있는가(viable: 범례로 찾지 못한 자리가 꼭 거쳐야 하는 길에 없음) · 묻는 수 · 한 줄 요약 ·
    ANY 의 권하는 갈래 (갈 수 있는 것 중 묻는 수가 가장 적은 것)."""
    if n["t"] == "leaf":
        # 되먹임으로 1 을 바라는 자리는 처음 상태에서 서지 않는다 (래치가 이미 켜져 있을 때만) — 권하지 않는다
        n["viable"] = n.get("kind") not in ("stuck", "deep") and not (n.get("kind") == "loop" and n.get("want") == 1)
        n["asks"] = 0 if n.get("auto") else 1
        if n.get("kind") == "loop" and n.get("want") == 1:
            n["summary"] = ["되먹임 — 이미 켜져 있을 때만 (처음 상태에서는 서지 않음)"]
        else:
            n["summary"] = [] if n.get("auto") or n.get("kind") == "zero" else [n.get("text") or ""]
        return n
    for k in n["kids"]:
        _finish(k)
    if n["t"] == "all":
        n["viable"] = all(k["viable"] for k in n["kids"])
        n["asks"] = sum(k["asks"] for k in n["kids"])
        n["summary"] = [x for k in n["kids"] for x in k["summary"]][:4]
    else:
        ok = [i for i, k in enumerate(n["kids"]) if k["viable"]]
        pick = min(ok or range(len(n["kids"])), key=lambda i: n["kids"][i]["asks"])
        n["pick"] = pick
        n["viable"] = bool(ok)
        n["asks"] = 1 + n["kids"][pick]["asks"]
        n["summary"] = n["kids"][pick]["summary"]
    return n


def _picked_reqs(n, out):
    """권하는 갈래를 따라 잎이 요구하는 값 — {key: want} (없어야 하는 묶음의 항목은 0)."""
    if n["t"] == "leaf":
        if n.get("kind") == "zero":
            for it in n.get("items") or []:
                if it.get("key"):
                    out.setdefault(it["key"], 0)
        elif n.get("key") and not n.get("auto") and n.get("kind") not in ("stuck", "deep", "loop"):
            out.setdefault(n["key"], n.get("want"))
        return out
    kids = n.get("kids") or []
    if n["t"] == "any":
        kids = kids[n.get("pick", 0):n.get("pick", 0) + 1]
    for k in kids:
        _picked_reqs(k, out)
    return out


def _tree_forces(tree, page):
    """권하는 갈래의 요구를 묶음 시뮬레이터 강제 꼴로 — {쪽: {key: 0|1}} (읽기 빈틈 hold 는 1 로 · 매크로 안쪽 키는 그 장)."""
    out = {}

    def walk(n):
        if n["t"] == "leaf":
            pg = n.get("page", page)
            if n.get("kind") == "zero":
                for it in n.get("items") or []:
                    if it.get("key"):
                        out.setdefault(pg, {}).setdefault(it["key"], 0)
            elif n.get("key") and not n.get("auto") and n.get("kind") not in ("deep", "loop"):
                out.setdefault(pg, {}).setdefault(n["key"], 1 if n.get("kind") == "stuck" else n.get("want", 1))
            return
        kids = n.get("kids") or []
        if n["t"] == "any":
            kids = kids[n.get("pick", 0):n.get("pick", 0) + 1]
        for k in kids:
            walk(k)
    walk(tree)
    return out


def _align_picks(tree, sheets, s, net, value, timers, cache=None):
    """L50 — 권하는 갈래를 시뮬레이터가 실제로 찾은 조합에 맞춘다 (L32 '권장은 짐작이 아니라 시험' 을 나무 전체로).
    갈래를 하나씩만 시험하면 안쪽 갈래가 함께 바뀌어야 서는 조합(HRSG G049 MOV CLOSE = CLOSE 요청 + REM + …)을
    못 찾았다.  시뮬레이터의 조합(sim.scenario · L14)과 어긋나지 않는 갈래를 고르고, 고른 길을 한 번 앞으로 돌려
    목표가 서는지 적는다 (`tested`).  못 찾으면 갈래는 그대로이고 tested 는 0 — 지어내지 않는다."""
    page = s["page"]

    def picks(n, out):
        if n["t"] == "any":
            out[n["id"]] = (n.get("pick", 0), n.get("asks"), n.get("summary"))
        for k in n.get("kids") or []:
            picks(k, out)
        return out

    def restore(n, saved):
        if n["t"] == "any" and n["id"] in saved:
            n["pick"], n["asks"], n["summary"] = saved[n["id"]]
        for k in n.get("kids") or []:
            restore(k, saved)

    def test():
        try:
            f = _tree_forces(tree, page)
            if not f:
                return None
            r = sim.simulate_bundle(sheets, f, None, page, timers=timers or {}, cache=cache, light=True)["focus"] or {"frames": []}
            return int(any(fr["values"].get(str(net)) == value for fr in r["frames"]))
        except Exception:
            return None

    before = picks(tree, {})
    first = test()
    if first != 0:
        # 원래 길이 서거나(1) 시험할 것이 없으면(None) 시뮬레이터 조합을 찾지 않는다 — 블록마다 부르는 needs 가 느려진다
        return first
    try:
        sc = sim.scenario(s, "net:" + str(net), value, limit=ALIGN_TRIES, sheets=sheets, cache=cache)
    except Exception:
        sc = {"ok": False}
    forces = sc.get("forces") or {} if sc.get("ok") else {}
    if forces:
        def score(n):
            r = _picked_reqs(n, {})
            bad = sum(1 for k, w in r.items() if k in forces and forces[k] != w)
            # 시뮬레이터가 안 쓴 신호를 1 로 요구하는 갈래는 뒤로 — 그 조합에 없는 1 은 대개 다른 길을 막는다 (PROTECTION CLOSE)
            extra = sum(1 for k, w in r.items() if w == 1 and k not in forces)
            hit = sum(1 for k, w in r.items() if k in forces and forces[k] == w)
            return (bad, extra, -hit, n.get("asks", 0))

        def walk(n):
            if n["t"] == "leaf":
                return
            if n["t"] == "any":
                kids = n["kids"]
                best = min((i for i, k in enumerate(kids) if k.get("viable")), key=lambda i: score(kids[i]), default=None)
                if best is not None and score(kids[best])[0] == 0 and best != n.get("pick", 0):
                    n["pick"] = best
                    n["asks"] = 1 + kids[best]["asks"]
                    n["summary"] = kids[best]["summary"]
                walk(kids[n.get("pick", 0)])
                return
            for k in n["kids"]:
                walk(k)
        walk(tree)
        if picks(tree, {}) != before:
            got = test()
            if got == 1:
                return 1
            # 맞춘 길도 안 서면 원래 길로 되돌린다 (1A5J DRIVE-3 START 처럼 시뮬레이터 조합이 나무의 갈래와 다른 선을 쓸 때) — 지어내지 않는다
            restore(tree, before)
    return first


def _resolve_picks(tree):
    """L50 — 권하는 갈래끼리 서로 어긋나지 않게 한다.  `_finish` 는 갈래마다 묻는 수만 보고 골라, 앞에서 '1 이어야'
    한 신호를 뒤 갈래가 '0 이어야' 로 요구하는 일이 있었다 (HRSG G049 MOV REM — 안내가 1 로 켠 신호를 다시 0 으로
    묻고 최종 출력이 꺼졌다).  묻는 순서(앞에서 뒤로)대로 요구를 모으며, ANY 에서는 모인 요구와 어긋나지 않는
    갈래 중 묻는 수가 가장 적은 것을 고른다 — 전부 어긋나면 원래 갈래를 두고 `conflict` 를 적는다 (지어내지 않는다)."""
    req = {}

    def clash(n):
        r = _picked_reqs(n, {})
        return [k for k, w in r.items() if k in req and req[k] != w]

    def walk(n):
        if n["t"] == "leaf":
            _picked_reqs(n, req)
            return
        if n["t"] == "any":
            kids = n["kids"]
            cur = n.get("pick", 0)
            if clash(kids[cur]):
                ok = [i for i, k in enumerate(kids) if k.get("viable") and not clash(k)]
                if ok:
                    n["pick"] = min(ok, key=lambda i: kids[i]["asks"])
                    n["asks"] = 1 + kids[n["pick"]]["asks"]
                    n["summary"] = kids[n["pick"]]["summary"]
                else:
                    n["conflict"] = clash(kids[cur])
            walk(kids[n.get("pick", 0)])
            return
        for k in n["kids"]:
            walk(k)
    walk(tree)
    return tree


def _all_want0(n):
    if n["t"] == "leaf":
        return n.get("want") == 0
    return all(_all_want0(k) for k in n.get("kids") or [])


def _order(parts):
    """한 무리 안에서 묻는 순서 — 조건(1) · 다른 시트에서 오는 것 → 하위 조건 → 없어야 하는 것(0) → 누름단추(명령) 마지막."""
    def rank(n):
        if n["t"] != "leaf":
            return 1
        if n.get("kind") == "button":
            return 3
        if n.get("want") == 0:
            return 2
        return 0
    return sorted(parts, key=rank)


# ---------------------------------------------------------------- L37 — 안내: 이 신호를 켜면 무엇이 달라지나
EFFECT_MAX = 8


def _on(res, net):
    """그 선이 어느 틀에서든 1 이었나 (펄스도 센다) · 마지막 틀 값."""
    if not res or net is None:
        return False, 0
    vals = [fr["values"].get(net) for fr in res["frames"]]
    return 1 in vals, 1 if vals and vals[-1] == 1 else 0


def effect(sheets, page, net, want, forces, add, timers=None, gate=None, cache=None):
    """지금까지의 답(forces)에 이 신호(add)를 더하면 — 같은 묶음 시뮬레이터로 앞뒤를 돌려 차이만 낸다 (판정 0줄).

    → {"target": {"before", "after", "steady"}, "gate": {입력 수 · 1 인 입력 수 앞뒤 · 출력 앞뒤} | None,
       "gained": [새로 1 이 된 출력 행 (목표 먼저)], "linked": [다른 시트로 넘어가 1 이 된 입력 행], "nets": 이 장에서 새로 1 인 선 수}"""
    cache = {} if cache is None else cache
    by_page = {s["page"]: s for s in sheets}

    def run(f):
        sim.simulate_bundle(sheets, f, None, page, timers=timers, cache=cache, light=True)
        return cache.pop("_last_results", None) or {}

    after_f = {p: dict(v) for p, v in forces.items()}
    for p, v in add.items():
        after_f.setdefault(p, {}).update(v)
    rb, ra = run(forces), run(after_f)
    tb, ta = _on(rb.get(page), net), _on(ra.get(page), net)
    out = {"target": {"before": int(tb[0]) if want == 1 else tb[1], "after": int(ta[0]) if want == 1 else ta[1],
                      "steady": ta[1] == want}}
    gained, linked, nets = [], [], 0
    for p, s in sorted(by_page.items()):
        a, b = ra.get(p), rb.get(p)
        if a is None:
            continue
        for side in ("R", "L"):
            for r in s["rows"]:
                if r["side"] != side or r.get("net") is None:
                    continue
                k = f"row:{r['n']}"
                if side == "L" and k in after_f.get(p, {}):
                    continue                       # 사람이 준 입력은 '넘어간 신호' 가 아니다
                if _on(a, r["net"])[0] and not _on(b, r["net"])[0]:
                    lab = dict(sim._row_label(s, side, r["n"]), page=p, sheet=s.get("sheet_no") or f"p{p}")
                    (gained if side == "R" else linked).append(lab)
        if p == page:
            va = a["frames"][-1]["values"] if a["frames"] else {}
            vb = (b["frames"][-1]["values"] if b and b["frames"] else {})
            nets = sum(1 for k, v in va.items() if v == 1 and vb.get(k) != 1)
    gained.sort(key=lambda x: (not (x["page"] == page and _row_net(by_page[page], x["row"]) == net), x["page"], x["row"]))
    out["gained"], out["linked"], out["nets"] = gained[:EFFECT_MAX], linked[:EFFECT_MAX], nets
    out["more"] = max(0, len(gained) - EFFECT_MAX) + max(0, len(linked) - EFFECT_MAX)
    if gate and gate.get("block") and "/" not in str(gate["block"]) and gate.get("page") in by_page:
        gs, bid = by_page[gate["page"]], str(gate["block"])
        ins = [p_["net"] for p_ in gs["ports"] if p_.get("block") == bid and p_.get("dir") == "in" and p_.get("net") is not None]
        outs = [p_["net"] for p_ in gs["ports"] if p_.get("block") == bid and p_.get("dir") == "out" and p_.get("net") is not None]
        a, b = ra.get(gate["page"]), rb.get(gate["page"])
        if ins and a is not None:
            out["gate"] = {"inputs": len(ins),
                           "on_before": sum(1 for x in ins if _on(b, x)[1]), "on_after": sum(1 for x in ins if _on(a, x)[1]),
                           "out_before": max([_on(b, x)[1] for x in outs] or [0]),
                           "out_after": max([_on(a, x)[1] for x in outs] or [0])}
    return out


def _row_net(s, n):
    r = _row(s, "R", n)
    return r.get("net") if r else None
