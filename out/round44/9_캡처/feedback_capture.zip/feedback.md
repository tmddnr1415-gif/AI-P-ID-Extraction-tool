# 피드백 — UIDB (2026-09-14T01:40:57+00:00)

* 분석 `uidb8f30b41ea57f` · 지문 `fb85b039` · 행 1038 · 리비전 A
* 작성자: 캡처
* 종류: false_positive 1 · missing 1

| # | 종류 | 장 | P&ID No. | Type | 내용 | 작성자 | 조각 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | false_positive | p6 | D00P-10LBA10-M05-0001 | FIT | ㉢ 오검출 — 행이 있는데 도면에 없음 · Excel 유지 · 캡처용 오검출 표시 | 캡처 검증 | 조각/001_p6_false_positive.png |
| 2 | missing | p6 | D00P-10LBA10-M05-0001 | PIT | 누락 추가 — scope (빈칸) (USER) · qty 2 (DRAWING) · 캡처용 마크업 | 캡처 검증 | 조각/002_p6_missing.png |
