# 계장ENG그룹 주간업무 Dashboard — 구조 안내 (다른 Claude Code 작업자용)

이 문서는 이 프로그램을 처음 보는 Claude Code 가 구조를 파악하고, **별도로 개발한 프로그램을 메뉴(입찰 프로젝트 / 실행 프로젝트 등)에 연결**할 수 있도록 정리한 것이다.
기준 버전: 화면 `APP_VERSION 2026-10-09.3`, 서버 `SERVER_VERSION 2026-10-09.2` (2026-10-09).
- 메뉴 권한: 사이드바 MENU 옆 ⚙(운영자=서버 PC localhost 만 표시) → 사용자·비회원 × 메뉴(weekly/pid/bidpjt/runpjt/board/mgmt) 체크. 기본 전부 허용, **Management(mgmt) 만 기본 비허용**. 저장: `accounts/_perms.json`, API: GET/PUT `admin/perms`(운영자만), 각 계정 권한은 `info.perms`·`auth/ping.perms` 로 전달(30초 안에 반영). 서버는 쓰기 API 에서 메뉴 권한도 확인(주간업무보고 쓰기=weekly, 게시판 쓰기=board → 403).
- 주간업무보고 하위 시트 `issue`(프로젝트 이슈사항): 사업군/PJT명/담당자/이슈사항/첨부파일/종결현황/Remark/AI 요약. 첨부파일은 PUT `files?name=`(pdf·ppt·pptx, 30MB, 로그인+weekly) → `files/{fid}.{ext}`+`files/{fid}.json`, 칸 값은 줄마다 `파일명 [fid]`, GET `files/{fid}` 로 열기. AI 요약은 현재 화면 안의 문장 추출 방식(`issueSummary`, 외부 전송 없음).
- 서버는 요청 본문을 읽지 않고 응답해도 남은 본문을 비움(keep-alive 연결 깨짐 방지, `dispatch`).
현재 위치: `C:\Claude\계장ENG그룹 주간업무 Dashboard\` (코드와 운영 데이터가 같은 폴더. 2장의 Desktop 경로는 옛 구조). 수정 전 백업은 이 폴더의 `backup\파일명_YYYYMMDD_HHMM.*`.

---

## 1. 한눈에 보기

- 엑셀 "계장ENG그룹 주간 업무 보고"를 대체하는 부서 주간업무 입력·조회 웹 프로그램.
- **단일 HTML 파일(`dashboard.html`)** + **Python 표준 라이브러리만 쓰는 서버(`server.py`)**. 빌드 도구·npm·CDN·외부 라이브러리 없음.
- 데이터는 DB 없이 **JSON 파일**(행 1개 = 파일 1개)로 운영 폴더에 저장.
- 서버는 부서장 PC(Windows, `ASEUNGWOOK-B01`, `65.3.30.234`, 포트 **8080**)에서 실행. 부서원은 `dashboard.html` 사본을 각자 PC에서 **Edge 로 file:// 실행**해 서버 API에 접속.
- **계정 로그인**(서버 모드): 첫 화면에서 로그인 / 계정 개설(ID·본명·비밀번호·메일·생년월일) / 비회원 보기. **모든 쓰기 API의 수정자(`by`)는 서버가 로그인 토큰으로 확인한 본명**으로 기록(브라우저가 보낸 by 는 무시). 비회원은 보기 전용. 관리자 기능은 여전히 서버 PC의 localhost 접속 시만(로그인도 필요). 폴더 모드만 예전처럼 이름 입력.
- 사이드바 위쪽에 계정 표시(이름 ▼ → 로그아웃). 오른쪽 '내 업무' 툴바에 사용자 목록(접속 중 녹색 ●, 오프라인 회색)과 쪽지.
- UI는 전부 한국어.

### 제약 (반드시 지킬 것)
| 항목 | 내용 |
|---|---|
| 외부 의존성 | **금지**. CDN, npm 패키지, pip 패키지 사용 불가 (사내 보안 정책, pip 설치 불가 환경) |
| Python | 3.11, 표준 라이브러리만 (`http.server`, `json`, `zipfile`, `ipaddress` …) |
| 브라우저 | Edge/Chrome (File System Access API, IndexedDB 사용) |
| JS 검사 도구 | 이 PC에는 **Node.js 없음** → JS 문법 검사 불가. 수정 후 코드를 다시 읽어 검토하고, 사용자가 Edge로 확인 |
| 보안 | 사내 기밀 데이터. 외부 서비스로 전송 금지. 서버는 사내망(사설망 + 65.3.0.0/16)만 허용 |

---

## 2. 폴더 구성

```
C:\Users\SAMSUNG\Desktop\Claude\                         ← 개발 폴더 (여기서 수정)
├─ dashboard.html            화면 전체 (HTML+CSS+JS 한 파일, 약 2,300줄)
├─ server.py                 REST API 서버 + 정적 파일 + 자동 백업/주간 마감/배포 파일 생성
├─ watchdog.py               server.py 감시·자동 재시작 (pythonw 로 창 없이 실행)
├─ start_server.bat          수동 실행 (포트 8080, 브라우저 자동 열기)
├─ install_autostart.bat     작업 스케줄러(로그온 시) 등록 → watchdog.py 실행
├─ uninstall_autostart.bat   등록 해제 + 프로세스 종료
├─ migrate_xlsx.py           엑셀 → JSON 1회 이관 스크립트 (표준 라이브러리로 xlsx 직접 파싱)
├─ fix_notice.py             주간회의 전달사항 재정리(1회용, 이미 적용 완료)
├─ deploy_backup\            운영 폴더에 배포하기 전 이전 버전 백업
└─ 계장ENG그룹 주간업무 Dashboard\                         ← 운영 폴더 (서버가 실제 사용)
   ├─ dashboard.html, server.py, watchdog.py, *.bat      코드 (개발 폴더에서 복사해 배포)
   ├─ 계장ENG그룹 주간 업무 보고_26.10월1주차.xlsx         원본 엑셀
   ├─ data\{시트키}\{행ID}.json      ★ 실제 업무 데이터 (행 단위)
   ├─ data\_meta\state.json          마감 상태(lastClosedAt/lastClosedWeek, 전체 저장 정보)
   ├─ data\_meta\staffing-columns.json   투입인력 PJT 열 정의
   ├─ history\{시트키}\{행ID}\{시각}_{이름}.json   수정 이력 (7일 보관 후 자동 삭제)
   ├─ trash\{시트키}\{행ID}.json     휴지통 (복구 가능)
   ├─ archive\YYYY-Www.json          주간 마감본 (매주 수 12:00 자동, 수요일 11:59 기준)
   ├─ saves\전체저장_*.json / .xlsx  [전체 저장] 결과
   ├─ board\{글ID}.json              익명게시판
   ├─ backup\YYYY-MM-DD.zip          일일 자동 백업 (60일 보관)
   ├─ deploy\dashboard.html, 부서원_사용법.txt   부서원 배포본 (서버가 자동 생성)
   ├─ apps\                          ★ 연결 프로그램 정적 파일 자리 (/apps/… 로 제공)
   └─ server.log, watchdog.log
```

> ⚠️ **운영 폴더의 데이터 폴더(data, history, trash, archive, saves, board, backup, apps 안의 데이터)는 절대 덮어쓰거나 지우지 않는다.** 코드 파일만 개발 폴더에서 복사한다.

---

## 3. 실행 모드 (dashboard.html 이 스스로 판단)

| 열린 방식 | 모드 | 동작 |
|---|---|---|
| `http://localhost:8080/` (서버 PC) | 서버 모드 + **관리자** | API 사용. 금주 마감·휴지통 영구삭제 표시 |
| `http://PC이름:8080/` 등 | 서버 모드 | API 사용 |
| `file:///…/dashboard.html` (부서원 PC) | 서버 모드(원격) | `DEFAULT_SERVERS` = [PC이름 주소, IP 주소] 순서로 접속 시도. 사용자가 [서버 주소 설정]으로 바꾸면 localStorage `dept-server-url` 사용 |
| file:// 인데 서버 연결 실패 + 보관본 있음 | **오프라인 모드** | IndexedDB 보관본 표시, 수정은 대기열에 저장 → 30초마다 재연결, 연결되면 자동 업로드(충돌 시 선택창) |
| file:// + 서버 실패 + 보관본 없음 | 안내 화면 | [다시 시도] [서버 주소 변경] [폴더 모드로 열기] |
| 폴더 모드 (구버전 방식) | File System Access API | 공유폴더를 직접 선택해 JSON 읽기/쓰기. 서버 없이 동작 (잠금 없음) |
| VS Code Live Preview 등 `/api` 없는 서버 | 안내 화면 | "서버로 접속하세요: http://localhost:8080" |

- 서버가 배포본(`/dashboard.html`, `deploy\dashboard.html`)을 줄 때 `const DEFAULT_SERVERS = [...]` 줄을 이 PC 기준 주소로 **치환**한다 (`server.py: html_bytes()`).
- 화면 버전(`APP_VERSION`)이 서버의 dashboard.html 버전과 다르면 file:// 사본에 "새 버전 [다운로드]" 배너 (`/dashboard.html?download=1`).

---

## 4. 데이터 모델

### 4.1 시트 (메뉴: 주간업무보고 하위 9개)
| 키 | 메뉴명 | 주요 필드 (fields 의 키, 한국어 그대로) |
|---|---|---|
| perform | 수행 | 사업군, PJT명, PJT 개요, PJT 주요 일정, 담당자, 업무 현황, 현안 |
| bid | 입찰 | (수행과 동일) |
| rnr | PJT R&R | 구분(수행/입찰), 사업군, PJT명, 담당자, 역할(LE/RE/LE (PMO)), 시작일, 종료일, 설계공정률, Remarks |
| general | 일반업무 | 구분, 소구분, 업무 내용, 책임자, 시작일, 종료일, 진행사항 |
| unit | 유닛분장 | 연도, 유닛, 그룹장, 구성원, 담당, 수행 PJT, 입찰 PJT |
| techshare | 기술공유 | 연도, 발표 내용, 발표자, 발표일 |
| todo | To do list | 구분, 소구분, 지시 사항, Issue Date, Target Date, PO, 완료 여부(O/△/X), 현황, 그룹장 추가요청 사항 |
| staffing | 계장 투입인력 | 그룹, 분야, 이름, 과제+기타업무(%), Remarks, **배정**: `{열ID: {pct:숫자, role:'LE'|'RE'}}` (매트릭스 화면) |
| notice | 주간회의 전달사항 | 일자(YYYY-MM-DD), 제목, 내용 — 화면·엑셀 모두 **일자 내림차순(최신이 위)** |

시트 정의는 `dashboard.html` 의 `const SHEETS = [...]` (열 순서·너비·여러 줄 여부 `long`·날짜 `date` 등).

### 4.2 행 레코드 (`data/{시트키}/{ID}.json`)
```json
{
  "id": "perform-0001",            // 이관분: 시트-0001, 새 행: 시트-<시간36진><랜덤>
  "sheet": "perform",
  "order": 10,                      // 표시 순서 (그룹 사이에 끼울 때 소수 가능)
  "fields": { "PJT명": "...", "업무 현황": "여러 줄\n텍스트" },
  "meta": {
    "createdBy": "엑셀이관", "createdAt": "...",
    "updatedBy": "백승욱", "updatedAt": "2026-10-07T07:54:18.585Z",   // UTC ISO (밀리초+Z)
    "rev": 3,                        // 저장할 때마다 +1 → 동시 수정 충돌 감지
    "changes": { "업무 현황": "<ISO>" },   // 필드별 마지막 변경 시각
    "orig": { ... }, "origSince": "<lastClosedAt>"   // 마감 이후 첫 수정 직전 내용(파란 글씨 비교용)
  }
}
```
- 텍스트 안의 `~~내용~~` = **삭제 표시(붉은 취소선)**. 저장 데이터에 실제로 들어 있음. 한 번 더 지우면 완전 삭제 (`mergeStrike`).
- "추가된 내용(파란 글씨)" 표시는 저장 데이터에 넣지 않고 화면에서 계산 (`markAdded`, 내부 표식 `\uE000…\uE001`).
- 수정자 `엑셀이관` = 이관/정리 작업 (변경 표시·최근 이력에서 제외).

### 4.3 기타 파일
| 파일 | 내용 |
|---|---|
| `data/_meta/staffing-columns.json` | `{columns:[{id, name, kind:'수행'|'입찰'|'기타'}]}` |
| `data/_meta/state.json` | `lastClosedAt`, `lastClosedWeek`, `closedBy`, `lastFullSaveAt/By/File` |
| `archive/YYYY-Www.json` | `{week, closedAt, closedBy, auto, cutoff, sheets:{시트키:[레코드…]}, staffingColumns}` |
| `history/…/{at}_{이름}.json` | `{sheet, rid, action(create/update/overwrite/delete/restore/purge), by, at, label, before, after, changed[]}` |
| `trash/{시트}/{ID}.json` | 레코드 + `meta.deletedBy/deletedAt` |
| `board/{ID}.json` | `{id,title,body,nick,createdAt,updatedAt,tokenHash,comments:[{id,body,nick,createdAt,tokenHash}]}` — 실명 저장 안 함 (쓰기는 로그인 필요, 계정과 연결하지 않음) |
| `accounts/{ID}.json` | `{id, name(본명), salt, hash(PBKDF2-SHA256 20만 회), rsalt, rhash(메일+생년월일 확인용 해시), createdAt, pwChangedAt}` — 비밀번호·메일·생년월일 원문 저장 안 함 |
| `accounts/_sessions.json` | `{sha256(토큰): {id, at}}` 로그인 세션 30일 (서버 재시작해도 유지) |
| `messages/{ID}/in\|sent/{쪽지ID}.json` | `{id, from, fromName, to, toName, body, at, read, readAt}` 쪽지, 180일 후 자동 삭제 |

### 4.4 주차·마감 규칙
- **수요일 오전 11:59까지 = 그 주 데이터, 수요일 12:00부터 = 다음 주.** 표기 `2026-W41(1007)` (= ISO 주차 + 그 주 수요일 MMDD).
- 서버가 매주 수 12:00 `archive/` 에 자동 저장(`auto_close`). 서버가 꺼져 있었으면 켜진 뒤 이력(7일)으로 마감 시점 데이터를 복원해 저장(`snapshot_at`).
- **변경 표시(노란 음영 / NEW(n) / 파란 글씨)** 의 기준 = 마지막 마감본(`state.lastClosedWeek`)과 필드 단위 비교 (`hlOf`, `isUpdated`, `baseFieldsOf`).

---

## 5. 서버 API (`server.py`, 모두 JSON, 경로 앞 `/api/`)

| 메서드 · 경로 | 설명 |
|---|---|
| GET `info` | `{mode:'server', admin, week, version(화면), serverVersion, urls, host}` |
| GET `all` | `{recs:{시트:[레코드]}, cols, state, archives:[주차…]}` |
| GET `rec/{시트}/{id}` | 행 1개 (없으면 404) |
| POST `rec/{시트}` | 새 행 `{fields, id?, order?, by}` |
| PUT `rec/{시트}/{id}` | 수정 `{fields, baseRev, force?, action?, by}` → `{status:'ok'|'conflict'(+cur)|'deleted'|'nochange'}` |
| DELETE `rec/{시트}/{id}?by=` | 휴지통으로 이동 |
| GET `trash` · POST `trash/{시트}/{id}/restore` · DELETE `trash/{시트}/{id}`(관리자) | 휴지통 |
| GET `history/{시트}/{id}` · GET `recent` | 이력 |
| GET `archive/{주차}` | `{arch, prev}` (직전 마감본 포함) |
| POST `close`(관리자) | 수동 주간 마감 |
| POST `columns` | 투입인력 PJT 열 추가 |
| POST `saveall` · PUT `saves?tag=` | 전체 저장(JSON) · 엑셀 파일 업로드 |
| GET/POST/PUT/DELETE `board…` | 익명게시판 (토큰 해시로 본인 확인, 로그에 IP 미기록) |
| GET `/`, `/dashboard.html[?download=1]` | 화면 (기본 서버 주소 치환) |
| GET `/apps/…` | **연결 프로그램 정적 파일** (운영 폴더 `apps/`, 상위 경로 접근 403) |
| POST `auth/register` · `auth/login` · `auth/reset` · `auth/logout`, GET `auth/me` | 계정. 로그인 응답 `{token, user:{id,name}}`, 이후 요청 헤더 `X-Auth-Token`. 로그인·재설정 5회 실패 시 10분 잠금 |
| GET `space/projects` · POST `space/projects` `{name}` · GET `space/{pid}` · GET `space/{pid}/saves/{sid}` · POST `space/{pid}/saves` `{data, memo, sum}` · POST `space/{pid}/notes` `{text}` · DELETE `space/{pid}/notes/{nid}` · GET `space/recent?n=` (모든 프로젝트 최근 저장) | 판넬 공간확보 서버 저장 (2026-10-22~). 운영 폴더 `space/{pid}/index.json`(프로젝트 · 저장 메타 · 노트) + `space/{pid}/saves/{sid}.json`(배치안). 보기 = 누구나, 쓰기 = 로그인 + `space` 권한, 노트 삭제 = 본인 · 운영자/그룹장. 일일 백업 포함 |
| POST `auth/ping` | 접속 표시 갱신(화면이 30초마다) → `{users:[{id,name,online}], unread}`. 75초 안에 요청이 있었으면 online |
| GET `msg` · POST `msg` `{to, body}` · POST `msg/{id}/read` · DELETE `msg/in\|sent/{id}` | 쪽지 (로그인 필요) |

- 쓰기 API(rec, trash 복구/영구삭제, close, columns, saveall, saves, board 쓰기)는 **로그인 필요(401)**. GET 은 비회원도 가능.

- 모든 쓰기는 서버 내부 `LOCK`(RLock) 안에서 수행, 파일은 임시 파일 → `os.replace` 로 원자적 교체.
- 접속 제한: 클라이언트 IP 가 루프백·사설망·서버 /16 대역(`--allow` 추가 가능)이 아니면 403. `Origin` 헤더가 `null`(file://) 또는 서버 자신 주소가 아니면 403 (CORS 는 그 경우에만 허용 헤더 응답).
- 관리자 = 요청 IP 가 `127.0.0.1`/`::1`.
- 백그라운드 스레드: 1시간마다 백업·이력 정리, 30초마다 주간 마감 확인·`deploy/` 갱신.

---

## 6. dashboard.html 내부 구조

한 파일 안에 `<style>` → 화면 골격(사이드바 `#side`, 상단 `header.top`, 본문 `#content`, 대화상자 `#dlg`/`#dlg2`) → `<script>` (IIFE 하나). 스크립트 구역(주석 `/* ===== … */`) 순서:

| 구역 | 주요 내용 |
|---|---|
| 상수 / 시트 정의 | `SHEETS`, `SHEET`, `PALETTE`, `IMPORT_BY='엑셀이관'` |
| 유틸 | `esc`(HTML 이스케이프, **innerHTML 에 넣는 모든 값에 사용**), `flatten`, `diffPaths`, `recLabel`, `toast` |
| 파일 시스템 계층 / 서버 | `APP_VERSION`, `DEFAULT_SERVERS`, `api(method, path, body, raw)` (네트워크 오류 시 `err.offline=true`), 폴더 모드용 `sub/readJSON/writeJSON`, IndexedDB `kv()` |
| 상태 | `DB={recs, cols, state, archives, baseSheets, board, recent}`, `view`(주차 선택), `route`, `curWeek()`, `weekLabel()`, 변경 판정 `hlOf/isUpdated/baseFieldsOf` |
| 데이터 로드 | `loadAll()` — 모드별(오프라인/서버/폴더)로 DB 채움, 서버 모드에서 보관본 저장 `cacheSave()` |
| 저장 / 이력 / 삭제 / 복구 | `createRecord`, `saveEdit`(rev 비교), `deleteRecord`, `restoreFromTrash`, `addColumn`, `closeWeek` — 모드별 분기(서버 API / 오프라인 대기열 / 폴더) |
| 오프라인 모드 | `QUEUE`(IndexedDB 'queue'), `applyOp`, `offlineCreate/Update/Delete`, `trySync`, `syncOp`(충돌 선택창), 대기열 내보내기/가져오기 |
| 다이얼로그 | `openDlg`, `ask`(Promise 반환 확인창), 편집 `openEdit/openStaffEdit/submitRecord/afterSave`(충돌 처리), 이력/휴지통 |
| 렌더링: 공통 | `render()` = `renderMenu()` + `renderHeader()` + route 별 본문, 메뉴 정의 `ROUTES`, `validRoute`, `renderMenu` |
| 익명게시판 | `Board` 객체, `renderBoard` |
| **입찰/실행 프로젝트** | **`MODULES` + `renderModule()`** ← 연결 프로그램 자리 |
| 홈 | `renderHome` (KPI·SVG 차트·툴팁·팝업 `openPop`·메모), 접속 시 할 일 팝업 `showMyTodo`, 칸 이동 `jumpTo` |
| 시트 화면 | `renderSheet`, `drawTable`, `tableHtml`/`matrixHtml`, 셀 서식 `fmtText`(글머리·날짜·취소선·추가 표시), 셀 선택(Ctrl/Shift)·크기 조절 |
| CSV / 엑셀 | `exportCsv`, 순수 JS xlsx 생성(`zipStore`(무압축 ZIP+CRC32), `xlSheets`, `buildXlsx`) |
| 초기화 | `init()` IIFE: 모드 판정 → `startOnline()` / 오프라인 / `initFolderMode()` |

라우팅: `location.hash` (`#home`, `#perform`, …, `#bidpjt`, `#runpjt`, `#board`). `go(route)` 로 이동.
메뉴 구조: 📋 주간업무보고(= `home` 대시보드, 하위 9개 시트) / 📈 입찰 프로젝트(`bidpjt`) / 🏗 실행 프로젝트(`runpjt`) / 💬 익명게시판(`board`).
브라우저 저장소 키(localStorage): `dept-dashboard-user`(이름), `dept-server-url`, `dept-dashboard-layout`(열 너비 등), `dept-nav-weekly-open`, `dept-board-*`, `dept-todo-hide`. IndexedDB `dept-dashboard` / store `kv` (키: `root`, `cache`, `queue`).

---

## 7. ★ 새 프로그램 연결 방법 (입찰 프로젝트 / 실행 프로젝트 메뉴)

현재 두 메뉴는 **빈 화면("준비 중")** 이다. 연결 지점은 이미 만들어져 있다.

### 방법 A (권장): 독립 HTML 앱을 `apps/` 에 두고 iframe 으로 연결
1. 프로그램을 **정적 파일(HTML/JS/CSS)** 로 만든다. 외부 CDN·라이브러리 금지 (필요하면 파일로 동봉).
2. 운영 폴더에 넣는다: `계장ENG그룹 주간업무 Dashboard\apps\bidpjt\index.html` (실행 프로젝트는 `apps\runpjt\`).
   → 서버가 `http://<서버>:8080/apps/bidpjt/` 로 제공 (재시작 불필요).
3. `dashboard.html` 의 `MODULES` 에 경로만 넣는다:
   ```js
   const MODULES = {
     bidpjt: { title:'입찰 프로젝트', src:'/apps/bidpjt/index.html' },
     runpjt: { title:'실행 프로젝트', src:'' },
   };
   ```
4. iframe 주소에 쿼리로 넘어가는 값: `?user=<이름>&server=<서버 주소>&admin=1|0`. 연결 앱은 이 `server` 값으로 `/api/...` 를 호출하면 기존 데이터(예: `GET /api/all` 의 `recs.bid`, `recs.rnr`, `recs.staffing`)를 그대로 쓸 수 있다.
5. 서버가 꺼져 있거나 오프라인 모드면 "서버에 연결되어 있을 때만 사용할 수 있습니다" 안내가 나온다.
6. `APP_VERSION` 을 올리고 배포 (8장).

### 방법 B: 별도 서버로 도는 프로그램 (예: 다른 포트의 웹 앱)
- `src:'http://ASEUNGWOOK-B01:8000/'` 처럼 전체 주소를 넣으면 iframe 으로 표시된다.
- 해당 서버가 iframe 삽입을 막는 헤더(X-Frame-Options 등)를 보내면 표시되지 않는다 → 그 서버 설정 확인 필요.
- 주의: 이 PC의 **8000 포트는 P&ID 추출 도구(uvicorn)가 사용 중**. 대시보드는 8080.

### 방법 C: dashboard.html 안에 직접 화면 구현 (데이터가 이 대시보드와 긴밀할 때)
- `renderModule(c, key)` 대신 새 렌더 함수를 만들고 `render()` 의 분기(`else if (MODULES[route]) …`)에서 호출.
- 새 데이터가 필요하면 `server.py` 에 **별도 접두어 API**(예: `/api/pjt/...`)와 **별도 저장 폴더**(예: 운영 폴더 `modules/pjt/`)를 추가하고, 쓰기는 반드시 `with LOCK:` + `write_json()`(원자적 교체) 사용. 기존 `data/` 구조는 바꾸지 말 것.
- 기존 함수 재사용: `api()`, `esc()`, `openDlg()/ask()`, `toast()`, `fmtText()`, `jumpTo(시트, 행ID, 필드)`.

### 메뉴를 더 추가하려면
- `ROUTES` 배열과 `MODULES` 에 키 추가 → `renderMenu()` 의 메뉴 HTML 에 `btn({k:'<키>', l:'<아이콘 이름>', n:'', c:0}, 'top')` 한 줄 추가.

### 방법 A' (2026-10-22~): 같은 서버 `apps/` 앱을 P&ID 와 같은 화면 틀로 — `APP_ROUTES`
- 예: **판넬 공간확보** = `APP_ROUTES.space = { title:'판넬 공간확보', src:'/apps/space/index.html' }`, 파일은 운영 폴더 `apps\space\index.html` (저장소 `dashboard/apps/space/index.html`).
- `MODULES`(카드 안 iframe)와 달리 본문 전체를 채우고(`pid-mode`), 1분 자동 갱신에도 iframe 을 다시 만들지 않는다(`#pidwrap` 유지) — 편집 중인 화면이 날아가지 않음. 위쪽 주간업무 버튼은 숨김.
- 주소 뒤 값: `?embed=1&user=<본명>`. 앱은 `embed=1` 이면 자기 제목줄을 숨긴다.
- 추가하려면: `APP_ROUTES` 에 한 줄 · `ROUTES` 에 키 · `renderMenu()` 에 `btn(...)` 한 줄 · (권한 표에 넣으려면) server.py `MENUS` 에 `(키, 이름)`.

---

## 8. 개발·배포 규칙

1. 개발 폴더에서 수정 → 확인 → **운영 폴더로 코드 파일만 복사**.
2. 배포 전 운영 폴더의 기존 `dashboard.html`(·`server.py`)을 개발 폴더 `deploy_backup\dashboard_YYYYMMDD_HHMM.html` 로 백업 (롤백용).
3. `dashboard.html` 을 바꾸면 **`APP_VERSION` 을 올린다** (부서원 사본에 새 버전 안내가 뜨는 기준). `server.py` 를 바꾸면 `SERVER_VERSION` 을 올리고 **서버 재시작** 필요(작업 스케줄러 사용 중이면 `uninstall_autostart.bat` → `install_autostart.bat`, 또는 watchdog 이 재시작하도록 server 프로세스만 종료).
4. `deploy\` 는 서버가 `dashboard.html` 변경을 감지해 30초 안에 자동 갱신.
5. 서버 기능 시험은 **운영 데이터가 아닌 사본**으로: 운영 `data\` 를 임시 폴더로 복사 → `python server.py --root <임시폴더> --port 87xx --log x.log` → urllib 로 API 호출 → 프로세스 종료.
6. Python 파일은 `python -m py_compile` 로 문법 확인. JS 는 Node 가 없어 검사 불가 → 수정 부분을 다시 읽어 검토.
7. 엑셀 원본이 열려 있으면 `~$` 잠금 파일이 생긴다 → glob 시 `~$` 로 시작하는 파일 제외.

---

## 9. 알려진 한계

- 계정 인증은 있으나 비밀번호 재설정이 메일+생년월일 확인뿐(메일 발송 없음) → 이 정보를 아는 사람은 재설정 가능. 메일·생년월일까지 잊은 경우 서버 PC에서 `accounts\{ID}.json` 을 지우고 다시 개설.
- 비회원도 데이터 조회는 가능. 사내망·출처 제한이 조회에 대한 접근 통제.
- 폴더 모드로 직접 파일을 쓰는 사용자가 있으면 서버 잠금이 적용되지 않음 → 부서원은 서버 접속(또는 file:// 사본)만 사용.
- 주간 마감 복원은 이력 7일 범위 안에서만 정확.
- 입찰/실행 프로젝트 메뉴는 현재 빈 화면 (이전에 만들었던 PJT 카드 화면은 `deploy_backup\dashboard_20261008_*.html` 에 남아 있음).

---

## 변경 이력

> 새 변경은 이 아래에 날짜별로 덧붙인다. 각 항목: 무엇을·왜 / 바뀐 곳(함수 이름) / 확인한 것 / 회사에서 확인할 것.

### 2026-10-13 — 시트 화면에 엑셀식 열 필터 (APP_VERSION 2026-10-13.1 / SERVER_VERSION 그대로 2026-10-09.2)
- **무엇을**: 수행·입찰·이슈사항·R&R·일반업무·유닛분장·기술공유·To do·투입인력·전달사항 등 모든 시트 표의 각 열 머리글에 `▾` 버튼. 누르면 엑셀 자동 필터처럼
  ↑오름차순 / ↓내림차순 정렬, 이 열 필터·정렬 지우기, 값 검색(포함된 값만), (모두 선택) + 값별 체크 목록(건수 표시), 확인/취소.
  - 필터·정렬이 걸린 열은 버튼이 파란색(정렬이면 ↑/↓ 표시). 표 아래 "열 필터 n개 적용 중".
  - 목록 값은 다른 열 필터를 적용한 뒤 남은 행 기준 (엑셀과 같음). 값은 칸 전체 문자열 그대로, `~~취소선~~` 부분은 목록 표시에서만 뺌. 빈 칸 = "(빈 셀)".
  - 구분(group) 있는 시트(R&R·일반업무·유닛분장·기술공유·To do)는 정렬해도 구분 묶음 순서는 유지하고 묶음 안에서만 정렬.
  - 투입인력 매트릭스: 이름·그룹·분야·수행·입찰·Total·각 PJT 열(값 예: `60 (LE)`)·과제+기타·합계%·Remarks 모두 필터 가능.
  - 기존 위쪽 필터(사업군·담당자·검색 등)와 함께 걸린다(AND). [필터 초기화] 누르면 열 필터·정렬도 함께 풀림. 상태는 메모리에만(새로고침하면 풀림).
  - 결과 0건이어도 [열 필터 모두 지우기] 버튼이 나와 풀 수 있다. CSV 내보내기는 화면에 보이는 행·순서 그대로, 엑셀 내보내기(전체)는 영향 없음. 인쇄에는 ▾ 안 나옴.
- **바뀐 곳** (dashboard.html만): CSS `.cfb`, `#cfPop`, `table.m th.cfh` / 시트 화면 구역 새 함수 `colVal`, `cfLabel`, `cfCmp`, `cfSort`, `openCf`, `closeCf` + 문서 click/keydown(Esc)/scroll 리스너 / `filteredRecs(s, skipCf)` 에 열 필터 조건 추가, 끝에서 `cfSort` / `thR(ck, label, extra, key)` 4번째 인자가 있으면 ▾ 버튼(`cfBtn`) / `tableHtml`·`matrixHtml` 머리글에 시트 키 전달 / `drawTable` 0건일 때 지우기 버튼·적용 개수 표시. 상태: `fstate(key).cf`, `fstate(key).sort`.
- **확인한 것**: 가짜 샘플 데이터(임시 폴더, 저장소에 넣지 않음)로 server.py 를 띄워 Chromium 에서 수행(사업군=화공 → 3건, PJT명 내림차순), 입찰·R&R·To do·투입인력 버튼 표시, 투입인력 PJT 열 'LE' 검색 → 2건, 아무것도 안 고르고 확인 → 경고 후 창 유지, Esc 로 닫힘. 스크립트 오류 없음.
- **회사에서 확인할 것**: Edge 에서 실제 데이터로 긴 글 칸(업무 현황 등) 목록이 너무 길지 않은지, 셀 선택·편집·열 너비 드래그가 그대로 되는지.

### 2026-10-13 (2) — 통합 업무 · 유닛 조직도 · 내 정보 · PJT 종결 · 작성 가이드 · 연도 탭 (APP_VERSION 2026-10-13.2 / SERVER_VERSION 2026-10-13.1)
> **서버 재시작 필요** (server.py 변경: 프로필 API·폴더). dashboard.html 만 먼저 바뀌어도 화면은 열리고, 프로필만 안 보인다.

1. **통합 업무 (route `work`, 메뉴 '🚀 통합 업무')** — 일반업무·To do·기술공유를 한 화면으로 합침.
   - **데이터는 합치지 않았다**: 지금처럼 `data/general`, `data/todo`, `data/techshare` 에 따로 저장. 화면만 합쳐 보여 준다 (이관 위험·마감본·엑셀 내보내기 호환 때문). 세 시트는 사이드바에서 숨김(`SHEETS[].merged:1`)이지만 주소 `#general` `#todo` `#techshare` 와 홈 팝업 이동은 그대로 동작, 통합 화면의 [원본 시트 보기] 버튼으로도 간다.
   - 매핑 `WORK` (dashboard.html): 제목/담당/시작/종료/진행 칸 = general(업무 내용/책임자/시작일/종료일/진행사항), todo(지시 사항/PO/Issue Date/Target Date/현황), techshare(발표 내용/발표자/발표일/발표일/-).
   - **연도 탭**(전체·데이터 연도 + 2024·2025·올해 항상 표시), 유형 칩, KPI(완료율 링·진행·임박 7일·지연·완료·상시·종료일 미입력, 누르면 그 상태만), **부서원별 상·하반기 막대**(기준일 = 시작일, To do = Issue Date, 기술공유 = 발표일. 1~6월 상반기, 7~12월 하반기. 날짜 없으면 합계 옆 `+n`. 담당 칸에 여러 명이면 각자 1건), 종료 현황 막대 + '지금 챙길 업무'(지연·임박), 업무 목록(상태 순 정렬, 편집/이력/삭제는 원본 시트 레코드로).
   - **종료 구분** 새 필드 `종료 구분` = `기한`(종료일 추적) / `상시`(종료일 없음, 추적 안 함) / 빈 칸(자동: 종료일 있으면 기한, 없으면 상시. 기술공유는 기본 기한). 세 시트 cols 에 `{f:'종료 구분', endk:1}` 추가, 편집 창은 select. 상태 계산 `workItem()`: todo = 완료 여부 O→완료, 기한 지남→지연, 7일 이내→임박 / general = 종료일 지남→종료(완료) / techshare = 발표일 지남→발표 완료. 상태 `WST_*`.
   - 상태 `WS`(메모리). 함수: `WORK`, `workItem`, `renderWork`, `WST_ORDER/WST_LABEL`.
2. **유닛분장**: 연도 탭(기본 = 가장 최근 연도) + **🏢 조직도(기본) / 📋 표** 전환. `수행 PJT`·`입찰 PJT` 열 삭제(cols·엑셀 `XL.unit` 에서 제거. 기존 JSON 값은 그 행을 다시 저장할 때 없어짐, 이력에는 남음).
   - 조직도 `orgHtml/orgPill/orgClick`: 맨 위 = 그룹장 칸의 이름, 그 아래 유닛(유닛명·담당·인원) → 구성원 알약(사진·이름·직책·전화·PJT 칩). 구성원 칸은 줄/쉼표로 나누고 `이름(직책)` 이면 괄호 안을 직책으로 표시. 유닛 머리를 누르면 그 행 편집, 사람을 누르면 `openProfile`.
3. **내 정보 (프로필)** — 계정 메뉴(이름 ▼)에 '🙋 내 정보', 조직도 아래 버튼. 사진(브라우저에서 240×240 JPEG 로 잘라 줄임, `shrinkPhoto`), 전화번호, 담당 업무, 수행/입찰 PJT(진행 중 PJT명 체크). `openMyInfo`, `loadProfiles`, `profOf`(계정 본명 ↔ 구성원 이름을 `normName` 으로 맞춤). `DB.profiles` 를 오프라인 보관본(`cacheSave`)에도 저장.
   - **server.py**: `GET /api/profiles` (모든 계정 프로필, **전화번호는 로그인한 사람에게만**), `PUT /api/profile` (로그인 본인만, `{phone≤30자, duty≤100자, run[], bid[], photo:data URL(jpeg/png/webp, 400KB 이하)}`). 저장 `profiles/{ID}.json` (시작 시 폴더 생성, 일일 백업 zip 에 포함). 함수 `api_profiles`, `api_profile_put`, `prof_list`, `PHOTO_RE`, `PHONE_RE`.
   - 폴더 모드(서버 없음)에서는 프로필을 쓰지 않는다.
4. **수행·입찰 PJT 종결 여부**: 새 필드 `종결 여부` (`진행`/`종결`, 빈 칸 = 진행) 열 추가(`c.closed`), 표에 배지, 종결 행은 회색, 위쪽 '진행 상태' 필터. `isLive(r)`.
   - **홈**: 수행/입찰 PJT 수·사업군별·담당자별 차트·'이번 주 미업데이트 PJT'·내 업무(`myTasks`)에서 **종결 PJT 제외**. KPI '현안' **삭제** → '종결 PJT (집계 제외)' 로 바꿈. 'To do 미완료' KPI 는 통합 업무로 이동.
5. **작성 가이드** (행 추가 시): 긴 글 칸(이름·제목 칸 제외, `guideOn`)에 틀 `1. / - / - / 2. / -` (일정 칸은 `- YY.MM.DD :`) 을 미리 넣고, 편집 창 위에 가이드 상자(`GUIDE_BOX`), 칸마다 서식 버튼(1. - → ※ 들여쓰기 내어쓰기 틀, `guideBar/guideAct`), `Enter` = 같은 글머리 이어 쓰기(빈 글머리에서 Enter = 지움), `Tab`/`Shift+Tab` = 3칸 들여쓰기(`guideKey`). 저장할 때 글머리만 남은 빈 줄은 지움(`cleanGuide`). 편집(기존 행)에도 버튼·키는 동작, 틀은 행 추가 때만.
6. **주간회의 전달사항**: 연도 탭(일자 기준, 기본 = 최근 연도). 공통 `YEAR_OF`, `yearsOf`, `yearSel`, `yearTabs`, `fstate().year` (`jumpTo` 는 연도를 '전체'로 풀어 항목이 숨지 않게).
- 공통: `fstate` 에 `closed, year, view` 추가. 인쇄 때 연도 탭·버튼 숨김.
- **확인한 것**: `node --check`(스크립트 문법), `py_compile`. 임시 폴더 가짜 데이터 + 가짜 계정 5개로 server.py 를 띄워 Chromium 에서 홈·수행·통합 업무(전체/2025/2026·임박)·유닛 조직도(2026/2025)·프로필 팝업·내 정보·행 추가 가이드·전달사항 연도 탭을 열어 스크립트 오류 없음. 새 일반업무 저장 → 빈 글머리 줄이 지워져 `1. 첫 항목` 만 저장, `종료 구분=상시` 저장 확인. 수행 PJT 를 종결로 저장 → 홈 '수행 PJT(진행 중)' 6→5, '종결 PJT' 4→5.
- **회사에서 확인할 것**: (1) 서버 재시작 후 각자 '내 정보' 입력 → 조직도에 사진·PJT 가 뜨는지 (구성원 칸 이름이 계정 본명과 같아야 함). (2) 기존 일반업무·To do 의 '종료 구분'은 빈 칸이라 자동 판단 — 상시 업무는 '상시'로 골라 주면 정확해짐. (3) 오른쪽 '내 업무' 막대가 표 오른쪽 칸(작업 버튼)을 가리는 것은 원래 동작 — 막대의 `–` 로 접어서 쓴다.

### 2026-10-13 (3) — 조직도 직책 심볼 · 수행/입찰 PJT 현황판 (APP_VERSION 2026-10-13.3 / SERVER_VERSION 그대로 2026-10-13.1)
> dashboard.html 만 바뀜. 서버 재시작 필요 없음.
- **조직도 심볼**: 그룹장 = 💎 다이아(아바타 오른쪽 아래 다이아 배지 + 하늘빛 테두리·빛), 유닛장 = ★ 골드(금색 원 배지 + 금색 테두리·알약). 유닛장 판단은 구성원 칸의 `이름(유닛장)` (`isUnitLead`: '유닛장'·'Unit Leader'·'UL'). 유닛 안에서 유닛장이 맨 위로 정렬. 조직도 아래 범례 표시. 바뀐 곳 `orgPill`, `orgHtml`, CSS `.osym .dia/.gold`, `.opill.r-dia/.r-gold`, `.olg`.
- **수행·입찰 PJT 현황판** (`pjHero(s)`, `#pjhero`): 통합 업무와 같은 그라데이션·카드 디자인을 표 **위에** 붙임. 아래 **엑셀형 표·필터·열 필터·셀 편집은 그대로**.
  - 머리 띠(수행 = 파랑→청록, 입찰 = 보라→주황) + 사업군 칩(누르면 표의 사업군 필터), KPI: 금주 업데이트율 링 · 진행 중 · 종결 · 금주 업데이트 · 미업데이트 (누르면 표가 그 조건으로 걸러짐, 다시 누르면 해제). 사업군별 진행/종결 막대, 담당자별 진행 PJT 막대(프로필 사진, 누르면 담당자 필터).
  - 새 필터 상태 `fstate().upd` ('upd' 금주 업데이트 / 'not' 미업데이트), `filteredRecs` 에 조건 추가. 공용 `avHtml(name)`. 인쇄 때 현황판 숨김(`.pjhero`).
- **확인한 것**: `node --check`. 임시 폴더 가짜 데이터로 Chromium 에서 조직도(2026)·수행·입찰 화면, '종결' 카드 → 표 2건, 담당자 막대 → 표 2건으로 걸러짐, 스크립트 오류 없음.
- **회사에서 확인할 것**: 유닛장 심볼이 나오려면 유닛분장 구성원 칸에 `홍길동(유닛장)` 처럼 써야 함.

### 2026-10-13 (4) — R&R · 투입 분석 (월말 시수 업로드) · Project Code · 열 추가 (APP_VERSION 2026-10-13.4 / SERVER_VERSION 2026-10-13.2)
> **서버 재시작 필요** (server.py: 시수·열 추가 API, `timesheets/` 폴더).
1. **메뉴 '👥 R&R · 투입 분석' (route `alloc`)** — PJT R&R(`rnr`) + 계장 투입인력(`staffing`)을 한 화면으로. 두 시트는 사이드바에서 숨김(`SHEETS[].merged:'alloc'`), 데이터·주소(`#rnr` `#staffing`)·화면 오른쪽 위 '원본 시트' 버튼은 그대로.
2. **월말 시수 파일 업로드** (부서원 개인 집계 엑셀 .xlsx, 예: `개인 집계_7월.xlsx`)
   - 서버 `parse_timesheet` (표준 라이브러리 zipfile + ElementTree): 머리글에 `Type`·`Project` 가 있는 시트를 찾고, 그 오른쪽에서 `01~31` 날짜 줄(숫자·'01' 글자·날짜서식 모두)을 찾아 줄마다 시간을 합산. 시간 값은 시간서식(`[h]:mm`, 하루 비율 → ×24), `h:mm` 글자, 서식 없는 숫자(모두 1 이하면 하루 비율로 봄) 모두 처리. 'Total'·'합계' 줄은 제외. 월은 파일 안의 `2026-07` 같은 글자/날짜에서, 없으면 업로드 창에서 고른 월.
   - 저장: `timesheets/{연도}/{계정ID}_{YYYY-MM}.json` (`rows:[{type, detail, code, work, days:{일:h}, h}]`) + 원본 `timesheets/{연도}/raw/…xlsx`. 같은 사람·같은 달은 덮어씀. 일일 백업에 포함.
   - API: `PUT /api/timesheet?person=ID&month=YYYY-MM&name=파일명` (본문 = xlsx, 로그인+주간업무보고 권한, **다른 사람 것은 Management 권한자만**), `GET /api/timesheets?year=YYYY` (로그인 필요), `DELETE /api/timesheet/{ID}/{YYYY-MM}` (본인 또는 Management).
   - **Step3 권한**: Management 메뉴 권한(`perms_for(...).mgmt`, 운영자=서버 PC 포함)이 있으면 `canHours:true` + 실제 시간. 없으면 서버가 **시간을 보내지 않고** 사람·연도별 합계가 100 이 되는 비율 단위 `v` 로만 보냄(사람 안의 월·프로젝트 비율은 그대로 정확). 화면 배지 🔒/🔓.
3. **Step1 분류** (`tsClass`, 화면에서 계산): Type 이 `공통` → 부서업무 / 그 외 → `Project` 코드를 **수행·입찰 PJT 의 새 칸 `Project Code`**(쉼표·줄바꿈으로 여러 개)와 맞춤(`projIndex`) / 못 찾으면 '미등록 코드 X'(경고 띠에 목록) / 코드 없음.
4. **Step2 화면** (`renderAlloc`, 상태 `AS`): 연도 탭 · 월 칩(연간/1~12월) · KPI(프로젝트 %, 부서업무 %, 미등록 %, 업로드 인원) · 부서원별 100% 막대(마우스 = 상세, Management 는 시간) · 프로젝트별 팀 대비 비율(권한 없으면 사람별 비중 동일 가정이라고 표시) · 개인 분석(도넛, 12개월 구성 막대, **R&R · 계획 대비 실제** 표 = rnr 역할·기간·공정률 + staffing 배정% (열 이름 ↔ PJT명 이름 맞춤 `nmKey`) + 시수 실제%, 차이 %p) · 업로드 현황(부서원×월 ✓, 본인/Management 는 눌러서 삭제). 색은 연도 전체 기준으로 고정.
5. **수행·입찰 `Project Code` 칸** (PJT명 옆).
6. **열 추가** (모든 표 시트, 투입인력 매트릭스 제외): [＋ 열 추가] → 이름·한 줄/여러 줄·너비. 정의는 `data/_meta/sheet-columns.json` (`GET all` 의 `sheetCols`), API `POST /api/sheetcols {sheet,f,long,w}` · `DELETE /api/sheetcols/{sheet}?f=`. 화면은 `applyExtraCols()` 가 `render()` 때마다 `s.cols = baseCols + 추가 열`. 지우기 = 그 열 머리글 ▾ → '추가한 이 열 지우기'(정의만 지움, 행의 값은 남음). 열 이름에 `.` `<` `>` 불가(필드 경로 규칙).
- **확인한 것**: `node --check`, `py_compile`. openpyxl 로 만든 가짜 시수 파일(시간서식/글자 두 방식)을 서버가 읽은 합계 = 엑셀 값과 일치(예: D026 40h, 19LT 21h). 시험 서버(사내망 주소)에서 일반 부서원 = 비율만, Management 권한자 = 시간 표시, 일반 부서원이 다른 사람 것 올리기·지우기 → 403, 비로그인 GET → 401, xlsx 아닌 파일 → 400. 화면: 연간/7월, 개인 분석·R&R 표, 업로드 창, 열 추가 → 저장 확인. 스크립트 오류 없음.
- **회사에서 확인할 것**: (1) 실제 개인 집계 파일 1개를 올려 합계가 엑셀 'Total' 과 같은지. 양식이 다르면(머리글 이름 등) 오류 문구 그대로 알려 주면 맞춤. (2) 수행·입찰 PJT 에 Project Code(D026, 19LT 등) 입력. (3) 실제 시간을 볼 사람에게 ⚙ 메뉴 권한에서 Management 체크.

### 2026-10-13 (5) — 통합 업무 종결·열 필터·완료 알림 · 사업군 단어 필터 · 조직도 업무 요약 (APP_VERSION 2026-10-13.5 / SERVER_VERSION 그대로 2026-10-13.2)
> dashboard.html 만 바뀜 (서버 재시작은 (4) 의 server.py 를 아직 안 넣었다면 필요).
1. **통합 업무 종결**: 일반업무·To do·기술공유에 `종결 여부`(진행/종결, `closed:1`) 열 추가. 통합 업무 목록 작업 칸 [🏁 종결] / [↩ 진행] 한 번 누르면 저장(`workToggleClose` → `saveEdit`). `workItem`: 종결 → 상태 '🏁 종결'(cls `done`), To do 의 완료 여부 O 는 상시라도 완료.
2. **통합 업무 표 열 필터**: 머리글마다 ▾ (유형·구분·업무 내용·담당·시작·종료·종료 관리·진행 내용, `WCOLS`). 목록 계산을 `workScope()`·`workList(skipCf)`·`workVal()` 로 분리하고, `openCf` 는 `route === 'work'` 이면 `WS.cf / WS.sort` 를 씀. `cfBtn('work', k)`.
3. **완료 알림**: `myTasks` 에서 기존 To do '현황 작성' 업무를 없애고, 통합 업무 중 내가 담당(To do 는 완료·종결 전 전부, 일반업무·기술공유는 지연·임박)인 것을 `🔔 완료 알림`(f `__ack`)으로. 팝업·툴바에서 한 번 누르면 편집 창을 열지 않고 '확인완료'(`ackTask`, 브라우저 localStorage `dept-ack|이름`, 키 = `주차|시트|ID` → 다음 주에 아직 미완료면 다시 알림). 종결·완료하면 알림에서 빠짐. 수행·입찰 PJT '업무 현황 작성'은 그대로(누르면 편집).
4. **사업군 단어 필터**: 수행·입찰 현황판의 사업군 칩·막대를 단어 단위로 (`bizTok`: '발전(UNIT1)' → 발전, '수소/LNG' → 수소·LNG, 숫자 든 조각 제외). 누르면 `fstate().kw` → 사업군에 그 단어가 **들어간** 행 모두 (예: 발전 → 발전(UNIT1)·발전/LNG·발전(UNIT2)·발전). 한 PJT 가 여러 막대에 들어갈 수 있음. 표 아래 "사업군에 '발전' 포함" 표시. (위쪽 '사업군' 드롭다운은 예전처럼 정확히 같은 값)
5. **조직도 → 업무 요약**: 사람을 누르면 프로필 아래 '담당 업무 요약' 3칸 — 수행 PJT(진행, 담당자 칸 기준, PJT명·사업군·업무 현황 첫 2줄), 입찰 PJT, 통합 업무(미완료, 상태 배지). `personSummary`, `brief`.
- **확인한 것**: `node --check`. 시험 서버(사업군 '발전(UNIT1)','수소/LNG','발전/LNG' 등 가짜 데이터)에서 입찰 '발전' → 4건, 'LNG' → 3건; 통합 업무 유형 열 필터 To do → 9건; HAZOP 행 [🏁 종결] → 종결·완료로 바뀌고 알림에서 빠짐; 알림 한 번 누름 → '✓ 확인완료'; 조직도 홍길동 → 요약 3칸. 스크립트 오류 없음.

### 2026-10-13 (6) — 통합 업무를 엑셀형 시트로 · 유형(과제 / 지시사항 및 Action List / To Do List) (APP_VERSION 2026-10-13.6 / SERVER_VERSION 2026-10-13.3)
> **서버 재시작 필요** (server.py `SHEETS` 에 `task` 추가 — 예전 서버는 '잘못된 시트'로 거부).
1. **새 시트 `task` (라벨 '통합 업무', 저장 `data/task/`)** — 메뉴 '🚀 통합 업무' = `#task` (예전 주소 `#work` 는 `render()` 에서 `#task` 로 바꿈). 수행·입찰 PJT 처럼 위 = 현황판(`taskHero`), 아래 = 엑셀형 표(셀 선택·더블클릭 편집·행 추가·열 추가·▾ 열 필터·작성 가이드 모두 공통 시트 기능 그대로).
   - 열: 유형(`ttype` select, 필수) · 구분 · 업무 내용(제목) · 담당자 · 요청자 · 시작일 · 종료일 · 종료 구분(기한/상시) · 진척률(%) · 종결 여부 · 진행 사항 · 비고. 표는 유형별로 묶어 정렬(`sortRecs`: 과제 → 지시사항 → To Do → 미지정, `group:'유형'`).
   - 유형 정의 `TASK_TYPES`, 모양 `TT`/`ttOf`(아이콘·색·설명). **진행 사항 작성 틀이 유형별**(`TASK_TPL`): 과제 = 목표/진행 현황/이슈·다음 단계, 지시사항 = 지시 내용/조치 계획(Action)/조치 결과, To Do = `- `. 편집 창에서 유형을 바꾸면 아직 손대지 않은 틀은 그 유형 틀로 바뀜.
   - 작업 칸 [🏁 종결]/[↩ 진행] (`actCell` 의 `data-wclose`, `#content` 클릭 처리 → `workToggleClose`).
2. **현황판 `taskHero`**: 연도 탭(기본 전체) · [＋ 업무 추가](유형 먼저 고름) · 유형 칩 · **유형별 요약 카드 3개**(진행 수, 지연/임박/진행/상시/종결, 종결률 막대, 과제 = 평균 진척률 · 지시사항 = 요청자별 · To Do = 7일 안 마감, 급한 업무 3개 → 누르면 편집) · 상태 KPI(누르면 표 필터 `fstate().wst`) · 부서원별 상·하반기(누르면 담당자 필터) · 종료 현황 막대. 표 필터는 공통 `fstate('task')`(연도 `YEAR_OF.task` = 시작일/종료일, 유형 = `f['유형']`, 담당자 = `owner`, 상태 = `wst`).
3. 상태 규칙(`workItem('task')`): 종결 → 종결(완료) / 상시 → 추적 안 함 / 기한인데 종료일 없음 → 미입력 / 종료일 지남 → **지연**(종결 전까지) / 7일 이내 → 임박 / 그 외 진행 중.
4. **기존 업무 가져오기** (`importLegacy`, `legacyToTask`): 일반업무 → 과제(구분·소구분 합침, 책임자 → 담당자, 종료일 지난 것 → 종결), To do → 지시사항 및 Action List(PO → 담당자, Issue/Target Date → 시작/종료, 완료 O → 종결, 완료 여부·그룹장 추가요청 → 비고), 기술공유 → 과제(구분 '기술공유', 발표자 → 담당자, 발표일 지남 → 종결). 새 ID = `task-` + 원래 ID 라서 두 번 눌러도 중복 없음(409 건너뜀). 예전 시트는 그대로(숨김, 현황판의 버튼으로 열 수 있음). 가져오기 전에는 현황판 위에 안내 띠.
   - 가져온 행의 변경 표시: 마감본에 그 행이 없으면 예전 시트의 원래 행을 `legacyToTask` 로 바꿔 비교(`baseRec`, `freshImport`) → 가져오기만으로 노란 음영·NEW 가 생기지 않음.
5. 알림·요약·홈은 `workRecs()` = 통합 업무 + 아직 안 가져온 예전 행. 완료 알림: 과제 = 지연·임박만, 지시사항·To Do = 종결 전 전부. 홈 '기한 지난 업무' 배지·팝업, KPI '통합 업무 미종결 (기한)'.
- 예전 통합 업무 화면 코드(`renderWork`, `WS`, `workList` 등)는 지움.
- **확인한 것**: `node --check`, `py_compile`. 시험 서버(가짜 데이터)에서 #work → #task, 가져오기 24건(유형 과제/지시사항), 노란 음영 없음, 셀 더블클릭으로 유형 변경, 업무 추가(유형 고르기 → 지시사항 틀 → 과제로 바꾸면 과제 틀), 열 추가 '관련 PJT', 유형 카드 → 표 10건, [🏁 종결] 저장. 스크립트 오류 없음.
- **회사에서 확인할 것**: 서버 재시작 후 통합 업무 화면의 **[기존 업무 가져오기]** 를 한 사람만 한 번 누름 → 각자 자기 업무의 **유형**이 맞는지 고침.

### 2026-10-13 (7) — 통합 업무 유형에 '기술공유' 추가 (APP_VERSION 2026-10-13.7 / SERVER_VERSION 그대로 2026-10-13.3)
> dashboard.html 만 바뀜 (v13.6 을 이미 적용했다면 서버 재시작 필요 없음).
- `TASK_TYPES` = 과제 / 지시사항 및 Action List / To Do List / **기술공유**. `TT['기술공유']` = 💡, 색 `#0b84c6`, 설명 '기술 발표 · 사례 공유 · 세미나 (종료일 = 발표일)'. 과제 설명에서 '기술공유' 뺌.
- 작성 틀 `TASK_TPL['기술공유']` = 1. 발표 주제 / 2. 주요 내용 / 3. 자료 · 질의응답.
- 요약 카드(기술공유): 다음 발표(가장 가까운 종료일·제목·발표자) · 발표 완료 수.
- 완료 알림: 과제·기술공유 = 지연·임박만, 지시사항·To Do = 종결 전 전부.
- 가져오기(`legacyToTask`): 예전 기술공유 → 유형 **기술공유**, 구분 = 'YYYY년 발표'(연도 칸). (v13.6 으로 이미 가져온 경우 기술공유 행은 유형 '과제'·구분 '기술공유' 로 들어가 있음 → 구분 열 ▾ 필터로 '기술공유' 를 골라 유형만 바꾸면 됨)
- **확인한 것**: `node --check`. 시험 서버에서 가져오기 → 과제 8 · 지시사항 9 · 기술공유 7, 기술공유 카드 → 표 7건, 업무 추가 창에 4가지 유형, 기술공유 틀. 스크립트 오류 없음.

### 2026-10-13 (8) — 통합 업무 유형 개편 · 수행/입찰 새 행 맨 위 · 이름 변경 · 툴바 이동 · 게시판 유형·실명 (APP_VERSION 2026-10-13.8 / SERVER_VERSION 2026-10-13.4)
> **서버 재시작 필요** (server.py: 게시판 `kind`·`real`, 이름 문구).
1. **통합 업무 유형** `TASK_TYPES` = **일반업무**(그룹 업무) / **표준화 담당**(ITEM PO) / To Do List / 기술공유 / **그룹장 요청 사항**. 담당자 열 머리 = '담당자 / ITEM PO'. 작성 틀 `TASK_TPL`: 일반업무 = 목표·진행 현황·이슈, 표준화 담당 = 표준화 ITEM·제·개정 현황·검토·배포, 그룹장 요청 사항 = 요청 내용·조치 계획(Action)·조치 결과. 카드 요약: 표준화 담당 = ITEM 수·ITEM PO 수·평균 진척률, 그룹장 요청 = 요청자별. 완료 알림: To Do·그룹장 요청 = 종결 전 전부, 나머지 = 지연·임박.
   - 예전 이름(v13.6~13.7): `TYPE_ALIAS` 과제 → 일반업무, 지시사항 및 Action List → 그룹장 요청 사항. 화면·필터·정렬·편집 창은 `normType()` 으로 새 이름처럼 다룸. 현황판 띠의 [저장된 값도 새 이름으로 바꾸기] (`renameOldTypes`) 로 실제 값도 바꿈. 가져오기 규칙도 일반업무 → 일반업무, To do → 그룹장 요청 사항, 기술공유 → 기술공유.
2. **수행·입찰 행 추가 → 맨 위** (`submitRecord`: order = 가장 작은 order − 10).
3. **이름**: 화면 제목·`<title>`·로그인 화면·server 사용법 문구 '계장ENG그룹 주간업무 Dashboard' → **'계장ENG그룹 Dashboard'**. (운영 폴더 이름 `C:\Claude\계장ENG그룹 주간업무 Dashboard\` 는 그대로 — APPLY.bat 는 `*Dashboard*` 로 찾음)
4. **내 업무 툴바 이동**: 머리(⠿)나 접힌 탭을 끌면 옮겨지고 위치는 브라우저에 기억(`dept-taskbar-pos`), ⠿ 두 번 누르면 원래 자리. `tbDragInit`, `tbPlace`. 끈 뒤 바로 오는 클릭은 무시.
5. **게시판**: 글 유형 `kind` = 💬 블라블라 / 🍻 회식제안 / 📣 VOC (예전 글 = 블라블라), 목록 위 유형 칩(`#bkinds`, 글 수). 글·댓글 작성자 = **익명 / 닉네임 / 실명**. 실명은 브라우저가 보낸 이름이 아니라 **서버가 로그인 계정 본명**으로 기록(`board_author`, `real:true`, 화면 '✔ 이름'). 익명·닉네임은 예전처럼 실명 저장 안 함. server: `api_board_create/update/api_comment_add(…, acc)`, `BOARD_KINDS`, `board_kind`.
- **확인한 것**: `node --check`, `py_compile`. 시험 서버(가짜 데이터): 제목 '계장ENG그룹 Dashboard', 예전 유형 행 2건 → [새 이름으로 바꾸기] 후 유형 = 일반업무 9 · 그룹장 요청 사항 10 · 기술공유 7, 툴바 끌어 옮김 → 새로고침 후에도 같은 자리, 수행 행 추가 → 맨 위, 게시판 회식제안(실명)·VOC(익명) 등록 → 칩 수·필터, API 로 real + 다른 이름을 보내도 계정 본명으로 저장. 스크립트 오류 없음.

### 2026-10-13 (9) — 엑셀 시트 구분대로 유형 나누기 · To do list → To Do List · 부서원 차트 접기 (APP_VERSION 2026-10-13.9 / SERVER_VERSION 그대로 2026-10-13.4)
> dashboard.html 만 바뀜. 서버 재시작 필요 없음.
- **원인**: v13.8 가져오기 규칙이 엑셀 'To do list' 시트를 '그룹장 요청 사항' 으로, '일반업무' 시트 전부를 '일반업무' 로 넣었음 → 회사 화면 To Do List 0건.
- **새 규칙** (`legacyType`, `generalType`): 일반업무 시트는 구분+소구분 글자로 — `ITEM` · `MDL` · `상품 담당` · 단어 `PO` → **표준화 담당**, `지시` · `Action` → **그룹장 요청 사항**, 과제 · 그룹 업무 · 그 외 → **일반업무**. To do list 시트 → **To Do List**, 기술공유 시트 → 기술공유. (회사 일반업무 시트의 구분 값: 과제 (Set-up 중) / 그룹 업무 - 업무 / 지시사항, Action List 등 / ITEM PO/MDL - 상품 담당 · MDL · PO)
- **이미 가져온 행 다시 나누기** (`reclassList`, `reclassify`): ID 가 `task-general-…` / `task-todo-…` 이고 유형이 예전 자동값(일반업무 / 그룹장 요청 사항, 예전 이름 포함)인 행만 대상. 원래 시트 행이 있으면 그 구분으로, 없으면 통합 업무의 구분 칸으로 판단. 사람이 다른 유형으로 고친 행은 건드리지 않음. 현황판 띠의 [유형 다시 나누기] → 확인 창(바뀔 건수) → 저장. 비교 기준(`baseRec` → `legacyToTask`)도 새 규칙이라 다시 나눈 유형 칸은 노란 음영이 생기지 않음.
- **부서원별 상·하반기 차트 반으로 접기**: 7명 이상이면 기본으로 위쪽 절반만(건수 많은 순), 머리의 [▼ 나머지 n명 펼치기] / [▲ 반으로 접기], 아래 [▼ n명 더 보기]. `fstate('task').pfold`.
- **확인한 것**: `node --check`. 시험 서버에서 회사와 같은 구분 값으로 '예전 규칙으로 가져온' 24건을 만들어 [유형 다시 나누기] → To do 9건 → To Do List, 일반업무 시트 7건 → 일반업무 3 · 표준화 담당 3 · 그룹장 요청 1, 사람이 기술공유로 바꿔 둔 행은 그대로, 띠 사라짐. 부서원 14명 → 접으면 7명, 펼치면 14명. 스크립트 오류 없음.
- **회사에서 할 일**: 통합 업무 화면 위 띠의 **[유형 다시 나누기]** 를 한 사람이 한 번.

### 2026-10-13 (10) — 시수 파일 끌어다 놓기 · 미리보기 후 업로드 · 실제 양식(두 줄 머리글) 읽기 · 조직도 꾸미기 (APP_VERSION 2026-10-13.10 / SERVER_VERSION 2026-10-13.5)
> **서버 재시작 필요** (server.py: 두 줄 머리글 읽기, 미리보기 API, 월 지정).
1. **실제 시수 양식 읽기 버그 수정** (`parse_timesheet`): 회사 양식(개인 집계_6월.xlsx)은 머리글이 두 줄 — 1행 `S/O · Project · Work · 2026-07 · Total`, 2행 `OBS · Type · Detail · 01~31`, 3행 요일. 예전 코드는 Type 과 Project 가 같은 줄에 있어야 해서 "머리글을 찾지 못했습니다" 오류. 이제 위·아래 두 줄을 합쳐 머리글을 찾음. 시간 칸은 `h:mm` 서식(하루 비율 ×24), 마지막 'Total' 줄 제외.
   - 받은 6월 파일 시뮬레이션: 9줄 중 시간 입력 2줄(6일 — 공통 계장ENG 주간회의 3:10, D026 4:10), 합계 7:20 = 엑셀 값과 일치. **파일 이름은 6월인데 파일 안 날짜는 2026-07(1일=수요일, 7월 달력)** → 아래 미리보기에서 경고.
2. **끌어다 놓기 → 미리보기 → [업로드 · 분석]** (`openTsUpload(file)`): 업로드 창의 큰 놓기 칸(또는 눌러서 고르기), R&R · 투입 분석 화면 아무 곳에 놓아도 창이 열림. 놓으면 서버 `POST /api/timesheet/preview`(저장 안 함, `api_ts_preview`)로 읽어 파일 안의 월·줄 수·합계·분류(Step 1: 부서업무 / PJT / 미등록 코드) 막대·표·줄별 내용을 보여 줌. 파일 이름의 'N월' 과 파일 안 월이 다르면 경고. **저장할 월**(기본 = 파일 안의 월)을 확인·변경하고 [업로드 · 분석] 을 눌러야 저장(`PUT timesheet?…&useMonth=1` → 화면에서 고른 월 사용).
3. **조직도 꾸미기 v2** (CSS '조직도 v2' 블록, `</style>` 바로 앞): 은하수 배경(빛 번짐·점무늬·천천히 도는 오로라), 빛나는 'ORGANIZATION' 제목, 통계 배지(유닛·인원·프로필 등록·수행/입찰 PJT 수), 유닛마다 다른 색(`--uc`)·번호 배지·담당 분야 칩·인원/PJT 수, 빛나는 연결선, 구성원 카드(유닛 색 띠·마우스 올리면 떠오름·빛), 그룹장 카드 은은하게 빛남. 유닛 열을 grid 로 가운데 정렬(회사 화면에서 오른쪽으로 치우치던 것 수정). 인쇄 때 움직임 끔.
- **확인한 것**: `node --check`, `py_compile`. 받은 6월 파일로 서버 읽기 = 엑셀 값과 일치(7:20). 시험 서버에서 업로드 창에 파일을 끌어다 놓기 → 미리보기(2026-07, 9줄·2줄, 7:20, 6월/7월 경고) → 저장할 월 2026-06 → [업로드 · 분석] → 6월로 저장·분석 화면 갱신. 분석 화면에 놓기 → 창 열림·미리보기. 조직도(유닛 2개·19명) 가운데 정렬·배지·마우스 효과. 스크립트 오류 없음.
- **회사에서 확인할 것**: 각자 시수 파일을 끌어다 놓고 미리보기의 합계가 엑셀 Total 과 같은지, 파일 안 월이 맞는지(템플릿 머리글 '2026-07' 을 고치지 않고 쓰는 경우 저장할 월을 직접 고름).

### 2026-10-13 (11) — 수행·입찰 부서원 그래프 전체 표시·반 접기 · 통합 업무 유형별 필터 분리 · 메뉴 이모지 삭제 (APP_VERSION 2026-10-13.11 / SERVER_VERSION 그대로 2026-10-13.5)
1. **수행·입찰 PJT 보드의 담당자 그래프** (`pjHero`): '상위 8명' → **전체 부서원**('부서원별 진행 PJT · 전체 n명'). 명단 = 진행 PJT 담당자 + 가장 최근 연도 유닛분장의 구성원(그룹장 제외, 새 함수 `deptNames()`) — PJT 0건인 사람도 0 으로 표시. 건수 많은 순 → 이름순. 7명 이상이면 기본으로 **위쪽 절반만**, 머리의 [▼ 나머지 n명 펼치기] / [▲ 반으로 접기], 아래 [▼ n명 더 보기] (`data-pjf="pfold|"`, 상태 `fstate('perform'|'bid').pfold`). 통합 업무 부서원 차트와 같은 방식.
2. **통합 업무: 유형마다 필터 따로** (`taskTypeSwitch(st, 유형)`, `TASK_FKEYS`): 유형 칩·유형 카드·표 위 '유형' 선택 상자로 유형을 바꾸면 지금 유형의 필터(담당자·사람 클릭·내 업무만·검색·종결 여부·현황 카드(지연/임박…)·열 필터·정렬)를 `st.byType[유형]` 에 넣어 두고, 새 유형의 필터를 꺼냄(처음이면 빈 필터). '전체' 도 하나의 유형으로 따로 기억. 연도 탭은 모든 유형이 함께 씀. [필터 초기화] 는 지금 보는 유형의 필터만 지움(연도·유형·다른 유형 기억은 유지).
3. **메뉴 글자**: '👥 R&R · 투입 분석' → 'R&R · 투입 분석', '🚀 통합 업무' → '통합 업무' (메뉴만, 화면 제목은 그대로).
- **확인한 것**: `node --check`. 시험 서버(유닛 2개·18명): 수행·입찰 보드 접힘 9명 / 펼침 18명, PJT 0건인 사람도 표시. 통합 업무 To Do List(9건)에서 사람 클릭 → 3건, 일반업무로 바꾸면 필터 없이 8건, 다시 To Do List → 3건(사람 선택 유지), [필터 초기화] → 9건·유형 유지. 메뉴에 이모지 없음. 스크립트 오류 없음.
- **회사에서 확인할 것**: 부서원 명단은 **가장 최근 연도 유닛분장의 '구성원'** 칸을 씀 — 빠진 사람이 있으면 유닛분장에 추가.

### 2026-10-13 (12) — 시수 파일 삭제 단추 · 통합 업무 진행 상태 필터 · 필터 창 스크롤 유지 · 삭제 취소선 없앰 (APP_VERSION 2026-10-13.12 / SERVER_VERSION 2026-10-13.6)
> **서버 재시작 필요** (server.py: 시수 삭제 때 원본 엑셀도 지움).
1. **올린 시수 파일 삭제** (`openTsDelete(list)`, R&R · 투입 분석 위 **[🗑 올린 파일 삭제]**): 그 연도에 지울 수 있는 파일(본인 것, Management 권한자는 전부)을 부서원·월·파일·올린 사람 목록으로 보여 주고 [삭제] → 확인 → `DELETE /api/timesheet/{id}/{YYYY-MM}`. 아래 '시수 업로드 현황' 표의 ✓ 도 마우스를 올리면 빨간 ✕ 로 바뀌어 눌러서 지울 수 있음(예전부터 있던 기능을 보이게 함). 서버 `api_ts_delete` 는 이제 `timesheets/{YYYY}/raw/{id}_{YYYY-MM}.xlsx` 원본도 함께 지움.
   - 주의: `ask()` 창을 연달아 열 때 앞 창의 close 이벤트가 새 창을 닫아 버리므로 `setTimeout(0)` 한 번 기다린 뒤 다음 창을 엶.
2. **통합 업무 필터** (`renderSheet`, `colVal`):
   - 담당자 옆에 **진행 상태(전체 / 진행 중 / 종결)** 선택 상자 (수행·입찰과 같은 `st.closed`, 유형별 필터 기억에 포함).
   - 머리글 ▾ 필터 목록에서 **'종결 여부' 빈 칸 = '진행'** 으로 보임(값이 '종결' 이 아니면 진행). '종료 구분' 빈 칸 = 화면에 보이는 자동 값('기한' / '상시'). 저장된 값은 그대로.
   - **필터 창(▾)이 마우스 휠로 화면을 굴려도 닫히지 않음** — ▾ 단추를 따라 움직임(`placeCf`). 다른 곳 클릭 · Esc 로 닫힘.
3. **수행·입찰 등 편집 시 '지운 내용 붉은 취소선(~~ ~~)' 기능 없앰**: 편집 창 저장 때 `mergeStrike` 를 쓰지 않고 지운 내용은 그냥 지움(`mergeStrike`·`joinTokens` 삭제). 추가된 내용의 **파란 글씨**(마지막 마감 대비, `markAdded`)는 그대로. 예전에 남은 `~~내용~~` 은 화면(`fmtText`)·엑셀 내보내기(`xlCell`)에서 숨기고, 편집 창에는 안 보이며 그 행을 저장하면 지워짐(`purgeStrike`). 편집 창의 취소선 안내 문구와 [취소선 내용 모두 완전 삭제] 단추 삭제.
- **확인한 것**: `node --check`, `py_compile`. 시험 서버: 시수 3건 올림 → [🗑 올린 파일 삭제] 목록 3줄 → 1건 삭제 → 목록 2줄, json·원본 xlsx 모두 지워짐. 통합 업무 24건 → 진행 상태 '종결' 10 / '진행 중' 14, '종결 여부' 필터 목록 = 종결 10 · 진행 14 (빈 셀 없음), '종료 구분' = 기한 20 · 상시 4. 필터 창 열고 휠 → 창 유지·단추 따라 이동, 다른 곳 클릭 → 닫힘. 수행 행에 `~~예전에 지운 줄~~` 을 넣어 두면 화면에 안 보임, 편집 창에도 안 보임, 내용 추가 후 저장 → 저장값에 ~~ 없음, 추가 부분만 파란 글씨. 스크립트 오류 없음.
- **회사에서 확인할 것**: 서버 재시작 후 시수 삭제. 예전 취소선이 남아 있던 행은 화면에서 사라짐(데이터에서 완전히 지우려면 그 행을 한 번 편집·저장).

### 2026-10-13 (13) — 서버 PC 절전 방지 · 서버가 꺼졌을 때 쓴 내용 '덮어쓸까요?' · 부서원 dashboard.html 자동 교체 (APP_VERSION 2026-10-13.13 / SERVER_VERSION 2026-10-13.7)
> **서버 재시작 필요** (server.py: 절전 방지).
1. **절전 모드** (server.py `keep_awake_loop`, 새 옵션 `--allow-sleep`): 서버가 켜져 있는 동안 1분마다 Windows `SetThreadExecutionState(ES_SYSTEM_REQUIRED)` (ctypes, 표준 라이브러리) → 서버 PC 가 **유휴 절전(대기) 모드로 들어가지 않음**. 화면 끄기·화면 잠금은 그대로 됨. 노트북 덮개 닫기·전원 단추·시작 메뉴 '절전'으로 직접 재우는 것은 못 막음 → 그때는 아래 2번(오프라인)으로 동작. 서버 로그에 `절전 방지: 켜짐`. 절전을 허용하려면 `server.py --allow-sleep` (bat 수정 필요).
2. **서버가 꺼져 있을 때 쓴 내용 → 서버가 켜지면 '덮어쓸까요?'** (`trySync`, 새 `askOverwrite`, `syncOp(op, force)`, `SYNC_HOLD`): 기존 오프라인 모드(부서원 PC 의 dashboard.html = file:// 로 열고 서버 연결 실패 → 이 PC 보관본 표시, 수정은 IndexedDB 대기열)는 그대로. 서버가 다시 연결되면(30초마다 자동 재연결 · [지금 재연결] · 파일을 다시 열 때 `startOnline`) 내 대기열이 있으면 먼저 팝업: 목록(시트·항목·작업·시각) + **[예 (덮어쓰기)]** = 모두 서버에 반영, 그 사이 다른 사람이 같은 행을 고쳤어도 묻지 않고 내 것으로(`force`, 서버 이력에 'overwrite' 로 남음) / **[하나씩 확인]** = 예전처럼 충돌 행만 비교 창 / **[나중에]** = 이 PC 에 보관, 자동 재연결 때는 다시 묻지 않고 배너의 [지금 동기화] 로 다시 물음.
   - 다른 사람이 이 PC 에서 오프라인으로 쓴 것은 예전처럼 그 사람이 로그인했을 때 올림.
   - 서버에 한 번도 연결된 적 없는 PC(보관본 없음)는 오프라인으로 열 수 없음 (안내 화면) — 기존과 같음.
3. **프로그램 업데이트 → '부서원의 dashboard.html 을 업데이트 파일로 교체하세요'** (`askUpdate`, `replaceSelf`, `newHtml`, IndexedDB 키 `self`): file:// 사본의 `APP_VERSION` 이 서버 dashboard.html 버전과 다르면(서버 연결 직후 · 오프라인 대기열 처리 뒤) 팝업 [예 (교체)] / [나중에]. [예] → 서버에서 새 `/dashboard.html`(DEFAULT_SERVERS 치환본) 받기 → File System Access API 로 **이 PC 의 파일을 덮어쓰고 다시 엶**. 처음 한 번은 저장 창이 열림 → 지금 쓰는 dashboard.html 을 골라 [저장] → [바꾸기]. 고른 파일 핸들을 IndexedDB 에 기억 → 다음 업데이트부터는 창 없이 바로(권한 확인 창만 뜰 수 있음). 고른 파일 이름이 지금 연 파일과 다르면 "그 파일을 여세요" 안내. 브라우저가 지원하지 않으면 예전처럼 내려받기. 배너에 [지금 교체] 단추 추가(나중에 → 다시 하기).
4. `ask()` 수정: 창을 연달아 열 때 앞 창의 늦은 close 이벤트가 새 창을 닫던 문제 → `dlg2.onclose` 는 창이 실제로 닫혀 있을 때만 처리.
- **확인한 것**: `node --check`, `py_compile`. 시험: 서버가 준 파일을 부서원 PC 사본처럼 file:// 로 열고(버전 하나 낮춤) → 업데이트 팝업·배너. 서버 끔 → 수행 2행 편집 → 오프라인·대기 2건, 파일을 닫았다 다시 열어도 유지. 서버 켬 + 다른 사람이 같은 행을 서버에서 고침 → [지금 재연결] → '덮어쓸까요?' 목록 2건 → [예] → 충돌 창 없이 두 행 모두 내 내용으로 서버 반영. 이어서 업데이트 팝업 → [예] → 새 버전(2026-10-13.13) 파일 내용을 저장 (자동 시험이라 저장 창은 흉내). 스크립트 오류 없음. (절전 방지는 Windows 전용이라 여기서는 문법만 확인)
- **회사에서 확인할 것**: 서버 로그에 '절전 방지: 켜짐'. 부서원 PC 한 대에서 [예 (교체)] → 저장 창에서 지금 쓰는 dashboard.html 고르기 → 다시 열린 화면 왼쪽 아래 버전이 새 버전인지. 회사 보안 정책이 파일 저장 창을 막으면 [새 버전 다운로드] 로.

### 2026-10-13 (14) — 서버 PC 를 사내 Wi-Fi 로 쓸 때 부서원 접속 (APP_VERSION 2026-10-13.14 / SERVER_VERSION 2026-10-13.8)
> **서버 재시작 필요** (server.py). 새 파일 `allow_firewall.bat`, `check_network.bat` (서버 폴더, ASCII · CRLF · chcp 없음).
- **증상**: 서버 PC 가 유선 LAN 일 때는 부서원 접속 OK, LAN 을 빼고 사내 Wi-Fi 로 바꾸면 접속 안 됨.
- **원인 후보와 대응**
  1. (코드) **허용 대역이 서버 시작 때 한 번만 정해짐**: `ALLOW_NETS` = 서버 IP 의 /16. 회사 IP 가 사설망(10.x·172.16~31.x·192.168.x)이 아니면, 서버가 Wi-Fi IP 로 시작했을 때 유선 부서원 대역이 '사내망 아님' 403 으로 거절됨(부서원 화면에는 그냥 '서버 연결 실패'로 보였음). → `refresh_nets()`: 30초마다(`weekly_loop`) IP 를 확인해 **지금까지 쓴 모든 /16 대역을 `data/_meta/server-nets.json` 에 기억**하고 계속 허용. 403 메시지에 접속 PC 주소 포함, 부서원 화면에 그대로 표시(`BLOCKED`).
  2. (코드) **IP 가 바뀌면 부서원 파일의 서버 주소가 옛 IP**: 배포본 `DEFAULT_SERVERS` = [PC 이름 주소, IP 주소]. → 배포본을 IP 가 바뀔 때도 다시 만듦(`_build_deploy` 기준 = 파일 시각 + `server_urls()`). 부서원 화면은 연결될 때마다 서버 주소들(`info.urls` + 지금 주소)을 localStorage `dept-server-known` 에 기억하고, 연결할 때(`findServer`: 시작 · 오프라인 재연결 `trySync`) **설정 주소 → 기본 주소 → 기억한 주소를 동시에** 시도(각 8초). 'PC 이름' 주소는 IP 가 바뀌어도 사내 DNS 가 새 IP 를 알려 주면 그대로 됨.
  3. (Windows) **Wi-Fi 가 '공용 네트워크'** 이거나, 처음 'python 액세스 허용?' 창에서 공용을 빼서 생긴 **python 차단 규칙**(차단이 허용보다 우선) → 방화벽이 막음. 서버가 시작·IP 변경 때 `Get-NetConnectionProfile` 로 네트워크 종류를 로그에 남기고(`net_profiles`), 서버 PC 관리자 화면에 '공용 네트워크' 경고 배너 · IP 바뀜 배너(`/api/info` 의 `net`, 관리자만). **`allow_firewall.bat`**(관리자 권한): TCP 8080 인바운드 허용(모든 네트워크 종류) + python 인바운드 차단 규칙 끄기 + 네트워크 종류·IP 표시.
  4. (회사망) **사내 Wi-Fi 와 유선망이 서로 막혀 있음**(무선 단말 간 격리·방화벽) → 코드로 못 고침. `check_network.bat`(관리자 권한 불필요): 네트워크 종류, IP, 서버 응답, 8080·python 방화벽 규칙, 방화벽 상태를 화면과 `network_check.txt` 로 보여 줌 → 3 이 아닌데도 안 되면 IT 문의.
- **바뀐 곳**: server.py `refresh_nets`, `net_profiles`, `nets_file`, `NET_STATE`, `EXTRA_NETS`, `_build_deploy`, `weekly_loop`, `main`, `_dispatch`(403 메시지), info / dashboard.html `findServer`, `rememberServers`, `serverCandidates`, `knownServers`, `BLOCKED`, `trySync`, init(file://), `render` 관리자 배너.
- **확인한 것**: `node --check`, `py_compile`, bat ASCII·CRLF. 서버 함수 시험: 유선 65.3.x → Wi-Fi 165.244.x 로 IP 바꿈 → 허용 대역 두 개 모두(유선 부서원 65.3.99.1 허용, 외부 8.8.8.8 거절), Wi-Fi 상태로 다시 시작해도 유선 대역 유지, 배포본 주소가 새 IP 로 바뀜. 화면 시험: 부서원 파일로 한 번 연결 → 주소 기억 → 기본 주소가 닿지 않는 파일로 열어도 1.7초 만에 기억한 주소로 연결. 관리자 화면 경고 배너(Windows 정보는 흉내). bat 은 Windows 에서만 실행 가능해 여기서는 형식만 확인.
- **회사에서 할 일**: ① 서버 재시작 ② 서버 PC 를 Wi-Fi 로 바꾼 뒤 `check_network.bat` → 'Public' 이나 python 'Block' 이 보이면 `allow_firewall.bat` 를 관리자 권한으로 ③ 부서원 PC 에서 `http://서버PC이름:8080/` 이 열리는지, 안 되면 `http://(Wi-Fi IP):8080/` ④ 둘 다 안 되면 IT 에 '사내 Wi-Fi ↔ 유선 PC 간 TCP 8080 허용' 요청.

### 2026-10-13 (15) — Management 메뉴: R&R · 투입 분석(실제 시간 병기) · 근무시간(월별·주별·일별) (APP_VERSION 2026-10-13.15 / SERVER_VERSION 2026-10-13.9)
> **서버 재시작 필요** (server.py: Management 권한자에게 일별 시간도 보냄).
1. **메뉴**: '🛠 Management' 가 하위 메뉴 묶음이 됨(접기/펼치기, localStorage `dept-nav-mgmt-open`) — **R&R · 투입 분석**(route `mgalloc`) · **근무시간 (월·주·일)**(route `mghours`). 머리(#mgmt)를 누르면 #mgalloc 으로. 두 화면 모두 메뉴 권한 키 `mgmt`(`menuOf`). 예전 `MODULES.mgmt`(준비 중 빈 화면) 삭제.
2. **R&R · 투입 분석 두 곳으로 나눔** (`renderAlloc(c, mg)`): 같은 화면·같은 데이터, 표시만 다름. `H` = 서버가 실제 시간을 줌(권한), `SH = H && mg` = 화면에 시간 표시.
   - 주간업무보고 › R&R · 투입 분석(`alloc`): **누구나 비율(%)만**. Management 권한자에게는 '실제 시간은 [Management › R&R · 투입 분석]' 단추.
   - Management › R&R · 투입 분석(`mgalloc`): **비율과 실제 시간 병기** — 예: `54.6% (116:00h)`, 프로젝트별 `53.6% … 437:40h`, 부서원 막대 오른쪽 총 시간, 도넛 가운데 총 시간, R&R 표 실제 투입 `54.6% 116:00h`, 월별 추이 위 월 합계.
   - 시수 올리기·삭제는 두 곳 모두.
3. **근무시간 (월·주·일)** (`renderHours`, `hoursIndex`, 상태 `HS`): 시수 파일의 **날짜별 실제 시간**(rows[].days)으로 부서원 × 기간 표.
   - [📅 월별] 1~12월 · [🗓 주별] 월요일~일요일(연간 = 시수가 있는 주만, 월 선택 = 그 달에 걸친 주 — 달 경계 주는 앞뒤 달 시간 포함 '그 주 전체') · [📆 일별] 한 달 1~31일(요일, 주말 회색).
   - 칸 색: 많을수록 진하게, **주 52시간 초과 · 하루 10시간 초과는 붉게**. 합계 열 · 평균 열(입력 있는 달/주/날 기준) · 팀 합계 줄.
   - 요약: 팀 총 근무시간, 1인 평균, 근무일 평균(하루), 하루 10시간 초과 일수(최장일), 주 52시간 초과 건수(사람 × 주).
   - 이름을 누르면 개인 상세: 날짜별 막대(PJT / 부서업무 / 기타·미등록 쌓기, 점선 = 8시간) + 합계·비율.
4. **server.py `api_ts_list`**: Management 권한자(`can_hours`)에게만 행마다 `days`(날짜 → 시간)를 더 보냄. 일반 부서원 응답은 그대로(비율 단위, days 없음).
- **확인한 것**: `node --check`, `py_compile`. 시험 서버(4명 × 6~9월 시수, 김철수 7/13~17 매일 11시간): 다른 PC 주소로 접속 시 일반 부서원 `canHours false · days 없음`, Management `true · days 있음`. Management 메뉴 하위 2개, #mgmt → #mgalloc. Management › R&R = `%(h)` 병기, 주간업무보고 › R&R = 같은 사람이어도 시간 안 보임. 근무시간 월별 김철수 6~9월 201:50 / 212:30 / 184:00 / 200:20 = 엑셀 합과 같음, 7월 주별 7/13~7/19 55:00 붉은 칸·52시간 초과 1건, 일별 34열(1~31+합계·평균), 개인 상세 23일·212:30h·PJT 93%. 일반 부서원은 메뉴 없음·주소로 들어와도 '접근 권한 없음'. 스크립트 오류 없음.
- **회사에서 확인할 것**: 시수 파일의 Total 과 근무시간 화면의 그 달 합계가 같은지.

### 2026-10-13 (19) — 13.15 로 되돌린 뒤 시수 Type 분류만 추가 (APP_VERSION 2026-10-13.19 / SERVER_VERSION 그대로 2026-10-13.9)
> **되돌림**: 사용자 요청으로 dashboard/ 전체를 2026-10-13.15 (커밋 5707be4, Management 근무시간까지) 상태로 되돌림. 그 뒤에 만들었던 13.16(net_check.py · PowerShell 없는 점검 bat · 서버 netsh), 13.17(보관 상태 표시), 13.18(파일에 데이터 담기 EMBED) 은 **회사에 적용하지 않음** — git 기록(커밋 2d8be53 · 2f76d28 · 7e39f99)에만 있음. 회사 운영본은 13.15 에서 이 변경으로 바로 감. 서버 재시작 필요 없음(server.py 는 13.15 와 같음).
- **시수 Type 분류** (`tsClass`, `tsIsPjtType`):
  - Type **'근태'** → '근태' 한 묶음 (kind `leave`, 노랑) — 여러 줄이어도 하나로, Project 코드가 있어도 무시.
  - Type **'공통'** → 부서업무 (전과 같음).
  - Type **'성과품'**으로 시작(성과품 · 성과품 과정관리 · 성과품 과정정리 …) 또는 **'신사업'** → Project Code 로 수행·입찰 PJT 찾기. **Project Code 가 비어 있으면 '입찰 (Project Code 없음)'** (kind `bid`, 입찰 PJT 로 셈). 코드가 있는데 PJT 에 없으면 전처럼 '미등록 코드'.
  - **그 밖의 Type**(교육 등) → Type 이름 그대로 (kind `other`, '기타 Type'), 코드가 있어도 PJT 로 안 셈.
- R&R · 투입 분석: 근태 KPI 추가(`.alkpis` 6칸), 부서업무 KPI 에 기타 Type %, 프로젝트별 순서 프로젝트 → 미등록 → 기타 Type → 부서업무 → 근태(`AL_RANK`). 업로드 미리보기·설명 문구도 새 규칙.
- 근무시간 화면(`hoursIndex`, `renderHours`): **근태는 근무시간에서 뺌**(합계 · 주 52시간 · 하루 10시간 계산 제외), 요약 '근태 ○h 제외', 개인 상세에 근태 따로.
- **확인한 것**: `node --check`. 시험 시수(공통 · 성과품 과정관리 19LT · 성과품 과정관리 코드 없음 · 신사업 코드 없음 · 근태 X1 · 교육 19LT): 입찰 (Project Code 없음) 52:00h, 예시수행-A 45:00h, 교육 17:00h(기타 Type), 부서업무 15:00h, 근태 20:00h → 프로젝트 투입 65.1%(입찰 포함), 근무시간 129:00h = 149 − 근태 20. 스크립트 오류 없음.

### 2026-10-13 (20) — 시수 분류 규칙 다시 정함: Project Code 우선 (APP_VERSION 2026-10-13.20 / SERVER_VERSION 그대로 2026-10-13.9)
- **규칙** (`tsClass`, 위에서부터 차례로):
  1. Type **'근태'** → 근태 (Project Code 가 있어도 무시).
  2. **Project Code 가 있으면** (Type 상관없음) → 수행·입찰 PJT 의 'Project Code' 칸과 대조해 **수행 / 입찰**. 어느 PJT 에도 없으면 '미등록 코드 ○○'.
  3. 코드 없음 + Type **'공통'** + Detail 에 **'입찰'** 이 들어 있으면 → **입찰** ('입찰 (공통 · Detail 입찰)', kind `bid`).
  4. 코드 없음 + Type **'공통'** (그 밖의 Detail) → **부서업무**.
  5. 코드 없음 + Type **'성과품'**(성과품 · 성과품 과정관리 · 과정정리 …) · **'신사업'** → **입찰** ('입찰 (Project Code 없음)') — 코드가 없어 수행 PJT 를 알 수 없으므로 13.19 규칙 유지.
  6. 코드 없음 + 그 밖의 Type(교육 등) → Type 이름 그대로 (기타 Type).
  - 13.19 와 다른 점: 코드가 있으면 Type 이 무엇이든(공통 · 교육 등) PJT 로 셈. 공통 + Detail 입찰 → 입찰.
- 화면 설명·업로드 창 '집계 방법' 문구도 새 규칙으로. 근태는 근무시간에서 빼는 것 그대로.
- **확인한 것**: `node --check`. 시험 시수 10줄(공통 회의 / 공통 Detail 입찰 / 공통 D026 / 성과품 과정관리 19LT / 성과품 코드 없음 / 신사업 B205 / 교육 A101 / 교육 코드 없음 / 근태 A101 / 성과품 과정관리 Z999) → 부서업무 19h · 입찰(공통 Detail 입찰) 18h · 예시입찰-A 22h · 예시수행-A 34h · 입찰(코드 없음) 13h · 예시입찰-C 21h · 예시수행-B 18h · 교육(기타) 14h · 근태 22h · 미등록 Z999 16h. 근무시간 175h = 197 − 근태 22. 스크립트 오류 없음.

### 2026-10-13 (21) — Management › R&R · 투입 분석: 근태를 누르면 날짜별 근태 상세 (APP_VERSION 2026-10-13.21 / SERVER_VERSION 그대로 2026-10-13.9)
- Management › R&R · 투입 분석(`mgalloc`)의 **🌴 근태** KPI 칸이 단추가 됨(`data-aleave`, 상태 `AS.leave`) → 누르면 KPI 아래에 **근태 상세** 카드(`leaveCard`): 지금 고른 기간(**연간** 또는 **월**)에 부서원별 근태 합계 · 일수 · **날짜별 칩**(월/일 · 요일 · 시간 · Detail 예: 연차/반차, 8시간 이상은 진하게). 월 탭을 바꾸면 그 달만. 다시 누르거나 [닫기]로 닫힘.
- 데이터: 시수 파일의 Type '근태' 줄(`tsClass` kind `leave`)의 날짜별 시간(`rows[].days`, Management 권한자에게만 서버가 보냄).
- 주간업무보고 › R&R · 투입 분석(비율만)에서는 단추 아님(그대로 %만).
- **확인한 것**: `node --check`. 시험: 근태 칸 누름 → 연간 98:00h · 46일 날짜별 칩(Detail 연차·반차), 12월 → 22:00h · 14일, 7월 → '근태 기록이 없습니다', 주간업무보고 쪽에는 단추 없음. 스크립트 오류 없음.

### 2026-10-13 (22) — 근무시간 막대그래프 색: 평일 파랑 · 주말/공휴일 빨강 · 근태 회색 (APP_VERSION 2026-10-13.22 / SERVER_VERSION 그대로 2026-10-13.9)
- Management › 근무시간 › 이름 클릭 → 날짜별 막대(`renderHours` 의 `bar`): 그날 **근무 시간**을 한 덩어리로 — **평일 = 파랑**(`.hc-work`), **주말·공휴일 = 빨강**(`.hc-off`) — 그 위에 **근태 = 회색**(`.hc-leave`)을 쌓음(예: 반차 4h 근무 + 4h 근태). 근태만 있는 날도 회색 막대로 보임. 막대 위 숫자 = 근무+근태, 마우스 = 근무·PJT·부서업무·기타·근태 내역. 공휴일은 날짜 아래 '휴'.
- 요약줄: 총 근무 · 근무일(근무시간 있는 날) · 일 평균 · **주말·공휴일 근무 ○h (○일)** · 근태 ○h(근무시간에서 제외) · PJT/부서업무/기타 비율(글자).
- **공휴일 목록** `HOLIDAYS` (2024~2027, 대체공휴일·선거일 포함, `isOff(dt)` = 토·일 또는 공휴일). 일별 표 머리글의 빨간 날짜도 공휴일까지. **회사에서 확인할 것**: 목록이 회사 달력과 맞는지(특히 2027년 · 임시공휴일), 회사 휴일(창립기념일 등)·2028년 이후는 `HOLIDAYS` 에 'YYYY-MM-DD' 추가.
- **확인한 것**: `node --check`. 시험 시수 2026-09(평일 8h, 9/5 토 4h, 9/24 추석 6h, 9/10 근태 8h, 9/11 근무 4h + 근태 4h): 막대 평일 파랑 · 9/5·9/24 빨강 · 9/10 회색 · 9/11 파랑+회색, 요약 '주말·공휴일 근무 10:00h (2일)', 머리글 빨간 날 = 주말 + 9/24·25·26·28. 스크립트 오류 없음.

### 2026-10-13 (23) — 내 업무: 매달 첫째 주 '직전 달 시수 파일 올리기' · 🔔 알림은 그 업무 행으로 이동만 (APP_VERSION 2026-10-13.23 / SERVER_VERSION 그대로 2026-10-13.9)
1. **시수 할 일** (`myTasks`, `TS_DUE`, `tsDueMonth`, `tsDueFrom`, `tsDueCheck`): 로그인한 부서원(서버 연결 시)의 '내 업무'(접속 팝업 · 오른쪽 툴바)에 **'⏱ 시수 · ○월 시수 입력 파일 올리기'**(○ = 직전 달).
   - 표시: 매달 **1~7일(첫째 주)**. 직전 달 내 시수 파일(서버 `timesheets?year=` 목록에서 내 ID · 그 달)이 **없으면 '미완료'** — 첫째 주가 지나도 올릴 때까지 계속 표시. 올리면 '완료'(첫째 주 동안만 '완료'로 보이고 그 뒤 사라짐).
   - 누르면 R&R · 투입 분석(#alloc)으로 가서 **시수 올리기 창**이 열림. 올리면(`openTsUpload` 성공 · `loadTs`) 바로 완료로 바뀜.
   - 접속 때 `startOnline` 에서 `tsDueCheck()` 후 `showMyTodo()`.
2. **🔔 통합 업무 알림 클릭** (`startTask` 의 `__ack`): 예전 = 확인완료만. 이제 **확인완료 + 그 업무 행으로 이동**(`jumpTo(key, rid, 제목 칸, false)` — 칸 선택·깜빡임, **편집 창은 열지 않음**).
- **확인한 것**: `node --check`. 날짜를 고정해 시험(김철수, 직전 달 10월): 11/3 미업로드 → '10월 시수 입력 파일 올리기 · 미완료', 누르면 #alloc + 올리기 창 / 11/20 미업로드 → 여전히 미완료 / 10월 올린 뒤 11/3 → '✓ 완료' / 11/20 → 표시 안 됨. 홍길동 🔔 To Do 알림 클릭 → #task 로 이동, 그 행 칸 선택, 편집 창 없음, 툴바 '확인완료'. 스크립트 오류 없음.

### 2026-10-13 (24) — 시수: 코드 없음 + 공통 + Detail 교육 → '교육' (APP_VERSION 2026-10-13.24 / SERVER_VERSION 그대로 2026-10-13.9)
- `tsClass` ③ 에 추가: Project Code 없음 + Type '공통' + Detail 에 **'교육'** 이 들어 있으면(교육 · 안전교육 · 사내교육 …) → **'교육'** (키 `__type:교육`, kind `other` — Type 이 '교육' 인 줄과 같은 한 묶음). 순서: Detail '입찰' → 입찰 먼저, 그다음 '교육', 나머지 → 부서업무. Project Code 가 있으면 전처럼 코드 우선(수행/입찰).
- 근무시간 화면에서는 교육도 근무시간(기타)으로 셈. 설명 문구 갱신.
- **확인한 것**: `node --check`. 시험 시수(이영희 8월: 공통·회의 16h / 공통·입찰 15h / 공통·교육 19h / 공통·안전교육 22h / Type 교육 11h / 공통·교육·A101 23h) → 교육 52h(19+22+11) · 예시수행-B 23h · 부서업무 16h · 입찰 15h. 스크립트 오류 없음.

### 2026-10-13 (25) — 근무시간: 주말·공휴일 출근 현황 · 시수 업로드 월 = 파일 안의 월 (APP_VERSION 2026-10-13.25 / SERVER_VERSION 그대로 2026-10-13.9)
> 회사 운영본은 13.22 → 이번 zip 으로 13.23(시수 할 일 · 알림 이동) · 13.24(공통+교육 → 교육) · 13.25 를 한꺼번에 받음.
1. **Management › 근무시간 — 주말·공휴일 출근 현황** (`renderHours`): 선택 기간(연간/월)에 토·일·공휴일(`isOff`, `HOLIDAYS`)에 근무시간이 있는 날(근태 제외).
   - KPI 칸 **'🗓 주말·공휴일 출근 ○일'** (○명 · ○h).
   - 카드 **'🗓 주말·공휴일 출근 현황'**: 부서원별 출근 일수 · 시간 · 날짜 칩(월/일 · 요일 · 시간, 공휴일은 '공휴일' 표시·진한 빨강). 줄을 누르면 그 사람 날짜별 막대(아래 개인 상세).
2. **시수 업로드 월** (`openTsUpload`): 파일 이름의 'N월'이 아니라 **파일 안의 월**(머리글 '2026-07' 등)로 저장 — 찾으면 '저장할 월' 칸을 그 값으로 **고정**(바꿀 수 없음), 이름과 다르면 'ℹ 파일 이름은 6월이지만 파일 안의 월 2026-07 로 저장합니다'. 파일 안에서 월을 못 찾을 때만 직접 고름.
- **확인한 것**: `node --check`. 근무시간 연간 '주말·공휴일 출근 31일 4명', 9월 14일 · 카드에 9/6(일) · 9/24·25·28(공휴일) 등, 줄 클릭 → 개인 막대. 받은 6월 파일(이름 6월 · 안 2026-07) 끌어다 놓기 → 저장할 월 2026-07 고정 + 안내. 스크립트 오류 없음.

### 2026-10-13 (26) — LOGIC 분석 메뉴 (P&ID 분석과 같은 방식) (APP_VERSION 2026-10-13.26 / SERVER_VERSION 2026-10-13.11)
> **서버 재시작 필요** (server.py: 메뉴 권한 목록에 LOGIC 분석). SERVER_VERSION 은 되돌린 13.10 과 겹치지 않게 13.11.
- 메뉴 **'🔀 LOGIC 분석'** (route `logic`, P&ID 분석 바로 아래). P&ID 분석과 같은 틀(`PID_ROUTES` 를 일반화): 대시보드 서버와 **같은 호스트의 포트 8001**(`PID_ROUTES.logic.port`)에서 `/version`(JSON) 을 3초 안에 확인 → 되면 `/?embed=1&user=본명` 을 화면 가득 iframe, 안 되면 'LOGIC 분석 서버가 꺼져 있습니다 — LOGIC 분석 서버(포트 8001) 을 확인하세요' + [다시 시도]. 위쪽 '새 창으로 열기 ↗'.
  - `pidBase(key)`, `pidUrl(key)`, `renderPid`, `pidConnect` 가 key 별 제목·포트·안내(`svc`) 사용. P&ID(8000) 동작은 그대로.
- **LOGIC 분석 도구 자체는 아직 없음** — 별도 프로그램(P&ID 추출 도구처럼)을 포트 8001 로 띄우면 연결됨. 필요한 것: `GET /version` → JSON, `GET /?embed=1&user=…` → 화면, 다른 출처(iframe) 허용.
- 메뉴 권한: server.py `MENUS` 에 `('logic', 'LOGIC 분석')` → ⚙ 메뉴 권한 설정에 칸 생김, 기본 허용(`DEFAULT_PERMS`).
- **확인한 것**: `node --check`, `py_compile`. 시험: 메뉴 순서 P&ID 분석 → LOGIC 분석, 8001 꺼짐 → 안내·다시 시도, 시험용 가짜 LOGIC 서버(8001) 켬 → [다시 시도] → iframe(`http://서버:8001/?embed=1&user=홍길동`)에 화면 표시, P&ID 분석은 그대로(8000 안내), 권한 목록·info.perms 에 logic. 스크립트 오류 없음.

### 2026-10-13 (27) — 시수 파일 여러 개 한꺼번에 올리기 (APP_VERSION 2026-10-13.27 / SERVER_VERSION 그대로 2026-10-13.11)
- `openTsUpload(files)`: 올리기 창 놓기 칸 · R&R 화면 아무 곳에 **여러 .xlsx 를 한꺼번에** 끌어다 놓거나 파일 고르기(`multiple`)로 여러 개 선택 가능. 1개면 예전 그대로(미리보기 상세 · 월 고정).
- 여러 개(`takeMany`): 파일마다 서버 미리보기(`POST timesheet/preview`, 저장 안 함)를 차례로 → 한 표: 파일 · **저장할 월 = 파일 안의 월** (못 찾으면 그 줄에서 직접 고름) · 시간 있는 줄 수 · 합계 · 분류 막대 · 상태. 월 순서로 정렬. **.xlsx 가 아닌 파일은 빼고 안내**, **같은 달 파일이 여럿이면 '중복' 표시 + 아래쪽(나중) 것이 덮어씀** 안내.
- [⬆ N개 업로드 · 분석] → 같은 부서원(위 선택)으로 하나씩 `PUT timesheet?…&useMonth=1` → 모두 되면 창 닫고 연간 보기로 다시 그림, 실패가 있으면 창에 남기고 상태 칸에 이유.
- **확인한 것**: `node --check`. 시험: 박민수 1~6월 6개 + 3월 수정본 + 메모.txt 를 R&R 화면에 한꺼번에 놓기 → 7개 표(월 2026-01~06, 3월 '중복'), txt 제외 안내 → [7개 업로드] → 서버에 1~6월 저장(3월은 수정본). 파일 1개 올리기(받은 6월 파일 → 2026-07 고정)도 그대로. 스크립트 오류 없음.

### 2026-10-13 (28) — LOGIC 분석 메뉴를 실제 LOGIC 검토 화면(P&ID 서버 8000 의 /logic)에 연결 (APP_VERSION 2026-10-13.28 / SERVER_VERSION 그대로 2026-10-13.11)
- 13.26 에서 LOGIC 분석을 '별도 서버 8001' 로 잡았던 것을 바로잡음: LOGIC 검토는 **P&ID 추출 도구와 같은 서버(부서장 PC 8000)** 에 들어 있음 — 브랜치 `claude/logic-review-design-pd2z75`(L1~L19)를 P&ID 브랜치에 결합(hotfix89~), 화면 주소 **`/logic`** (`app/logic/api.py` 의 `GET /logic` → `logic.html`, `?user=` 를 작성자 이름으로 읽음).
- `PID_ROUTES` 에 `path` 추가: pid → `/`, logic → `/logic`(포트 둘 다 `PID_PORT` 8000). iframe 주소 `http://<대시보드 서버 호스트>:8000/logic?embed=1&user=<본명>`. 살아 있나 확인은 같은 `/version`. 꺼져 있으면 '…부서장 PC 의 run_lan_service.bat (P&ID 분석과 같은 서버)' 안내.
- 필요 조건: 부서장 PC 의 P&ID 도구가 LOGIC 이 결합된 판(hotfix89 이후, 최신 hotfix93)이어야 함. 그 전 판이면 /logic 이 없어 iframe 에 404.
- **확인한 것**: `node --check`. 실제 P&ID 도구(브랜치 claude/titleblock-parsing-c5st4x = hotfix93 · LOGIC L19)를 시험 PC 에서 8000 으로 켜고 대시보드 → '🔀 LOGIC 분석' → iframe `…:8000/logic?embed=1&user=홍길동`, 화면 제목 'LOGIC 검토', 'Logic 분석 · 어디에 넣을지 · 자료(Logic Diagram 필수 · Loop · System Description · IO List · Logic Table)' 표시. P&ID 분석은 `…:8000/?embed=1&user=…` 그대로. 스크립트 오류 없음.

### 2026-10-13 (29) — 근무시간: 부서원을 누르면 위 숫자가 그 사람 값 · 하루 8시간 기준 · 주 52시간 칸 삭제 (APP_VERSION 2026-10-13.29 / SERVER_VERSION 그대로 2026-10-13.11)
- Management › 근무시간 위 KPI 칸(`renderHours` 의 `kdl` · `kTot` · `kPM` · `kOver8` · `kOff`): 표·주말 현황에서 **부서원 이름(줄)을 누르면**(`HS.person`) KPI 가 **그 사람 값**, 안 누르면 팀 전체. 큰 칸에 '팀 전체 보기' 단추.
  - 칸: **총 근무시간** · **(1인) 월 평균** = 근무시간 ÷ 근무시간이 있는 (사람×)달 수 · **근무일 평균** · **하루 8시간 초과** 일수(최장일) · **주말·공휴일 출근일** · **주말·공휴일 근무시간**(하루 평균). **'주 52시간 초과' 칸은 뺌**.
- 일별 표의 붉은 칸 기준 하루 10시간 → **8시간**(머리글 안내도). 주별 표는 주 52시간 초과 붉게 그대로.
- **확인한 것**: `node --check`. 9월 팀: 753h · 1인 월 평균 188:15 · 8시간 초과 47일 · 주말·공휴일 14일 111h → 홍길동 누름: 150h · 월 평균 150h · 근무일 평균 7:30 · 8시간 초과 0일 · 주말·공휴일 2일 · 10h(시험 파일과 같음) → 연간으로 바꿔도 홍길동 값 유지 → '팀 전체 보기'로 복귀. 일별 9월 붉은 칸 = 8시간 초과. 스크립트 오류 없음.

### 2026-10-13 (30) — LOGIC 분석 메뉴를 요청 사양 그대로 (APP_VERSION 2026-10-13.30 / SERVER_VERSION 그대로 2026-10-13.11)
- 요청 사양: 주소 `http://<P&ID 서버 PC>:8000/logic?user=<로그인 이름>`(P&ID 메뉴와 같은 서버 주소, /logic 만 다름) · 살아 있나 = `:8000/version` · 꺼져 있으면 P&ID 와 같은 안내 · user = P&ID 메뉴와 같은 로그인 이름(LOGIC 메모 작성자).
- 13.28 과 다른 점 두 가지를 맞춤: ① LOGIC 주소에서 `embed=1` 을 뺌 → `/logic?user=본명` (P&ID 는 그대로 `/?embed=1&user=본명`, `PID_ROUTES[key].q`) ② 꺼졌을 때 안내를 두 메뉴 모두 **'P&ID 서버가 꺼져 있습니다 — 부서장 PC 의 run_lan_service.bat 을 확인하세요'**(`PID_OFF`).
- **확인한 것**: `node --check`. 8000 꺼짐 → LOGIC · P&ID 모두 같은 안내 + 다시 시도. 실제 P&ID/LOGIC 도구(hotfix93)를 8000 으로 켬 → LOGIC iframe `http://서버:8000/logic?user=홍길동`, 화면 제목 'LOGIC 검토', 도구 쪽 `user` = 홍길동 / P&ID iframe `…:8000/?embed=1&user=홍길동` 그대로. 스크립트 오류 없음.

### 2026-10-14 (31) — 수행·입찰 행 추가 → 정렬·필터와 상관없이 맨 위 + 그 행으로 이동 (APP_VERSION 2026-10-13.31 / SERVER_VERSION 그대로 2026-10-13.11)
- 13.8 부터 새 행의 order = 가장 작은 order − 10 이라 **기본 순서**에서는 맨 위였지만, ① 머리글 ▾ **열 정렬**을 걸어 두면 정렬 자리로 들어가고 ② 사업군 등 **필터**에 안 맞으면 안 보이고 ③ 화면을 내려 둔 상태면 위가 안 보여 '맨 위로 안 올라간다' 로 보였음.
- `submitRecord`(새 행, 수행·입찰): 만든 행 id 를 `NEW_TOP[시트]` 에 넣고 `filteredRecs` 마지막에 **정렬·필터와 상관없이 맨 위에 고정**(이 화면을 새로고침할 때까지 — 새로고침 뒤에는 order 가 가장 작아 기본 순서에서 맨 위). 그리고 `JUMP` 로 그 행의 PJT명 칸으로 **스크롤 + 깜빡임**.
- **확인한 것**: `node --check`. 시험: 화면을 내린 상태에서 추가 → 맨 위 · 보임 / PJT명 오름차순 정렬 중 '가가…' · '하하…' 추가 → 둘 다 각각 맨 위 / 사업군 'LNG' 필터 중 '발전' 행 추가 → 맨 위에 보이고 깜빡임 / 새로고침 → 맨 위. 스크립트 오류 없음.

### 2026-10-14 (1) — [금주 마감] = 바로 마감하고 다음 주차로 (APP_VERSION 2026-10-14.1 / SERVER_VERSION 2026-10-14.1)
> **서버 재시작 필요** (server.py).
- 예전: [금주 마감] 은 그 시각 데이터를 이번 주 마감본으로 '미리' 저장할 뿐, 주차는 수요일 12:00 까지 그대로였고 수요일 자동 마감이 그 마감본을 다시 덮어씀.
- 이제: **누르지 않으면** 지금처럼 수요일 11:59 에 자동 마감. **누르면** 그 순간 이번 주차로 마감하고 **바로 다음 주차로 넘어감**.
  - server.py: `api_close` 가 `state.json` 에 `manualClosedWeek` = 마감한 주차 기록. `iso_week()` 는 시간으로 정한 주차가 `manualClosedWeek` 이하이면 그다음 주(`manual_closed_week`). `auto_close` 는 그 주 마감본이 수동이고 `manualClosedWeek` ≥ 그 주면 덮어쓰지 않음(예전 방식으로 만든 수동 마감본은 전처럼 수요일에 자동 마감으로 다시 저장).
  - dashboard.html: `curWeek()` 도 `DB.state.manualClosedWeek` 를 반영(머리글 주차 · 마감 날짜 · 주차 선택 · 금주 업데이트 기준). 마감 확인 창 문구 '바로 마감하고 다음 주차 ○○ 로 넘어갑니다'. 폴더 모드 마감도 같은 값 기록.
- **확인한 것**: `node --check`, `py_compile`. 서버 함수 시험: 화요일 15:00 [금주 마감] → W42 마감, 지금 주차 W43(화·수 오전 모두), 다음 수요일 12:01 → W44 / 수요일 12:00 자동 마감 → W42 는 건너뜀(수동 마감본 그대로) / 다음 주 수요일 자동 마감 → W43 정상 저장. 화면 시험(관리자): 머리글 '2026-W42 · 마감 10/14(수)' → [금주 마감] → '2026-W43(1021) · 마감 10/21(수) 11:59', 주차 선택 'W43 (현재) / W42 마감본 / W41 마감본', 서버 info.week = W43. 스크립트 오류 없음.

### 2026-10-15 (1) — 수행·입찰 담당자 그래프: 이름이 들어 있으면 카운트 · 마우스 = 미리보기 · 클릭 = 그 사람 PJT 만 / 계정 비밀번호 변경 (APP_VERSION 2026-10-15.1 / SERVER_VERSION 2026-10-15.1)
> **서버 재시작 필요** (server.py).
- 무엇을: 수행·입찰 위 담당자 그래프의 숫자 = **담당자 칸에 그 사람 이름이 들어 있는 진행 PJT 수**. 예전에는 칸 값을 이름 하나로 잘라 맞췄기 때문에 '홍길동 프로', 'PM 김철수', '박민수(LE), 홍길동', 줄바꿈으로 두 사람 등은 빠지거나 덜 셌음. 왜: 사진(W43)에서 부서원 숫자가 실제보다 적게 나옴.
  - dashboard.html: `nk`(공백 없앤 이름) · `hasName(칸값, 이름)` = 공백 무시 포함 비교(이름 2글자 이상). `pjHero` 담당자 막대 = 부서원 명단(`deptNames`) + 명단에 없는 담당자 토큰, 각자 `hasName` 으로 셈.
  - 막대에 마우스 → 미리보기(`data-tip`): '이름 · 진행 N건 (+종결 M)' + PJT명 · 사업군 목록.
  - 막대 클릭 → 담당자 필터 = 그 이름(`filteredRecs` 의 담당자 조건도 `hasName` 포함 비교) → 그 사람이 들어 있는 PJT 만 표에. 표는 종결 필터를 따로 안 걸었으면 종결 PJT 도 보임(그래프 숫자는 진행만).
- 무엇을: **계정 비밀번호 변경**. 오른쪽 위 계정 메뉴 → '🔑 비밀번호 변경'(서버 연결 때만) → 지금 비밀번호 · 새 비밀번호 · 새 비밀번호 확인.
  - server.py `api_change_pw` · 경로 `POST /api/auth/password` (로그인 필요): 지금 비밀번호 확인(틀리면 로그인과 같은 횟수 제한), 새 비밀번호 규칙 = `check_pw`, 지금과 같으면 거절 → 새 salt·hash 저장, `pwChangedAt`, 그 사람의 다른 로그인(세션) 모두 끊고 새 토큰을 돌려줌(이 화면은 그대로 로그인 유지).
  - dashboard.html `openChangePw`.
- **확인한 것**: `node --check`, `py_compile`. 시험 데이터(담당자 '홍길동 프로\n이영희 프로' · 'PM 김철수' · '홍길동 이영희' · '박민수(LE), 홍길동') → 그래프 홍길동 3 · 김철수 2 · 이영희 2 · 박민수 1. 마우스 → '홍길동 · 진행 3건 (+종결 1) 예시수행-A 발전 …'. 홍길동 클릭 → 표 A·C·D·G(G 종결), 김철수 클릭 → B·H. 비밀번호: 틀린 지금 비밀번호 → '지금 비밀번호가 맞지 않습니다' / 바꿈 → 옛 비밀번호 로그인 실패 · 새 비밀번호 로그인 성공 · 새로고침해도 로그인 유지. 스크립트 오류 없음.
- **회사에서 확인할 것**: 서버 재시작 뒤 Ctrl+F5. 이름이 다른 이름 안에 들어가는 경우(예: '김철'과 '김철수')는 둘 다 셈 — 부서에 그런 이름이 있으면 알려줄 것.

### 2026-10-15 (2) — 행 순서 옮기기 · 새 행 노란 줄 · IEC 인력 · 부서원 생일 · 근로시간 관리(52h) (APP_VERSION 2026-10-15.2 / SERVER_VERSION 2026-10-15.2)
> **서버 재시작 필요** (server.py). 새 폴더 `worktime/` 은 서버가 만듦(자동 백업에도 포함). 생일 명단 = `profiles/_birthdays.json`.
- **행 추가 → 맨 위 / 행 옮기기** (수행 · 입찰 · 통합 업무, `TOP_NEW`)
  - 통합 업무도 새 행 order = 가장 작은 order − 10 + `NEW_TOP` 고정 + 그 행으로 이동 (`submitRecord`). 예전 통합 업무는 같은 유형 맨 뒤에 들어갔음.
  - 표 위 **[⬆ 위로] [⬇ 아래로]** (또는 **Alt+Shift+↑/↓**): 선택한 셀의 행을 지금 표에 보이는 바로 위·아래 행과 order 맞바꿈 (`moveRow`). 서버 `PUT /api/order/{시트}` `{orders:{행ID:order}}` (`api_reorder`, 주간업무보고 권한) — 내용·rev·수정 이력은 그대로. 열 정렬(▾) 중에는 안 됨, 통합 업무는 같은 유형 안에서만, 서버 연결 때만.
- **새로 추가한 행 = 행 전체 노란 음영** (`rowAttr` 의 `newrow`: 마지막 마감 이후 새로 생긴 행(`hlOf(r).all`) · 방금 추가한 행). 작업 칸까지 노랗고 왼쪽에 진한 노란 줄. 표 아래 범례 '노란 행 = 새로 추가한 행'.
- **수행** 열 이름: '계장ENG 업무 현황' → **'업무 현황'**, '계장ENG 현안 (Cost/Schedule Impact)' → **'현안 (Cost/Schedule Impact)'** (필드 이름은 그대로 — 데이터 변화 없음). 입찰은 그대로.
- **IEC 인력 (India Engineering Center, 영문 이름)**
  - 수행 PJT 담당자 그래프: 영문 이름은 **세지 않음**. 입찰 PJT 그래프: IEC 명단(`iecNames`) + 담당자 칸의 영문 이름을 **셈** (막대 옆 'IEC' 표시). `pjHero`.
  - 부서원 명단(`deptNames`)에서 IEC 유닛·영문 이름은 뺌 (할 일·근무시간 등 다른 집계에 안 섞이게).
  - 유닛분장 조직도: Unit 1 · Unit 2 오른쪽에 **I&C ENG Group (IEC 인력 구성)** — 유닛 이름이나 담당에 'IEC' 또는 'I&C ENG' 가 들어간 유닛(`isIecUnit`). 표에 아직 없으면 가장 최근 연도에 기본 명단(`IEC_DEFAULT`: Part Leader Ranjit Malakar + Pro 11명, 받은 사진 그대로)을 보여 주고, 유닛 제목을 누르면 **[표에 등록]** → 유닛분장 행이 생겨 그다음부터 고칠 수 있음(`iecRegister`). 'Part Leader' 도 유닛장처럼 ★.
- **부서원 생일** (Management › 부서원 생일 `mgbday`, `renderBday`)
  - 명단: 이름 · 직급 · 생일(월·일) · 양력/음력. 생일 엑셀(사진 양식: 이름 · 직급 · 생일 '10월 13일' · 양력 '생일(양)/생일(음)')을 올리면 미리보기 후 명단 교체, 한 명씩 추가·고치기·삭제. 서버 `GET /api/birthdays`(로그인) · `PUT /api/birthdays` · `POST /api/birthdays/preview`(엑셀 읽기) — 고치기는 Management 권한.
  - 생일 **하루 전 · 당일**: 로그인한 모든 부서원 화면에 **폭죽 + 축하 팝업** ('오늘은 ○○○ 프로의 생일입니다! 축하해 주세요') — 브라우저·계정마다 하루 한 번(`bdayCheck`, localStorage `dept-bday-shown`). 폭죽은 canvas 로 직접 그림(`fireworks`).
  - 생일 **당일**: 유닛분장 조직도의 그 사람 사진과 왼쪽 위 로그인 이름에 **고깔모자**(`HAT` SVG), 이름 옆 🎂.
  - 음력 생일은 브라우저의 한국 음력 달력(`Intl` 'dangi')으로 그해 양력 날짜 계산(`lunarToSolar`, 음력 30일이 없는 달은 29일). 2/29 양력은 평년에 2/28.
- **근로시간 관리 (52h)** (Management › 근로시간 관리 `mgwork`, `renderWork`)
  - 회사 근태 시스템의 월별 근무시간 엑셀(첨부 양식: 1~2행 머리글 — 작업년월 · 성명 · 사번 · 부서명 · 직급명 · 근무스케줄타입 · 근무조 · 근무상태 · 평일의무/평일근무 · 실근무(평일+휴일) 상태/시간 · 주평균근무 상태/시간 · 연장 · 심야 · 휴일 · 휴일연장 · 탄력(+/−) · 월잔여 최대근무가능/소정)을 올림 — 여러 개 한꺼번에, 끌어다 놓기 가능. 서버 `parse_worktime` · `GET/PUT /api/worktime` · `DELETE /api/worktime/{ID}` — **보기·올리기·지우기 모두 Management 권한**. 저장 `worktime/uploads/{ID}.json` + 원본 `worktime/raw/{ID}.xlsx`.
  - 같은 사람(사번, 없으면 이름)·같은 달이 여러 파일에 있으면 나중에 올린 파일 값. 파일을 지우면 그 파일 값만 빠짐.
  - 판정(`wtJudge`): 기준 = 주 평균 소정 40h · 월 평균 주 52h. **위험** = 주 평균 52h 초과 또는 파일 판정 '위험' / **우려** = 주 평균 48h 이상 또는 파일 판정 '우려' 또는 월잔여 최대근무가능 10h 이하. 주 평균 = 파일의 '주평균근무 시간'(없으면 실근무 ÷ (그달 일수 ÷ 7)). 기준값은 `WT_STD` · `WT_MAX` · `WT_WARN` · `WT_REMAIN`.
  - 화면: 월 탭 → KPI(팀 주 평균 · 위험 · 우려 명단 · 최고 주 평균 · 연장 합계 · 휴일근무 합계) + 부서원 표(판정 · 실근무 · 주 평균 막대(40h 점선 · 52h 빨간 선) · 40h 대비 · 연장 · 심야 · 휴일 · 탄력 · 월잔여 · **시수 파일 합계(근태 제외, 8h 이상 차이면 Δ)** · 사유) / '월별 추이' = 부서원 × 월 주 평균 표 / 이름을 누르면 그 사람의 달별 막대 + 표. 근무시간(월·주·일) · R&R · 투입 분석으로 가는 단추.
  - 숫자 칸은 시간(h)으로 읽음 (`194.07` = 194.07시간, '194:07' 처럼 쓰면 194시간 7분).
- **확인한 것**: `node --check`, `py_compile`, 받은 Foramt.xlsx 읽기(6달 1명, 2026.07 실근무 '우려' · 주평균 '위험'). 시험 서버 화면 시험(시험 계정 · 임시 폴더):
  - 수행 열 머리 '업무 현황 | 현안 (Cost/Schedule Impact)'. 수행 그래프 김철수 2 (담당 'PM 김철수\nNikhil Aggarwal' 에서 영문 안 셈) / 입찰 그래프 Abhishek Sinha 1 · Nikhil Aggarwal 1 (IEC 표시) + IEC 나머지 0.
  - 통합 업무 행 추가 → 맨 위 + 노란 행. 수행 행 추가 → 맨 위 노란 행. 3번째 행 [⬆ 위로] → 2번째 / Alt+Shift+↓ 두 번 → 4번째 / 새로고침해도 유지.
  - 조직도: UNIT 1 | UNIT 2 | I&C ENG Group (IEC 12명, Ranjit Malakar ★) → [표에 등록] → 표 행으로 바뀜.
  - 생일 엑셀 6명 → 미리보기 → 저장, 음력 9/20 → 2026-10-30, 2/29 → 2/28. 홍길동 화면: 팝업 '오늘은 백그룹 그룹장, 홍길동 프로의 생일입니다! … 내일(10/16)은 김철수 프로의 생일입니다!' + 폭죽, 조직도 고깔모자 2개 · 로그인 이름 고깔모자, 새로고침하면 팝업 다시 안 뜸.
  - 근무시간 엑셀 2개(시험 파일 4명·4달 + Foramt.xlsx) 올림 → 2026.09: 위험 홍길동(55h) · 우려 김철수(49h), 2026.10 홍길동 51h + 잔여 7.5h → 우려, 월별 추이 · 개인 막대, 파일 하나 삭제 → 그 파일 달만 빠짐. 일반 부서원은 /api/worktime 403. 스크립트 오류 없음.
- **회사에서 확인할 것**: 서버 재시작 + Ctrl+F5. 근태 시스템 엑셀의 시간 숫자가 '194.07' 처럼 소수면 시간(h)으로 읽음 — 실제로 '시:분' 뜻이면 알려 줄 것. 음력 생일 날짜는 Chrome/Edge 의 음력 달력으로 계산(그 밖의 브라우저는 '계산 안 됨').

### 2026-10-15 (3) — 생일 팝업 바로 · 매번 · 오늘 하루 안 보기 / 주 소정근로시간 공휴일 차감 / 근무시간 숫자 칸 → 부서원별 상세 (APP_VERSION 2026-10-15.3 / SERVER_VERSION 2026-10-15.3)
> **서버 재시작 필요** (server.py: 생일 명단 보기 로그인 불필요).
- **생일 팝업** (생일 하루 전 · 당일)
  - 예전: 로그인한 사람에게 하루 한 번, 데이터를 다 받은 뒤 0.8초 뒤.
  - 이제: **화면(dashboard.html)을 열 때마다 · 로그인할 때마다** 뜸. 열자마자 이 PC 에 보관한 명단(localStorage `dept-bday-cache`)으로 바로 띄우고(`bdayBoot`, init 첫 줄), 서버 명단은 로그인 창보다 먼저 기다리지 않고 받음(`startOnline` 첫 줄). 로그인하면 다시(`afterAuth`). 1분 자동 갱신 때는 다시 안 띄움(`BD.shown`).
  - 비회원 화면에도 뜸: 서버 `GET /api/birthdays` 로그인 불필요(이름·직급·월일만). 오프라인으로 연 파일도 보관 명단으로 뜸.
  - **[오늘 하루 안 보기]**: 누르면 그날(같은 생일자)은 이 브라우저에서 안 뜸 (localStorage `dept-bday-hide` = 날짜|이름들).
  - `<dialog>`(showModal)로 바꿈 → 로그인 창·업데이트 안내가 떠 있어도 그 위에 바로 보임. Esc 로도 닫힘.
- **근로시간 관리 (52h) — 주 소정근로시간 = 40h − 평일 공휴일 × 8h** (`wtStd`)
  - 예) 월요일이 공휴일인 주 = 32h. 달 단위 = 40h × (그달 일수 ÷ 7) − 평일 공휴일 수 × 8h = 월 소정 → ÷ (일수 ÷ 7) = **그달 주 평균 소정** (공휴일 없는 달 = 40h). 토·일과 겹친 공휴일은 빼지 않음. 공휴일 = `HOLIDAYS`(2024~2027, 회사 휴일은 여기에 더함).
  - '40h 대비' 열 → **'소정 대비'** (머리에 그달 주 소정, 마우스 = 계산식), KPI '주 소정 ○○h (공휴일 n일 반영)', 막대 점선 = 그달 소정, 개인 막대에 달마다 소정 점선, 개인 표에 '주 소정' · '소정 대비' 열. 위험·우려 판정(52h · 48h · 잔여 10h)은 그대로.
- **근무시간 (월·주·일) — 위 숫자 칸을 누르면 부서원별 상세** (`HS.kpi`, `kpiDetail`)
  - 1인 월 평균(사람별 총·근무한 달·월 평균 + 달별) · 근무일 평균(근무일·총·하루 평균) · 하루 8시간 초과(초과한 날·최장·초과 시간 합 + 날짜) · 주말·공휴일 출근일 / 근무시간(일수·시간·하루 평균 + 날짜). 많은 순. 줄을 누르면 그 사람 값 · 날짜별 막대(기존). 다시 누르거나 [닫기] = 닫힘.
  - 함께 고침: 시수 칸 합의 반올림 찌꺼기(예: 8.0001h)를 '8시간 초과'·붉은 칸으로 세던 것 → 30초 여유(`EPS_H`).
- **확인한 것**: `node --check`, `py_compile`. 시험 서버: 비회원으로 처음 열기 → 0.3초 만에 팝업(서버 명단) · 다시 열기 → 0.1초(보관 명단) · [오늘 하루 안 보기] 후 다시 열기 → 안 뜸 · 로그인한 부서원 화면 팝업 + 두 단추. 근로시간: 2026.07 소정 40h, 08 38.2h(8/17), 09 34.4h(9/24·25·28), 10 36.4h(10/5·10/9) → 소정 대비 다시 계산. 근무시간 연간: 다섯 칸 모두 눌러 상세 표(8시간 초과 김철수 70일 → 54일로 바로잡힘), 줄 누르면 그 사람 값, 닫기. 스크립트 오류 없음.
- **회사에서 확인할 것**: 서버 재시작 + Ctrl+F5. 부서원 파일(dashboard.html)은 새 버전으로 바꾸면 서버가 꺼져 있어도 보관 명단으로 팝업.

### 2026-10-15 (4) — 생일 팝업: 로그인할 때 · html 을 켤 때 · 그 사용자가 '오늘 하루 안 보기' 누르기 전까지 (APP_VERSION 2026-10-15.4 / SERVER_VERSION 그대로 2026-10-15.3)
- 무엇을·왜: 15.3 은 ① '오늘 하루 안 보기' 가 그 PC(브라우저) 전체에 걸려 같은 PC 의 다른 사람도 안 보였고 ② 로그인 화면이 뜨는 경우 팝업이 로그인 전에 먼저 떠서 로그인한 뒤에는 안 떴고 ③ 바로 뒤에 뜨는 '내 할 일' 창이 팝업을 덮어 단추를 못 누름.
- 이제 (`bdayCheck` · `bdayBoot` · `startOnline` · `afterAuth` · `bdRaise`):
  - **html 을 켤 때**: 저장된 로그인이 있으면 바로(이 PC 보관 명단), 없으면 로그인 화면에서 로그인(또는 비회원 보기)한 뒤.
  - **로그인할 때마다**(사용자가 바뀌면) 다시. 같은 화면·같은 사용자에게는 한 번(1분 자동 갱신·새로고침 단추 때는 다시 안 뜸, `BD.shownFor`).
  - **[오늘 하루 안 보기]** 는 **그 사용자만**(계정 ID, 비회원은 'guest') 그날 안 뜸 — localStorage `dept-bday-hide` = 오늘 키 목록(날짜|생일자|사용자).
  - 팝업이 떠 있는 동안 다른 창(내 할 일 · 업데이트 안내 · 확인 창)이 열려도 팝업이 맨 위(`openDlg` → `bdRaise`).
  - 오프라인으로 연 파일도 보관 명단으로 팝업.
- **확인한 것**: `node --check`. 시험 서버(같은 브라우저): 처음 켬 → 로그인 화면(팝업 없음) → 홍길동 로그인 → 팝업(내 할 일 창 위) → 다시 켬 → 0.13초 만에 팝업 → [오늘 하루 안 보기] → 다시 켜도 안 뜸 → 로그아웃 후 김철수 로그인 → 팝업 → 새로고침 단추 → 다시 안 뜸 / 새 브라우저 비회원 보기 → 팝업. 스크립트 오류 없음.
- **회사에서 확인할 것**: Ctrl+F5 (server.py 는 안 바뀜, 15.3 서버 그대로). 부서원 파일은 새 버전으로 교체.

### 2026-10-15 (5) — 근로시간 관리: 연장 = 소정근로시간 초과 전부 / 심야는 근태 시스템 값 (APP_VERSION 2026-10-15.5 / SERVER_VERSION 그대로 2026-10-15.3)
- 무엇을·왜: 요청 "평일 소정 주 근로시간을 초과하면 모두 연장". 예전 '연장' 칸은 근태 시스템 엑셀의 '연장근로시간' 그대로라 '소정 대비' 와 맞지 않았음.
- 이제 **연장 = 실근무(평일+휴일) − 그달 월 소정** (`wtOt`) — 월 소정 = 40h × (일수 ÷ 7) − 평일 공휴일 × 8h (`wtStd`, 15.3). 곧 (주 평균 − 주 소정) × 그달 주 수. 근태 시스템 값은 칸 아래 '시스템 ○○' 로 작게, 마우스 = 계산식. KPI '연장근로 합계' · 개인 막대 풍선도 같은 값.
- **심야(오후 8시부터)**: 엑셀에는 달 합계만 있고 출퇴근 시각이 없어 계산할 수 없음 → '심야' 칸은 근태 시스템 값 그대로, 머리에 '근태 시스템 값'(마우스 = 이유). 일별 출퇴근 시각 파일을 받으면 20:00 이후를 세도록 바꿀 것.
- 한계: 진행 중인 달은 실근무가 오늘까지이고 월 소정은 그달 전체라 연장이 적게(0) 나옴 — 달이 끝난 뒤 파일 기준.
- **확인한 것**: `node --check`. 2026.09(월 소정 147.4h): 홍길동 실근무 235.7 → 연장 88.3 (= +20.6 × 30/7, 시스템 67.7), 김철수 210 → 62.6, KPI 합계 220.3h. 스크립트 오류 없음.

### 2026-10-15 (6) — 생일 팝업 계정(로그인)마다 · 본인 축하 인사 / 근로시간 관리 엑셀 값 우선 + 엑셀 기준 확인 (APP_VERSION 2026-10-15.6 / SERVER_VERSION 2026-10-15.4)
> **서버 재시작 필요** (server.py: 생일 '오늘 하루 안 보기' 를 계정마다 서버에 저장).
- **생일 팝업 = 로그인한 사람 기준**
  - '오늘 하루 안 보기' 를 그 **계정**에 저장: server.py `api_bday_hide` · `POST /api/birthdays/hide` → `profiles/_bdhide.json` {계정ID: [오늘 키]} (오늘·어제 것만 남김). `GET /api/birthdays` 가 로그인한 사람의 키를 `hidden` 으로 돌려줌 → 그 사람의 **다른 PC 에서도** 그날은 안 뜸, 같은 PC 의 다른 사람에게는 뜸. 이 PC(localStorage)에도 같이 기록(오프라인용).
  - html 을 켤 때: 서버 명단(그 사람의 안 보기 포함)으로 바로, 서버가 안 닿으면 1.5초 뒤 이 PC 보관 명단으로(`bdayBoot`).
  - 로그인한 사람이 **오늘 생일**이면 맨 위에 '○○○ 프로님, 생일 축하합니다!' (`showBdayPop` 의 `me`), 다른 생일자는 그 아래.
- **근로시간 관리 — 엑셀 값 우선, 계산은 비교** (`wtStd` · `wtWeeks` · `wtCal` · `wtMon` · `wtCmp` · `wtBasis`)
  - 주 평균 = 엑셀 '주평균근무'(없으면 실근무 ÷ 엑셀이 쓰는 주 수). 월 소정 = 엑셀 '평일의무근로시간'(그 사람 값, 없으면 달력). 연장 = 엑셀 '연장근로시간'. 칸 아래 작게 '계산 ○○'(연장 = 실근무 − 월 소정, 소정 초과 전부 / 월 소정 = 달력), 1h 이상 다르면 주황 Δ.
  - 달력 계산 바꿈: 월 소정 = (평일 − 평일 공휴일) × 8h (예: 2026-09 = 19일 × 8 = 152h), 주 소정 = 40h − 8h × 평일 공휴일 ÷ 주 수.
  - 표에 '월 소정 (엑셀 평일의무)' 열 추가(월별 표 · 개인 표). KPI 연장 합계 = 엑셀 값.
  - **📐 엑셀 기준 확인** 카드(월 화면 아래): 그달 엑셀 값으로 ① 주평균근무가 실근무를 몇 주(며칠 ÷ 7)로 나눴는지, 그달 일수와 같은지 ② 평일의무근로시간이 달력(평일 − 평일 공휴일) × 8h 와 같은지, 다른 사람(휴가 등) ③ 연장근로시간이 어느 월 단위 계산(실근무 − 평일의무 / 평일근무 − 평일의무 / (실근무 − 휴일) − 평일의무 / 실근무 − 달력 소정 / (주평균 − 주 소정) × 주 / (주평균 − 40) × 주)과 맞는지(연장 있는 사람 중 ±0.5h 일치 수), 어느 것과도 안 맞으면 '일별(하루 8시간 초과 · 승인 연장) 기준으로 보임' ④ 심야 = 엑셀 값 그대로(출퇴근 시각 없음).
  - 받은 사진(2026.09) 분석: 엑셀 주평균근무 = 실근무 ÷ 약 4.43주 = **31일 ÷ 7** (9월은 30일) — 근태 시스템 집계 기간이 달력 월과 다를 수 있음. 연장근로시간은 실근무 − 소정과 맞지 않음(예: 실근무 183.1 · 휴일 19.2 인데 연장 7.5).
- **확인한 것**: `node --check`, `py_compile`. 생일: 홍길동 PC1 → 본인 축하 인사 + [오늘 하루 안 보기] → 홍길동 PC2(다른 브라우저) 안 뜸 · 김철수 뜸. 근로시간(사진 값으로 만든 시험 엑셀): 2026.09 → '실근무 ÷ 31일/7 (6/6명) · 그달 30일과 다름', '평일의무 152h 5명 · 144h 1명 ↔ 달력 152h', '연장은 월 단위 계산과 안 맞음 → 일별 기준'; 2026.08(연장 = 실근무 − 평일의무로 만든 줄) → '연장 ≈ 실근무 − 평일의무근로시간 3/3명'. 스크립트 오류 없음.
- **회사에서 확인할 것**: 서버 재시작 + Ctrl+F5 → 근로시간 관리에서 실제 엑셀의 '📐 엑셀 기준 확인' 카드 내용을 알려 줄 것 (그 결과로 계산 방식을 엑셀에 맞출 수 있음).

### 2026-10-15 (7) — 메뉴별 그래프 점검: 담당자 이름 맞추기 통일 · 홈 사업군 · R&R 투입 비중 (APP_VERSION 2026-10-15.7 / SERVER_VERSION 그대로 2026-10-15.4)
- 왜: 요청 "각 메뉴의 차트가 제대로 된 현황을 표기하는지 체크". 그래프마다 원본 데이터로 따로 계산한 값과 화면 값을 비교(시험 스크립트 `audit.js`, 시험 서버·가짜 데이터)해서 틀린 곳을 고침.
- 고친 것
  1. **담당자 이름 맞추기를 모든 그래프에서 같게** (`personGroups`): 칸에 그 이름이 '들어 있으면' 그 사람 것 ('홍길동 프로' · 'PM 김철수' · '홍길동 이영희' · '박민수(LE), 홍길동'). 예전엔 수행·입찰 보드만 이렇게 세고 다른 곳은 칸을 이름 하나로 잘라 정확히 같을 때만 셌음 → 덜 세거나 '홍길동 이영희' 같은 이상한 이름이 막대로 나옴.
     - 홈 '담당자별 담당 PJT 수 (진행 중 · 상위 12)' (수행 = 영문 이름 뺌, 입찰 = IEC 포함 — 수행·입찰 보드와 같은 규칙) · 통합 업무 '부서원별 상·하반기 업무 건수' 와 표준화 'ITEM PO ○명' · 조직도에서 사람 누르면 나오는 담당 업무 요약(`personSummary`) · R&R · 투입 분석의 'R&R 계획 대비 실제' 표(PJT R&R 담당자).
  2. **홈 '사업군별 PJT 수'**: 사업군 칸의 첫 줄 전체를 한 묶음으로 세던 것('발전/LNG' 가 따로 한 막대) → 수행·입찰 보드와 같은 사업군 단어(`bizTok`, 여러 개면 각각)로. 제목에 '진행 중'.
  3. **R&R · 투입 분석 (부서원 화면 = 비율만)**: 서버가 사람마다 '연간 = 100' 으로 바꿔 보내서, **월을 고르면** 그 달만 올린 사람이 여러 달 올린 사람보다 훨씬 크게 반영됨(화면 설명 '사람별 비중을 같게' 와 다름) → 고른 기간 안에서 사람마다 100 으로 다시 맞춰 팀 합산(`renderAlloc`). Management 화면(실제 시간)은 그대로 시간 가중.
- 점검 결과 (시험 데이터, 원본 계산 = 화면): 수행·입찰 보드(전체 · 진행 · 종결 · 업데이트+미업데이트 · 사업군별 · 부서원별 · 수행에 영문 이름 없음) / 홈(진행 수행·입찰 · 종결 · 투입인력 · 사업군 차트 · 담당자 차트) / 통합 업무(상태별 6칸 · 유형 합계 · 부서원별) / 근무시간(팀 총 · 근무일 · 근태 · 부서원별 연간) / R&R(연간·월 프로젝트별 % 합 100, 부서원 화면 근태 % = 사람별 근태 비율 평균) — 틀린 곳 0, 스크립트 오류 없음. 근로시간 관리(엑셀 값 그대로)·생일은 15.6 에서 확인.
- **회사에서 확인할 것**: Ctrl+F5 (server.py 안 바뀜). 홈·통합 업무 그래프의 사람별 숫자가 예전보다 늘 수 있음(직함·여러 이름이 든 칸을 이제 셈).

### 2026-10-16 (1) — 가상 광장(메타버스)을 대시보드로 옮김 · 홈 '최근 변경 이력' 반으로 접기 (APP_VERSION 2026-10-16.1 / SERVER_VERSION 2026-10-16.1)
> **서버 재시작 필요** (server.py). 새 폴더 `plaza/` (화면·서버 파일). 새 데이터 `data/plaza/roles.json` · `looks.json` (서버가 만듦, 자동 백업 포함).
- 무엇을·왜: 요청 "타이틀블록 파싱 구현에서 구현한 메타버스는 여기서 관리한다". P&ID 저장소 브랜치 `claude/titleblock-parsing-c5st4x` 의 인계 묶음(`out/plaza_handover`, 커밋 e5b29d1)을 그대로 가져와 `plaza/` 에 둠 — 앞으로 가상 광장은 이 대시보드에서 고침. 자세한 기능·규칙 = `plaza/README_인계.md` (§5 규칙: 사람이 쓴 글은 HTML 로 넣지 않음 · prompt/confirm/alert 금지 · 역할·맞은 사람은 서버가 정함 · LOOK_RANGES 와 plaza.js 표 · 지도 56×32 같게 · 방향키는 code/key/keyCode 모두).
- `plaza/plaza_server.py` (표준 라이브러리만): 인계본 + `--nets-file`·`--allow` 만 더함 — 사설·루프백 말고도 대시보드가 기억하는 사내 대역(`data/_meta/server-nets.json`, 유선↔Wi-Fi 바뀌면 바로 따라감)과 대시보드 `--allow` 대역을 허용. (인계본은 사설 주소만 허용 → 회사 대역 165.244.x.x 등 공인 주소의 부서원이 403.) 길·응답은 그대로. `python plaza/selftest.py` → 모두 통과.
- `plaza/static/plaza.js` 한 줄: embed(대시보드 카드 안)일 때 들어가자마자 스스로 포커스를 가져가지 않음 — 가져가면 대시보드 생일 팝업이 Esc 로 안 닫혔음(키가 광장으로 감). 카드를 한 번 누르면 움직임('클릭하면 캐릭터를 움직일 수 있습니다' 안내는 원래 있음).
- server.py: `plaza_loop` — 대시보드 서버가 켜질 때 `plaza/plaza_server.py --port 8100 --data data/plaza --nets-file … [--allow …]` 를 창 없이 함께 띄움, 꺼지면 30초 안에 다시 띄움(3번 연속 꺼지면 10분 쉼), 이미 8100 에서 광장이 돌고 있으면 그대로 씀. 대시보드가 끝날 때 `plaza_stop` = 자기가 띄운 PID 하나만 terminate (python 일괄 종료 안 함). `--plaza-port 0` = 안 띄움. `/api/info` 에 `plazaPort`.
- dashboard.html 홈:
  - '최근 변경 이력' 카드 제목 오른쪽 [펼치기 ▾ / 반으로 접기 ▴] — 접히면 목록 높이의 절반 + 아래 흐리게, **기본 접힘**, localStorage `dash.history.half` (`recentHalf` · `fitRecent`).
  - 그 바로 아래 '가상 광장' 카드 (메뉴 항목 없음): iframe `http://<대시보드 서버 호스트>:8100/plaza?embed=1&user=<로그인 이름>` (높이 470 · 테두리 없음 · sandbox 없음). 띄우기 전에 `/version` 3초 확인 → 실패면 '가상 광장 서버가 꺼져 있습니다' + [다시 시도]. 비회원 = '로그인하면 …', 오프라인 = '서버에 연결되어 있을 때만'.
  - **홈을 다시 그려도(1분 자동 갱신 · 새로고침 단추) iframe 을 새로 만들지 않음**: iframe 은 `#content` 밖 `#plazaHost` 에 두고 카드 자리 `#plazaSlot` 위에 위치를 맞춰 올림(`placePlaza` — 그릴 때 · 창 크기 · 접기 · 본문 크기 바뀔 때). iframe 을 DOM 에서 옮기면 다시 읽혀 캐릭터가 나갔다 들어오기 때문. 홈을 떠나면 iframe 을 닫아 광장에서 나감(`plazaOff`), 로그인 사용자가 바뀌면 새 이름으로.
- allow_firewall.bat: TCP 8100 도 엶 (규칙 이름 'DeptDashboard Plaza 8100').
- **확인한 것**: `node --check`, `py_compile`, `plaza/selftest.py` 모두 통과, 허용 대역 단위 시험(165.244.1.2: 파일 없으면 거절 → 대역 파일 있으면 허용, 파일이 바뀌면 바로 반영, --allow 65.3/16 허용). 시험 서버(가짜 계정)에서 대시보드 서버를 켜면 광장 서버가 8100 으로 함께 켜짐. 브라우저 두 사람(홍길동·김철수): 홈 카드 자리 = 광장 창 위치, 방향키로 걷기([23,15]→[27,17]), Enter 대화가 상대 대화 기록에 보임, Space 목검, 얼굴 바꾸기 → `data/plaza/looks.json` 저장, [새로고침] 뒤에도 같은 iframe·같은 광장 ID, 접기 풀면 광장 창이 따라 내려감, 수행 메뉴로 가면 나감(상대 화면 접속 2→1명), 홈으로 오면 다시 들어옴(1→2명), 생일 팝업 Esc 로 닫힘. 스크립트 오류 없음.
- **회사에서 확인할 것**: 서버 재시작 + Ctrl+F5 → 홈 아래 '가상 광장'. **처음 한 번** `data/plaza/roles.json` 의 `"operators": []` 에 운영자 이름(대시보드 로그인 이름)을 적으면 그 사람 광장 화면에 [역할 지정]. 부서원이 Wi-Fi 에서 광장만 안 보이면 `allow_firewall.bat` 을 관리자 권한으로 다시 실행. 이름은 iframe 주소의 user= 로 정해지므로 주소를 손으로 바꾸면 다른 이름으로 들어갈 수 있음(역할·얼굴은 장식이라 그대로 둠).

### 2026-10-16 (2) — 가상 광장 서버가 회사 PC(한글 Windows)에서 켜지자마자 꺼지던 것 고침 (APP_VERSION 그대로 2026-10-16.1 / SERVER_VERSION 2026-10-16.2)
> **서버 재시작 필요** (server.py · plaza/plaza_server.py).
- 증상: 홈 '가상 광장' 카드에 "가상 광장 서버가 꺼져 있습니다 (포트 8100)". `data/plaza/roles.json` 은 생겼음.
- 원인: `plaza_server.py` 가 시작 안내를 print 할 때 '—'(U+2014) 이 있는데, 대시보드가 띄울 때 출력이 콘솔이 아니라서 한글 Windows 기본 글자표 cp949 로 쓰다가 UnicodeEncodeError → 바로 종료. roles.json 은 print 직전에 만들어져 파일만 남음. (시험 환경 리눅스는 UTF-8 이라 못 잡음 — `PYTHONIOENCODING=cp949` 로 재현함.)
- 고침: ① plaza_server.py — stdout 을 utf-8(errors=replace)로 바꾸고 print 실패해도 계속, '—' 대신 '-'. ② server.py `plaza_loop` — 광장 서버를 `PYTHONIOENCODING=utf-8` 로 띄우고, 광장 서버의 출력·오류를 운영 폴더 `plaza.log` 에 남김(2MB 넘으면 plaza.log.old) → 다음에 꺼지면 이유가 거기 있음.
- **확인한 것**: `py_compile`, `plaza/selftest.py` 모두 통과. 고치기 전: `PYTHONIOENCODING=cp949` 로 실행 → roles.json 만 생기고 종료(UnicodeEncodeError). 고친 뒤: 같은 조건에서 /version 응답, 대시보드 서버(cp949 환경)가 광장 서버를 띄우고 plaza.log 에 시작 기록.
- **회사에서 확인할 것**: 적용 → 대시보드 서버 다시 켬 → 홈 F5 → 광장 보임. 안 되면 운영 폴더의 `plaza.log` 내용을 보내 줄 것.

### 2026-10-16 (3) — 계장 광장: 이름 · 다른 메뉴에서도 캐릭터 유지 · P&ID/LOGIC 분석 중 표시 · 겹치지 않음 · Space 꾹 (APP_VERSION 2026-10-16.3 / SERVER_VERSION 2026-10-16.3 · PLAZA_VERSION 2026-10-16.3)
> **서버 재시작 필요** (server.py · plaza/plaza_server.py). 돌고 있던 옛 판 광장 서버는 대시보드 서버가 알아서 바꿔 띄움(아래).
- 이름 '가상 광장' → **'계장 광장'** (홈 카드 · 안내 · iframe 제목 · plaza.html 제목 · 로그).
- **다른 메뉴로 가도 캐릭터 유지**: iframe 을 한 번만 만들고 계속 둠 — 홈이 아니면 `#plazaHost.away`(화면 밖 · 보이지 않음 · 접속 그대로). `render()` 첫머리에서 어느 메뉴든 `plazaOn()` (처음부터 다른 메뉴로 들어와도 광장에 들어감). 로그아웃 · 다른 사람 로그인 때만 `plazaOff` (나감).
- **P&ID 분석 · LOGIC 분석 메뉴에 있으면** 광장의 그 캐릭터 이름 아래 '(P&ID 분석 중...)' · '(LOGIC 분석 중...)' — 대시보드 `plazaStatus` 가 iframe 에 postMessage({type:'plaza-status'}) → plaza.js `setStatus` → 서버 `POST /plaza/api/status` (24자, 들어올 때 join 에도 실림) → 모두의 화면(머리 위 글자 · '광장에 있는 사람' 목록). 메시지는 부모 창에서 온 것만 받음. 글자로만 그림(§5 규칙 1).
- **캐릭터끼리 겹치지 않음**: 서버 `api_move` 가 다른 사람이 선 칸으로 가는 걸 막고 `{blocked, x, y}` 를 돌려줌 → 화면이 제자리로 되돌림. 화면도 미리 막음(`occupied` — 남의 서버 칸 · 가고 있는 칸). 들어오자마자 남과 같은 칸이면 가장 가까운 빈 칸으로 비켜섬(`freeNear`).
- **Space 꾹 누르면 계속 휘두름**: keydown 에서 `S.atkHeld`, keyup · 창 벗어남에서 풂, 그리는 동안 0.32초마다 `attack()` (서버는 그대로 0.3초에 한 번).
- **옛 판 광장 서버 바꿔 띄우기**: plaza_server.py 에 `PLAZA_VERSION`, `/version` 에 `ver`, `POST /plaza/api/quit`(이 PC·루프백에서만 → 스스로 끔). server.py `plaza_loop` 가 돌고 있는 광장의 ver 가 파일과 다르면(업데이트 전 · 서버 창을 닫아 남은 것) 끄고 새로 띄움 — 내가 띄운 것이면 그 PID 를 terminate, 아니면 quit 요청, quit 이 없는 16.2 판이면 Windows `netstat -ano` 로 8100 을 듣는 PID 하나를 찾아 `tasklist` 로 python 인지 확인 후 그 PID 만 `taskkill` (python 일괄 종료 안 함). 그래도 안 꺼지면 로그에 안내하고 10분 뒤 다시.
- **확인한 것**: `node --check`(dashboard · plaza.js), `py_compile`, `plaza/selftest.py` 모두 통과(+ 겹치지 않음 · 상태 24자 · 판 번호). 옛 판(ver 'old') 광장을 8100 에 띄워 둔 채 대시보드 서버 시작 → '옛 판(old)이라 새 판으로 바꿉니다' → ver 2026-10-16.3. 브라우저 두 사람: 홍길동이 수행 → P&ID → LOGIC → 게시판 → 홈으로 가는 동안 같은 iframe(새로 안 만듦), 김철수 화면 '홍길동 (P&ID 분석 중...)' → '(LOGIC 분석 중...)' → 표시 없음, 접속 2명 그대로. 김철수를 홍길동 옆 칸에 세우고 홍길동이 그쪽으로 → 못 감(화면 · 서버 둘 다 blocked). Space 1.7초 꾹 → 6번 휘두름, 떼면 멈춤. 스크립트 오류 없음. (netstat·taskkill 경로는 Windows 에서만 — 시험 환경에서는 quit 경로만 확인.)
- **회사에서 확인할 것**: 적용 → 대시보드 서버 다시 켬(server.log 에 '옛 판 … 새 판으로 바꿉니다') → 홈 F5. 그래도 옛 모습이면 plaza.log · server.log 를 보내 줄 것.

### 2026-10-16 (4) — 계장 광장: 한 PC(IP)에 캐릭터 하나 (PLAZA_VERSION 2026-10-16.4 / APP · SERVER 그대로 2026-10-16.3)
> 서버 재시작 필요 없음: 대시보드 server.py 가 30초마다 광장 판을 보고 새 판(plaza_server.py)으로 바꿔 띄움 → 적용 후 30초 뒤 F5.
- 증상: 대시보드를 여러 창(탭)으로 열면 한 사람 캐릭터가 여러 개.
- 이제 (plaza/plaza_server.py · plaza/static/plaza.js):
  - 광장 서버가 접속 주소(IP)를 직접 기록(`do_POST` 가 `_ip` 를 넣음 — 화면이 보낸 값은 덮어씀). `api_join`: 같은 IP · 같은 이름이 이미 있으면 **그 캐릭터를 함께 씀**(같은 id · 지금 자리 · `shared:true`), 같은 IP 에 다른 이름이면 그 PC 의 옛 캐릭터를 내보내고 새로 만듦.
  - 창마다 따로 움직여도 한 캐릭터: 어느 창에서 걸으면 서버 자리가 바뀌고, 다른 창은 1초 넘게 스스로 안 움직였으면 서버 자리를 따라감(`S.lastMove`).
  - 나가기: 창 하나를 닫아도(sendBeacon leave) 같은 캐릭터의 연결이 더 있으면 남김(`streams > 1`), 마지막 창이 닫히면 바로 나감(`left_at` + 연결 끊김). 끊긴 연결은 2초마다 확인(예전 12초).
- **확인한 것**: `node --check`, `py_compile`, `plaza/selftest.py` 모두 통과(+ 같은 PC 에서 창을 더 열면 같은 캐릭터 · 같은 PC 에서 다른 사람이 들어오면 바뀜 — 사람마다 127.0.0.N 주소). 브라우저: 김철수 PC(127.0.0.1) + 홍길동 PC(192.0.2.2) 창 2개 → 김철수 화면 접속 2명(홍길동 하나), 두 창 같은 id · 같은 자리, 창1 에서 걸으면 창2 · 김철수 화면 모두 [22,17], 창1 닫음 → 홍길동 남음, 창2 닫음 → 바로 1명. 스크립트 오류 없음.
- 알아둘 점: 같은 PC 에서 두 사람이 각자 다른 계정으로 동시에 광장에 들어가면 나중에 들어온 사람 캐릭터만 남음 (요청대로 IP 당 하나).

### 2026-10-16 (5) — 계장 광장: 주간업무보고 중 표시 · 상태는 머리 위 (APP_VERSION 2026-10-16.5 / PLAZA_VERSION 2026-10-16.5 / SERVER 그대로 2026-10-16.3)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5.
- dashboard.html `plazaStatus`: 주간업무보고 메뉴 중 홈이 아닌 화면(수행 · 입찰 · 통합 업무 · R&R · 투입 분석 · 유닛분장 · 이슈 · 전달사항 등, `menuOf(route) === 'weekly'`)이면 '(주간업무보고 중...)'. 홈(광장이 보이는 곳)은 표시 없음, P&ID · LOGIC 은 그대로 '(… 분석 중...)', 게시판 · Management 등은 표시 없음.
- plaza.js: 상태 글자를 이름 아래 → **머리 위**로(`statusTag` y = 칸 위 40px), 말풍선이 있으면 상태 위로 16px 올림.
- **확인한 것**: `node --check`(dashboard · plaza.js), `py_compile`. 대시보드 서버가 광장을 2026-10-16.5 로 스스로 바꿈. 브라우저 두 사람: 홍길동 수행 → 통합 업무 → R&R → P&ID → 홈 → 수행 = 김철수 화면 '주간업무보고 중...' ×3 → 'P&ID 분석 중...' → 없음 → '주간업무보고 중...'. 말하는 동안 머리 위 상태 · 그 위 말풍선이 겹치지 않음. 스크립트 오류 없음.

### 2026-10-16 (6) — 계장 광장: 캐릭터 누르기 → [캐릭터 정보] → 그 부서원 정보 창 (APP_VERSION 2026-10-16.6 / PLAZA_VERSION 2026-10-16.6 / SERVER 그대로 2026-10-16.3)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5.
- plaza.js: 지도에서 캐릭터(몸 · 이름표 자리, `actorAt` — 그리는 카메라 자리 `S.cam` 기준)를 누르면 작은 판(`.pz-ctx`): '[칭호] 이름' · 지금 상태(예: 주간업무보고 중...) · **[캐릭터 정보]**. 빈 곳을 누르거나 Esc 면 닫힘. 내 캐릭터도 됨. 글자는 textContent 로만(§5 규칙 1).
- [캐릭터 정보] → 부모 창(대시보드)에 postMessage({type:'plaza-profile', name}) → dashboard.html 이 **내 광장 iframe 에서 온 것만**(source · origin 확인) 받아 `openProfile(name)` — 유닛분장 조직도에서 사람을 누른 것과 같은 창(사진 · 담당 업무 · 전화 · 수행/입찰 PJT · 담당 업무 요약). 광장만 따로 열었을 때는 '대시보드 안에서 열면 볼 수 있습니다'.
- **확인한 것**: `node --check`, `py_compile`, 대시보드 서버가 광장을 2026-10-16.6 으로 스스로 바꿈. 브라우저: 김철수 화면에서 홍길동 캐릭터 누름 → '홍길동 · 주간업무보고 중... · [캐릭터 정보]' → 누름 → 대시보드에 '👤 홍길동' 창(DCS 설계 리드 · 전화 · 수행 3 · 입찰 1 · 통합 업무 4), 빈 곳 누르면 판 닫힘, 내 캐릭터 누르면 '김철수 (나)', 대시보드 페이지가 스스로 보낸 같은 메시지는 무시. 스크립트 오류 없음.

### 2026-10-16 (7) — 계장 광장: 체력 100 · 맞으면 -1 · 0 이면 유령 · 주간 마감에 부활 (PLAZA_VERSION 2026-10-16.7 / APP · SERVER 그대로 2026-10-16.6 · 2026-10-16.3)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5. 바뀐 파일은 `plaza/` 안뿐.
- 무엇을: 모든 캐릭터 체력 100. Space 로 한 대 맞을 때마다 1 씩 줄고(0.3초에 한 번 — 예전 그대로), 0 이 되면 **유령**. 유령은 공격 못 함(누르면 대화창에 나만 보는 안내) · 맞지 않음 · 남과 겹쳐 지나감(남도 유령 칸은 지나감). **주간 마감**이 지나 주차가 바뀌면 모두 100 으로 부활 + 대화창 알림.
- 왜: 사용자 요청 '공격시 피 1씩, 모두 100, 다 깎이면 유령, 다음 주(마감)가 되면 부활'.
- 바뀐 곳: plaza_server.py `HP` · `manual_closed_week` · `plaza_week` · `load_hp` · `check_week` · `hp_of` · `save_hp` · `hp_loop` · `api_attack` · `api_move` · `snapshot`(players 에 hp · hp_max · ghost, 맨 위 week) · `main`. plaza.js `newActor` · `occupied` · `applySnapshot` · `ghostly` · `drawActor` · `hpBar` · `attack` · `localNote` · `showCtx`. selftest.py 7개 더.
  - 체력은 **이름별**로 `data/plaza/hp.json` (`{"week": "2026-W43", "hp": {"홍길동": 0, …}}`, 100 인 사람은 안 적음)에 2초마다 저장 → 창을 닫고 다시 들어오거나 서버를 다시 켜도 유령 그대로.
  - 주차 = 대시보드 server.py `iso_week` 와 같은 규칙(수요일 12:00 이 지나면 다음 주 · [금주 마감] 을 누르면 `data/_meta/state.json` manualClosedWeek 를 읽어 그때 바로). 30초마다 + 때릴 때 · 화면 갱신 때(5초에 한 번) 확인. 서버가 꺼져 있는 동안 마감이 지났으면 켜질 때 부활.
  - 화면: 이름 아래 체력 막대(초록 > 50 · 노랑 > 20 · 빨강), 유령은 막대 대신 '유령' + 희푸른 반투명 몸이 둥둥 · 그림자 없음. 위쪽 '접속 n명 · 내 체력 87/100'(유령이면 '나는 유령 (주간 마감 때 부활)'), 오른쪽 사람 목록에 [유령], 캐릭터 누른 판에 '체력 87/100' 또는 '유령 (주간 마감 때 부활)'.
  - 체력을 손으로 되돌리려면: 광장이 도는 동안 `data/plaza/hp.json` 은 2초마다 다시 쓰이므로, 고치려면 대시보드 서버를 끄고(광장도 꺼짐) 고친 뒤 켠다.
- 확인한 것: `py_compile`, `node --check`, `python plaza/selftest.py` 모두 통과(남은 1 맞으면 유령 · 유령 공격 못 함 · 유령 안 맞음 · 유령 겹쳐 지나감 · 파일에 남음 · [금주 마감] 기록 → 부활 · 새 주차). 브라우저 두 사람: 체력 3 인 홍길동을 김철수가 Space 꾹 → 0 · 유령, 양쪽 화면 같음, 대화창 '홍길동 님이 김철수 님에게 쓰러져 유령이 되었습니다', 홍길동 Space → 안내 한 줄, 캐릭터 판 '유령 (주간 마감 때 부활)'. 스크립트 오류 없음.
- 회사에서 확인할 것: 수요일 12:00(또는 [금주 마감]) 뒤 30초 안에 유령이 다시 사람으로 돌아오는지.

### 2026-10-16 (8) — 계장 광장: 캐릭터 그림체 바꿈 (큰 머리 · 큰 눈 · 진한 외곽선 · 음영 · 손에 목검) (plaza.js 만 · APP · SERVER · PLAZA_VERSION 그대로)
> plaza.js 는 광장 서버가 파일에서 바로 읽어 주므로(no-store) 서버 재시작 필요 없음 → 적용 후 Ctrl+F5.
- 무엇을: 사용자가 보낸 도트 캐릭터 그림(2등신 · 큰 눈 · 굵은 검은 외곽선 · 밝음/중간/어둠 3단 음영 · 무기를 세워 듦) 느낌으로 캐릭터를 새로 그림. **옷은 따라하지 말라**는 요청대로 옷은 예전 것(저고리 + 흰 깃 + 고름, 통 넓은 바지 + 대님, 노비 무명옷 + 새끼줄 띠)과 역할 머리 장식(관모 · 사모 · 왕관 · 두건)을 그대로 두고 새 그림체로만 다시 그림.
- 바뀐 곳: plaza.js `charSprite` 를 통째로 새로 씀 — 몸 격자 20×28 점(예전 16×24), 머리 14×13 점. 점 판(`grid`)에 색을 칠한 뒤 빈 칸 중 그림에 닿은 칸을 외곽선(`OL`)으로 칠하는 방식(외곽선이 늘 1점 · 끊김 없음). 새 인자 `armed` = 손에 목검 듦(휘두르는 동안은 `drawSwing` 이 그리므로 안 듦 · 얼굴 바꾸기 판의 머리 단추 · 유령은 안 듦). 새 상수 `GW` `GH` `CW` `CH` `FOOT`(그림 위 → 발바닥 px) `HEAD_PX`(발바닥 → 모자 꼭대기).
  - 이를 쓰는 곳도 맞춤: `drawActor`(가운데 = 칸 가운데, 발 = 칸 바닥) · 상태 글자 · 말풍선 높이(`HEAD_PX`) · `actorAt`(누르는 자리) · `drawSwing`(손 높이) · 얼굴 판 미리보기(2배) · 머리 모양 단추(머리 부분만 잘라 보임).
  - 외형 번호(머리 10 · 머리색 8 · 피부 4 · 눈 5 · 수염 4 · 옷 12 · 바지 6)는 그대로 → 저장된 얼굴(looks.json) 그대로 쓰임. '점 눈' 은 빛 한 점 있는 까만 큰 눈, '큰 눈' 은 속눈썹 + 갈색 눈동자 + 빛.
- 확인한 것: `node --check`. 모든 역할 × 4 방향 × 걸음 3, 머리 모양 10 × 앞 · 옆 · 뒤, 눈 5 · 수염 4 를 한 장에 그려 봄(스크립트 오류 없음). 광장에서 두 사람: 걷기 · 말풍선 · '(주간업무보고 중...)' · 체력 막대 · 휘두르기 · 맞은 표시 · 캐릭터 머리 누르기 → [캐릭터 정보] 판 · 얼굴 바꾸기 판 모두 자리 맞음.
- 회사에서 확인할 것: 캐릭터가 예전보다 조금 커서(가로 약 1칸, 세로 약 2칸) 옆 칸 사람과 이름표가 겹쳐 보일 수 있음 — 거슬리면 말해 주면 조정.

### 2026-10-16 (9) — 계장 광장: 부여성 남쪽 지도도 캐릭터와 같은 도트 해상도 (plaza.js 만 · APP · SERVER · PLAZA_VERSION 그대로)
> 서버 재시작 필요 없음 → 적용 후 Ctrl+F5.
- 무엇을: 땅 · 생울타리 · 나무 · 집 · 문 · 울타리 · 남문 · 성벽 · 우물 · 등 · 장승 · 좌판을 캐릭터처럼 **2px 한 점 · 짙은 외곽선 · 또렷한 색**으로. 왜: 사용자 요청 '부여성 남쪽 이미지도 비슷한 해상도로'.
- 바뀐 곳: plaza.js 새 함수 `layers` · `shrink` · `palette` · `pixelize`. 소품 그림 함수(`treeImg` `houseImg` `gateImg` `fenceImg` `southGateImg` `castleWallImg` `wellImg` `lanternImg` `jangseungImg` `stallImg`)는 모양 그리는 부분은 그대로 두고 끝에서 `pixelize(c)` 를 돌려줌. `drawGround` 끝에서 땅 전체를 반으로 줄였다 2배(점 2px) + 잔디밭 둘레 짙은 선.
  - `pixelize`: 반으로 줄여 색을 고름 → 원래 그림에서 많이 쓴 색 16 개(`palette`, 0.2% 미만은 뺌)로 맞춰 섞인 중간색 없앰 → 반투명 가장자리 없앰 → 그림 둘레 빈 칸을 옆 색의 아주 어두운 색으로(외곽선) → 2배. 그림자는 `c.shadow`(layers 가 만듦)에 따로 그려 점 모양 반투명으로, 글자(南 門 · 장승 글씨)는 `c.after` 로 다 바꾼 뒤 또렷하게 덧씀. 결과 그림은 둘레로 2px 씩 커짐(자리는 그대로).
  - 지도는 처음 열 때 한 번만 만듦(그 뒤 매 틀은 붙이기만) → 움직임 속도 그대로.
- 확인한 것: `node --check`. 브라우저 큰 창(1900×1150)에서 지도 전체 · 확대: 나무가 점 덩어리 잎 + 외곽선, 집 · 남문 · 성벽 · 우물 · 좌판 외곽선, 南 門 글자 또렷, 그림자 자리 맞음, 캐릭터 · 이름표 · 체력 막대 그대로. 스크립트 오류 없음.

### 2026-10-16 (10) — 계장 광장: 캐릭터를 보낸 그림에 더 가깝게 (plaza.js 만 · APP · SERVER · PLAZA_VERSION 그대로)
> 서버 재시작 필요 없음 → 적용 후 Ctrl+F5.
- 무엇을: 사용자가 다시 보낸 도트 캐릭터 5장처럼 — **얼굴보다 넓고 풍성한 머리**(앞머리 가닥 14줄 · 빛띠 · 가닥 사이 그늘), **세로 4점 큰 눈**(속눈썹 + 바깥 꼬리 · 진한/중간/밝은 갈색 눈동자 · 흰 빛 두 점), **키보다 긴 목검**(나뭇결 · 코등이 · 끈 감은 손잡이), 둥근 3단 음영. 옷은 이번에도 우리 것 그대로(저고리 · 흰 깃 · 고름 · 통 넓은 바지 · 대님 · 노비 무명옷, 역할 모자).
- 바뀐 곳: plaza.js `charSprite` 다시 씀 — 몸 격자 22×31(예전 20×28), 머리 = 위 16줄(키의 절반), 머리카락 덩어리 폭 19점. 새 도구 `blob`(둥근 덩어리를 왼쪽 위 밝게 · 오른쪽 아래 둘레 어둡게 칠함 — 머리카락 · 얼굴 · 쪽 · 상투 · 양갈래 · 포니테일에 씀) · `get` · `eye`(눈 5가지를 한 곳에서) · `sword`. 상수 `GW` 22 · `GH` 31 · `OY` 6, `FOOT` · `HEAD_PX` 는 자동으로 따라감. `drawSwing` 칼 1.4배 · 칼바람 반지름 30, 발밑 그림자 14×5, 머리 모양 단추는 위 23줄을 잘라 보임.
  - 외형 번호 · looks.json 그대로 (머리 10 · 머리색 8 · 피부 4 · 눈 5 · 수염 4 · 옷 12 · 바지 6).
- 확인한 것: `node --check`. 모든 역할 × 4 방향 × 걸음 3, 머리 모양 10 × 앞 · 옆 · 뒤, 눈 5 · 수염 4 를 한 장에(오류 없음). 광장 두 사람: 말풍선 · 상태 글자 · 이름표 · 체력 막대 · 휘두르기 · 맞은 표시 · 캐릭터 누르기 판 자리 맞음.
- 회사에서 확인할 것: 캐릭터 폭이 한 칸(32px)보다 조금 넓어(약 44px) 바로 옆 칸 사람과 몸이 맞닿아 보임 — 거슬리면 말해 주면 조정.

### 2026-10-16 (11) — 계장 광장: 노비(운영자)를 산발 · 거지 같은 누더기로 (plaza.js 만 · APP · SERVER · PLAZA_VERSION 그대로)
> 서버 재시작 필요 없음 → 적용 후 Ctrl+F5.
- 무엇을: 사용자 요청 '노비는 더 산발에 거지같이'. 운영자(노비) 캐릭터만 바뀜.
  - 머리: 고른 머리 모양과 상관없이 **늘 산발**(머리색만 따름) — 사방으로 뻗친 머리칼 12가닥, 엉킨 옆머리가 어깨 아래까지, 들쭉날쭉 긴 앞머리 · 한쪽 눈을 덮는 머리칼, 뒤는 들쭉날쭉 긴 뒷머리. **두건은 없앰.**
  - 옷: 더 바랜 삼베 색, 다른 색 헝겊으로 기운 자국 + 바늘땀, 얼룩, 너덜너덜한 밑단, 찢어진 소매(팔뚝이 보임), 무릎 구멍, 새끼줄 띠 끝이 늘어짐.
  - 발 · 얼굴: 대님 대신 맨 정강이 + **짚신**(발가락 보임). 볼 홍조 대신 때 자국.
- 바뀐 곳: plaza.js `charSprite` — `hs = nobi ? -1 : F.hair`(머리 모양 무시), `if (nobi)` 누더기 덩어리(헝겊 · 밑단 · 소매 · 무릎 · 짚신), '노비 — 산발' 덩어리(머리칼 · 옆머리 · 앞머리), 얼굴의 때 자국 · 눈 덮는 머리칼, 역할 장식에서 두건 삭제. 얼굴 바꾸기 판 안내 문구 `openFace`: '운영자는 노비 차림 — 머리는 늘 산발, 옷은 기운 누더기에 짚신입니다 (머리 모양 · 옷 색 · 바지 색은 안 씀).'
- 확인한 것: `node --check`. 노비를 4 방향 × 걸음 3 × 머리색 3 가지로 그려 봄(오류 없음) — 산발 · 기운 자국 · 짚신 · 눈 덮는 머리칼 보임. 다른 역할은 그대로.

### 2026-10-16 (12) — 계장 광장: 노비에 흰 머리띠 (plaza.js 만 · APP · SERVER · PLAZA_VERSION 그대로)
> 서버 재시작 필요 없음 → 적용 후 Ctrl+F5.
- 무엇을: 사용자 요청 '노비는 흰색 머리띠도'. 산발 위 이마 높이에 흰 무명 머리띠(좀 때 탄 주름 · 얼룩). 앞에서는 옆으로 삐져나온 끝, 옆에서는 뒤로 늘어진 끝, 뒤에서는 뒤통수 매듭 + 늘어진 두 끝.
- 바뀐 곳: plaza.js `charSprite` 역할 장식의 `role === "operator"` 덩어리(11 에서 지운 두건 자리), `openFace` 안내 문구 '머리는 늘 산발에 흰 머리띠'.
- 확인한 것: `node --check`, 노비 4 방향 × 걸음 3 그려 봄(오류 없음).

### 2026-10-19 (1) — 계장 광장: 처치 수 · killer · 이름이 점점 짙은 붉은색 (PLAZA_VERSION 2026-10-19.1 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5.
- 무엇을: 사용자 요청 '사용자를 많이 죽이면 killer 로 표기하면서 이름을 점점 짙은 붉은색으로'. 상대 체력을 0(유령)으로 만들면 처치 1.
  - 이름 색: 1명부터 붉어짐 — 연분홍(1) → 새빨강(5쯤) → 짙은 붉은색(10명 이상). 테두리는 늘 검정.
  - **3명부터** 이름 앞에 **[killer n]**(빨강) + 이름 둘레 붉은 빛무리. 3명이 되는 순간 대화창 '⚔ ○○ 님이 이번 주 3명을 쓰러뜨려 killer 가 되었습니다!'.
  - 오른쪽 사람 목록: killer 딱지 + 이름 붉은색, 캐릭터 누른 판: '체력 … · 이번 주 n명 처치 (killer)'.
  - 처치 수는 **주마다 새로**: 주간 마감(부활)할 때 체력과 함께 0. (계속 쌓이게 하려면 plaza_server.py `check_week` 의 `kills={}` 를 빼면 됨)
- 바뀐 곳: plaza_server.py `KILLER_AT`(3) · `HP["kills"]` · `load_hp` · `check_week` · `save_hp`(hp.json 에 kills) · `api_attack`(0 으로 만든 사람에게 +1) · `snapshot`(players 에 kills · killer). plaza.js `killColor` · `nameTag` · `newActor` · `applySnapshot`(사람 목록) · `showCtx`. plaza.css `.pz-who .role.killer`. selftest.py 처치 수 시험(3명 → killer · 마감에 0).
- 확인한 것: `py_compile`, `node --check`, `python plaza/selftest.py` 모두 통과. 대시보드 서버가 광장을 2026-10-19.1 로 스스로 바꿈. 브라우저: 처치 0 · 1 · 3 · 6 · 10 의 이름 색과 [killer n], 사람 목록 딱지, 캐릭터 판 문구. 스크립트 오류 없음.

### 2026-10-19 (2) — 계장 광장: 고양이 기사 캐릭터 (사용자가 준 시트에서 뽑은 그림) · 동물 6 · 갑옷 6 · 망토 7 · 사람도 고를 수 있음 (PLAZA_VERSION 2026-10-19.2 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5.
- 무엇을: 사용자가 준 '고양이 기사' 캐릭터 시트(1254×1254 PNG — 갈색 고양이 얼굴 · 은빛 갑옷 · 빨간 망토 · 황금 검, 8방향 · 걷기 · 달리기 · 공격 · 피격 · 점프 · 사망 칸)를 기준으로 광장 캐릭터를 바꿈. **모두 처음엔 원본 고양이 기사**, [얼굴 바꾸기] 에서 종류(고양이 기사 / 사람) · 동물(치즈 · 회색 · 검은 · 흰 고양이 · 호랑이 · 여우) · 갑옷(은빛 · 황금 · 흑철 · 청동 · 푸른 강철 · 백은) · 망토(빨강 · 파랑 · 초록 · 보라 · 검정 · 흰 · 노랑). '사람' 을 고르면 예전 사람 캐릭터(머리 · 눈 · 수염 · 옷 · 역할 모자 · 노비)가 그대로.
- 그림 만든 방법 (회사에서 다시 만들 일은 없음 — 결과 PNG 만 씀): 시트 전체는 쓰지 않고 캐릭터 칸만 잘라 → 남색 배경을 테두리에서부터 지워 투명 → 시트의 점 크기(방향 줄 약 3.1px · 걷기/공격 줄 약 2.7px, AI 그림이라 줄마다 다름)에 맞춰 한 점 크기로 줄이고(칠한 픽셀만 평균) → 원본 캐릭터 픽셀에서 뽑은 40 색 팔레트로 맞춰 번짐 없앰 → `plaza/static/catknight.png`(548×48 · 25KB, 16 칸). 화면에서는 2배(PX) 로 키우되 imageSmoothing 끔 → 흐리지 않음.
  - 쓴 칸: 서 있기 = 시트의 DOWN · UP · LEFT · RIGHT, 걷기 = WALK 4~8번(오른쪽 보는 5칸, 왼쪽은 좌우 뒤집음 — 1~3번은 왼쪽을 봐서 안 씀), 공격 = ATTACK 1 · 2 · 3(뒤집음) · 4(뒤집음) · 6 (칼바람 포함 — 옆으로 공격할 때), 맞음 = HURT 1번(옆), idle 큰 그림은 칸 목록엔 있지만 지금은 안 씀.
  - 시트에 없는 것은 만들지 않음: 위 · 아래로 걸을 때는 서 있는 칸을 한 점씩 들썩임, 서 있을 때는 0.8초마다 한 점 오르내림(숨쉬기), 위 · 아래 공격은 예전 칼 휘두르기(색만 황금 검)를 겹침, 유령은 서 있는 칸을 반투명하게.
- 바뀐 곳:
  - plaza.js: `KINDS` `FURS` `ARMORS` `CAPES` · `RANGES`(kind · fur · armor · cape) · `defaultFace`(kind 0 = 고양이 기사) · 새 `CAT_FR`(칸 자리 · 가운데 · 발바닥) · `CAT_PAL`(40 색 + 묶음: O 외곽선 · F 털 · f 털(머리 쪽만 — 갑옷 반사에도 쓰인 색) · m 주둥이 · A 갑옷 · G 금 장식 · C 망토) · `loadCat` · `rgb2hsl` · `hsl2rgb` · `FUR_T` `MUZ_T` `ARM_T` `CAPE_T`(색 바꾸는 법) · `catMap` · `catSprite`(색 바꾸기 + 2배 + 뒤집기, canvas.cx · canvas.foot) · `catPose`(서기 · 걷기 · 공격 · 맞음 칸 고르기) · `isCat`. `drawActor`(고양이 기사 · 유령) · `drawSwing(…, gold)` · `drawPreview` · `buildFace` · `faceNote` · `arrowRow` · 무작위(종류는 그대로).
  - plaza_server.py: `LOOK_EXTRA`(kind 2 · fur 6 · armor 6 · cape 7, 없으면 0 — 예전에 저장한 얼굴도 그대로 읽힘) · `clean_look` · FILES 에 `/static/catknight.png`.
  - plaza.html: [얼굴 바꾸기] 단추 설명. selftest.py: 얼굴 저장(예전 값 → 기본값 붙음 · 고양이 기사 값) · PNG 파일 시험.
- 확인한 것: `py_compile`, `node --check`, `python plaza/selftest.py` 모두 통과. 대시보드 서버가 광장을 2026-10-19.2 로 스스로 바꿈. 브라우저 두 사람: 서 있기 · 오른쪽/왼쪽 걷기(걷기 칸 돌아감) · 위 · 옆 공격(칼바람 칸) · 이름 · 체력 막대 · 상태 자리, 얼굴 판(고양이 줄 · 사람 줄로 바꾸기 · 미리보기 · 저장 → 상대 화면에도 같은 모습), 동물 6 · 갑옷 6 · 망토 7 을 한 장에 그려 봄. 스크립트 오류 없음.
- 회사에서 확인할 것: 예전에 '얼굴 바꾸기' 로 사람 모습을 저장한 사람도 이번엔 고양이 기사로 나옴(종류 값이 없던 저장본 = 고양이 기사). 사람으로 돌리려면 [얼굴 바꾸기] → 종류 ▶ 사람 → 저장.

### 2026-10-19 (3) — 계장 광장: 그룹장 = 황금 갑옷 + 금빛 후광 · 유닛장 = 은색 갑옷 + 은빛 후광 (plaza.js 만 · PLAZA_VERSION · APP · SERVER 그대로)
> 서버 재시작 필요 없음 → 적용 후 Ctrl+F5.
- 무엇을: 사용자 요청. 고양이 기사일 때 **그룹장은 황금 갑옷, 유닛장은 백은(밝은 은색) 갑옷** — 역할이 정하므로 [얼굴 바꾸기] 의 갑옷 줄은 '황금 갑옷 (그룹장)' / '백은 갑옷 (유닛장)' 으로 고정 표시(고를 수 없음, 동물 · 망토는 고름). 부서원 · 운영자는 예전처럼 갑옷을 고름.
  - 후광: 몸 뒤에 천천히 숨쉬는 빛(그룹장 금빛 · 유닛장 은빛) + 머리 뒤 둥근 고리(PX 칸 점으로 그림) + 몸 둘레를 도는 반짝이 6개. 사람 모습을 고른 그룹장 · 유닛장에게도 후광은 나옴(왕관 · 사모는 그대로). 유령일 때는 없음.
- 바뀐 곳: plaza.js 새 `ROLE_ARMOR` · `roleFace` · `AURA` · `drawAura`, `drawActor`(역할 갑옷 · 후광), `drawPreview`, `buildFace`(갑옷 줄 고정), `faceNote` · 사람 안내 문구.
- 확인한 것: `node --check`. 시험 서버(임시 폴더의 roles.json 에 그룹장 · 유닛장 지정)에서 세 사람: 그룹장 황금 갑옷 + 금빛 고리 · 빛, 유닛장 백은 갑옷 + 은빛 고리 · 빛, 부서원은 그대로. 유닛장 얼굴 판 '갑옷 백은 갑옷 (유닛장)'. 스크립트 오류 없음.

### 2026-10-19 (4) — 계장 광장: 마을 시트 — 캐릭터 5종(고양이 양반 · 팬더 학자 · 사자 무관 · 호랑이 무관 · 노비) · 마을 배경 · 운영자 = 노비 (PLAZA_VERSION 2026-10-19.3 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5.
- 무엇을: 사용자가 준 '마을' 시트(1536×1024 — 캐릭터 5종의 큰 그림 · 대기/걷기/달리기/공격/점프 줄, 배경 타일셋 · 건물 · 소품, 마을 지도 예시)처럼 캐릭터와 배경을 바꿈. **운영자는 늘 노비**(시트의 노비 · 평민).
  - [얼굴 바꾸기] 종류: 고양이 기사 · 사람 · 고양이 양반 · 팬더 학자 · 사자 무관 · 호랑이 무관 (노비는 운영자만 — 다른 사람은 못 고름, 운영자는 '노비 (운영자)' 고정). 마을 캐릭터는 색 고르기 없이 시트 그대로, 미리보기는 시트 맨 위 큰 그림.
  - 그룹장 · 유닛장 후광은 모든 종류에 나옴(갑옷 색 고정은 고양이 기사만).
- 그림 만든 방법 (결과 PNG 만 씀): 시트 전체는 안 쓰고 필요한 칸만 잘라 → 남색 배경을 테두리에서부터 지워 투명 → 시트의 점 크기(약 2px)로 한 점씩 줄이고 → 원본 팔레트(캐릭터 48 색 · 배경 64 색)로 맞춰 번짐 없앰. 시트 칸 구분선(가는 줄) · 나무 밑의 시트 뒤판(물빛)은 지움.
  - `plaza/static/village_chars.png`(512×125 · 65KB): 캐릭터 칸 28 + 큰 그림 5. 쓴 칸 — 앞모습 대기(2칸, 0.65초마다 번갈아 = 숨쉬기) · 앞으로 걷기(2~4칸) · 옆(비스듬한) 모습(1~4칸, 반대쪽은 좌우 뒤집음) · 공격 칸(고양이 양반 부채 · 팬더 · 사자 · 호랑이 칼바람). 시트에 **뒷모습이 없어** 위로 갈 때도 앞모습, 노비는 공격 칸이 없어 예전 칼 휘두르기.
  - `plaza/static/village.png`(512×105 · 46KB): 땅 타일(흙 · 풀 · 물 · 돌판) · 건물 4(집 · 작은 집 · 깃발 걸린 전각 · 문채) · 나무 3(초록 2 · 벚꽃) · 나무문 · 울타리 · 분수 · 꽃덤불 · 깃발 2 · 석등 2 · 수레 · 항아리 2 · 좌판 · 우물(나무 통) · 덤불.
- 배경: 지도 배치(56×32 칸 · 길 · 남문 · 성벽 · 장승 · 당산나무)는 그대로 두고 그림만 바꿈.
  - 땅: 흙 · 풀 · 물은 시트 타일의 색 4 가지만 뽑아 2px 점을 흩뿌림(시트 타일을 그대로 깔면 칸 가장자리 선이 격자로 보여서), 돌길은 시트의 밝은 돌판 타일, 잔디 둘레는 시트 덤불(생울타리), 연못 둘레는 돌.
  - **오른쪽 잔디 테 안에 연못**(48~50 · 17~21 칸, 막힘) + 가운데 분수. 집 2 → 시트 전각 · 집, 오른쪽 위에 작은 집, 왼쪽 위 잔디에 문채, 작은 문 3 → 나무문, 울타리 · 우물 · 좌판 · 석등 → 시트 그림, 좌판 옆 수레 · 항아리, 남문 앞 깃발 2 · 석등 2 · 깃발 1 더, 잔디 나무 → 시트 나무(벚꽃 약 28%), 잔디에 꽃덤불(밟고 지나감). 남문 · 성벽 · 장승 · 당산나무는 손그림 그대로(시트에 맞는 것이 없음).
  - 그림 파일을 받은 뒤 한 번에 만듦(`buildWorld`) — 6초 안에 못 받으면 예전 손그림 지도. 시작 자리는 지도가 다 만들어진 뒤 고름(`join` 이 `WORLD.promise` 를 기다림).
- 바뀐 곳: plaza.js `WATER` · 연못 `fill/block` · `drawGround`(IIFE → 함수, 마을 그림이면 `drawGroundVil`) · 새 `CHR_FR` `VIL_FR`(칸 자리 · 가운데 · 발바닥) · `VIL` `CHR` · `loadAtlas` · `atlasSprite` · `vs` · `vFence` · `drawGroundVil` · `place`(이제 목록에만 적음: make · vil · vsolid · vilOnly · flat) · `trees(V)` · `WORLD` · `buildWorld` · `KINDS`(7) · `KIND_FR` · `isChr` · `chrSprite` · `chrPose` · `roleFace`(운영자 → 노비 · 노비는 운영자만) · `drawActor` · `drawPreview` · `arrowRow(…, skip)` · `kindRow` · `buildFace` · `faceNote` · 프레임의 소품 정렬(`p.z`). plaza_server.py `LOOK_EXTRA.kind` 7 · FILES 에 village.png · village_chars.png. selftest.py PNG · 마을 캐릭터 얼굴 저장 시험.
- 확인한 것: `py_compile`, `node --check`, `python plaza/selftest.py` 모두 통과. 대시보드 서버가 광장을 2026-10-19.3 으로 스스로 바꿈. 브라우저 + 다른 주소에서 들어온 시험 캐릭터 5: 고양이 양반(그룹장 금빛 후광) · 사자 무관(유닛장 은빛 후광) · 노비(운영자) · 팬더 학자 · 호랑이 무관 · 고양이 기사 함께, 걷기 · 공격 칸(사자 칼바람) · 맞은 표시, 지도 곳곳(집 · 문채 · 연못 · 분수 · 좌판 · 수레 · 나무 · 꽃덤불 · 석등 · 깃발), 얼굴 판(운영자 '노비 (운영자)' 고정 · 종류 돌리기에 노비 없음 · 큰 그림 미리보기). 스크립트 오류 없음.
- 회사에서 확인할 것: 운영자(roles.json operators)가 노비로 나오는지. 오래된 PC 에서 처음 들어올 때 그림 두 장(약 110KB)을 받느라 1초 정도 늦을 수 있음.

### 2026-10-19 (5) — 계장 광장: 조선 마을 RPG 로 개편 (지도 64×44 · 구역 · 한옥 · 담장 · 연못 · 시장 · 자연스러운 땅) (PLAZA_VERSION 2026-10-19.4 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5.
- 무엇을: 사용자가 준 '조선 마을 타일셋'(1536×1024 — 땅 타일 · 풀 · 꽃 · 나무 · 바위 · 석등 · 울타리 · 돌담 · 우물 · 좌판 · 수레 · 통 · 깃발 · 한옥 · 지붕 · 기와 담장 · 관아문 · 다리 · 연못 · 돌계단, 오른쪽 위 완성 지도)을 참고해 광장을 조선시대 마을로. 이동 · 충돌 · 캐릭터 · 체력 · 말 · 상태 · 캐릭터 정보 등 기능은 그대로.
- 지도(plaza.js `W` `H` = 64 × 44, plaza_server.py `MAP_W` `MAP_H` 도 같게): 북쪽 관아(큰 한옥 · 돌판 앞마당 · 깃발 · 석등) / 가운데 둥근 흙 광장(당산나무 · 우물 · 석등 넷 · 장승 둘) / 서쪽 주거(한옥 넷 · 낮은 돌담 · 울타리 · 장독대 셋 · 우물통 · 수레, 남북 골목) / 동쪽 시장(좌판 두 줄 — 가운데 줄은 걸어 다니는 통로, 수레 · 통 · 항아리 · 상자 · 깃발) / 북동 연못(연못 둘 · 잇는 물길 위 나무다리 · 다리 건너 정자 · 바위 · 대나무 울타리 · 연잎) / 남쪽 성문(관아문 모양 문루 · 기와 담장 · 석등 · 이끼 돌) / 둘레는 숲(소나무 · 벚꽃 · 큰 나무), 안쪽 풀밭에 나무 · 덤불 · 꽃.
  - 걸을 수 있는 칸 1715 / 2816, 시작 자리에서 모두 이어짐(한 칸만 떨어짐). 처음 시작 자리는 광장 둘레 고리(가운데에서 4~9칸)에 이름마다 흩어짐(`spawn`) — 성문 앞에 몰리지 않음.
  - 건물은 아래 벽 · 기단만 막고 지붕은 막지 않음 → 뒤로 지나가면 지붕에 가려지고, 그때 그 건물을 반투명(55%)하게 그려 내 캐릭터가 보임(`fade`). 이름표 · 말풍선은 늘 맨 위. 앞뒤는 예전처럼 발바닥 높이로 정렬.
- 그림: `plaza/static/joseon.png`(1024×196 · 268KB · 103 칸) — 시트에서 배경색으로 떨어진 덩어리(136 개)를 찾아 **그 덩어리의 픽셀만** 쓰고(옆 덩어리가 겹친 칸도 섞이지 않음, 덩어리 안 구멍은 메움), 땅 타일은 덩어리 안쪽(테두리 3px 안)만 → 경계를 짐작해 자르지 않음. 점 크기 약 2px → 한 점, 원본 96 색 팔레트. 시트에 없는 **장독대**는 같은 화풍(2px 점 · 짙은 외곽선 · 3단 음영)으로 그림(`jangdokImg`). 장승은 예전 그림. 예전 `village.png` 는 지움(캐릭터 `village_chars.png` 는 그대로).
- 땅(`drawGround`, 처음 한 번): 점 해상도(1024×704)로 칠한 뒤 2배.
  1) 흙 · 풀 · 물 경계는 값 잡음(`vnoise`)으로 일렁이게(돌판 · 이끼 돌은 반듯).
  2) 칸(16점)마다 시트 타일의 다른 16×16 조각을 떼어 쓰고 좌우 · 위아래 뒤집기도 칸마다 다르게 — 같은 무늬가 규칙적으로 되풀이되지 않음, 점은 늘이지 않음. 풀은 세 가지(풀 · 흰꽃 풀 · 분홍꽃 풀), 흙은 두 가지를 큰 잡음으로 섞음. 물은 시트 연못의 청록 4 색 + 가끔 물결.
  3) 풀 끝은 어둡게(흙 · 돌을 만나는 곳), 풀 아래 흙에 그늘, 물가는 돌 · 짙은 물.
  4) 흩뿌림: 풀포기 · 작은 꽃 · 흙자국 · 꽃덤불(풀밭), 자갈(흙 · 돌판), 흙길 가장자리 풀포기, 연잎 · 연꽃(물).
- 바뀐 곳: plaza.js 지도 부분 다시 씀 — `DIRT LAWN PAVE WATER MOSS` · `oval` · `unblock` · 새 지도 배치 · `CHR_FR` · `JOS_FR` · `JOS` · `loadAtlas` · `atlasSprite` · `js` · `vnoise` · `drawGround` · `drawGroundPlain`(그림을 못 받으면 땅 색만) · `jangdokImg` · `PLACES` · `put` · `bld` · 소품 배치 · `TREES` · `scatter` · `WORLD` · `buildWorld`, `spawn`, 프레임의 소품 그리기(`fade`). 예전 손그림 소품(`treeImg` `houseImg` `gateImg` `fenceImg` `southGateImg` `castleWallImg` `wellImg` `lanternImg` `stallImg`) · `VIL` · `drawGroundVil` 은 지움(`jangseungImg` 만 남김). `__plazaDebug` 에 `solid` `ground` `W` `H` `props` `WORLD`(시험용). plaza_server.py `MAP_W/MAP_H` · FILES(`joseon.png` 넣고 `village.png` 뺌). selftest.py PNG 이름.
- 확인한 것: `node --check`, `py_compile`, `python plaza/selftest.py` 모두 통과. 대시보드 서버가 광장을 2026-10-19.4 로 스스로 바꿈. 브라우저(그림 받고 그리기까지 약 2.6초 · 스크립트 오류 · 빠진 파일 없음):
  - 지도 전체(2100×1460 창) · 구역마다 확대 화면.
  - 갈 수 있는 곳 BFS: 관아 앞 · 광장 · 서쪽 길 · 주거 골목 남북 · 시장 통로 · 시장 남쪽 · 다리 · 정자 앞 · 성문 앞 · 동쪽 길 끝 모두 이어짐.
  - 충돌: 관아 기단(위로 걸으면 10줄에서 멈춤) · 당산나무 줄기 · 연못 물 · 닫힌 성문(34줄에서 멈춤)은 막히고, 나무다리는 건너감(12 → 6줄), 시장 통로는 지나감.
  - 앞뒤: 한옥 뒤(지붕 아래)에 서면 한옥이 반투명해지고 이름표는 보임. 시험 캐릭터 6(다른 주소) 함께 · 겹침 없음.
  - 화면 크기: 640×420 · 1100×700 · 1920×1080 · 대시보드 홈 안 모두 정상(카메라가 지도 끝에서 멈춤).
- 회사에서 확인할 것: 처음 들어갈 때 그림 두 장(약 330KB)을 받고 땅을 그리느라 2~3초 걸릴 수 있음. 지도가 넓어져 예전 자리(56×32 안)에 있던 사람도 그대로 들어오지만, 새로 들어오는 사람은 광장 둘레에서 시작.

### 2026-10-22 (1) — 계장 광장: EPC 발전플랜트 현장 RPG (설비 점검 · 수리 · 경험치 · 기력 · 유닛장 회복 오라 · NPC) (PLAZA_VERSION 2026-10-22.1 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5.
- 무엇을: 조선 마을 배경을 **EPC 발전플랜트 현장**으로 바꾸고, 계장 설비를 점검 · 교정 · 수리하는 놀이를 넣음. 광장 기능(이동 · 대화 · 공격 · 체력/유령 · killer · 캐릭터 정보 · 상태 표시 · 얼굴 바꾸기 · 역할)은 그대로, 캐릭터 디자인(고양이 기사 · 사람 · 마을 캐릭터 5종 · 노비)도 그대로. **실제 DCS · 계장 설비와는 아무 연결이 없다(모든 값은 광장 안에서만).**
- 참고 그림: 사용자가 말한 `assets/reference/wide_detailed_isometric_top_down_game_concept.png` 는 저장소 · PC 어디에도 없음. 첨부 사진(발전플랜트 콘셉트 그림 · 계장 아이콘 · 변전소 게임 화면 · 엔지니어 스프라이트)은 **구성 · 색감 참고만** 하고 그림은 쓰지 않음 — 콘셉트 그림은 등각 시점이라 탑다운인 광장과 안 맞고, 아이콘 · 엔지니어 스프라이트는 다른 회사 사이트의 그림. 설비 · 건물은 전부 캐릭터와 같은 화풍(2px 점 · 짙은 외곽선 · 왼쪽 위 빛)으로 코드가 그림 (그림 파일 0 개 추가, `joseon.png` 는 지움).
- 지도(64 × 44 칸, 크기는 그대로): A 주 발전동(터빈 홀 · 발전기동 · 연돌 항공등) / B 공정 · 유틸리티(냉각수 펌프 스키드 3 · 열교환기 · 냉각탑 2셀, 팬이 돎) / C 배관랙 통로(6 줄 배관 · 케이블 트레이 · 철골 기둥 5 칸마다 · 사다리, 밑은 그레이팅) / 동서 · 남북 큰길(차선 · 횡단보도) / D 변전(울타리 · 변압기 2 · 단로기) · MCC/E-HOUSE · 마샬링 / E 중앙 제어실(지붕 없는 단면 — 영상 벽 · 경보창 · 콘솔 2 · 의자 · DCS/I/O/PLC/마샬링 캐비닛, 북쪽 입구) / F 시운전 구역(시험 전송기 · 밸브 · 임시 케이블 · LOOP CHECK 판 · 시험대 · 콘) / G 정비동(작업대 · 공구판 · 케이블 드럼 3 · 부품 선반) / H 현장 사무소(2층 컨테이너 사무실) · 해상 컨테이너 3 · 크레인(경고등) · 지게차 · 파이프 스풀 · 주차장(트럭 5) · 쉼터(자판기 · 벤치) · 경비실 · 정문 / 둘레 녹지 · 나무 · 조명탑 10(바닥 불빛). 바닥: 자갈 · 콘크리트(줄눈) · 아스팔트 · 그레이팅 · 에폭시(제어실) · 잔디를 점마다 무늬 + 큰 잡음으로 섞고, 구역 노란 안전선 · 맨홀 · 얼룩 · 그림자.
  - 걸을 수 있는 칸 1787, 모두 이어짐. 건물은 바닥 점유 칸만 막고, 뒤에 서면 반투명(예전 그대로). 시작 자리는 가운데 네거리 둘레 길 · 보도에 흩어짐.
- 설비 28 개(서버 `EQUIP` — PT · DPT · TT · FT · LT · CV · PG · JB · TRAY · MC · DCS · IO · PLC · CON): 상태 정상(초록 점) · 경고(주황 !) · 고장(빨간 ✕ 깜빡 + 바닥 붉은빛). 처음엔 경고 4 · 고장 2, 15초마다 1/2 확률로 정상 하나가 경고(동시 7 개까지), 경고를 3분 두면 고장.
  - 설비 옆(한 칸 안)에서 **E** → 정상: Loop Check 3초 +5 XP · 경고: 교정 5초 +10 · 고장: 수리 7초 +20. 내 직무의 설비면 0.6배 시간 · 1.5배 XP, 시운전 리드는 무엇이든 0.8배. 진행 막대 · 도구(HART 통신기 · 루프 교정기 · 렌치와 불똥 · 콘솔 화면빛 · 케이블 릴) · 완료 글씨 · 깡충 축하. 걸으면 작업 취소. 남이 작업 중인 설비는 '○○ 작업 중'. 교정 · 수리 · 레벨 업은 대화창에 알림.
  - 경험치는 이름별 `data/plaza/xp.json`(주간 마감과 상관없이 쌓임), 레벨 = √(XP/25)+1.
- 유닛장(roles.json `unit_leaders`) = **시운전 리드, 회복 오라**: 둘레 4 칸 안 팀원 체력 1초에 +1(최대 100, 유령은 안 됨 — 부활은 그대로 주간 마감), 기력 회복 2배. 발밑 바닥빛 · 맥동 점선 고리 · 퍼지는 물결 · 올라가는 초록/청록 입자, 회복될 때 '+1 HP' · 체력 막대가 부드럽게 늘어남. 설정은 plaza_server.py `HEAL_ROLES` `HEAL_RADIUS` `HEAL_PER_SEC`.
- 기력: Shift 로 달리기(한 칸 0.125초, 초당 −24), 쉬면 +12, 15 밑이면 지침(느리게 · 땀). 이동 키에 WASD 도.
- 직무: 계장 엔지니어 · DCS 엔지니어 · 현장 기술자 · 케이블 기술자 (얼굴 바꾸기 판 '직무'), 유닛장은 시운전 리드 고정. 이름 밑에 직무 · 레벨, 사람 목록에 직무 · Lv · 체력.
- NPC 5(계장 · DCS · 시운전 리드 · 현장 · 케이블, 마을 캐릭터 그림): 자기 직무 설비들을 A* 길로 돌며 7초씩 작업. 위치를 '지금 시각'으로 계산해 누구 화면에서나 같은 자리. 내 캐릭터는 NPC 칸에 못 들어가고, NPC 는 사람을 지나쳐 감(서버가 NPC 를 모름). 공격 · 회복 · 캐릭터 정보 대상 아님.
- 화면: 왼쪽 위 작은 상태판(HP · 기력 · Lv/XP · 직무 · 지금 하는 일 · 설비 현황), 가까운 설비 위 [E] 안내, 남색 철골 틀 · 현판 'EPC 발전플랜트 현장', 작은 화면에선 대화창 · 상태판을 줄임. 입자 180 개 풀 · 떠오르는 글씨 40 개까지(재사용).
- 바뀐 곳: plaza_server.py `PLAZA_VERSION` · `LOOK_EXTRA.job` · 새 `HEAL_*` `EQ_*` `JOBS` `JOB_CATS` `WORK` `EQUIP` `EQ` `XP` `level_of` `eq_init` `eq_tick` `job_of` `eq_near` `heal_tick` `save_xp` `api_work`(start · done · cancel, 거리 · 시간 확인) `equip_defs` · `hp_loop`(1초) · `snapshot`(players 에 xp · lv · job · healer · heal_seq/age · cheer_age · work, 맨 위 eq · heal_r) · `api_move`(걸으면 작업 취소) · GET `/plaza/api/equip` · POST `/plaza/api/work` · FILES(joseon.png 뺌). plaza.js 지도 부분 다시 씀(땅 종류 · 배치 · `pix` · `building` 과 설비 · 건물 그림 함수들 · `drawGround` · `PLACES` · `put` · `loadEquip` · `buildWorld` · `findPath`) · 새 EPC 부분(`JOB_*` · 기력 · 입자 `PARTS` `puff` · `floater` · `nearEquip` · `interact` · `finishWork` · `cancelWork` · `NPC_DEF` `npcInit` `npcUpdate` `npcAt` · `drawHealAura` · `drawTool` · `drawEqMarks` · `updateHud`) · `spawn` · 틀 · `RANGES.job` · `newActor` · `epcFields` · `applySnapshot` · `occupied` · `stepActor`(달리기 · 지침) · `drawActor`/`drawActorBody` · `hpBar` · `jobTag` · `nameTag` · `frame` · 자판(E · Shift · WASD) · 얼굴 판 `jobRow`. plaza.html 상태판 · 안내 · 제목. plaza.css 상태판 · 작은 화면. selftest.py 설비 · 작업 · 경험치 · 회복 시험.
- 확인한 것: `py_compile`, `node --check`, `python plaza/selftest.py` 모두 통과(설비 목록 · 멀면 거절 · 시간 전 완료 거절 · 완료 XP · xp.json · 유닛장 곁 회복). 대시보드 서버가 광장을 2026-10-22.1 로 스스로 바꿈. 브라우저 두 사람(김철수 · 유닛장 홍길동): PT-101 Loop Check → +8 XP(계장 직무 1.5배), 고장 MC-302 수리 → 정상 · +20 · Lv 2, 걸으면 취소, 걷기 1.5초 8 칸 · 달리기 12 칸(기력 100 → 65), 터빈 홀 벽 · 랙 기둥 · 제어실 벽 막힘 · 제어실 입구로 들어감, 유닛장 곁 체력 73 → 77(4.5초) · 멀어지면 멈춤, NPC 5 가 설비마다 작업, 640×420 · 1100×700 · 1920×1080(60 fps) · 대시보드 홈 안, 스크립트 오류 · 빠진 파일 없음.
- 아직 안 한 것: 시트에 없는 동작(작업 · 축하 · 지침)은 도구 · 깡충 · 땀으로만 표현(캐릭터 그림 자체의 작업 포즈 없음). NPC 와 사람의 겹침은 내 쪽만 막음. 실내(제어실 외) 건물 안으로는 못 들어감.

### 2026-10-22 (2) — 계장 광장: EPC 시트 그래픽 · UI · 효과 (직무 캐릭터 작업 포즈 · 초상 상태판 · 도구칸 · 미니맵 · 장비/효과 아이콘) (PLAZA_VERSION 2026-10-22.2 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5.
- 무엇을: 사용자가 준 EPC 에셋 시트(안전모 쓴 직무 캐릭터 · 초상 · 계장 장비 · 도구 · UI 효과 아이콘)를 배경을 빼고 잘라 `static/epc.png`(512×201, 투명) 한 장으로 만들어 씀. 요청 "그래픽 · UI · 스킬 이펙트 동일한 수준으로". 콘셉트 그림(회사 로고 있음) · 게임 화면 예시는 구성 참고만.
- 캐릭터: 얼굴 종류에 **7 = EPC 안전모 (직무별)** 추가, 새 기본값. 직무 → 그림: 계장 엔지니어 고양이 · DCS 판다 · 시운전 리드 사자(유닛장) · 현장 기술자 호랑이 · 케이블 기술자 작업자. 시트 동작 그대로: 대기 · 걷기 5 · 점검 · HART · 케이블 · DCS · 수리 · 점프(축하 때) · 피격 · 축하 · 지침. 작업 종류와 설비에 따라 포즈가 바뀜. 시트에 뒷모습이 없어 위로 걸을 때도 앞모습. 유령은 같은 그림 반투명.
  - 예전에 저장된 얼굴(판 표시 `v` 없음)은 한 번만 EPC 안전모로 옮김. 얼굴 판에서 다시 고양이 기사 · 사람 · 마을 캐릭터로 바꿀 수 있고, 저장하면 `v: 2` 가 붙어 다시 안 옮김.
- 효과: 설비 그림 = 시트의 장비 아이콘(PT · DPT · TT · FT · LT · CV · PG · JB · MC · IO · PLC · CON · DCS 카드), 설비 상태 = LED(정상) · ?(경고) · 경보(고장) 아이콘. 작업 중 스캔 빛 · 불똥 · 케이블 연결 · HART 신호 아이콘, 완료 때 측정값 말풍선(가짜 값, 예 '4.02 mA OK'), 레벨 업 아이콘, 유닛장 회복 오라에 도는 + 십자.
- UI: 왼쪽 위 상태판을 남색 빛나는 판으로 — 내 직무 초상 · Lv · 직무 · HP/기력/XP 막대(시트 아이콘) · 하는 일 · 과제 줄 'LOOP CHECK 정상 n/28 · 경고 · 고장'. 아래 가운데 도구칸 5(Loop · 교정 · 케이블 · 측정 · 수리) — **누르는 버튼이 아니라 표시만**: 지금 작업에 노란 불, 내 직무 칸은 파란 테두리. 오른쪽 아래 미니맵(땅 · 건물 · 설비 상태 점(고장 깜빡) · 사람 · NPC · 지금 보이는 곳). 작은 화면에선 도구칸 · 초상 · 과제 줄을 숨기고 미니맵을 줄임(폭 560 밑은 미니맵도 숨김). 설비 위 '○○ 작업 중' 글씨는 작업자 머리 위 진행 막대와 겹쳐 뺌.
- 바뀐 곳: plaza_server.py `PLAZA_VERSION` · `LOOK_EXTRA`(kind 8 · 새 v 4) · FILES(`/static/epc.png`). plaza.js 새 `EPC_FR` `EPC` `eps` `EQ_ICON` `JOB_CHAR` `isEpc` `epcWho` `workPose` `epcPose` `fxIcon` `POPS` `reading` `drawPops` `paintIcons` `hudPortrait` `TOOL_OF` `JOB_TOOL` `drawMini` · 바뀐 `atlasSprite`(그림 묶음별 캐시 키) · `eqImg` · `KINDS` `RANGES`(v) · `defaultFace` · `faceOf`(옮김) · `drawActorBody`(EPC 갈래) · `drawTool` · `drawEqMarks` · `drawHealAura` · `updateHud` · `frame` · 얼굴 판(초상 · 설명 · 저장 v) · NPC 얼굴. plaza.html 상태판 · 도구칸 · 미니맵. plaza.css 같은 것. selftest.py 얼굴 기대값(v) · epc.png.
- 확인한 것: `node --check`, `py_compile`, `python plaza/selftest.py` 모두 통과. 시험 서버에서 광장이 2026-10-22.2 로 바뀜. 브라우저(1500×900 · 900×560 두 사람): EPC 캐릭터 · NPC 그림, PT-101 Loop Check 포즈 · 스캔 효과 · 진행 막대 · 완료 말풍선, 상태판 초상 · 아이콘 막대 · 과제 줄, 도구칸 'Loop' 불, 미니맵 점 · 보이는 곳 네모, 달리기, 얼굴 판 초상, 스크립트 오류 · 빠진 파일 없음.
- 회사에서 확인할 것: 처음 들어가면 캐릭터가 모두 EPC 안전모로 바뀜(정상). 예전 모습을 원하면 '얼굴 바꾸기'에서 종류를 바꾸고 저장.

### 2026-10-22 (3) — 계장 광장: EPC 캐릭터 뒷모습 · 아이템(무작위 3 개 · 쓰러지면 떨어뜨림 · 밟으면 주움) · 운영자 무적 · 운영자 부활 (PLAZA_VERSION 2026-10-22.3 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5.
- 뒷모습: EPC 시트에 뒷모습이 없어, 앞모습(대기 · 걷기 5)을 고쳐 만든 30 칸을 `static/epc.png` 맨 아래 줄에 붙임(512×201 → 512×272): 안전모 앞 로고 지움 · 얼굴 → 털/머리 뒤통수(고양이 주황 · 판다 흰색+검은 귀 · 사자 갈기 · 호랑이 줄무늬 · 작업자 갈색 머리) · 등 반사띠 · 꼬리(고양이 · 사자 · 호랑이). 위로 걷거나 위를 보고 서 있으면 뒷모습(유령도). 이름 `<동물>_back_idle` `<동물>_back_w0~4`.
- 아이템: EPC 시트의 도구 그림 20 종(HART 통신기 · 멀티미터 · 루프 교정기 · 케이블 드럼 · 계장 케이블 · 글랜드 · 단자대 · 에어/임펄스 튜브 · 포지셔너 · 교정 펌프 · 안전모 · 조끼 · 렌치 · 드라이버 · 노트북 · 점검표 · 무전기 · 압력계 · DCS 카드). 처음 들어온 사람은 무작위 3 개. 쓰러지면(유령) 가방을 그 자리에 떨어뜨림(튀어나와 흩어지는 그림 · 반짝임 · 대화창 알림). 산 사람이 그 칸을 밟으면 주움(가방 8 칸, 떨어진 지 0.8초 뒤부터). 부활하면 빈 가방은 새로 3 개. 주간 마감에 바닥은 치우고 빈 가방은 새로. 가방은 상태판 아래 8 칸 · 캐릭터를 누르면 '가방: …'. 아이템은 모으는 것뿐(능력치 없음). 파일 `data/plaza/items.json`.
- 운영자: **무적**(맞아도 체력 안 줄고 쓰러지지 않음 · 체력 막대 금색 ∞ · 상태판 '∞ 무적'). **부활**: 유령 곁(2.5 칸 안)에서 **R** (또는 유령을 눌러 '부활 (운영자)' 단추) → 체력 100 · 빛기둥 · '부활!' · 대화창 '✨ 운영자 ○○ 님이 △△ 님을 부활시켰습니다'. 운영자 곁 유령 위에 '[R] 부활' 안내.
- 배경: 요청의 '첨부처럼' 그림이 이번 메시지에 안 붙어 와서 이번엔 바꾸지 않음.
- 바뀐 곳: plaza_server.py `PLAZA_VERSION` · 새 `hp_p`(운영자 = 늘 가득) · `ITEM_NAMES` `ITEM_START` `ITEM_MAX` `GROUND_MAX` `REVIVE_DIST` `ITEMS` `load_items` `save_items` `give_items` `drop_items` `pick_up` `items_new_week` `api_revive`(POST `/plaza/api/revive`) · `check_week` · `heal_tick` · `api_work` · `snapshot`(players 에 inf · items · revive_age/by, 맨 위 ground) · `api_join`(아이템 줌) · `api_move`(줍기 → picked) · `api_attack`(운영자 무적 · 쓰러지면 떨어뜨림) · `equip_defs`(items) · `hp_loop`(저장) · `main`. plaza.js `EPC_FR`(뒷모습) · `epcPose` · 유령 그림 · `epcFields` · 새 `ITEM_DEF` `itemName` `GROUND` `G_SEEN` `drawGroundItems` `drawRevive` `nearGhost` `revive` · `applySnapshot`(ground) · `loadEquip` · `frame` · `hpBar`(∞) · `updateHud`(가방) · R 키 · `showCtx`(가방 · 부활 단추) · 안내 글. plaza.html 가방 칸 · 안내. plaza.css 가방. selftest.py 아이템 · 부활 · 무적 시험(첫 때리기 시험은 운영자를 때리므로 '무적'으로 바꿈).
- 확인한 것: `node --check`, `py_compile`, `python plaza/selftest.py` 모두 통과(들어오면 3 개 · 쓰러지면 바닥에 3 개 · 밟으면 주움 · 부서원 부활 403 · 멀면 400 · 곁이면 200 · 유령 아니면 400 · 운영자 무적 · items.json/hp.json 기록). 브라우저 두 사람(김철수 · 운영자 박민수): 위로 걷기/서기 뒷모습, 운영자를 때려도 안 맞음, 박민수가 김철수를 쓰러뜨림 → 아이템 3 개 튀어나옴 · 대화창 알림, 그 칸을 밟아 주움(+ 글씨 · 가방 6 칸), [R] 부활 안내 → R → 빛기둥 · 체력 100 · 새 아이템 3 개, 스크립트 오류 · 빠진 파일 없음.
- 회사에서 확인할 것: 운영자는 roles.json `operators` 에 있는 사람(광장 '역할 지정'). 처음 적용하면 광장에 있던 사람 모두 아이템 3 개를 받음.

### 2026-10-22 (4) — 계장 광장: 레벨 → 최대 체력 · 마나 증가 / 마나 쓰는 기술 3 개 (PLAZA_VERSION 2026-10-22.4 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5.
- 무엇을: 레벨이 오르면 최대 체력 · 마나가 오르고, 마나를 쓰는 기술을 넣음. 요청 "레벨 오르면 체력과 마나도 오르게, 스킬 마나 사용 적절하게".
- 체력: 최대 = 100 + 레벨마다 10 (Lv 2 110 · Lv 5 140, Lv 30 까지). 맞으면 그대로 1 씩. 기록이 없으면 가득이라 레벨이 오르면 바로 늘어난 만큼 가득.
- 마나: 최대 = 50 + 레벨마다 5. 1초에 +1 찬다(유령은 안 참). 주간 마감 · 부활 · 서버 다시 켜면 가득. 상태판에 보라색 막대.
- 기술 (키 1 · 2 · 3 또는 아래 가운데 기술 칸을 누름): **1 강타** 마나 10 · 3초 — 앞 사람 체력 −5 (평타는 −1) / **2 응급 처치** 마나 20 · 8초 — 내 체력 +25 / **3 현장 지원** 마나 30 · 15초 — 둘레 3 칸 팀원 체력 +15 · 기력 +30. 앞에 사람이 없거나 체력이 가득하거나 둘레에 팀원이 없으면 마나를 안 씀. Lv 1 마나 50 이면 강타 5 번 또는 지원 한 번 + 응급 한 번 정도, 다 쓰면 50초에 다시 참.
  - 효과: 강타 불꽃 고리 · 튀는 불똥 · '강타!' / 응급 처치 초록 고리 · 하트 · 올라가는 초록빛 / 현장 지원 3 칸까지 퍼지는 청록 고리 · 둘레 빛 알갱이 · 대화창 알림. 맞으면 머리 위에 '−5' · '−1' (운영자는 '무적'), 회복은 '+15 HP' 처럼 실제 양.
  - 기술 칸: 아이콘 · 키 · 마나 숫자, 재사용 중엔 어두운 덮개 + 남은 초, 마나 모자라면 빨간 테두리, 유령이면 흐림. 폭 1100 밑에선 도구칸은 숨기고 기술 칸만, 폭 700 밑에선 숨김(키는 됨).
  - 운영자도 기술을 씀(무적은 그대로). 값은 plaza_server.py `SKILLS` `STRIKE_DMG` `AID_HEAL` `SUPPORT_HEAL` `SUPPORT_R` `HP_PER_LV` `MP_BASE` `MP_PER_LV` `MP_REGEN` 에서 바꾸면 화면도 따라감(`/plaza/api/equip` 로 받음).
- 바뀐 곳: plaza_server.py `PLAZA_VERSION` · 새 `HP_PER_LV` `MP_*` `LV_CAP` `SKILLS` 값들 `MP` `lv_of` `hp_max` `mp_max` `mp_of` `set_hp` `damage` `mp_tick` `api_skill`(POST `/plaza/api/skill`) · `hp_of`(레벨 최대) · `hp_p` · `load_hp` · `check_week`(마나 가득) · `heal_tick` · `hp_loop` · `api_attack`(damage 로) · `api_revive` · `snapshot`(hp_max 레벨별 · mp · mp_max · skill/seq/age · hit_dmg · heal_amt) · `equip_defs`(skills). plaza.js 새 `SKILL` `SKILL_KEYS` `dmgFloat` `skillFx` `useSkill` `drawSkillFx` `updateSkillBar` · `epcFields` · `applySnapshot`(맞은 양) · `loadEquip` · `updateHud`(마나) · `paintIcons` · `frame` · 키 1·2·3 · 레벨 업 안내. plaza.html 마나 막대 · 기술 칸 · 안내. plaza.css 같은 것. selftest.py 기술 · 레벨 시험(xp.json 에 '고수' 400 XP = Lv 5).
- 확인한 것: `node --check`, `py_compile`, `python plaza/selftest.py` 모두 통과(강타 −5 · 마나 70→60 · 재사용 거절 · 지원 회복 · 마나 50→20 · Lv 5 체력 140 · 마나 부족 거절). 브라우저 두 사람(김철수 Lv 2 체력 110 · 마나 55 / 운영자 박민수): 1 강타 −5, 2 응급 처치, 3 현장 지원 +15, 운영자를 치면 '무적', 앞에 없으면 '앞 칸에 사람이 없습니다', 기술 칸 재사용 덮개 · 남은 초, 스크립트 오류 없음(지원 고리 크기가 음수가 되던 것 고침).

### 2026-10-22 (5) — 계장 광장: 아이템 공격력 · 마법 공격력(무작위 · 등급) / Z 로 줍기 / 사람끼리 교환 / 마법 기술 '전기 충격' (PLAZA_VERSION 2026-10-22.5 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5.
- 무엇을: 요청 "죽으면 아이템 떨어트리게, 떨어진 아이템은 Z 키로 먹게, 아이템은 상대방과 교환할 수 있도록, 아이템 공격력은 랜덤으로 적절하게, 마법 공격력도".
- 아이템마다 **공격력 · 마법 공격력 · 등급**: 등급 일반 70% · 고급 22% · 희귀 7% · 전설 1% (배수 1 · 1.6 · 2.4 · 3.5), 값 = 종류 성향 × 2~5 × 배수. 공구(렌치 · 드라이버 · 케이블 드럼 …)는 공격, 계측 · 통신 · 전자(HART · 노트북 · DCS 카드 · 무전기 …)는 마법 쪽 (`ITEM_W`). 예: 일반 렌치 공 3~8, 희귀 케이블 드럼 공 14. 가방(8 칸)에 든 것의 합이 내 공격력 · 마법 공격력.
  - 예전(판3) 파일의 '종류만 있는 아이템'은 처음 읽을 때 값을 새로 굴려 붙임.
- 피해 · 회복 (공 = 공격력, 마 = 마법): 평타(Space) 1 + 공/10 · 1 강타 5 + 공/4 · **4 전기 충격(새 마법 기술, 마나 15 · 4초)** 보는 쪽 4 칸 안 첫 사람 4 + 마/3 · 2 응급 처치 +25 + 마/3 · 3 현장 지원 +15 + 마/4. 가방 합이 공 20 · 마 15 쯤이면 평타 3 · 강타 10 · 전기 9 → 체력 100 을 평타만으론 30 대쯤. 식은 plaza_server.py `dmg_basic` `dmg_strike` `dmg_bolt` `heal_aid` `heal_support`.
- 죽으면 떨어뜨림(그대로) — 대화창에 아이템 · 값까지. 바닥 아이템: 고급 이상은 등급 색 바닥빛, 곁에 가면 '[Z] 이름 공·마'.
- **Z 로 줍기**: 선 칸 + 둘레 8 칸의 아이템을 가까운 것부터 가방이 찰 때까지(밟기만 해서는 안 주움). 가방이 차면 '가방이 가득' 안내.
- **교환**: 상대를 눌러 '교환' → 내 가방 · 상대 가방에서 고르고(여러 개 · 한쪽만 = 선물도 됨) '교환 제안' → 상대 화면 위에 제안 판(받음/줌 그림 · 값) '수락 · 거절', 보낸 쪽엔 '기다리는 중 · 취소'. 3 칸 안 · 1분 · 둘 다 살아 있어야 함 · 그사이 아이템이 바뀌면 취소 · 가방이 넘치면 거절. 끝나면 대화창 '🤝 A ↔ B 교환 — …' · 둘 머리 위 '교환!'.
- 화면: 상태판에 '⚔ 공격력 · ✦ 마법 · 평타', 가방 칸 테두리 = 등급 색(희귀 · 전설은 빛), 캐릭터를 누르면 가방 그림 · 공격력 · 마법. 기술 칸에 '4 전기'. 폭 1360 밑에선 도구칸을 숨기고 기술 칸만(대화창과 겹침 방지).
- 바뀐 곳: plaza_server.py `PLAZA_VERSION` · 아이템 부분 다시 씀(`ITEM_W` `RARITY` `PICK_DIST` `TRADE_DIST` `TRADE_S` `TRADES` `make_item` `fix_item` `load_items` `save_items` `bag` `power` `item_txt` `give_items` `drop_items` `api_pickup`(POST `/plaza/api/pickup`) `dist` `api_trade`(POST `/plaza/api/trade` offer · accept · decline)) · `pick_up` 없앰(걸어서 줍기 없음) · `SKILLS.bolt` `BOLT_*` `dmg_*` `heal_*` · `api_attack` · `api_skill`(bolt · 값 반영) · `snapshot`(items 에 값 · atk · matk · trade_age · skill_to · ground 에 등급/값 · trades) · `equip_defs`(rarity · trade_dist). plaza.js 새 `RARE` `RARE_COL` `itemStat` `itemFull` `itemIcon` `pickup` `openTrade` `closeTrade` `fillTrade` `sendTrade` `answerTrade` `showTrades` · `itemName` · `epcFields` · `drawGroundItems` · `SKILL.bolt` · `drawSkillFx`(번개) · `useSkill` · `updateHud`(가방 · 힘) · 키 Z · 4 · Esc · `showCtx`(가방 그림 · 교환). plaza.html 교환 판 · 제안 판 · 힘 줄 · 기술 4 · 안내. plaza.css 같은 것. selftest.py 아이템 값 · Z 줍기 · 강타/전기 식 · 교환 시험.
- 확인한 것: `node --check`, `py_compile`, `python plaza/selftest.py` 모두 통과(값 붙음 · 멀면 못 주움 · 밟기만으론 안 주움 · 곁에서 Z 3 개 · 강타 = 5 + 공/4 · 전기 = 4 + 마/3 · 남의 아이템 제안 거절 · 멀면 거절 · 받는 사람만 수락 · 수락하면 서로 바뀜 · 끝난 제안 404). 브라우저 두 사람(김철수 · 운영자 박민수): 4 전기 충격 번개 · −8 → 쓰러져 3 개 떨어뜨림, [Z] 안내 · Z 로 주움(가방 8 칸 가득 → 1 개 남음 안내), R 부활, 김철수가 박민수를 눌러 교환 판 → 제안 → 박민수 화면 제안 판 → 수락 → 서로 바뀜 · 대화창, 스크립트 오류 없음.
- 회사에서 확인할 것: 판3 의 아이템은 처음 켤 때 값이 무작위로 새로 붙음. 평타가 세져서(1 → 1 + 공/10) 유령이 예전보다 빨리 나옴 — 너무 세면 `dmg_basic` 의 10 을 키우면 됨.

### 2026-10-22 (6) — 기술공유 최신순 · 왼쪽 메뉴 숨기기 · 수행/입찰 열 숨기기(나에게만) · 엑셀식 복사/선택 · 그룹장 권한 · 게시판 피드형 · 홈 배치 · LNG/수소 묶기 · 담당자 그래프 수행/입찰 색 (APP_VERSION 2026-10-22.1 / SERVER_VERSION 2026-10-22.1)
> server.py 가 바뀜 → **서버 재시작 필요** (8장 3번). 부서원 사본은 새 버전 [다운로드] 배너로 받음.
- 1 기술공유: 기술공유 시트와 통합 업무의 '기술공유' 유형 모두 **최신 날짜가 맨 위**(발표일 → 시작일 → 종료일, 날짜 없는 행은 아래). 열 필터의 정렬을 고르면 그쪽이 우선. 바뀐 곳: `dateDesc` `tsDate` `sortRecs`.
- 2 왼쪽 메뉴 숨기기: 사이드바 로고 옆 **◀ 숨기기**, 숨기면 위 ☰ 단추가 '☰ 메뉴'(다시 열기). 넓은 화면에서 숨긴 상태를 이 PC 에 기억(localStorage `dept-nav-closed`). 좁은 화면(900px 이하)은 예전처럼 겹쳐 여닫기. 바뀐 곳: `#sideHide` · `setNavClosed` · CSS `body.nav-closed #burger`.
- 3 수행 · 입찰 열 숨기기: 머리글 ▾ → '🙈 이 열 숨기기 (나에게만)' 또는 셀을 고르고(여러 열은 Shift/Ctrl) 툴바 '🙈 선택 열 숨기기'. **숨긴 사람에게만** 적용(이 PC localStorage `dept-hidecols`, 로그인 이름별 — 다른 PC 에서 같은 사람으로 들어오면 그 PC 에서 다시 숨겨야 함). 표 위에 '🙈 숨긴 열 n개' 줄(이름을 누르면 그 열만 · '모두 보이기'), 숨긴 자리 바로 오른쪽 머리글에 '◂n' 표시(누르면 다시 보임). PJT명(제목 열)은 숨기지 않음. 엑셀 내보내기 · 다른 부서원 화면 · 데이터는 그대로. 바뀐 곳: `LS_HIDE` `HIDE_SHEETS` `hiddenCols` `setHidden` `hideCols` `visCols` · `tableHtml` · `drawTable` · `openCf`(data-cfhide) · `renderSheet`(#fHide) · 본문 클릭(data-unhide).
- 4 엑셀식 복사 · 선택: Ctrl+C 가 **엑셀 표 모양**(탭 구분 글 + HTML 표, 칸 안 줄바꿈 유지)으로 복사 → 엑셀 · 메일 · PPT 에 표로 붙여넣기. 예전엔 `navigator.clipboard` 를 써서 http://PC이름:8080 (보안 연결 아님)에서 복사가 안 됐음 → 브라우저 copy 이벤트에 직접 넣음(안 오면 예전 방식). **Shift+방향키** = 범위 늘리기, **머리글 클릭** = 열 전체(Shift = 열 범위, Ctrl = 더하기), **작업 칸 빈 곳 클릭** = 행 전체(Shift = 행 범위), **마우스로 끌기** = 사각형 범위. 바뀐 곳: `selGrid` `copySel` copy 이벤트 · `nextCell` `moveSel` `extendSel` `selectLines` · 끌기(`DRAG`) · 키 처리 · 본문 클릭.
- 5 그룹장 권한: server.py `SUPER_NAMES = ('구종현',)` — 운영자(서버 PC)와 같은 권한: 모든 메뉴(Management 포함) · 금주 마감 · 휴지통 영구삭제 · 게시판 관리자 삭제 · 시수 실제 시간. **메뉴 권한 설정(⚙, 부서원 권한 주기)만 운영자(서버 PC)** 그대로. 로그인 계정 본명으로 확인(토큰). `/api/info` · `auth/ping` 에 `super` 추가, 화면은 `SUPER` · `MGR()`. 바뀐 곳: server.py `SUPER_NAMES` `is_super` `need_super` · `need_menu` · info · ping · 시수 · trash 영구삭제 · close · board 삭제 / dashboard.html `SUPER` `MGR` `setPerms(p, sup)` `can` `closeWeek` `openTrash` `bAdmin` `renderHeader` `serverLabel` `refreshPerms`.
- 6 익명게시판: 인스타그램 느낌 피드 — 가운데 한 줄 카드, 유형 '스토리' 동그라미(전체 · 블라블라 · 회식제안 · VOC + 글 수), 둥근 검색창, '무슨 이야기를 나눠 볼까요?' 글쓰기 상자, 동그란 프로필(익명 🙂 회색 · 닉네임 색 · 실명 파랑 ✔ · 테두리 = 유형 색), '몇 분 전', 유형 색 카드 안 제목 · 본문, 긴 글은 접고 '… 더 보기', 댓글은 최근 2 개 미리보기 + '댓글 n개 모두 보기', 아래 '댓글 달기… 게시'. 기능(익명/닉네임/실명 · 수정 · 삭제 · 관리자 삭제)은 그대로. 바뀐 곳: `renderBoard` `drawBoard` `agoText` `avatarHtml` · `boardAction`(more) · CSS `.ig*`.
- 7 주간업무보고 첫 화면: 아래 칸을 **왼쪽 = 주간회의 전달사항(크게, 최대 620px · 글자 14.5) + 계장 광장**, **오른쪽 = 최근 변경 이력(작게 · 스크롤 460px)**. 이력은 지난 마감 이후 ~ 이번 주 마감 전까지 전부(건수 표시), '반으로 접기' 단추는 없앰. 바뀐 곳: `renderHome` · CSS `.memo.big` `.recentside`.
- 8 LNG/수소: 그래프 · 사업군 칩에서 LNG 와 수소를 **'LNG/수소' 하나**로(홈 '사업군별 PJT 수' · 수행/입찰 PJT 보드 사업군 칩 · 사업군별 막대 · 표 필터). 마우스를 올리면 'LNG n개 · 수소 n개 · LNG/수소 n개'(엑셀 사업군 값 기준)와 PJT 목록(각 PJT 의 구분). 바뀐 곳: `BIZ_LH` `bizGrp` `lhKind` `lhSplit` `lhLine` · `renderHome` · `pjHero`(`bizTip`) · `filteredRecs`.
- 9 담당자별 담당 PJT 수(홈): 한 막대에 **수행(파랑) · 입찰(주황)** 을 쌓고 끝에 '5 (3 + 2)', 막대 조각에 마우스 = 그쪽 PJT 만, 이름 · 줄 = '■ 수행 n건 … ■ 입찰 n건 …' 로 나눠서. 제목 옆 범례. 바뀐 곳: `PJ_COL` · `svgBars`(parts) · `renderHome`.
- 확인한 것: `py_compile`, JS 문법(`node --check`, 스크립트 부분), 임시 폴더 서버(사본 데이터)로 브라우저: 기술공유 · 통합 업무 기술공유 최신순, ◀ 숨기기 → 새로고침해도 숨김 · ☰ 메뉴로 열림, 열 숨기기(▾ · 선택 열) → 숨긴 열 줄 · ◂ 표시 · 다시 보이기, Shift+→→↓ = 6 칸 · 복사 글/HTML 표, 머리글 클릭 = 열 · Shift = 2 열, 작업 칸 = 행, 끌기 = 15 칸, 구종현(서버 PC 아님) 금주 마감 단추 보임 · ⚙ 안 보임 · Management 보임 · `admin/perms` 403 / 일반 부서원 금주 마감 403, 게시판 피드, 홈 배치, LNG/수소 툴팁, 수행/입찰 막대 툴팁, 스크립트 오류 없음.
- 회사에서 확인할 것: 엑셀에 붙여넣기(표 모양 · 칸 안 줄바꿈). 구종현 계정의 본명이 정확히 '구종현' 이어야 함(띄어쓰기 없이) — 다르면 server.py `SUPER_NAMES` 를 고침.

### 2026-10-22 (7) — 계장 광장: 아이템 들기(선택) · 내려놓기 · 단축키 판 · 얼굴 바꾸기 점검(머리 그리드 안 숨던 것 고침) (PLAZA_VERSION 2026-10-22.6 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5.
- 아이템 들기(선택): 상태판 가방 칸을 누르거나 **Q**(가방의 다음 것, 끝이면 내려놓은 상태) → 든 아이템은 노란 테두리 · 상태판 '🖐 들고 있음: …' · 캐릭터 손 옆에 그림(모두에게 보임, 희귀 이상은 빛). **X** = 든 아이템을 선 자리에 내려놓음(남이 Z 로 주움 · 0.8초 뒤부터). 교환 판을 열면 든 아이템이 '줄 것'에 미리 골라짐. 서버 POST `/plaza/api/hold` `{item}` (없으면 내려놓음) · POST `/plaza/api/drop` `{item}` · snapshot players 에 `held`.
- 단축키 판: **H · ?** 또는 오른쪽 아래 '⌨ 단축키' 단추 — 걷기 · 달리기 · E · Space · 1~4 기술(마나 · 식) · Q · X · Z · Enter · 사람 클릭 · R. Esc 로 닫음. 판이 열려 있으면 키가 캐릭터로 안 감.
- 얼굴 바꾸기 점검(브라우저로 8 종류 × 저장 · 새로고침 · 취소 · 사람 머리 10 종): 저장 · 유지 · 취소 모두 정상. **고친 것**: 사람(머리 모양 그리드)에서 다른 종류로 넘기면 머리 그리드가 그대로 보이던 것 — `.pz-hairs{display:grid}` 가 `hidden` 을 이김 → CSS `[hidden]{display:none!important}`.
- 마법 · 기술: 1~4 키와 기술 칸 클릭 둘 다 됨을 다시 확인(앞에 사람이 없거나 체력이 가득하면 마나 안 씀). 바뀐 곳: plaza_server.py `PLAZA_VERSION` `api_hold` `api_drop` · snapshot(held) · POSTS. plaza.js `S.held` `holdItem` `holdNext` `dropHeld` `drawHeld` `KEY_ROWS` `toggleKeys` · `updateHud`(가방 칸 클릭 · hud-held) · `epcFields`(heldItem) · `drawActor` · `openTrade` · 키 Q · X · H · ?. plaza.html 가방 안내 · `#hud-held` · `#pz-keys` · '⌨ 단축키'. plaza.css 같은 것 + `[hidden]`. selftest.py 들기 · 내려놓기 · 다시 줍기.
- 확인한 것: `node --check` · `py_compile` · `selftest.py` 모두 통과. 브라우저 두 사람: 가방 칸 클릭 → 들림 · 상대 화면에 손 옆 그림, Q 두 번(다음 → 없음), X · Z, 1~4 (전기 충격 55→40 · 현장 지원 → 11 · 상대 +17), H → 15 줄 판 → Esc, 단추로 열기, 사람 → 고양이 양반에서 머리 그리드 숨김, 교환 판 미리 선택, 스크립트 오류 없음.

### 2026-10-22 (8) — 계장 광장: 사람 캐릭터 없앰(동물만) · 케이블 기술자 = 검은 고양이 · 아이템 착용(더블클릭 · F) → 모습 바뀜 (PLAZA_VERSION 2026-10-22.7 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5.
- 사람 캐릭터 없앰: 얼굴 바꾸기 '종류'에서 '사람'을 뺌 → 고양이 기사 · 고양이 양반 · 팬더 학자 · 사자 무관 · 호랑이 무관 · EPC 안전모 (동물만). 무작위 단추도 동물 종류 중에서. 예전에 '사람'으로 저장한 얼굴은 EPC 안전모로(화면 `faceOf` · 서버 `clean_look` 둘 다).
  - EPC 안전모의 케이블 기술자는 사람(작업자) 그림이었음 → **검은 고양이** (치즈 고양이 그림 22 칸의 털색만 짙은 회색으로 바꿔 `epc.png` 맨 아래에 붙임 · `bcat_*` `p_bcat`). NPC 케이블 기술자도 같음.
  - 운영자 = 노비(마을 시트)는 예전 요청대로 그대로 둠 — 노비도 없애려면 plaza.js `roleFace` 의 `kind: 6` 을 바꾸면 됨.
- 아이템 착용: 상태판 가방 칸 **더블클릭**(또는 고른 뒤 **F**) → 손(도구) · 머리(안전모) · 몸(안전 조끼) 칸에 끼기 / 다시 하면 벗기. 낀 칸은 초록 테두리, 상태판 '착용 🖐 렌치 ⛑ 안전모 🦺 안전 조끼', 캐릭터를 누르면 '착용: …'.
  - 모습: 손 = 도구가 손 옆에 · 몸 = 주황 안전 조끼를 입음 · 머리 = EPC 캐릭터는 자기 안전모 색이 등급 색(일반 노랑 · 고급 초록 · 희귀 파랑 · 전설 금), 다른 캐릭터는 머리 위에 작은 안전모. 희귀 · 전설을 끼면 반짝이. 걷기 · 옆 · 뒷모습에서도 보이고, 다른 사람 화면에도 보임.
  - 능력치: 낀 아이템은 공격력 · 마법이 **두 배**로 셈(가방 합 + 낀 것 한 번 더). 가방에서 빠지면(내려놓기 · 교환 · 쓰러짐) 저절로 벗음. 저장 `data/plaza/items.json` 의 `eq`.
  - 단추 정리: 클릭 = 고르기(내려놓기 X · 교환용), 더블클릭 · F = 끼기, 단축키 판에 F 줄 추가. 예전 '들기(손에 보임)'는 '착용 손'으로 합침.
- 바뀐 곳: plaza_server.py `PLAZA_VERSION` · 새 `SLOTS` `SLOT_NAME` `slot_of` `equipped` `api_equip`(POST `/plaza/api/equip`) · `power`(낀 것 한 번 더) · `load_items` `save_items`(eq) · snapshot(`equip`) · `clean_look`(kind 1 → 7). plaza.js `EPC_FR`(bcat) · `JOB_CHAR` · `KINDS` · `faceOf` · `kindRow` · 무작위 · `NPC_DEF` · 새 `SLOT_ICON` `equipItem` `rareTint` `helmTint` `HELM_COL` `drawEquip` · `drawHeld`(손 착용) · `drawActorBody`(그림 위치 `_top` `_h` `_ox` · 안전모 색) · `updateHud`(착용 줄 · 더블클릭) · `epcFields`(equip) · 키 F · `KEY_ROWS` · `showCtx`. plaza.html `#hud-equip` · 안내. plaza.css `.worn` · `.equip`. epc.png(512×334). selftest.py 착용 · 벗기 · 사람 → EPC.
- 확인한 것: `node --check` · `py_compile` · `selftest.py` 모두 통과. 브라우저: 종류 한 바퀴에 '사람' 없음 · 무작위 5 번 모두 동물, 케이블 기술자 = 검은 고양이 초상 · 걷기, 안전모 · 조끼 · 렌치 더블클릭 → 공 21 → 35 · 모습 바뀜(앞 · 옆 · 뒤) · 상대 화면에도 보임, F 로 벗기, 고양이 기사 · 팬더 · 호랑이에도 조끼 · 작은 안전모, 스크립트 오류 없음.

### 2026-10-22 (9) — 판넬 공간확보 메뉴 · 분석·도구 화면 헤더 정리 (APP_VERSION 2026-10-22.3 / SERVER_VERSION 2026-10-22.2)
> server.py 가 바뀜(메뉴 권한 표에 '판넬 공간확보' 한 줄) → **서버 재시작 필요** (8장 3번). 재시작 전에도 화면은 열린다(권한 기본 = 허용).
> 새 파일 `apps\space\index.html` 이 운영 폴더에 생긴다 (패치 APPLY.bat 이 폴더를 만듦). 데이터 폴더는 건드리지 않음.
- 무엇을: 계장 Control Room 판넬 **초기 공간확보 툴**(단일 HTML 프로토타입)을 세 번째 분석 메뉴 '🗄 판넬 공간확보'로 넣음 (P&ID 분석 · LOGIC 분석과 같은 레벨). 왜: 계장이 판넬을 대략 배치해 필요 면적 · 권장 실 크기를 건축에 전달하는 업무.
  - 툴 정리: Google Fonts · claude.ai 전용 다운로드 코드 제거(폐쇄망), 대시보드 색 · 글꼴 토큰, 다크모드 제거, 출력 창이 처음부터 떠 있던 버그(`[hidden]`) 수정.
  - 세 메뉴 맞춤: 흐름 ①②③ 번호 · '<형식> 출력' 버튼 이름 · OK/경고/간섭 pill · 검토 문장에 '→ 어떻게 고치나' · 불러오기 실패 알림.
  - 추가 기능: ① 프로젝트 정보(프로젝트명 · Room 명칭 · 작성자 · Rev → 요약 머리 · DXF 타이틀 · 파일 이름), Panel Type 프리셋 저장/불러오기, Spare 공간 %(+ 증설 방향, 기본 0%), Rev 이력(이전 Rev 대비 면적 변화).
  - 저장: 지금은 브라우저 보관(localStorage `crspace.v1`) + 배치안 JSON 파일. 서버 폴더 저장은 제안만(보고서) — 승인 후 구현.
  - 대시보드: P&ID · LOGIC · 판넬 공간확보 화면에서 위쪽 주간업무 전용 버튼(주차 · 전체 저장 · 금주 마감 · CSV · 엑셀 내보내기 · 인쇄 · 대기열)을 숨기고 부제목을 '<메뉴> · 입력 → 실행 → 결과 → 출력은 아래 화면 안에서' 로. 예전엔 P&ID 화면에서 '엑셀 내보내기'를 누르면 주간업무가 받아졌음.
- 바뀐 곳: dashboard.html 새 `APP_ROUTES` `FRAME_ROUTES` `appUrl` `renderApp`, `render()`(pid-mode · keepPid · 분기) · `ROUTES` · `renderMenu` · `PZ_STATUS` · `renderHeader`(부제목) · CSS `body.pid-mode header.top .actions` / server.py `MENUS` / 새 `apps/space/index.html`.
- 확인한 것: `py_compile`, `node --check`(두 HTML 의 스크립트). 임시 폴더 + 가짜 계정으로 server.py(8780) 와 P&ID 도구(8000, titleblock 브랜치 소스 그대로)를 띄워 Chromium 에서 홈 · P&ID · LOGIC · 판넬 공간확보 캡처, 페이지 · iframe 요청 중 외부 주소 **0건**. 공간확보: 시나리오(기둥 간섭 · 실 밖) 불러오기 → 간섭 2건 문장, 출력 4종 실제 다운로드(.txt · .dxf · .csv(BOM) · .json 이름 그대로), DXF ezdxf audit 오류 0 · Layer 8개 · 글자 스타일 CR-KOR(malgun.ttf), Spare 20% X → 권장 27,700 × 10,600(손 계산 일치), Rev A→B +35.0 m². P&ID · LOGIC 코드는 이 작업에서 0줄 바뀜.
- 회사에서 확인할 것: (1) 서버 재시작 후 ⚙ 메뉴 권한 표에 '판넬 공간확보'. (2) DXF 를 AutoCAD 2026 에서 열어 Layer · 치수 · 한글(CR-KOR = 맑은 고딕) 확인. (3) Edge 개발자도구 Network 탭에서 외부 요청 0건. (4) P&ID 회귀 `python spike/regression_3p.py` 와 LOGIC 샘플 1건 — 코드는 안 바뀌었지만 완료 기준이라 기록을 남김.

### 2026-10-22 (10) — 판넬 공간확보: 어두운 CAD 화면 · 도어 위치/열림 · 회전 궤적 (APP · SERVER 그대로 — apps/space/index.html 만)
> 서버 재시작 · 대시보드 교체 필요 없음. `apps\space\index.html` 만 바꾸고 화면에서 Ctrl+F5.
- 무엇을: 요청 "UI 를 CAD 처럼 어둡게, 도어가 열리는 궤도까지, 판넬 Type 을 만들 때 L-R Open · 전면 · 후면 어디에 도어가 있는지 선택".
  - 기본 화면 = 어두운 CAD(짙은 회색 바탕 · 흰 벽선), 도구줄 [☀ 밝게] 로 예전 밝은 화면 (localStorage `crspace.theme`).
  - Type 카드: Door 위치(없음/전면/후면/전·후면) · 열림(L 힌지/R 힌지/양개 L-R — 그 면 앞에 서서 볼 때 기준). 화면에 열린 문짝 + 점선 호, DXF 새 Layer `CR-DOOR`(LINE + ARC).
  - 검토(경고): 문짝 반경 > 유지보수 공간, 궤적이 벽 · 기둥 · 다른 판넬에 닿음. 궤적이 유지보수 공간 밖이면 필요 영역에 포함.
  - 예전 배치안 · 프리셋 Type 은 '도어 없음' → 예전 숫자 그대로. CSV 에 Door · Hinge 열.
- 바뀐 곳: apps/space/index.html — CSS 테마 토큰(`:root` 어두움 · `[data-theme=light]`), `setTheme`, `DOOR_AT` `HINGE` `fixDoor` `FRONT_N` `edgeOf` `doors`, `check`(도어 경고), `envelope`, `render`(문짝 · 호), `buildTypes`(선택칸), `cleanType`, 요약 · CSV · DXF(`arc`, CR-DOOR).
- 확인한 것: `node --check`. 임시 서버 + Chromium: 도어 시험 배치(L · R · 양개 · 1200 단문 · 후면만 · 벽 옆) → 경고 3건 기대대로, DXF ezdxf audit 오류 0 · ARC 15 = 문짝 수 · 각도 확인, 도어 없는 예전 시나리오 권장 실 23,400 × 10,600 그대로, 외부 요청 0건.
- 회사에서 확인할 것: AutoCAD 에서 CR-DOOR 호의 방향(힌지 쪽)이 화면과 같은지, L/R 기준(앞에서 볼 때)이 부서 관례와 맞는지.

### 2026-10-22 (11) — 판넬 공간확보: DXF Layer 색을 화면과 같은 톤으로 (apps/space/index.html 만)
- 무엇을: 요청 "DXF 출력도 너무 눈부시다. UI 와 같은 색감으로". 원색(빨강 1 · 노랑 2 · 초록 3 · 자홍 6 · 순백 7)을 화면 색에 가장 가까운 ACI 로.
  CR-ROOM 254 · CR-COLUMN 8 · CR-PANEL 253 · CR-PANEL-FRONT 254 · CR-CLEARANCE 43 · CR-ENVELOPE 161 · CR-TEXT 9 · CR-DIM 151 · CR-DOOR 133. Layer 이름 · 도형은 그대로.
- 바뀐 곳: `$('#bDxf').onclick` 의 `layers`.
- 확인한 것: ezdxf audit 오류 0, Layer 색 읽어 확인, 화면 바탕색(#212830)으로 그려 비교.
- 회사에서 확인할 것: AutoCAD 바탕이 흰색이면 회색 선(254 · 9)이 흐릴 수 있음 — 그 경우 CR-ROOM · CR-TEXT 를 7 로 되돌리면 됨.

### 2026-10-22 (12) — 판넬 공간확보: PPT 도형 삽입처럼 Type 만들기 · 저장 · 눌러서 배치 (apps/space/index.html 만)
- 무엇을: 요청 "Panel 을 PPT 주석 넣듯 Type 별로 생성 · 저장하고, 생성된 Type 을 누르면 그 Type 의 panel 을 배치". 개발 의도 = 1단계(계장이 빈 상태에서 판넬을 배치해 필요 볼륨 산출) → 건축 전달 → 건축 Room CAD → 계장이 그 CAD 를 backdrawing 으로 상세 배치.
  - 도구줄 아래 'Panel 삽입' 줄(그림 단추) → 누르면 배치 모드 → 도면 클릭. ✎/두 번 누르기 = 고치기, [＋ 새 Type] = 만들기 창(실시간 미리보기 · 입력 오류 문장).
  - 📚 라이브러리(localStorage `crspace.lib.v1`) — 다른 프로젝트에서 다시 쓰기.
- 바뀐 곳: apps/space/index.html — HTML `.ribbon #palette` · `#tdlg` · `#libdlg`, `buildTypes`(삽입 줄), `typeSvg` `doorSvg`, `geom(p, tt)`, `openTypeDlg` `tdRead` `tdPreview` `tdSave`, `libGet` `libSet` `libPut` `buildLib`, 키 입력(열린 창이면 도면 단축키 끔 · Esc 닫기). 사이드 Type 입력 카드 삭제.
- 확인한 것: `node --check`, Chromium 으로 만들기 → 만들고 배치 → 도면 클릭 2 EA, 다른 Type 단추 배치, 이름 중복 오류, 라이브러리 1건, 스크립트 오류 0.
- 회사에서 확인할 것: 라이브러리는 PC · 브라우저마다 따로 (Edge 사이트 데이터 지우면 사라짐) — 부서 공용은 서버 저장(보고서 5-1) 승인 시.

### 2026-10-22 (13) — 판넬 공간확보: 서버에 프로젝트별 · 날짜별 저장 · 저장 이력 · 프로젝트 노트 / 도면 노트 / 기둥 편집 (APP_VERSION 2026-10-22.4 / SERVER_VERSION 2026-10-22.3)
> server.py 가 바뀜 → **서버 재시작 필요** (8장 3번). 운영 폴더에 `space\` 폴더가 생긴다(일일 백업 zip 에 포함). 부서원 사본은 새 버전 배너로 교체.
- 무엇을: 요청 "프로젝트별 · 날짜별로 작업을 저장, 도면에 또는 별도 노트를 추가, 다른 부서원이 그 history 를 볼 수 있게, 기둥 위치도 사용자가 바꿀 수 있게".
  1. 서버 저장 (server.py 새 API `space/…`, 위 5장 표): 저장은 덮어쓰지 않고 매번 새 파일 → 날짜별 이력(시각 · 저장한 사람 · 메모 · Rev · 판넬 수 · 필요 영역 · 권장 실). 프로젝트 노트(시각 · 사람). 작성자 = 서버가 로그인 토큰으로 정함.
  2. 앱: ① 에 '서버 프로젝트' 상자 [💾 서버에 저장] [🗂 프로젝트 · 이력 · 노트], 🗂 창(프로젝트 · 저장 이력 · 프로젝트 노트 세 칸), 저장본 열기, '서버 저장 이후 바뀜' 표시.
  3. 도면 노트: [📌 노트] → 도면 위 번호 핀 + 말풍선, 목록 · 끌어 옮기기 · 고치기, 배치안에 저장(서버 이력에도), 요약 7절 · DXF CR-NOTE.
  4. 기둥 편집: [기둥 편집] → 기둥 Drag 이동 · 빈 곳 클릭 추가 · Delete 삭제 · X/Y/W/H 입력, [격자로 다시 만들기].
  5. dashboard.html: 연결 앱에 로그인 토큰을 postMessage 로 전달(부서원 file:// 사본은 앱 주소의 저장소를 못 읽음) — 받는 쪽 = 앱 주소로 한정.
- 바뀐 곳: server.py 새 `SPACE_ID_RE` `space_id` `space_idx_path` `space_idx` `space_name` `api_space_projects` `api_space_project_new` `api_space_get` `api_space_save_get` `api_space_save` `api_space_note_add` `api_space_note_del`, `api()` 의 `space` 분기, 백업 · 시작 폴더에 `space` / dashboard.html `renderApp` · 새 `appAuth` · `render()` / apps/space/index.html `sapi` `openHist` `loadProjects` `loadProject` `updSrv`, 노트(`hitNote` `openNote` `saveNote` `buildNotes`), 기둥(`toCustomCols` `hitCol` `delCol`, `columns()` 이 `S.cols` 우선).
- 확인한 것: `py_compile`, `node --check`, 임시 폴더 서버 + 가짜 계정 두 개(홍길동 · 김철수): API 생성 · 중복 409 · 비로그인 401 · 잘못된 배치안 400 · 잘못된 ID 400 · 노트 삭제 · 저장본 읽기. 브라우저: 홍길동 저장 2회 · 노트 → 김철수가 이력 2건 · 노트 1건 보고(남의 노트 지우기 없음) 첫 저장본 열기, file:// 사본에서 postMessage 로 로그인 전달, 도면 노트 · DXF(audit 0), 기둥 이동 · 추가 · 삭제 · 격자로 다시. 스크립트 오류 0.
- 회사에서 확인할 것: (1) 서버 재시작 후 [🗂] 창이 열리는지, 두 사람이 서로의 저장 · 노트를 보는지. (2) 부서원 PC(file:// 사본)에서 [💾 서버에 저장] 이 본인 이름으로 남는지. (3) 메뉴 권한 표에서 '판넬 공간확보' 를 끈 사람은 보기만 되는지.

### 2026-10-22 (14) — 판넬 공간확보: P&ID · LOGIC 과 같은 첫 화면 (APP 그대로 / SERVER_VERSION 2026-10-22.4)
> server.py 가 바뀜(GET `space/recent` 한 개) → **서버 재시작 필요**. (11) 과 함께 적용하면 재시작 한 번.
- 무엇을: 요청 "프로젝트별 저장은 P&ID 분석 · LOGIC 분석 첫 화면 UI 와 같이". 메뉴에 들어오면 첫 화면 — ① 어디에 넣을지(프로젝트 · 새 프로젝트 · Room · Rev) · ② 어떻게 시작할지(최근 저장본 / 하던 작업 / 빈 실 / 예시 / JSON) · [배치 시작] · 저장된 프로젝트 · 최근 저장 이력. 배치 화면 [⌂ 첫 화면] 으로 돌아옴. 첫 화면은 밝게(P&ID · LOGIC 첫 화면과 같은 색 · 모양), 배치 화면은 어두운 CAD.
- 바뀐 곳: server.py 새 `api_space_recent` + `space` 분기 / apps/space/index.html `#home` (CSS `.lh-*` `.pj*` `.jn` `.jm` — LOGIC logic.css 와 같은 이름), `showHome` `showEditor` `hmLoad` `hmRender` `hmLast` `hmOpen`, `#hmGo`, 도구줄 `#bHome`, `HAD_LOCAL`.
- 확인한 것: `py_compile`, `node --check`, Chromium 으로 첫 화면 → 새 프로젝트 → 배치 시작 → 서버 저장 → 첫 화면에 카드 · 최근 이력 → 이력 줄로 열기. 스크립트 오류 0.
- 회사에서 확인할 것: P&ID · LOGIC 첫 화면과 나란히 봤을 때 같은 느낌인지.


### 2026-10-22 (15) — 통합: 계장 광장(판 7 · 8) 과 판넬 공간확보(판 9~14) 를 한 판으로 (APP_VERSION 2026-10-22.4 / SERVER_VERSION 2026-10-22.4 / PLAZA_VERSION 2026-10-22.7)
- 두 갈래가 따로 만든 수정본을 합침. 겹친 파일은 이 문서뿐(광장은 plaza/ 만, 판넬 공간확보는 dashboard.html · server.py · apps/space/ 만 바꿈).
- 위 (9)~(14) 는 판넬 공간확보 쪽에서 (7)~(12) 로 적었던 것을 번호만 뒤로 옮김.
- 회사에서: server.py 가 바뀜 → 서버 재시작. 적용 후 Ctrl+F5 → 왼쪽 메뉴 '🗄 판넬 공간확보' · 홈 '계장 광장' 둘 다 확인.

### 2026-10-22 (15) — 계장 광장: 착용이 몸에 자연스럽게 · 무기마다 휘두르기 효과 (PLAZA_VERSION 2026-10-22.8 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5. (이 번호는 판넬 공간확보 (12)~(14) 다음)
- 무엇을: 요청 "아이템 끼면 자연스럽게 껴져야 하고, 무기 휘두를 때 이펙트가 무기 특성에 맞아야 한다" (사진: 노비 위에 조끼 그림이 통째로 붙고 케이블 드럼이 몸을 가림).
  - 몸(안전 조끼): 그림을 위에 붙이지 않고 **캐릭터 그림의 몸통 점 색을 형광 주황 + 반사띠 두 줄**로 바꿈(외곽선 · 머리 · 다리는 그대로) — 어느 캐릭터(EPC · 고양이 기사 · 마을 · 노비)나, 앞 · 옆 · 뒤 모두.
  - 머리(안전모): EPC 는 자기 안전모 색 = 등급 색(그대로), 안전모가 없는 캐릭터는 머리 폭에 맞춘 크기로 머리 위에.
  - 손(도구): 캐릭터 키의 36% 크기로 줄여 **몸 옆 손 높이**에 (몸통을 가리지 않음, 왼쪽을 보면 왼손).
  - 휘두르기(Space · 1 강타): 목검 대신 **손에 낀 도구를 실제로 휘두르고**, 효과는 도구 성질대로 —
    둔기(렌치 · 단자대 · 글랜드 · 압력계 · 포지셔너) = 무거운 호 + 끝에서 '쾅' 충격 고리 · 불똥 / 찌르기(드라이버) = 앞으로 찌름 + 별빛 /
    채찍(케이블 드럼 · 계장 케이블 · 에어 · 임펄스 튜브) = 케이블이 앞 칸으로 휘감겨 '찰싹'(케이블 색) / 전기(HART · 멀티미터 · 교정기 · 노트북 · DCS 카드) = 내민 도구에서 번개 + 파란 빛 /
    전파(무전기) = 퍼지는 전파 고리 / 분사(교정 펌프) = 물안개 / 종이(점검표) = 종이 휘두르기 + 종잇조각. 희귀 · 전설은 맞는 곳에 등급 빛. 공격 칸이 있는 마을 캐릭터 · 고양이 기사도 도구를 끼면 같은 효과. 도구가 없으면 예전 목검.
- 바뀐 곳: plaza_server.py `PLAZA_VERSION` 만. plaza.js 새 `WPN` `WHIP_COL` `SWING_A` `drawWeaponSwing` `cvCam` `vestTint` `dress` · `drawSwing`(도구 있으면 그쪽) · `drawEquip`(조끼 덧그림 없앰 · 안전모 크기) · `drawHeld`(크기 · 자리) · `drawActorBody`(모든 캐릭터 `dress` · 그림 너비 `_w` · 도구 휘두르기 조건).
- 확인한 것: `node --check` · `py_compile` · `selftest.py` 모두 통과. 브라우저: 운영자(노비) 조끼 · 안전모 · 케이블 드럼 → 몸에 입혀짐 · 드럼은 손 옆 · 왼쪽 걷기 · Space = 케이블 채찍. EPC 캐릭터 렌치 · 드라이버 · 케이블 드럼 · HART · 무전기 · 교정 펌프 · 점검표 하나씩 끼고 Space — 들고 있는 모습과 휘두르는 두 순간 캡처로 효과 7 종 확인, 스크립트 오류 없음.

### 2026-10-22 (16) — 익명게시판 메뉴별 VOC (실명 · 그림 첨부) · 모든 화면 '📷 스크린 → VOC' (APP_VERSION 2026-10-22.5 / SERVER_VERSION 2026-10-22.5)
> server.py 가 바뀜 → **서버 재시작 필요** (8장 3번). 부서원 사본은 새 버전 배너로 교체. 그림은 운영 폴더 `board\img\` 에 저장(게시판 폴더라 일일 백업에 함께).
- 무엇을: 요청 "익명게시판에 각 메뉴별 VOC · VOC 는 실명만 · 왼쪽 = 사진/스크린 미리보기 · 오른쪽 = VOC 적는 칸 · 모든 화면에서 스크린 단추 → 범위 지정 → 바로 VOC · 등록해도 지금 화면 유지(예: P&ID 분석)".
  - 게시판: 'VOC' 동그라미를 누르면 메뉴 탭(전체 · 주간업무보고 · P&ID 분석 · LOGIC 분석 · 판넬 공간확보 · 입찰/실행 프로젝트 · 익명게시판 · Management · 계장 광장 · 기타 + 글 수) · [📣 VOC 쓰기] · [📷 화면 캡처로 VOC]. VOC 글 카드에 '📍 메뉴' · 첫 그림 크게 + 나머지 작게(누르면 원본 새 창).
  - VOC 창: 왼쪽 = 그림 미리보기(끌어다 놓기 · **Ctrl+V 붙여넣기** · 파일 고르기 · [📷 화면 캡처 추가], 최대 6 장, 큰 그림은 JPEG 로 줄임), 오른쪽 = 메뉴(지금 보던 화면이 기본) · 제목 · 내용 · '작성자 ✔ 본명'. 예전 글쓰기 창에서 VOC 를 고르면 이 창으로. VOC 글 수정도 이 창.
  - **실명만**: 서버가 VOC 글은 익명 · 닉네임을 보내도 로그인 본명으로 기록(비회원 401).
  - **📷 스크린 → VOC** 단추: 위쪽 제목 옆(P&ID · LOGIC · 판넬 공간확보 화면에서도 보임). 누르면 브라우저 화면 공유('이 탭' 허용) → 멈춘 화면 위에서 끌어 범위 지정(Enter = 전체 · Esc = 취소) → 그 자리에 VOC 창(메뉴 = 지금 화면) → 등록 → 안내 한 줄, **화면 전환 없음**(P&ID 분석 iframe 그대로).
  - 브라우저 제한: 화면 캡처(getDisplayMedia)는 보안 연결에서만 됨 — 서버 PC(localhost) · 부서원 file:// 사본은 됨, `http://PC이름:8080` 으로 연 화면은 막힘 → 'Win+Shift+S 로 캡처 후 VOC 창에 Ctrl+V' 안내 후 VOC 창을 엶.
- 바뀐 곳: server.py `SERVER_VERSION` · 새 `VOC_MENUS` `IMG_ID_RE` `IMG_MAX` `IMG_TYPES` `VOC_IMG_MAX` `img_ext`(PNG/JPG/GIF/WEBP 머리 바이트 확인) `img_path` `api_board_img_put` `board_voc` · `api_board_create` `api_board_update`(뺀 그림 지움) `api_board_delete`(그림도 지움) · `board` 분기(GET `board/img/{id}` 누구나 · PUT `board/img` 로그인 + 게시판 권한). dashboard.html `APP_VERSION` · `Board.create/update`(menu · images) · `BS.vmenu` · `renderBoard`(#bvoc) · `drawBoard`(메뉴 탭 · 필터 · 그림) · `boardAction`(VOC 수정) · `openPost`(VOC → 창 바꿈) · 새 `VOC_MENU` `imgUrl` `vocImgsHtml` `vocMenuOf` `blobToJpeg` `openVoc` `captureRegion` `pickRegion` `shotToVoc` · `#btnShot` · CSS `.vtabs` `.vimgs` `.vocdlg` `.shotov` `.shotbtn`.
- 확인한 것: `py_compile` · JS 문법. 임시 서버 + 가짜 계정 브라우저(Chromium, 탭 캡처 자동 허용): P&ID 분석 화면에서 📷 → 범위 600×450 → VOC 창(메뉴 = P&ID 분석 · 그림 1) → 파일 하나 더(2 장) → 등록 → 창 닫힘 · 주소 #pid 그대로 · P&ID 화면 그대로, 게시판 VOC › P&ID 분석 탭에 글 1 · 그림 2 장 표시(실제 크기로 읽힘), 일반 글쓰기에서 VOC 고르면 VOC 창, 서버에 익명으로 보내도 본명 · 없는 그림 ID 는 버림, 보안 연결이 아닌 주소에서 안내 → VOC 창. 스크립트 오류 없음.
- 회사에서 확인할 것: (1) 서버 재시작 후 부서원 PC(file:// 사본)에서 📷 → Edge 가 '이 탭 공유'를 물으면 허용. (2) `http://PC이름:8080` 으로 여는 사람은 Win+Shift+S → Ctrl+V. (3) 그림이 큰 VOC 가 많으면 `board\img` 용량 확인(그림 하나 최대 8MB, 보통 0.2~1MB).

### 2026-10-22 (17) — 계장 광장: 접속 경험치 (하루 첫 접속 · 연속 접속일 · 접속 유지) · 레벨 업 때 체력 · 마나 가득 (PLAZA_VERSION 2026-10-22.9 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5.
- 무엇을: 요청 "접속 횟수 · 접속 유지가 많고 오래될수록 경험치를 주고, 레벨이 오를 때마다 체력 · 마나를 적절히 올려라".
  - **하루 첫 접속 +10 XP**, **연속 접속일 보너스** 이틀째부터 하루마다 +4 (7일 연속부터 최대 +28/일). 같은 날 다시 들어와도 한 번만.
  - **접속 유지**: 광장에 연결되어 있으면(대시보드 어느 메뉴에 있든 광장 접속은 유지됨) 5분마다 +2, 오늘 1시간 넘게 머물면 5분마다 +3. 켜 두기만 해서 끝없이 오르지 않게 **하루 60 XP 까지**.
    → 하루 최대 약 10 + 28 + 60 = 98 XP. 예) 매일 30분 접속 · 일주일 연속이면 Lv 1 → 약 Lv 5. 설비 작업 경험치(5 · 10 · 20, 직무 1.5배)는 그대로.
  - **레벨 업**(어떤 경험치로든): 최대 체력 +10 · 마나 +5 (예전 규칙 그대로, Lv 30 까지) + **체력 · 마나 가득 참**(유령은 그대로) + 대화창 '🎉 Lv n 달성! 최대 체력 … (+10) · 마나 … (+5) — 가득 찼습니다' + 머리 위 '레벨 업!' · 금빛 불꽃.
  - 화면: 받으면 머리 위 '+2 XP · 접속 유지 25분' 등. 상태판에 '🕒 오늘 n분 · 🔥 연속 n일 · 접속 XP n/60 · 총 n일'. 머리 위 글이 여럿이면 줄을 바꿔 차례로(겹쳐 읽히던 것 고침).
  - 값은 plaza_server.py `VISIT_XP` `STREAK_XP` `STREAK_CAP` `STAY_EVERY` `STAY_XP` `STAY_LONG` `STAY_CAP` 에서 바꿈. 기록 `data/plaza/xp.json` 의 `pres`(오늘 머문 초 · 받은 접속 XP) · `streak`(연속일 · 총 접속일).
- 바뀐 곳: plaza_server.py `PLAZA_VERSION` · 새 `VISIT_XP` … `STAY_CAP` `today_str` `pres_of` `add_xp`(레벨 업 · 가득 · 알림) `visit_xp` `stay_tick`(10초마다) · `api_work`(add_xp 로) · `api_join`(두 갈래 모두 visit_xp) · `hp_loop` · `eq_init`(읽기) · `save_xp` · snapshot(xp_seq · xp_gain · xp_why · xp_age · lvup_age · pres). plaza.js `epcFields`(접속 XP · 레벨 업 표시) · `updateHud`(#hud-pres) · `floater`(줄 바꿔 차례로) · `drawFloats`. plaza.html `#hud-pres`. plaza.css `.pres`. selftest.py 접속 경험치 · 같은 날 한 번 · 5분 +2 · 하루 상한 · 연속 이틀째 · 레벨 업 가득(작업 경험치 기대값에 첫 접속 +10 반영).
- 확인한 것: `py_compile` · `node --check` · `selftest.py` 모두 통과. 브라우저: XP 95 · 체력 40 인 캐릭터가 들어오자 +10 → Lv 3 · 체력 120/120 · 마나 60/60 · 대화창 알림, 615 → Lv 6 (150 · 75), 머리 위 '+10 XP · 오늘 첫 접속' · '레벨 업!' · '최대 체력 · 마나 증가 · 가득 참' 이 세 줄로 차례로, 상태판 접속 줄, 스크립트 오류 없음.

### 2026-10-22 (18) — 계장 광장: 레벨 무기 빛 · NPC 한마디 · 박병두 프로님 동상 · 복지 구역(식당 · 헬스장 실내) · 지도 확장 (PLAZA_VERSION 2026-10-22.10 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 (대시보드 서버가 30초 안에 새 판 광장으로 바꿈) → 적용 후 30초 뒤 Ctrl+F5.
- 무엇을: 요청 "레벨 오를수록 무기 빛 · 임팩트 화려하게 / NPC 를 때리면 '이름 프로님 그만좀 때리세요!!' / NPC 를 마우스로 누르면 '아!! 프로님 왜 불러요!! 바쁜데' / 광장에 '박병두 프로님' 동상 — 때리면 움직여 때린 사람을 따라다니며 10번 때리고 제자리로 와서 다시 동상 / 광장을 더 크게 · 식당 · 헬스장 · 들어가면 배경이 바뀌게".
  - **레벨 빛**: 휘두를 때 무기 빛 · 빛 꼬리 · 맞는 곳 고리(1~4겹) · 빛살 · 섬광 · 불꽃이 레벨에 따라 커짐. 색 단계 1~4 없음 · 5~9 초록 · 10~14 파랑 · 15~19 보라 · 20~29 주황 · 30 무지개. Lv 5 부터 손에 든 도구 둘레도 맥동하는 빛(15 부터 반짝이).
  - **NPC 한마디**(모두에게 보임): Space 로 앞 칸 NPC 를 치면 NPC 가 붉게 번쩍 + '박부서 프로님 그만좀 때리세요!!', 마우스로 누르면 '아!! 프로님 왜 불러요!! 바쁜데'. 연타는 0.4초에 한 번. NPC 체력 · 경험치는 없음(놀이).
  - **박병두 프로님 동상**: 복지 광장 가운데 받침대(칸 78,31 · 명판 '박병두 프로님'). Space(또는 1 강타)로 치면 흔들리며 깨어나 → 때린 사람이 **걸은 칸을 그대로 밟아** 따라가(벽을 뚫지 않음, 문으로 들어가면 같이 들어감) 곁에서 0.8초마다 한 대씩 **10대**(한 대 체력 −3, 운영자는 무적이라 시늉만) → 걸어온 길을 되짚어 받침대로 돌아와 다시 돌빛 동상. 쓰러지거나 나가거나 2분이 지나면 바로 돌아감. 대화창에 깨어남 · 10대 알림, 머리 위 '1대!' … '10대! 이제 됐다.'
  - **지도 확장** 64×44 → 96×60: 동쪽에 '복지 구역'(식당 · 헬스장 건물 · 보도블록 광장 · 꽃밭 · 벤치 · 가로등 · 나무 · 자판기), 큰길을 동쪽 끝까지. 아래 44~59 줄은 **실내**(바깥과 안 이어짐).
  - **실내 · 배경 바뀜**: 건물 문 칸(식당 71,11 · 헬스장 86,11)으로 걸어 들어가면 화면이 잠깐 어두워졌다 밝아지며 방 안으로 — 카메라는 그 방만, 밖은 어둡게, 바닥 · 벽 · 소품이 실내로. 식당 = 마루 · 크림 벽지 · 배식대(김 나는 반찬통) · 메뉴판 · 식탁 12 · 식판 반납 · 정수기. 헬스장 = 고무 바닥 · 거울 벽 · 러닝머신 4(벨트 움직임) · 덤벨 · 벤치프레스 · 스쿼트랙 · 샌드백 · 매트. 방 아래 빨간 깔개 칸으로 나오면 건물 앞. 현장 지도는 바깥만(실내면 건물 자리에 내 점), 동상 점(돌빛 · 깨면 빨강).
- 바뀐 곳: plaza_server.py `PLAZA_VERSION` · `MAP_W/MAP_H` 96·60 · 새 `STATUE_*` `STATUE` `statue_say` `statue_wake` `statue_front` `statue_trail` `statue_step` `statue_home` `statue_tick` `statue_loop`(0.07초 스레드) `statue_snap` `NPC_LINES` `NPC_SAY` `api_npc`(POST /plaza/api/npc {id, npc, kind: hit|click}) · `api_attack`·`api_skill`(강타)에서 동상 깨움 · `api_move`(쫓기는 사람 칸 적기) · snapshot(statue · npc_say) · `main`. plaza.js `W/H` · 새 `H_OUT` 땅 종류 `WOOD RUBBER VOID WALLI PAVE` · `ROOMS` `DOORS` `roomAt` `goDoor` `STATUE_HOME` · 새 그림 `foodHallImg` `gymImg` `awning` `pedestalImg` `flowerBedImg` `counterImg` `menuBoardImg` `tableImg` `chairsImg` `waterImg` `trayRackImg` `treadmillImg` `dumbbellImg` `benchPressImg` `squatRackImg` `punchBagImg` `matImg` `bannerImg` · `drawGround`(정수 해시 `ih` 로 빠르게 · 마루 · 고무 · 보도블록 · 실내 벽 · 동상 둘레 무늬) · `frame`(방 카메라 · 잘라 그리기 · 문 안내 · 방 이름 · 어둡게 전환) · `drawMini` · 새 `lvFx` `lvRgb` · `drawWeaponSwing` `drawSwing` `drawHeld` · NPC `npcOn` `npcAtPx` · 동상 `statueActor` `stoneTint` `statueLift` · `applySnapshot` · `attack` · 캔버스 클릭 · `nameTag` `jobTag` `occupied` · `KEY_ROWS`. plaza.html/css 현장 지도 192×88. selftest.py NPC 말 2 · 동상 2.
- 확인한 것: `py_compile` · `node --check` · `selftest.py` 모두 통과. 브라우저(임시 서버): 동상 앞에서 Space → 흔들리며 깨어남 → 오른쪽으로 달아나자 같은 칸을 밟아 따라와 10대(체력 −30) → 제자리 돌빛 동상. 식당 문 → 방 안(배경 · 카메라 바뀜) → 빨간 깔개 → 건물 앞, 헬스장도 같음. NPC 치기 · 누르기 말풍선. Lv 1 · 10 · 20 · 30 휘두르기 캡처 비교. 스크립트 오류 없음.
- 회사에서 확인할 것: 두 사람이 함께 들어가 동상 쫓기 · 식당 안에서 서로 보이는지. 예전에 칸 62~63(옛 동쪽 끝)에 떨어뜨린 아이템은 그 자리 그대로.

### 2026-10-22 (19) — 계장 광장: 배경 품질 — 해질녘 · 밤 조명 · 땅 · 나무 다듬기 (PLAZA_VERSION 2026-10-22.11 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 → 적용 후 30초 뒤 Ctrl+F5.
- 무엇을: 요청 "첨부한 epc_plant_game_starter.zip 같은 퀄리티로 배경 개선". 첨부의 참고 그림(EPC 발전플랜트 야경 — 남색 · 철골 회색 · 따뜻한 작업등 · 상태 LED · 풍성한 나무)은 **보기만** 하고(그림 · 로고는 넣지 않음), 지금 지도 · 설비 · 충돌 · 캐릭터는 그대로 두고 그리는 방식만 바꿈.
  - **해질녘 · 밤 조명**(기본): 화면 전체를 남색으로 낮추고, 가로등 아래 노란 빛 웅덩이(살짝 일렁임) · 켜진 창(건물 · 현장 사무소 · 경비실 · 식당은 따뜻한 색 · 헬스장은 흰 파랑) · 제어실 화면 · 자판기 · 가로등 머리가 스스로 빛남. 설비는 상태 색 빛(정상 초록 · 경고 주황 · 고장 빨강 깜빡), 사람 · NPC 둘레는 은은한 빛(얼굴이 보이게), 휘두르면 무기 빛이 땅을 비춤(레벨이 높을수록 크게), 유닛장 회복 오라는 초록 빛. 화면 가장자리는 조금 더 어둡게. 실내는 천장 등(식당 따뜻 · 헬스장 차가움).
  - **🌙 밤 / ☀ 낮** 단추(오른쪽 아래 '얼굴 바꾸기' 옆): 예전 낮 화면으로 돌아감 · 이 PC 브라우저에 기억.
  - **땅**: 차도 연석(밝은 돌 줄 + 차도 쪽 그늘) · 잔디 가장자리 그늘 · 잔디 결 · 아스팔트 균열 · 바퀴 자국 · 막힌 칸(설비 · 건물 밑동) 아래 · 오른쪽 접지 그림자.
  - **나무 · 덤불**: 잎 3~4 톤(아래 그늘 → 왼쪽 위 빛 · 잎 끝 점) · 밑동 그림자 · 덤불 꽃.
  - 이름표 · 말풍선 · 설비 표시 · 효과는 조명 뒤에 그려 늘 또렷함. 빛 지도는 반 해상도로 그려 느려지지 않게(시험 PC 50 fps 안팎).
  - 참고: 스타터가 권한 '1.5~1.8배 확대'는 하지 않음 — 지금 캐릭터 키가 화면 높이의 약 8% 로 스타터 기준(7~12%) 안이라서.
- 바뀐 곳: plaza.js 새 `lit` `WARM` `COOL` `SCREEN` `NIGHT` `nightBtn` `toggleNight` `AMB_*` `drawNight` · `building`(창 · 간판 빛, `glowCol`) · `lightPoleImg` `vendingImg`(→`vendingImg0`) `crWallN`(→`crWallN0`) · 현장 사무소 · 경비실 put · `treeImg` `shrubImg` · `drawGround`(연석 · 그늘 · 잔디 결 · 균열 · 바퀴 자국) · `frame`(drawNight). plaza.html `#pz-night`. plaza_server.py `PLAZA_VERSION` 만.
- 확인한 것: `node --check` · `py_compile` · `selftest.py` 모두 통과. 브라우저: 큰길 네거리 · 터빈 홀 앞 · 공정 구역 · 복지 구역(식당 · 헬스장 앞) · 동상 광장 · 식당 · 헬스장 안을 밤 · 낮으로 캡처, 스크립트 오류 없음, 약 50 fps.
- 회사에서 확인할 것: 회사 PC 에서 너무 어둡거나 느리면 ☀ 낮 단추. 어둡기는 plaza.js `AMB_OUT`(바깥 남색, 숫자가 클수록 밝음)에서 바꿈.

### 2026-10-22 (20) — 계장 광장: 공격 = 무기를 손에 쥐고 휘두르는 동작 (PLAZA_VERSION 2026-10-22.12 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 → 적용 후 30초 뒤 Ctrl+F5.
- 무엇을: 요청 "공격 모션을 무기로 공격하는 자연스러운 동작으로". 예전엔 무기 그림이 손에서 떨어져 몸 둘레를 돌았고, 몸은 거의 안 움직였고, 시트의 '수리' 칸(손에 렌치가 그려져 있음)을 써서 도구가 둘로 보였음.
  - 한 번 휘두르기 = **준비**(몸을 뒤로 젖히며 무기를 머리 뒤로 들어 올림, 내려치기는 살짝 솟음) → **휘두름**(점점 빠르게 · 무기 뒤로 옅어지는 잔상) → **맞힘**(멈칫 · 무기 끝에서 충격) → **돌아옴**(허리 옆 쉬는 자리). 0.28 → 0.32초.
  - **손잡이가 늘 손에** 붙어 있고 손은 몸과 함께 움직임(쉴 때 허리 · 들어 올리면 어깨). 머리 뒤로 들어 올린 동안 · 뒷모습일 때는 무기를 몸 뒤에 그림.
  - 도구마다 쥐는 법: 렌치 · 단자대 · 글랜드 · 압력계 · 포지셔너 = 내려치기 / 드라이버 = 당겼다 찌르기 / 점검표 = 옆으로 후려치기 / 목검(맨손) = 베기 / 케이블 드럼 · 케이블 · 튜브 = 들고 케이블을 앞으로 '찰싹' / HART · 멀티미터 · 교정기 · 노트북 · DCS 카드 · 무전기 · 교정 펌프 = 세워 든 채 앞으로 내밀어 끝에서 번개 · 전파 · 물안개(반동).
  - EPC 시트 도구 아이콘은 비스듬하고 옆 아이콘이 섞여 있어, 무기마다 깨끗한 자리 · 손잡이 점 · 머리 점을 따로 적음(`WGRIP`).
  - 몸 그림은 서 있는 칸 그대로(걷기 칸은 크기가 작아 몸이 줄었다 커져 보였음) — 움직임은 젖힘 · 내딛음 + 손의 무기.
  - 레벨 빛(판10)은 무기 끝을 따라감.
- 바뀐 곳: plaza.js `ATK_MS` 320 · 새 `ATK_ARC` `easeO/easeI/easeIO` `atkCurve` `atkKind` `atkLean` `scrAng` `handOf` `WGRIP` `WSC` `weaponIcon` `weaponLen` `weaponTip` `uprightTilt` `drawWeaponAt` `drawAttack` · `drawSwing`(몸 뒤 · 앞 두 번) · `drawActorBody`(젖힘 · 내딛음, 네 갈래 모두 drawSwing 두 번) · `epcPose`(공격 중 서 있는 칸). 옛 `drawWeaponSwing` 없앰. plaza_server.py `PLAZA_VERSION` 만.
- 확인한 것: `node --check` · `selftest.py` 모두 통과. 브라우저에서 시각을 멈춰 렌치 · 드라이버 · 케이블 드럼 · HART · 무전기 · 점검표 · 목검 × 4 방향 × 8 순간 캡처로 동작 확인, Space 꾹 누르기(실제 시간) 연속 휘두르기, 스크립트 오류 없음.

### 2026-10-22 (21) — 계장 광장: 그래픽 해상도 2배 · 4배 (PLAZA_VERSION 2026-10-22.13 / APP · SERVER 그대로)
> 서버 재시작 필요 없음 → 적용 후 30초 뒤 Ctrl+F5.
- 무엇을: 요청 "계장 광장 그래픽의 해상도를 높여줘". 그림은 점(dot) 하나 = 2px 의 픽셀 그림이라 한 점이 2×2 네모로 커져 계단 모서리가 보였음.
  - **2배 (Scale2x / EPX)**: 점 그림을 키울 때 이웃 점을 보고 모서리 · 비스듬한 선 · 둥근 곳을 한 단계 잘게 다듬음. 건물 · 설비 · 소품(점 그림 pix) · 캐릭터 · 아이콘(시트) · 무기 · 땅 모두. 땅은 그 위에 1px 결(자갈 · 콘크리트 · 아스팔트 · 잔디)을 더함.
  - **4배 (.hd)**: 그림마다 한 번 더 키운 그림(점 하나 = 4px)을 만들어 두고 화면에 그릴 때 그것을 같은 크기로 부드럽게 줄여 그림 → 보통 화면(100%)은 계단 대신 매끈한 테두리, 윈도우 배율 125% 이상 · 노트북 화면은 화면 실제 화소만큼 잘게. 글씨(간판 · 명판)는 4배 그림에 큰 글씨로 따로 써서 또렷함. 색 입힌 그림(맞을 때 붉게 · 유령 · 안전모/조끼 색 · 동상 돌빛)도 4배를 따라 만듦.
  - 땅 그림의 4배는 너무 커서(6144×3840) 만들지 않음.
  - 주소에 `hd=0` 을 붙이면 예전처럼(2배만). 느린 PC 대비.
- 바뀐 곳: plaza.js 새 `EPX_TOL` `epx` `HD` `hdOf` · `pix`(EPX · .hd · 글씨 두 번) · `awning`(.hd 에도) · `atlasSprite`(scale 2 = EPX + .hd) · `drawGround`(EPX + 1px 결) · `weaponIcon`(2배 · HD 4배, `k`) · `drawWeaponAt` · `tinted` `ghostly` `helmTint` `vestTint` `stoneTint`(.hd 따라 만듦) · 화면 캔버스 `ctx.drawImage`(.hd 가 있으면 그것을 같은 크기로 부드럽게). plaza_server.py `PLAZA_VERSION` 만.
- 확인한 것: `node --check` · `selftest.py` 통과. 브라우저(배율 100% · 150%)로 같은 자리 전후 캡처 비교 — 동상 둘레 고리 · 보도블록 · 간판 · 문 모서리가 매끈, 스크립트 오류 없음. 시험 PC(그래픽 카드 없음) 속도: 100% 48 → 40 fps, 150% 25 → 23.5 fps. 처음 그리기 1.1 → 1.3초.
- 회사에서 확인할 것: 회사 PC 에서 느리면 `hd=0`(대시보드 광장 카드 주소 끝에 `&hd=0`) — 다음 판에서 단추로 뺄 수 있음.

### 2026-10-23 (22) — VOC 처리 완료 (운영자) · 완료 표기 (APP_VERSION 2026-10-23.1 / SERVER_VERSION 2026-10-23.1)
> server.py 가 바뀜 → **서버 재시작 필요** (8장 3번). 부서원 사본은 새 버전 배너로 교체.
- 무엇을: 요청 "VOC 는 운영자가 처리 완료를 누를 수 있도록 하고, 처리가 완료되면 완료된 표기".
  - 운영자 = 서버 PC 또는 그룹장(`SUPER_NAMES`, 지금은 구종현) — 게시판 관리 삭제와 같은 사람. VOC 글 카드에 **[✅ 처리 완료]** 단추 → 창에서 처리 내용 한 줄(선택) → 모두에게 **'✅ 처리 완료 · 처리한 사람 · 언제'** + 💬 처리 내용, 제목 앞 ✅, 카드가 조금 옅어짐. 실수하면 **[완료 취소]**.
  - 처리 전 VOC 는 **'⏳ 처리 대기'**. VOC 탭 줄에 '✅ 완료 n · ⏳ 미처리 n' 과 **[미처리만]** 체크(완료 글 숨김).
  - 부서원 화면엔 단추가 없고, 서버도 운영자가 아니면 거절(403). 글쓴이가 글을 고쳐도 완료 표시는 그대로, VOC 가 아닌 유형으로 바꾸면 지움.
  - 기록: 글 파일 `board/<id>.json` 의 `done: {by, at, note}`. 폴더 직접 연결(file://, 서버 없이) 모드에서는 보기만(단추 없음).
- 바뀐 곳: server.py `SERVER_VERSION` · 새 `api_board_done` · `board_voc`(VOC 아니면 done 지움) · `board` 분기(POST `board/{id}/done` {done, note} — `need_super`). dashboard.html `APP_VERSION` · `Board.done` · `renderBoard`(미처리만) · `drawBoard`(상태 · 단추 · 탭 줄 수) · `boardAction`(vdone · vundo) · CSS `.vdone` `.vwait` `.vnote` `.vstat` `.vopen` `.btn.ok` `.igpost.vocdone`.
- 확인한 것: `py_compile` · JS 문법. 임시 서버 + 가짜 계정 브라우저(다른 PC 주소로 접속): 부서원 = '처리 대기'만 · 단추 없음 · API 403, 그룹장 = 단추 → 처리 내용 입력 → '✅ 처리 완료 · 구종현 · 방금' + 처리 내용, 부서원 새로고침하면 완료 보임, [미처리만] 체크하면 완료 글 빠짐, [완료 취소] → 다시 '처리 대기'. 스크립트 오류 없음.
- 회사에서 확인할 것: 서버 재시작 후 그룹장 계정(구종현) 또는 서버 PC 에서 VOC 하나 처리 완료 → 부서원 PC 에서 보이는지.

### 2026-10-23 (23) — 전체 점검: 내 업무 툴바 도킹 · 작성 가이드 접기 · 마감 D-day · 🔍 빠른 찾기(Ctrl+K) · 광장 카드 오류 (APP_VERSION 2026-10-23.2 / SERVER 그대로 / PLAZA_VERSION 2026-10-23.1)
> server.py 안 바뀜 → 서버 재시작 필요 없음. 부서원 사본은 새 버전 배너로 교체 · 광장은 30초 안에 새 판으로 바뀜.
- 무엇을: 요청 "전체적으로 대시보드를 검토하고 개선 · 보완 · 기능 추가, UI 편집은 시뮬레이션을 돌려가며". 임시 서버에 부서원·그룹장·운영자로 접속해 22개 메뉴 × 3가지 화면(1500·1180·그룹장) + 창 28개(행 편집 · 이력 · 행/열 추가 · 휴지통 · 대기열 · 내 정보 · 비밀번호 · 내 업무 · 쪽지 · 글쓰기 · VOC · 메뉴 권한 · 금주 마감 · 전체 저장 · 마감본 · 인쇄 · 메뉴 숨김)을 캡처하고 콘솔 오류 · 가로 넘침 · 글자 잘림을 자동으로 검사. 스크립트 오류 1건(광장) 외 깨짐 없음. 고친 것·더한 것:
  1. **내 업무 툴바 도킹**: 펼쳐 둔 툴바가 본문 위에 떠서 `+ 행 추가` · 편집/이력/삭제 단추 · 오른쪽 KPI 카드를 가렸음(시험 스크립트도 `+ 행 추가`를 못 눌렀음). 이제 펼쳐 두면 본문 오른쪽을 270px 비워 **나란히** 놓임. 접거나(–) 끌어서 옮기면 비우지 않음(⠿ 두 번 누르면 원래 자리 + 다시 도킹). **1300px 미만 화면은 처음에 접힌 탭**으로 시작(사용자가 펼쳐 둔 기억이 있으면 그대로). 인쇄 때 여백 없음.
  2. **작성 가이드 접기**: 행 추가·편집 창의 '✍ 작성 가이드' 상자에 [접기]/[펼치기] — 접으면 한 줄만, 이 PC 에 기억(`dept-guide-fold`).
  3. **⏰ 마감까지 n일 n시간**: 홈 배지 줄에 이번 주 마감(수요일 11:59)까지 남은 시간. 24시간 안이면 붉게. 마감본을 보는 중엔 없음.
  4. **🔍 빠른 찾기 (Ctrl+K · 머리의 [🔍 찾기])**: 메뉴 이름 · 모든 시트의 행(제목·내용·담당자 등 모든 칸) · 게시글을 한 번에 검색 → ↑↓ Enter 또는 클릭으로 그 행(칸)으로 이동(노란 표시, 기존 `jumpTo`), 메뉴면 그 메뉴로, 게시글이면 게시판 검색어로. 시트당 8건 · 전체 40건 · 찾은 글자 노란 표시. 권한 있는 메뉴만.
  5. **계장 광장 카드 오류**: 홈 카드가 치워져 크기 0 일 때 `drawImage` 오류(InvalidStateError) → 캔버스가 2px 미만이면 그리지 않음.
- 바뀐 곳: dashboard.html `APP_VERSION` · CSS `body.tb-dock #main` `.gbox .gfold` `.gbox.fold` `.badge.dday` `.findbtn` `.qf …` · `renderTaskBar`(min 기본값 · tb-dock) `tbDragInit`(옮기면 해제 · resize 때 다시) · 새 `LS_GFOLD` `guideFolded` `guideBox`(GUIDE_BOX 사용처) · 새 `ddayChip`(홈 배지) · 새 `QF_MENUS` `qfSearch` `openFind` + Ctrl+K · 머리 `#btnFind`. plaza.js `frame`(크기 0 보호) · plaza_server.py `PLAZA_VERSION`.
- 확인한 것: JS 문법 · `py_compile` · 광장 selftest 통과. 브라우저: 홈·일반업무·판넬 공간확보에서 padding 270 · 접으면 0 · 펼치면 270 · 끌면 0 · ⠿ 두 번 = 270, 인쇄 0, 1180 화면은 접힌 채 시작, 예전에 펼침을 저장했으면 펼침. 행 추가 창 가이드 접기 → 다시 열면 접힌 채. Ctrl+K '노랑' → 수행 1건 → Enter → #perform 으로 이동 · 셀 표시, '게시판' → 메뉴 이동, 없는 글 → '찾은 것이 없습니다'. 홈에 30초 머물며 광장 카드 오류 없음(전엔 1건).
- 회사에서 확인할 것: 회사 모니터 크기에서 툴바가 나란히 놓이는지(1300 미만이면 접힌 탭). 불편하면 툴바를 끌어 옮기거나 접으면 예전처럼 됨.

### 2026-10-23 (24) — VOC 스크린 캡처: 작업 중 어디서든 · 빠르게 · 하던 일 그대로 (APP_VERSION 2026-10-23.3 / SERVER 그대로)
> server.py 안 바뀜 → 서버 재시작 필요 없음. 부서원 사본은 새 버전 배너로 교체.
- 무엇을: 요청 "P&ID · LOGIC · 주간업무보고 · 판넬 어디서 무슨 작업을 하든 스크린샷 범위 지정 → 바로 내용 작성 → 그 메뉴 VOC 에 자동 저장. 작업 화면에서 이동하면 안 되고, 등록 뒤 하던 작업을 문제없이 이어서. 가볍고, 스크린샷이 오래 걸리면 안 됨".
- 고치기 전 측정(시험 브라우저): 캡처마다 1.4초 + 실제 브라우저는 매번 '탭 공유' 허락 창. 그리고 **버그 2개**: ① 행 편집 창이 열린 채 📷 를 누르면 범위 고르기 화면이 편집 창 **밑에** 깔림, ② VOC 창이 편집 창과 같은 창(`dlg`)을 써서 **쓰던 편집 내용이 사라짐**.
- 바꾼 것:
  1. **빠른 캡처**: '이 탭 공유'를 한 번 허락하면 5분 동안 연결을 살려 둠 → 두 번째부터는 묻지 않고 **0.1~0.2초** 안에 범위 고르기 화면. 마지막 캡처 후 5분 지나면 · 브라우저의 '공유 중지' · 범위 화면의 [끄기] 로 끊김. 📷 단추 옆 **초록 점** = 켜짐. (켜져 있는 동안 브라우저 위쪽에 '이 탭 공유 중' 표시가 보이는 것은 브라우저 규칙)
  2. **범위 고르기 = 최상위 창**(`#shotdlg`): 편집 창 · 다른 창이 열려 있어도 맨 위에 뜸. Esc = 취소(아무 일 없던 것처럼, 포커스도 원래 칸).
  3. **VOC 쓰기 = 전용 창**(`#vocdlg`): 열려 있던 편집 창 · 쓰던 글 · 스크롤 · 메뉴 · iframe(P&ID · LOGIC · 판넬) 상태를 건드리지 않음. 등록하면 창만 닫히고 **포커스가 쓰던 칸으로 돌아감** → 바로 이어서 작업. 메뉴는 지금 화면으로 자동(주간업무보고 하위 · R&R · 통합 업무 = 주간업무보고, Management 하위 = Management).
  4. **F8 = 어디서든 스크린 → VOC** (편집 창이 열려 있어도). Edge 는 Ctrl+Shift+S 를 자기 '웹 캡처'로 써서 F8 로 정함. VOC 창에서 **Ctrl+Enter = 등록**. (P&ID · LOGIC 화면 안을 클릭한 상태면 키가 그 화면으로 가므로 📷 단추를 누름)
  5. **가볍게**: 큰 범위는 WebP(0.92), 작은 범위는 PNG(글자 또렷). 그림 여러 장은 한꺼번에 올림. 등록 뒤 게시판 새로고침은 기다리지 않음(등록 → 닫힘 0.1초 안팎).
  6. **임시 저장**: 글을 쓰다 등록 안 하고 닫으면 이 창(탭)에서 기억 → 다음 📷/VOC 쓰기 때 '✏ 지난번에 닫은 VOC 를 이어 씁니다' + [새로 쓰기]. 그림만 찍고 닫은 것은 버림.
  7. **보안 연결이 아닌 주소**(`http://PC이름:8080` — 브라우저가 캡처 자체를 막음): F8/📷 = 바로 VOC 창(메뉴 자동) + 그림 칸에 포커스 + 안내 'Win+Shift+S 로 캡처 → Ctrl+V'. (전엔 안내 창을 한 번 더 닫아야 했음.) 서버 PC(localhost) · 부서원 사본(file://)은 1~6 그대로 됨.
- 바뀐 곳: dashboard.html `APP_VERSION` · 새 창 `#vocdlg` `#shotdlg` · CSS `dialog.shotov` `.shotbar .qon` `.shotbtn.warm` `.vdraft` · `openVoc`(전용 창 · back 포커스 · VDRAFT · Ctrl+Enter · 병렬 업로드 · 기다리지 않는 새로고침) · 새 `SHOT_KEEP_MS` `SHOT` `shotStop` `shotArm` `shotStream` `shotFrame` · `captureRegion` · `pickRegion`(최상위 창 · WebP/PNG · [끄기]) · `shotToVoc`(보안 아님 → 바로 VOC · 취소 = 포커스 복귀) · F8 단축키 · #btnShot 설명.
- 확인한 것: JS 문법. 임시 서버(127.0.0.1, 탭 캡처 자동 허락) 시뮬레이션 26 항목 모두 통과 — 수행 표를 내리고 행 편집 창에 글을 쓰는 중 F8 → 범위 화면이 편집 창 위 → 끌어 고름 → VOC(메뉴 주간업무보고 자동) → Ctrl+Enter → 편집 창 · 쓰던 글 · 스크롤 · #perform 그대로, 포커스 쓰던 칸, 이어서 편집 저장 정상. 첫 캡처 0.83초(허락 포함) · 두 번째 0.15~0.2초. 판넬 화면(iframe)에 Room 입력 중 VOC → 입력값 그대로 · 다시 안 불러옴. P&ID · LOGIC · 게시판 · R&R 화면 메뉴 자동. 닫았다 다시 열면 이어 쓰기 · [새로 쓰기]. 창 안 '화면 캡처 추가' → 2장. [끄기] → 초록 점 꺼짐. 게시판에 VOC 3건(그림 수 맞음). 보안 아닌 주소(192.0.2.2): F8 → VOC 창 · 그림 칸 포커스 · 붙여넣기 → 등록 · #logic 그대로.
- 회사에서 확인할 것: Edge 에서 첫 📷 때 '이 탭 공유' 허락 → 5분 안의 다음 📷 은 묻지 않는지. `http://PC이름:8080` 으로 쓰는 부서원은 Win+Shift+S → Ctrl+V. 그 주소에서도 바로 캡처를 쓰려면 회사 IT 가 Edge 정책 `OverrideSecurityRestrictionsOnInsecureOrigin` 에 `http://PC이름:8080` 을 넣으면 됨(선택).

### 2026-10-24 (25) — 작업 창 관리: 가장자리·모서리 크기 조절 · 최대화 · 최소화 · 왼쪽/오른쪽 절반 (APP_VERSION 2026-10-24.1 / SERVER 그대로)
> server.py 안 바뀜 → 서버 재시작 필요 없음. 부서원 사본은 새 버전 배너로 교체.
- 무엇을: 요청 "내용을 수정할 때 뜨는 작업 창을 각 모서리를 마우스로 끌어 크기 조절 · 최대화 · 최소화 · 화면 오른쪽 절반 / 왼쪽 절반 배치". 편집 창뿐 아니라 제목 줄(`.dh`)이 있는 모든 창(행 편집 · 행 추가 · VOC · 확인 · 내 정보 …)에 적용. 범위 고르기 화면(#shotdlg)은 제외.
  - **크기 조절**: 창의 네 가장자리 · 네 모서리를 끌면 크기가 바뀜(커서가 ↔ ↕ ⤡ 모양으로 바뀜). 최소 380×220, 화면 밖으로 안 나감. 줄이면 안쪽만 스크롤되고 [저장]·[취소] 줄은 늘 보임.
  - **제목 줄 단추 4개** (닫기 왼쪽): [왼쪽 절반] [오른쪽 절반] [최대화 ↔ 이전 크기] [최소화 ↔ 되살리기]. 같은 절반 단추를 한 번 더 누르면 가운데로. **제목 줄 두 번 누르기** = 최대화 ↔ 이전 크기.
  - **끌어서 붙이기(윈도우처럼)**: 제목 줄을 화면 왼쪽/오른쪽 끝으로 끌면 파란 미리보기 → 놓으면 절반, 위쪽 끝이면 최대화. 붙여 둔 창의 제목 줄을 끌면 떼어 내 원래 크기로.
  - **절반 · 최소화 동안 뒤 화면을 씀**: 이때는 '뒤 화면을 쓸 수 있는 창'으로 바뀌어 표를 스크롤 · 클릭 · 복사하며 편집할 수 있음. 절반이면 본문이 나머지 절반에 맞춰 보임(오른쪽 절반 → 본문이 왼쪽 절반). 최소화한 창은 왼쪽 아래 한 줄(여러 개면 위로 쌓임) — 제목 줄을 누르면 되살아남(이전 배치 그대로).
  - **쓰던 글 보호**: 창 모드를 바꿔도 입력값 · 커서 위치 그대로. 창을 세워 둔(절반 · 최소화) 동안 다른 [편집]을 누르거나 바로 가기로 다른 행을 열려 하면 덮어쓰지 않고 그 창을 되살려 반짝 + '열어 둔 작업 창이 있습니다 — 먼저 저장하거나 닫으세요'. 내 업무 · 빠른 찾기 이동도 세워 둔 창은 닫지 않음.
  - **마지막 배치 기억**: 창 종류(편집 창 · VOC 창 …)마다 마지막 배치(절반 · 최대화 · 직접 바꾼 크기)를 이 PC 에 기억(`dept-wm`) → 다음에 열 때 그대로. 가운데로 되돌려 두면 다음에도 가운데. 확인 창 같은 작은 창은 기억하지 않음.
- 바뀐 곳: dashboard.html `APP_VERSION` · CSS `dialog .wmb` `dialog.wm-n` `.wm-fill` `.wm-left` `.wm-right` `.wm-max` `.wm-min` `[data-rz]` `.wmhint` `body.wm-split-r/l` · `.toast` z-index 2000 · `openDlg`(세워 둔 창 보호 · 배치 클래스 유지 · 마지막 배치 · 단추) · 창 관리 묶음 새 `WM` `WmBusy` `wmOn` `wmParked` `dlgModalOpen` `wmBusy` `wmKey` `wmSave` `wmRestore` `wmModal`(close 이벤트 삼킴) `wmSet` `wmLayout` `WM_SVG` `wmInject` `wmButtons` `wmAct` `wmZone` · 크기 조절 · 끌어 붙이기(옛 '제목 줄 끌어 이동'을 대신) · MutationObserver · 표 키보드 이동 2곳(`dlgModalOpen`) · `jumpTo` · 내 업무 시수 이동(세워 둔 창 안 닫음).
- 확인한 것: JS 문법. 임시 서버 시뮬레이션 36 항목 모두 통과 — 수행 행 편집 창에 글을 쓴 채: 오른쪽 아래 모서리로 980×792 → 680×592, 왼쪽 가장자리로 넓히기(오른쪽 끝 고정), 위 가장자리로 높이 줄이기, 저장 단추 보임, 최대화 1428×868 → 두 번 눌러 이전 크기, 오른쪽 절반(본문 왼쪽 절반 · 뒤 표 스크롤), 다른 [편집] → 덮어쓰지 않음 · 안내, 왼쪽 절반, 최소화(360×45 왼쪽 아래 · 뒤 스크롤) → 제목 줄로 되살리기(왼쪽 절반 그대로), 끝으로 끌어 오른쪽 절반 · 끌어 떼어 내기 · 위로 끌어 최대화, 그 뒤 저장 → 표에 반영, 닫히면 본문 원래대로, 다음 편집 창이 마지막 배치로 열림, 삭제 확인 창 최대화 → 취소 = 삭제 안 됨, VOC 창 절반 · 최소화 · 되살리기 · 등록, 모서리 커서 모양. 콘솔 오류 없음.
- 회사에서 확인할 것: 회사 모니터에서 오른쪽 절반 + 왼쪽 표 보기가 편한지. 화면이 좁으면(1366 등) 본문이 반이 되어 표가 좁아짐 → 그때는 크기 조절로 맞추면 됨.

### 2026-10-24 (26) — VOC 그림 마크업 (펜 · 형광펜 · 네모 · 화살표 · 글자) (APP_VERSION 2026-10-24.2 / SERVER 그대로)
> server.py 안 바뀜 → 서버 재시작 필요 없음. 부서원 사본은 새 버전 배너로 교체.
- 무엇을: 요청 "VOC 작성 시 캡처된 이미지에 그림펜으로 마크업". VOC 창 왼쪽 그림 위에 도구줄 — **펜 · 형광펜 · 네모 · 화살표 · 글자**, 색 5(빨강 · 노랑 · 파랑 · 초록 · 검정), 굵기 3, **되돌리기 · 다시 · 원본으로**. 그림 위에 끌면 바로 표시, 글자는 누른 곳에 쓰고 Enter.
  - 단축키(글 칸 밖): P 펜 · H 형광펜 · R 네모 · A 화살표 · T 글자 · Ctrl+Z 되돌리기 · Ctrl+Y(또는 Ctrl+Shift+Z) 다시. 고른 도구 · 색 · 굵기는 이 PC 에 기억(`dept-voc-pen`).
  - 표시는 그림 좌표로 기억하고 그릴 때마다 0.3초 뒤 원본 + 표시를 한 장으로 굳힘 → 썸네일에 ✏ 표시, 등록하면 표시가 들어간 그림이 올라감(원본은 안 올림). 큰 그림 WebP · 작은 그림 PNG.
  - 굳힌 뒤에도 표시를 기억 → 다른 그림으로 갔다 와도 · '화면 캡처 추가' 뒤에도 · 닫았다 이어 쓰기 때도 되돌리기 · 원본으로 가능. VOC 수정 때 올린 그림에 표시하면 새 그림으로 바꿔 올림(표시를 모두 지우면 원래 그림 그대로).
  - 창을 키우면(최대화 · 절반 · 크기 조절) 그림판도 따라 커짐 — 크게 놓고 정밀하게 표시.
  - 함께 고침: VOC 창 안 '화면 캡처 추가' 때 '쓰던 VOC 는 기억해 둡니다' 안내가 잘못 뜨던 것.
- 바뀐 곳: dashboard.html `APP_VERSION` · CSS `.vprev canvas` `.vtxt` `.vtools …` `.vth .vmark` · 새 `VMK_COLORS` `VMK_SIZES` `VMK` `vmkSave` `VMK_I` `VMK_TOOLS` `VMK_BAR` `vmkOps` `vmkLive` `vmkPaint` `vocMarkup`(그리기 · 글자 · 되돌리기 · 굳히기 flush · 크기 따라 다시 그림) · `openVoc`(그림 = {id|blob, base, ops} · 도구줄 · drawList · snap/임시 저장에 표시까지 · 등록 전에 굳히기 기다림 · 화면 캡처 추가 때 onclose 끊기).
- 확인한 것: JS 문법. 임시 서버 시뮬레이션 22 항목 모두 통과 — 캡처 → 빨간 펜(굳힌 그림 그 자리 빨강) · 노란 굵은 네모(변만 노랑 · 안쪽 그대로) · A 키 화살표 · 형광펜 · 글자 '여기 고쳐 주세요'(빨강 픽셀) · Ctrl+Z/Ctrl+Y · 원본으로(원래 색 · ✏ 없음) → 되돌리기로 살림 · 화면 캡처 추가(2장 · 첫 그림 표시 기억 · 돌아가 되돌리기) · 최대화하면 그림판 580 → 769px · 큰 창에서도 같은 자리 · 등록 → 서버에 올라간 그림에서 빨간 펜 · 노란 네모 확인 · 닫았다 열면 표시 · 글 그대로. 콘솔 오류 없음.

### 2026-10-24 (27) — 서버 꺼졌을 때 오프라인으로 안 열리고 '데이터 폴더 선택'이 뜨던 문제 (APP_VERSION 2026-10-24.3 / SERVER 그대로)
> server.py 안 바뀜 → 서버 재시작 필요 없음. 부서원 사본은 새 버전 배너로 교체.
- 무엇을: 질문 "서버 켜졌을 때 한 번 들어왔다가, 서버 꺼졌을 때 오프라인이 안 되고 데이터 폴더를 선택하라고 함". 재현(브라우저 프로필 유지 · 껐다 켜기)으로 원인 4가지 확인:
  1. **주소(http://PC:8080)로 들어갔던 사람이 서버 꺼진 뒤 파일 사본을 엶** → 브라우저 보관본(IndexedDB)은 주소마다 따로라 파일 쪽엔 없음. (서버가 꺼지면 http 주소는 아예 안 열림)
  2. **파일로 열었지만 로그인 화면에서 닫음** → 보관본은 로그인 뒤에만 만들었음.
  3. **브라우저가 닫을 때 사이트 데이터를 지움** (회사 정책 · 설정) · InPrivate · 다른 브라우저 → 보관본 없음.
  4. 보관본이 없으면 '폴더 모드'로 떨어져 왼쪽 아래에 [데이터 폴더 선택]이 보였음 → 부서원이 헷갈림.
  - 고친 것:
    - (2) 로그인 화면이 뜨면 그 뒤에서 보관본을 먼저 만듦(`loadAll({warm:true})`, 생일 팝업 없음). 로그인 뒤 불러오기와 겹치지 않게 끝날 때까지 기다림.
    - 보관본 저장 뒤 `navigator.storage.persist()` 한 번 요청(브라우저가 임의로 안 지우게).
    - (1)(3) **파일 안에 보관본을 넣음**: `<script id="deptSnap" type="application/json">`(`<` → `<`). 새 버전 교체(`replaceSelf`) 때 자동으로, 그리고 왼쪽 아래 새 단추 — 주소로 연 부서원: **[📥 내 PC 사본 받기]**(서버의 최신 파일 + 지금 데이터 → dashboard.html 내려받기), 파일로 연 부서원: **[📥 이 파일에 최신 데이터 넣기]**(이 파일을 덮어씀). 서버 PC(관리자 · 주소)는 안 보임.
    - 파일로 열 때 서버가 없으면: 브라우저 보관본과 파일 안 보관본 중 **새것**으로 오프라인. 브라우저 보관본이 없어 파일 것으로 열면 '이 파일에 들어 있는 ○○ 기준 데이터로 열었습니다' 안내.
    - 주소로 연 부서원(관리자 아님)에게 하루 한 번 배너 '서버가 꺼지면 이 주소는 열리지 않습니다 → [📥 내 PC 사본 받기]' + [오늘은 그만]. 한 번 받으면 안 보임(`dept-copy-at` · `dept-copy-hide`).
    - (4) 보관본이 하나도 없을 때 화면: 제목 '서버가 꺼져 있어 열 수 없습니다' + 흔한 이유 3가지 쉬운 말로 + [다시 시도] [서버 주소 변경]. '폴더 모드'는 아래 작은 '관리자용' 글씨로만, 왼쪽 아래 [데이터 폴더 선택] · [이름 변경] 숨김.
- 바뀐 곳: dashboard.html `APP_VERSION` · `loadAll(o)`(warm · 오프라인 때 `snapLoad` 대체) · `cacheSave`(persist) · 새 `PERSIST_ASKED` `SNAP_TAG` `withSnap` `snapLoad` `saveCopy` `copyTip` `fileCopyUpdate` · `replaceSelf`(withSnap · 저장 창 못 쓰는 브라우저는 saveCopy) · `authStart(beforeDialog)` · `startOnline`(warm) · 처음 열기 file:// 갈래(파일 안 보관본 · 보관본 없음 화면) · `renderHeader`(#btnCopy) · 배너 · data-net copy/copyno · 새 단추 `#btnCopy`.
- 확인한 것: JS 문법. 임시 서버 + 브라우저 프로필 유지(껐다 켜기) 재현: 파일로 로그인 → 서버 끔 → 오프라인 ✅(전에도 됨) / **로그인 화면에서 닫음 → 서버 끔 → 오프라인 ✅(전엔 폴더 선택)** / 주소로만 씀 → 파일 → '서버가 꺼져 있어…' 안내 화면(데이터 폴더 선택 단추 없음) / **주소에서 배너 [📥 내 PC 사본 받기] → 받은 파일 → 서버 끔 → 오프라인 ✅** / **새 프로필(보관본 지워진 브라우저)에서 그 파일 → 오프라인 ✅**. 파일 안 보관본을 다시 넣을 때 겹치지 않음(지우고 새로). 배너는 받은 뒤 사라짐.
- 회사에서 확인할 것: 부서원에게 "바탕화면의 dashboard.html 파일로 열기" 안내. 주소로 쓰는 부서원은 배너로 사본 받기. 파일 크기는 데이터만큼 커짐(시험 데이터 0.6 MB → 0.7 MB). Edge 정책 '닫을 때 검색 데이터 지우기'가 켜져 있는지 IT 확인(켜져 있어도 파일 안 보관본으로는 열림 — 다만 그 파일에 넣은 시점 데이터).

### 2026-10-24 (28) — 오프라인(서버 꺼짐) 보기가 끊기지 않게: 배포 파일에 데이터 · 파일 자동 보관 (APP_VERSION 2026-10-24.4 / SERVER_VERSION 2026-10-24.1)
> **server.py 바뀜 → 서버 재시작 필요** (stop_server → start_server). 부서원 사본은 새 버전 배너로 교체.
- 무엇을: 요청 "절전(오프라인) 모드를 이런 문제가 안 일어나게 개선". (27)은 브라우저 보관본이 없을 때의 대비였고, 이번엔 **파일 자체가 늘 데이터를 들고 있게** 함.
  1. **서버가 만드는 배포 파일에 데이터를 넣음**: `deploy/dashboard.html` 과 `/dashboard.html?download=1`(새 버전 다운로드) 안에 지금 데이터(비회원이 보는 범위: 시트 · 열 · 상태 · 기준 마감본 · 게시판 목록 · 구성원 사진 제외)를 `deptSnap` 으로 넣음. `deploy/` 는 30분마다 데이터만 새로 넣어 다시 만듦(안내문 · 로그는 화면 파일/IP 가 바뀔 때만). → **처음 받은 파일도 서버에 한 번도 연결하지 않고 바로 오프라인으로 열림.** 그냥 화면으로 여는 `/dashboard.html` 에는 안 넣음(가볍게).
  2. **파일 사본 자동 보관**: 파일로 열고 서버에 연결되면 3시간마다 이 dashboard.html 파일 안의 보관본을 조용히 새로 씀(서버의 같은 버전 파일 + 지금 보관본). 파일 쓰기 허락이 없으면(처음 · 허락이 끝난 경우) 파일 안 보관본이 없거나 3일 넘었을 때만 배너 '💾 서버가 꺼져도 이 파일로 열리게 … [💾 자동 보관 켜기] [오늘은 그만]' → 한 번 누르면 저장 창(지금 연 파일 선택) · Edge '방문할 때마다 허용' 이면 그 뒤로는 안 물음. 다른 이름 파일을 고르면 쓰지 않음. 새 버전이 있으면 교체 쪽으로(교체 때 보관본도 같이 들어감).
  3. 왼쪽 아래 [📥 이 파일에 최신 데이터 넣기] = 2를 바로 실행(전엔 교체 + 다시 열기). 부서원 사용법.txt 4번에 '주소로 들어가면 서버가 꺼졌을 때 안 열리니 늘 이 파일로' 추가.
- 바뀐 곳: server.py `SERVER_VERSION` · `html_bytes(snap)` · 새 `SNAP_RE` `snap_data`(dashboard.html `cacheSave` 와 같은 모양, savedAt = `stamp()`) `embed_snap` · `_build_deploy`(30분 · 데이터만 갱신) · GET `/dashboard.html?download=1`. dashboard.html `APP_VERSION` · 새 `EMBED_MS` `EMBED_ASK` `embedAt` `embedSelf` `autoEmbed` `embedTip` · 배너 data-net embed/embedno · `startOnline`(4초 뒤 + 30분마다 autoEmbed) · `replaceSelf`(dept-embed-at 기록) · #btnCopy · 보관본 없음 화면 문구. (27)의 `fileCopyUpdate` 없앰.
- 확인한 것: 문법(JS · Python). 임시 서버: deploy 파일 · ?download=1 에 데이터 들어감, 그냥 화면 파일엔 없음. **서버가 만든 deploy 파일 → 서버 끔 → 새 브라우저(보관본 없음)에서 오프라인으로 열림 ✅**. 보관본 없는 파일로 로그인 → 배너 → [자동 보관 켜기](저장 창은 시험용 가짜) → 파일에 데이터가 써짐 · 배너 사라짐 → 그 파일을 서버 끔 + 새 브라우저로 열기 → 오프라인 ✅. (27) 경우(로그인 화면에서 닫음 → 오프라인) 그대로 ✅. 아무 데이터도 없는 파일 + 새 브라우저 → 안내 화면.
- 회사에서 확인할 것: 서버 재시작 뒤 `deploy\dashboard.html` 크기가 데이터만큼 커졌는지(30분마다 시각 갱신). Edge 에서 [💾 자동 보관 켜기] → 저장 창 → '방문할 때마다 허용' 이 뜨는지 · 다음날 다시 묻지 않는지(묻는다면 그 PC 정책상 허락이 세션마다 끝나는 것 — 3일에 한 번만 배너). 서버 PC 공유 폴더 deploy 를 부서원이 볼 수 있는 곳이면 안의 데이터도 같이 보임(비회원 보기 범위와 같음).

### 2026-10-24 (29) — 오른쪽 위 '오프라인 보관' 초록/빨강 표시 · 메뉴 이름 ROOM SIZE 계산 (APP_VERSION 2026-10-24.5 / SERVER_VERSION 2026-10-24.2)
> server.py 는 메뉴 이름 한 줄만 바뀜 → 서버 재시작하면 '메뉴 권한' 창 이름도 바뀜(안 해도 동작엔 문제 없음). 부서원 사본은 새 버전 배너로 교체.
- 무엇을:
  1. 요청 "서버에 접속되면 서버 꺼지기 전 데이터를 저장했다고 오른쪽 위에 심볼로 — 녹색 = 저장됨, 빨강 = 안 됨, 빨강일 때 부서원이 강제로 저장". 머리줄 [🔍 찾기] 왼쪽에 **● 오프라인 보관됨(초록) / ● 오프라인 보관 안 됨(빨강, 깜빡임)**. 좁은 화면(1200px 아래)은 점만.
     - 파일로 연 경우 초록 = 이번 접속에서 브라우저 보관본 저장 + **이 파일 안 보관본이 하루 안**(브라우저가 지워도 파일로 열림). 주소로 연 경우 초록 = 하루 안에 [내 PC 사본 받기] 함(주소는 서버 꺼지면 안 열리므로).
     - **빨강 누르기 = 바로 강제 저장**: 파일 → 이 파일 안에 지금 데이터 쓰기(`embedSelf(true)`, 처음엔 저장 창) · 주소 → 사본 파일 내려받기. 초록 누르기 = 자세히(브라우저 보관 시각 · 파일 안 보관 시각) + [지금 다시 저장].
     - 서버 PC(관리자 · 주소) · 오프라인 중 · 폴더 모드에는 안 보임(오프라인 중엔 위 빨간 배너가 있음).
  2. 요청 "판넬 공간확보 가 아니라 ROOM SIZE 계산 으로": 대시보드에 보이는 이름만 바꿈 — 왼쪽 메뉴 · 화면 제목 · VOC 메뉴 이름 · 메뉴 권한 목록 · 광장 상태('ROOM SIZE 계산 중...') · server.py `MENUS`. 메뉴 키(`space`) · 주소(#space · /apps/space/) · 권한 · 저장 자료는 그대로. **도구 안쪽 화면(apps/space)의 제목은 그 도구를 만드는 쪽에서 바꿀 것.**
- 바뀐 곳: dashboard.html `APP_VERSION` · 새 단추 `#btnSafe` · CSS `.safebtn` · 새 `CACHE_OK` `SAFE_MS` `SNAP_AT` `safeState` `renderSafe` `safeClick` · `cacheSave`(CACHE_OK) · `saveCopy`(dept-copy-at = 시각) · `embedSelf`(조용히 쓴 뒤 표시 갱신) · `renderHeader`(renderSafe) · `VOC_MENU` `APP_ROUTES` 메뉴 · 권한 목록 · `PZ_STATUS`. server.py `SERVER_VERSION` · `MENUS`.
- 확인한 것: 문법(JS · Python). 임시 서버: 보관본 없는 파일로 로그인 → 빨강 → 누름(저장 창은 시험용 가짜) → 파일에 써짐 → 초록 → 누르면 자세히 창. 서버가 만든 deploy 파일 → 처음부터 초록. 주소(보안 아닌 192.0.2.2)로 → 빨강 → 누름 → dashboard.html 내려받음 → 초록. 서버 PC 주소 → 안 보임. 메뉴 · #space 제목 'ROOM SIZE 계산'. 콘솔 오류 없음.
- 회사에서 확인할 것: Edge 에서 빨강 → 저장 창 → 지금 연 dashboard.html 선택 → [저장] → 초록. 다음날 빨강으로 바뀌면(허락이 세션마다 끝나는 PC) 한 번 눌러 주면 됨.

### 2026-10-25 (30) — LOGIC 분석 하위 메뉴 'LOGIC 작성' (APP_VERSION 2026-10-25.1 / SERVER 그대로)
> server.py 안 바뀜 → 서버 재시작 필요 없음. 부서원 사본은 새 버전 배너로 교체.
- 무엇을: 요청 "LOGIC 작성은 LOGIC 분석 메뉴의 하위 메뉴로". 왼쪽 메뉴 🔀 LOGIC 분석을 접기/펼치기 묶음으로 바꾸고 아래에 **LOGIC 작성**. 누르면 P&ID 서버(같은 포트 `PID_PORT`)의 `/logic/draw`(LOGIC 작도 화면, 다른 브랜치 `claude/logic-review-design-pd2z75` 에서 만듦)를 P&ID · LOGIC 분석과 같은 틀(본문 전체 iframe · 새 창으로 열기 · 서버 꺼짐 안내)로 띄움. 머리(🔀 LOGIC 분석)를 누르면 그대로 `/logic`.
  - 권한은 'LOGIC 분석'과 같음(따로 권한 칸 없음). VOC 메뉴 = LOGIC 분석. 광장 상태 'LOGIC 작성 중...'. 빠른 찾기(Ctrl+K)에 'LOGIC 분석 · LOGIC 작성'. 접기 상태 기억 `dept-nav-logic-open`.
- 바뀐 곳: dashboard.html `APP_VERSION` · `PID_ROUTES.logicdraw` · `ROUTES` · `menuOf`(logicdraw → logic) · `NAV_LS` · `renderMenu`(LOGIC 묶음) · `QF_MENUS`(권한은 menuOf) · `PZ_STATUS`.
- 확인한 것: JS 문법. 임시 서버: 메뉴에 LOGIC 분석 ▾ › LOGIC 작성, 누르면 #logicdraw · 주소 `http://…:8000/logic/draw?user=본명` · 제목 'LOGIC 작성', 다시 LOGIC 분석 → `/logic`. (시험 PC 엔 P&ID 서버가 없어 '서버가 꺼져 있습니다' 안내까지 확인.) 콘솔 오류 없음.
- 회사에서 확인할 것: 회사 P&ID 서버에 LOGIC 작도(`/logic/draw`)가 들어 있는 판이어야 화면이 뜸 — 없으면 iframe 안에 Not Found. 그 판은 LOGIC 쪽 zip 으로 적용.

### 2026-10-25 (31) — 메뉴 '🌪️ 도서검토' 연결 (APP_VERSION 2026-10-25.2 / SERVER_VERSION 2026-10-25.1)
> **server.py 바뀜 → 서버 재시작 필요.** 부서원 사본은 새 버전 배너로 교체.
- 무엇을: 사용자 "🌪️ 도서검토도 다른 브랜치에서 업데이트한다". 도서검토 앱(`apps/books/` · `books_api.py`)은 다른 작업 줄기(`claude/new-session-v23o67`, 그쪽 `apps/books/INTEGRATION.md`)에서 만들고 zip 도 거기서 냄 → 여기서는 ROOM SIZE 계산과 같은 방식(`APP_ROUTES`)으로 **메뉴 연결만**. 이 zip 에 도서검토 파일은 없음.
  - 왼쪽 메뉴 ROOM SIZE 계산 아래 **🌪️ 도서검토** → `/apps/books/index.html` 를 본문 전체 iframe 으로. 메뉴 권한 키 `books`(기본 허용) · VOC 메뉴 '도서검토' · 빠른 찾기 · 광장 상태 '도서검토 중...'.
  - server.py: `books_api` 를 **있으면** 불러옴(`try: import books_api`), `main()` 에서 ROOT 정한 뒤 `books_api.setup(...)`, `/api/books/…` → `books_api.handle`. **books_api.py 가 없어도 서버는 정상**(그 API 만 404 '설치되지 않았습니다').
  - 연결 앱 화면 파일이 서버에 없으면(도서검토 zip 을 아직 안 넣음) iframe 에 서버 오류 글 대신 '화면 파일이 서버에 아직 없습니다 — apps\books 폴더 필요, 업데이트 zip 을 적용하세요' 안내(`renderApp`, ROOM SIZE 계산도 같음).
- 바뀐 곳: dashboard.html `APP_VERSION` · `APP_ROUTES.books` · `ROUTES` · `renderMenu` · `VOC_MENU` · `QF_MENUS` · `PZ_STATUS` · `renderApp`(404 안내). server.py `SERVER_VERSION` · `books_api` 선택 import · `main`(setup) · `Handler.api`(head 'books') · `MENUS` · `VOC_MENUS`.
- 확인한 것: 문법(JS · Python). 임시 서버: books_api.py · apps/books 없음 → 서버 정상 기동 · `/api/books/info` 404 안내 · 메뉴 → '화면 파일이 아직 없습니다'. 시험 폴더에만 그쪽 브랜치 파일을 넣고 재기동 → `/api/books/info` 정상 · 메뉴 → 도서검토 화면(제목 '계장도서검토') iframe 으로 뜸. 콘솔 오류 없음.
- 회사에서 확인할 것: 이 zip 적용 + 서버 재시작 → 메뉴에 🌪️ 도서검토. 화면은 도서검토 쪽 zip(apps\books\ · books_api.py)을 넣고 **서버 재시작**해야 뜸. 메뉴 권한 창에 '도서검토' 줄이 생김.

### 2026-10-26 (32) — ROOM SIZE 계산 · 도서검토를 P&ID 서버(run_lan_service.bat)로 연결 (APP_VERSION 2026-10-26.1 / SERVER 그대로)
> server.py 안 바뀜 → 서버 재시작 필요 없음. 부서원 사본은 새 버전 배너로 교체.
- 무엇을: 사용자 "ROOM SIZE 계산은 LOGIC 분석, PID 분석과 같이 run_lan_service.bat 에서 동작해야 한다" (현장 사진: 대시보드 서버 `/apps/space/` 의 옛 판넬 화면이 뜨고 있었음). P&ID 쪽 꾸러미(`claude/titleblock-parsing-c5st4x` hotfix106~116)가 같은 P&ID 서버(8000)에 `/space`(ROOM SIZE 계산, 저장 `{data}/space/`)와 `/books/`(도서검토, hotfix115~)를 이미 넣어 둠 → 대시보드 메뉴를 그쪽으로.
  - `PID_ROUTES.space` = `:8000/space?embed=1&user=본명`, `PID_ROUTES.books` = `:8000/books/?embed=1&user=본명` (P&ID · LOGIC 과 같은 `pidBase` · `/version` 확인 · 새 창으로 열기). `APP_ROUTES` 는 비움(틀만 남김).
  - P&ID 서버 확인 넉넉히(3 → 6초, 분석 중엔 늦을 수 있음) · '꺼져 있습니다' 화면에 있는 동안 **5초마다 자동 재연결**(켜지면 저절로 화면이 뜸). LOGIC 작성이 '꺼져 있습니다'로 남던 현장 사진 대응.
  - 대시보드 서버의 `/api/space/*` · `books_api` 연결은 그대로 둠(옛 자료 · P&ID 쪽 '대시보드 자료 가져오기'가 `/api/space` 를 읽음).
- 바뀐 곳: dashboard.html `APP_VERSION` · `PID_ROUTES`(space · books) · `APP_ROUTES`(빈 것) · `PID_OFF` · `pidConnect`(6초 · 5초 자동 재시도).
- 확인한 것: JS 문법. 임시 대시보드 서버 + 가짜 P&ID 서버(8000, `/version` · 페이지): P&ID 서버 꺼짐 → ROOM SIZE 계산 '꺼져 있습니다' → 가짜 서버 켬 → 자동으로 `:8000/space?embed=1&user=박부서` iframe. 도서검토 → `:8000/books/?embed=1&user=…`, LOGIC 작성 → `:8000/logic/draw?user=…`. 콘솔 오류 없음.
- 회사에서 확인할 것: P&ID 서버에 hotfix116 이상(판넬 `/space` · 도서 `/books`)이 깔려 있어야 함. 예전에 대시보드 서버에 저장한 판넬 자료는 ROOM SIZE 계산 첫 화면 ① 카드의 [대시보드 자료 가져오기]로 P&ID 서버에 들임(P&ID 쪽 기능). 도서 색인은 P&ID 서버에서 한 번 [색인 갱신].

### 2026-10-26 (33) — 📷 스크린 → VOC 를 누르면 바로 '화면 캡처를 취소했습니다'만 뜨던 것 (APP_VERSION 2026-10-26.2 / SERVER 그대로)
> server.py 안 바뀜 → 서버 재시작 필요 없음. 부서원 사본은 새 버전 배너로 교체.
- 무엇을: 현장 사진(서버 PC `localhost:8080` · 수행 화면) — 단추를 누르자마자 '화면 캡처를 취소했습니다'. 고르는 창이 뜨기도 전에 브라우저가 화면 캡처(`getDisplayMedia`)를 거절한 것 = 사람이 취소한 게 아니라 **회사 Edge 정책(ScreenCaptureAllowed 등) · 보안 프로그램 · 브라우저 설정이 캡처를 막음**. 예전 코드는 어떤 실패든 '취소'로 보고 아무것도 안 했음.
  - 거절이 0.8초 안에 오거나 NotAllowedError 가 아닌 오류면 '막힘'으로 봄 → **바로 VOC 창을 열고**(지금 화면 · 메뉴 자동 그대로) 'Win+Shift+S 로 캡처 → 왼쪽 그림 칸 Ctrl+V(그림 파일 끌어 놓기도 됨)' 안내 + 그림 칸에 포커스. 그날은 다시 묻지 않고 바로 VOC 창(`dept-shot-blocked` = 오늘 날짜). VOC 창 안 '화면 캡처 추가'도 같은 안내.
  - 사람이 고르는 창에서 [취소] 한 것(0.8초 넘어서 거절)은 전과 같음(아무 일 없음).
- 바뀐 곳: dashboard.html `APP_VERSION` · `shotStream`(오류 이름 · 걸린 시간 → `SHOT.err.blocked`) · `captureRegion`('blocked' 돌려줌) · 새 `shotBlocked` `vocPaste` · `shotToVoc` · VOC 창 `#vShot`.
- 확인한 것: JS 문법. 임시 서버: 캡처 즉시 거절(정책 흉내) → VOC 창 열림 · 안내 · #perform 그대로 → 다시 누르면 묻지 않고 바로 VOC 창 · 창 안 '화면 캡처 추가' → 안내. 고르는 창에서 1.5초 뒤 취소 → '취소했습니다'만(전과 같음). 정상 캡처(탭 허락) → 범위 고르기 화면. 콘솔 오류 없음.
- 회사에서 확인할 것: 서버 PC 에서 📷 → VOC 창 + 안내가 뜨는지. Win+Shift+S 도 막힌 PC 면 그림 파일을 끌어 놓기. 브라우저 캡처를 쓰고 싶으면 IT 에 Edge 정책 `ScreenCaptureAllowed`(또는 `ScreenCaptureAllowedByOrigins` 에 `http://localhost:8080` · `http://PC이름:8080`) 확인 요청(선택).

### 2026-10-28 (34) — 부서원 VOC 3건: 접어서 '나' 위주로 · 홈 그래프 수행/입찰 색 (APP_VERSION 2026-10-28.1 / SERVER 그대로)
> server.py 안 바뀜 → 서버 재시작 필요 없음. 부서원 사본은 새 버전 배너로 교체.
- 무엇을 (게시판 VOC · 이영주):
  1. **수행 · 입찰 PJT 보드 '👥 부서원별 진행 PJT'** — "펼치기 전에 너무 많은 사람이 보임, 2~3명만 · 아래 수행/입찰 표가 첫 화면에 보이게": 접힌 상태 = **3명**(많이 맡은 순, 전엔 절반). 나 · 지금 고른 사람은 접혀도 보임(`foldPick`). [▼ 나머지 N명 펼치기] / [▲ 접기].
  2. **R&R · 투입 분석** (주간업무보고 메뉴):
     - 🏗 프로젝트별 투입 = 처음엔 **내가 시수를 쓴 수행 · 입찰 PJT 만**(공통 입찰 묶음 포함) + [▼ 나머지 항목 N개 더 보기].
     - 👤 부서원별 = 처음엔 **나 + 나와 같은 PJT(코드 있는 수행 · 입찰)를 한 사람**(+ 지금 고른 사람) + [▼ 나머지 부서원 N명 더 보기]. 공통 묶음(입찰 공통 · 코드 없음)은 '같은 PJT' 로 안 봄.
     - 🎯 개인 R&R 표 = '계획 투입(투입인력 시트 고정값)' · '차이' 열 **뺌** → 'R&R · 실제 투입'. 투입인력에만 있고 R&R · 시수가 없는 줄도 뺌. 많이 투입된 **상위 3줄** + [▼ 나머지 항목 N개 더 보기].
     - 내 시수가 없으면(관리자 등) 접지 않고 전부. **Management › R&R · 투입 분석은 처음부터 펼침**(팀 전체 보는 곳, 접기 단추는 있음). 펼침 상태는 그 메뉴 안에서 유지(`AS.open`).
  3. **홈 그래프 수행/입찰 색 구분**: '사업군별 PJT 수' = 수행(파랑) · 입찰(주황) **쌓은 막대**(조각에 마우스 = 그쪽 PJT 만), 'PJT별 투입인력' = 막대 색 = 투입인력 열 구분(수행 · 입찰 · 기타 회색) · 범례.
- 바뀐 곳: dashboard.html `APP_VERSION` · 새 `PJ_FOLD_N` `foldPick` `pjLegend` · `pjHero`(ofold) · `AS.open` · `renderAlloc`(isPj · myPj · opened · foldBtn · mates · R&R 표 · projRows · data-afold) · `svgBars`(세로 막대 parts · i.color) · `renderHome`(grpItems parts · 투입인력 색 · 범례) · CSS `.afnote`.
- 확인한 것: JS 문법. 임시 서버: 수행 · 입찰 보드 부서원 3명 + '나머지 15명/27명 펼치기'. 시수 있는 계정(박민수): 프로젝트 11 → 내 PJT 5 + '나머지 6개', R&R 표 6 → 3 + '나머지 3개', 열 = PJT · 구분 · R&R 역할 · 기간 · 실제 투입, 펼치기 → 11 · 6. 시수 없는 계정 → 접지 않음. 홈 두 그래프 수행/입찰 두 색. 콘솔 오류 없음.
- 회사에서 확인할 것: 회사 해상도에서 수행/입찰 표가 첫 화면에 보이는지(사업군 줄이 많으면 왼쪽 카드 높이만큼은 남음). VOC 처리 완료는 운영자가 게시판에서.

### 2026-10-29 (35) — 새 버전 교체가 바탕화면 등 다른 폴더에 저장되어 적용되지 않던 것 (APP_VERSION 2026-10-29.1 / SERVER 그대로)
> server.py 안 바뀜 → 서버 재시작 필요 없음.
- 무엇을 (VOC · 이영주): 교체 창에 '지금 쓰는 파일: D:\Desktop\새 폴더\dashboard.html' 이 나오는데 [예] → 저장 창이 **바탕화면**에서 열림 → 그대로 [저장] → 바탕화면에 새 파일이 생기고 지금 쓰는 파일은 그대로. 예전 코드는 **이름만 같으면(dashboard.html) 성공으로 보고 그 '다른 파일'을 기억** → 다음 교체 · 파일 자동 보관도 묻지 않고 계속 바탕화면 파일에 씀.
  - 고른 파일이 지금 연 파일인지 **수정 시각으로 확인**(`isSelfFile`: file:// 문서의 `document.lastModified` = 그 파일의 수정 시각 ↔ 고른 파일의 `lastModified`, 2.5초 안 · 이번 접속에서 직접 쓴 뒤의 시각도 인정). 같은 이름이라도 다른 폴더면 다름.
  - 저장 창 전에 **지금 폴더 경로를 클립보드에 복사**하고 '저장 창 위쪽 주소 칸 Ctrl+V → Enter' 안내(`selfPick`). 다른 폴더를 고르면 '⚠ 지금 쓰는 파일이 아닙니다' 창 → [다시 고르기] / [그래도 거기에 저장] / [취소]. 저장 창이 새로 만든 빈 파일은 지움.
  - 예전에 기억한 파일이 다른 폴더의 것이면 버리고 다시 고름(교체 · 파일 자동 보관 둘 다). 지금 쓰는 파일일 때만 기억.
  - 교체 뒤 다시 열렸는데 버전이 그대로면 '교체가 지금 쓰는 파일에 들어가지 않았습니다' 알림 + 기억한 파일 버림(`sessionStorage` `dept-upd`). 바뀌었으면 '새 버전으로 바꿨습니다'.
  - 저장 창을 못 쓰는 브라우저(내려받기)는 '다운로드 폴더의 그 파일을 <지금 폴더> 로 옮겨 덮어쓰세요' 안내.
- 바뀐 곳: dashboard.html `APP_VERSION` · 새 `selfDir` `SELF_WROTE` `isSelfFile` `selfPick` `selfWrite` · `askUpdate`(안내 문구) · `replaceSelf` · `embedSelf` · `saveCopy`(file:// 안내) · 처음 열기 file:// 갈래(교체 결과 확인).
- 확인한 것: JS 문법. file:// 의 `document.lastModified` = 파일 수정 시각(일치). 옛 버전 파일 + 임시 서버 + 저장 창 흉내: [지금 교체] → 첫 번째로 '다른 폴더'를 고름 → 경고 창 · 빈 파일 지움 · 아무 데도 안 씀 → [다시 고르기] → 지금 파일 → 씀 · 다시 열기 → (흉내라 실제 파일은 그대로) '교체가 지금 쓰는 파일에 들어가지 않았습니다' 알림. 콘솔 오류 없음.
- 회사에서 확인할 것: **이번 한 번은 옛 코드로 교체**되므로, 이미 바탕화면 파일을 기억한 PC 는 또 바탕화면에 저장됨 → 그 파일을 쓰는 폴더로 직접 옮겨 덮어쓰기(또는 서버 폴더 deploy 의 새 dashboard.html 복사). 그 다음 교체부터는 위처럼 확인함.

### 2026-10-30 (36) — VOC: 홈 그래프 누르면 상세 · 제목 = 첫 화면 · '변경 없음' 저장도 내 업무 완료 (APP_VERSION 2026-10-30.1 / SERVER_VERSION 2026-10-30.1)
> **server.py 바뀜 → 서버 재시작 필요.** 부서원 사본은 새 버전 배너로 교체.
- 무엇을 (게시판 VOC · 백승욱):
  1. **주간업무보고 첫 화면 그래프** "마우스 올리면 현황, 누르면 상세": 그래프 막대 · 쌓은 조각 · 도넛을 누르면 **상세 창** — 그 칸의 PJT/행 목록(시트 · 항목 · 담당자 · 사업군 · 금주 작성/변경 없음/미작성 · 최근 수정), 줄을 누르면 그 행으로 이동. PJT별 투입인력은 투입인력 행 목록. 막대에 `data-rows`('시트|ID,…'), `chartA` · `chartDetail`.
  2. **머리줄 제목 '계장ENG그룹 Dashboard'** 를 누르면 주간업무보고 첫 화면(#home).
  3. **"변경 없음 — 눌러도 내 업무에서 완료로"**: 수행 · 입찰 편집 창에서 바꾼 것 없이 [저장] → 서버가 `meta.checkedAt/checkedBy` 를 적음(내용 · rev 그대로 → 다른 사람 편집과 충돌 없음, 이력 action `check` '변경 없음 확인'). 이번 주(마지막 마감 이후)에 확인했으면 **내 업무 완료 · 금주 업데이트율 · 미업데이트 목록/배지 · 금주 업데이트 필터**에서 '작성'으로 셈(`isChecked` · `isDone`). 수정 표시(노란 칸 · 메뉴 !(n) · 시트별 업데이트 그래프)는 그대로 실제 수정만(`isUpdated`). 옛 서버는 confirm 을 모르므로 전처럼 '변경된 내용이 없습니다'.
- 바뀐 곳: dashboard.html `APP_VERSION` · 새 `isChecked` `isDone` `chartA` `chartDetail` + 클릭 처리 · `saveEdit`(confirm) · 편집 저장(수행 · 입찰 confirm) · `afterSave`('checked') · `ACT.check` · `myTasks` · 미업데이트 목록 · `renderHome`(notUpd · 그래프 rows · 안내 문구) · 수행/입찰 보드 업데이트율 · 필터 · 제목 클릭 · CSS `.cdt` `.cdtip`. server.py `SERVER_VERSION` · `api_update`(confirm → checked).
- 확인한 것: 문법(JS · Python). 임시 서버(박민수): 내 업무 '수행 PJT 예시수행-D 미완료' → 편집 창 → 그대로 저장 → '완료' · 보드 '18건 중 0건 → 1건 작성'. 제목 클릭 → #home. 사업군 그래프 수행 조각 클릭 → '발전 · 수행 11개' 창 11줄(예시수행-D = ✓ 변경 없음) → 줄 클릭 → #perform 이동. 투입인력 막대 → 3줄. 콘솔 오류 없음.
- 같은 날 VOC 중 **LOGIC 분석 3건(매크로가 보이지 않음 · 글자 상자 잘림 · LOGIC 기호 잘림)** 은 LOGIC 작성 화면(`/logic/draw`, P&ID 서버) 안의 일 → '3. LOGIC 검토 코드' / '2. PID 코드' 에서.

### 2026-10-30 (37) — 내 업무: 담당자 중 누구든 작성/변경 없음이면 완료 · 누가 했는지 표시 (APP_VERSION 2026-10-30.2 / SERVER 그대로)
- 무엇을: 사용자 "수행 · 입찰, 내 업무에서 해당 프로젝트에 어사인된 사람 중 어느 누구 한 명이라도 수정(변경 없음)하면 완료되도록". 완료 판정은 원래부터 **PJT 행 기준**(`isDone` = 이번 주 수정 또는 변경 없음 확인, 누가 했든) → 그대로. 확인: 박민수가 '변경 없음' 저장한 예시수행-D(담당 박민수 · 홍길동)가 홍길동 내 업무에서도 '완료'. 다른 사람이 한 것은 1분 자동 갱신 때 반영.
  - 헷갈리지 않게 완료 항목 설명(내 업무 창 · 툴바 마우스)에 **'박민수 님이 변경 없음 확인 (10-30 09:04)' / '내가 작성 (…)'** 표시, 미완료 설명에 '담당자 중 한 명만 하면 완료'.
- 바뀐 곳: dashboard.html `APP_VERSION` · `myTasks`(수행 · 입찰 sub). 서버는 v16.48 그대로(변경 없음 확인은 v16.48 서버 필요).
- 확인한 것: JS 문법 · 위 시나리오(홍길동 로그인 → 예시수행-D 완료 · 설명 '박민수 님이 변경 없음 확인').

### 2026-10-30 (38) — '변경 없음'이 회사에서 안 되던 것: 판넬 브랜치 server.py 합침 · 그 판도 덮어쓰기 · 옛 서버 안내 (APP_VERSION 2026-10-30.3 / SERVER_VERSION 2026-10-30.2)
> **server.py 바뀜 → 서버 재시작 필요.**
- 무엇을: 사용자 "변경 없음 기능이 반영되지 않았다". 원인(유력): 판넬 브랜치(`ccr-d82d97fa-bb3ty3`, 10-24 `0a80898` · `9ccd881`)가 **대시보드 server.py 를 따로 고쳐(SERVER 2026-10-24.1/.2) 회사에 보냄** → 회사 server.py 가 이 저장소가 모르는 판 → 대시보드 zip 의 APPLY.bat 이 server.py 를 덮지 않고 **`server.py.new`** 로만 둠 → 서버에 v16.40 이후 서버 변경(파일 안 보관본 · 도서 연결 · 변경 없음 기록)이 안 들어감. 임시 서버에 그 판 server.py 를 띄워 재현: 그대로 [저장] → '변경된 내용이 없습니다'(기록 안 됨).
  - 판넬 브랜치의 server.py 변경(룸 · Rev 만들기 · 프로젝트/룸/Rev 지우기 API, `space_room` `space_rev_add` `space_trash_saves` `space_can_del` `api_space_room_new` `api_space_rev_new` `api_space_project_del` `api_space_room_del` `api_space_rev_del` + 라우팅)을 이 server.py 에 **합침**(`git apply --3way`, 충돌 없음) → 덮어써도 그쪽 기능이 사라지지 않음.
  - `dashboard_tools/known_extra.txt`(새): 다른 줄기가 회사에 보낸 판의 커밋 목록 → `make_patch --any` 가 그 판들도 `known/` 에 넣음 → **회사본이 판넬 브랜치 판이어도 백업 후 덮어씀**.
  - 화면: 수행 · 입찰을 그대로 저장했는데 서버가 옛 판(2026-10-30.1 전)이면 '⚠ 서버가 옛 판(v…)이라 변경 없음을 기록하지 못했습니다 — server.py 를 새 판으로(옆에 server.py.new 가 있으면 그것) 바꾸고 서버 재시작' 안내.
- 바뀐 곳: server.py `SERVER_VERSION` · 판넬 API(위) · Handler 'space' 라우팅. dashboard.html `APP_VERSION` · `afterSave`(nochange 안내). dashboard_tools `make_patch.py`(extra) · `known_extra.txt`.
- 확인한 것: 문법. 새 서버(2026-10-30.2): 홍길동 예시수행-A 그대로 저장 → 완료 · `/api/space/projects` 정상. 판넬 브랜치 server.py(2026-10-24.2): 그대로 저장 → 위 ⚠ 안내 · 미완료(재현). zip 의 known/ 에 판넬 브랜치 server.py 가 들어감(아래 전달 기록).
- 회사에서 확인할 것: 대시보드 폴더에 **`server.py.new`** · `dashboard.html.new` 등 `.new` 파일이 있는지 — 있으면 이번 zip 을 적용하면 덮어씀(옛 것은 backup\). 적용 후 서버 재시작 → 왼쪽 아래 '서버 v2026-10-30.2' 확인.

### 2026-10-31 (39) — 편집 창에 [✓ 변경 없음] 단추 (APP_VERSION 2026-10-31.1 / SERVER 그대로 2026-10-30.2)
- 무엇을: 사용자 "변경 없음 ← 여전히 반영 안 됨"(편집 창 사진: [취소] [저장] 뿐). VOC 의 '변경 없음'은 **누르는 단추**였음 — (36)은 '바뀐 것 없이 [저장]' 만 기록해서 화면에 보이는 것이 없었음.
  - 수행 · 입찰 편집 창 아래 왼쪽에 **[✓ 변경 없음]**(초록). 누르면 내용 그대로 서버에 '변경 없음 확인' 기록(`saveEdit(..., rec.fields, …, {confirm:true})`) → 내 업무 완료 · 금주 업데이트에 포함(담당자 중 한 명만). 창에서 고친 내용이 있으면 '고친 내용 저장 / 버리고 변경 없음 / 취소' 를 물음.
  - 창 위 '최종 수정' 옆에 이번 주 상태: '✍ 이번 주 작성됨 (누구 · 시각)' / '✓ 이번 주 변경 없음 확인 (누구 · 시각)' / '이번 주 아직 작성 안 함 — 바꿀 것이 없으면 [✓ 변경 없음]'.
  - 표의 편집 칸(최종 수정 아래)에 '✓ 변경 없음 · 누구'.
  - 바뀐 것 없이 [저장]을 눌러도 전처럼 변경 없음으로 기록. 옛 서버(2026-10-30.1 전)면 '⚠ 서버가 옛 판…' 안내.
- 바뀐 곳: dashboard.html `APP_VERSION` · `openEdit`(pjRec · wk · collect · data-nochg) · `afterSave`('checked' 문구) · `actCell` · CSS `.btn.nochg` `.wkst` `.by .chkd`.
- 확인한 것: JS 문법. 임시 서버(2026-10-30.2 · 홍길동): '그린수소 실증' 편집 창 → '이번 주 아직 작성 안 함' + [✓ 변경 없음] · 업무 현황을 고친 채 누르면 '고친 내용이 있습니다' 물음 · 그대로 누르면 '✅ 완료' · 내 업무 미완료 → 완료 · 표에 '✓ 변경 없음 · 홍길동'. 콘솔 오류 없음.
- 회사에서 확인할 것: 서버가 v2026-10-30.2 인지(왼쪽 아래) — 아니면 (38) 대로 server.py 갱신 + 재시작.

### 2026-11-04 (40) — 통합 업무 정리 · 유닛분장 부서원 화면(인스타 느낌) · 부서원 표 · 오프라인 보관 10분 · 나갈 때 저장 묻기 (APP_VERSION 2026-11-04.1 / SERVER 그대로)
> server.py 안 바뀜 → 서버 재시작 필요 없음. 부서원 사본은 새 버전 배너로 교체.
- 무엇을 (사용자 요청 5가지):
  1. **일반업무 · 표준화 담당을 통합 업무 메뉴에서 뺌** → 유닛분장에서 부서원별로. 통합 업무 현황판(유형 카드 · 칩 · 숫자) · 표 · 메뉴 수 · [+ 업무 추가] 유형 고르기에서 빠짐(`TASK_HIDE` · `TASK_VIS` · `taskShown`). 데이터 · 내 업무 알림 · 엑셀 내보내기는 그대로. 편집 창 유형 목록에는 남기되 '— 유닛분장 부서원 화면에서 보임' 표시.
  2. **To Do List · 기술공유 · 그룹장 요청 사항: 늘 최신(등록 시각 `meta.createdAt`)이 맨 위** (`sortRecs` task · `TASK_NEWEST`; 같은 시각이면 기술공유 = 발표일, 그 외 = 순서).
  3. **조직도에서 부서원 누르면 부서원 화면(인스타그램 프로필 느낌)** — 사진(진행 업무 있으면 그라데이션 링) · 이름 · 직책 · 유닛 · 숫자 줄(수행 PJT · 입찰 PJT · To Do · 기술공유 · 그룹장 요청 · 일반업무 · 표준화 담당) → 하이라이트 동그라미 → 탭 → 카드 격자(진행 먼저 · 최신 위, 종결은 흐리게). 카드 = 편집 창(보기 전용이면 그 행으로 이동) · 수행/입찰 카드 = 그 행(금주 작성/변경 없음/미작성 표시). 일반업무 · 표준화 등 업무 탭에 **[+ 추가]**(유형 · 담당자 미리 채움). 조직도 카드에 진행 중 업무 수(🗂 📐 ✅ 📌). 수행/입찰 = PJT 행 담당자 칸, 업무 = 통합 업무(및 예전 시트) 담당 칸 기준(`personItems` · `openProfile` · `IG_CATS`).
  4. **유닛분장 [📋 부서원 표]**: 위 = 부서원마다 한 줄 엑셀식 표(유닛 · 이름 · 직책 · 담당 업무 · 전화 · 수행 PJT · 입찰 PJT · To Do · 기술공유 · 그룹장 요청 · 일반업무 · 표준화, 업무는 진행 중만) · 이름/칸 누르면 부서원 화면 · **[⬇ 엑셀로 저장]**(xlsx 한 시트). 아래 = 기존 유닛 편집 표. 조직도(그림)는 그대로(`unitPeople` · `peopleRows` · `peopleTableHtml` · `peopleXlsx` · `buildXlsx(sheetsIn)`).
  5. **오프라인 보관**: 파일 사본으로 로그인해 서버에 연결된 동안 **10분마다** 파일 안 보관본 갱신(바뀐 것이 없으면 6시간마다 · 1분마다 확인 · `EMBED_MS` · `latestChange` · `autoEmbed`). **나갈 때**(창 닫기 · 새로고침): 마지막 보관 뒤 바뀐 내용이 있으면 브라우저 '사이트에서 나가시겠습니까?' → [취소] → **'💾 최신 내용으로 저장할까요? [예] [아니요]'** → 예 = 파일에 저장 후 '이제 닫으셔도 됩니다'(`beforeunload` · `askSaveOnExit` · `UNLOAD_OK`). 브라우저가 닫히는 순간에는 파일 쓰기 · 저장 창을 띄울 수 없어 '머무르기'를 고른 다음에 묻는 방식. 주소(http)로 연 경우 · 서버 꺼짐 · 비회원은 묻지 않음. 새 버전 교체 · 서버 주소 바꾸기의 다시 열기는 묻지 않음.
- 바뀐 곳: dashboard.html `APP_VERSION` · `TASK_HIDE` `TASK_VIS` `taskShown` `TASK_NEWEST` `workType` · `sortRecs` · `filteredRecs` · `drawTable`(unit) · `renderMenu`(cntOf) · `taskHero` · 업무 추가 유형 · `inputFor`(유형) · `orgPill`(owc) · 새 `IG_CATS` `personItems` `IGP` `openProfile`(새로) `unitPeople` `PT_COLS` `peopleRows` `peopleTableHtml` `peopleXlsx` `latestChange` `askSaveOnExit` `UNLOAD_OK` · `buildXlsx(sheetsIn)` · `EMBED_MS` `autoEmbed` · `replaceSelf` · `setServerUrl` · CSS `.igp…` `.pfav` `.igc…` `.ptwrap` `.ptbl` `.pname` `.owc`.
- 확인한 것: JS 문법. 임시 서버(홍길동): 통합 업무 칩 = 전체 17 · To Do 10 · 기술공유 7 · 그룹장 요청 0(일반업무 · 표준화 없음) · 메뉴 17 · To Do 표 순서 = 등록 시각 내림차순과 같음. 조직도 카드 '🗂1 ✅2' · 홍길동 클릭 → 부서원 화면(수행 4 · 입찰 1 · To Do 3 · 기술공유 2 · 일반업무 2) · 일반업무 탭 [+ 일반업무 추가] → 행 추가 창(유형 일반업무 · 담당자 홍길동). 부서원 표 31명 · 엑셀 저장(시트 '부서원별 정보' 32행) · 칸 클릭 → 그 탭. 파일 사본 + 로그인: 나가기 → 브라우저 확인 → [취소] → '최신 내용으로 저장할까요?' → 예 → 파일에 씀 · 그다음 나가기는 바로 나감. 콘솔 오류 없음.
- 회사에서 확인할 것: Edge 에서 창을 닫을 때 '사이트에서 나가시겠습니까?' → [취소] → 저장 질문이 뜨는지. 파일 쓰기 허락이 '방문할 때마다 허용'이 아니면 10분 자동 보관은 조용히 못 하고 [💾 자동 보관 켜기] / 빨간 표시로 안내됨.

### 2026-11-04 (41) — 유닛분장(부서원 화면)에서 추가한 To Do · 기술공유 · 그룹장 요청 = 통합 업무에도 바로 (APP_VERSION 2026-11-04.2 / SERVER 그대로)
- 무엇을: 사용자 "유닛분장에서 To Do List, 기술공유, 그룹장 요청 사항을 추가하면 자연스럽게 통합 업무에도 등록". 부서원 화면의 [+ 추가]는 원래부터 **같은 통합 업무 자료(task 시트)** 에 행을 만듦 → 통합 업무에 바로 보임(시험 확인). 다만 저장하면 창이 닫히고 유닛분장만 남아 등록됐는지 알기 어려웠음 → 
  - 저장 뒤 **부서원 화면을 그 탭으로 다시 띄워 새 카드를 맨 앞에** + 알림 '✅ To Do List 등록 — 통합 업무 메뉴(To Do List 맨 위)에도 등록되었습니다'(일반업무 · 표준화는 '유닛분장 부서원 화면에서 봅니다').
  - To Do · 기술공유 · 그룹장 요청 탭 위에 '이 탭의 업무는 통합 업무 메뉴와 같은 자료입니다' + **[🚀 통합 업무에서 보기 (이름 · 유형)]** → 통합 업무를 그 유형 · 그 담당자로 걸러서 엶.
  - 반대로 통합 업무에서 추가 · 고친 것도 부서원 화면에 그대로 보임(같은 자료).
- 바뀐 곳: dashboard.html `APP_VERSION` · `openEdit`(after) · `submitRecord`(after) · `openProfile`(추가 뒤 다시 띄움 · data-igtask · `.igtl`).
- 확인한 것: JS 문법. 임시 서버(홍길동): 부서원 화면 To Do 탭 [+ To Do List 추가] → 저장 → 부서원 화면 다시 · 첫 카드 = 새 To Do · 알림 → [통합 업무에서 보기] → #task · To Do List 필터 · 표 맨 위 = 새 To Do. 기술공유 · 그룹장 요청도 통합 업무 표에 보임. 콘솔 오류 없음.

### 2026-11-04 (42) — 유닛분장 조직도 새 판 (첨부 시안 결: 밝은 트리 · 확대/축소 · 전체 보기 · 전체 화면 · 미니맵 · 오른쪽 상세 창) (APP_VERSION 2026-11-04.3 / SERVER 그대로)
- 무엇을: 사용자 시안(Organization Chart) "조직도 · 유닛분장을 전체로 볼 수 있고, 미리보기 · 클릭하면 상세 · 전체 보기". 예전 어두운 우주풍 카드 → 밝은 트리.
  - 모양: 맨 위 그룹장 큰 카드(👑) → 선으로 유닛 상자(유닛 색 · 인원 · 담당) → 아래로 부서원 카드(사진 · 이름 · 직책 · 수행/입찰 PJT 수 · 🗂📐✅📌 진행 업무 수, 유닛장 ★). 모눈 바탕.
  - 도구줄: [－] 배율 [＋] · [⊙ 전체 보기](가로 · 세로 모두 한 화면) · [1:1] · [⛶ 전체 화면](Esc = 나가기) · [🙋 내 정보]. 처음 열 때는 가로에 맞춤(글자가 너무 작아지지 않게). 끌어서 이동 · 휠 = 이동 · Ctrl+휠 = 커서 쪽 확대/축소.
  - 오른쪽 위 **Overview 미니맵**(조직도 축소본 + 지금 보이는 범위 파란 상자, 누르면 그곳으로).
  - **오른쪽 상세 창**: 마우스 올리면 **미리보기**, 누르면 **고정**(카드 강조) — 사진 · 이름 · 직책 · 유닛 · 담당 · 전화 · 수행/입찰 PJT · To Do/기술공유/그룹장 요청/일반업무/표준화 진행 수(누르면 부서원 화면 그 탭) · **[부서원 화면 열기 →]** · 조직 정보(전체 인원 · 유닛 · IEC · 프로필 입력). 카드를 **두 번 누르면** 바로 부서원 화면. 전체 화면에서도 부서원 화면이 위에 뜸.
  - 유닛 제목 = 유닛 편집(편집 권한) · IEC 기본 명단 = [표에 등록] (전과 같음). 범례.
  - 배율 · 위치 · 고른 사람은 1분 자동 갱신에도 유지(조직이 바뀌면 다시 맞춤).
- 바뀐 곳: dashboard.html `APP_VERSION` · `orgHtml`(새로) · 새 `OC` `OC_UC` `ocSide` `ocApply` `ocFit` `ocZoom` `orgBind` · `orgClick`(data-oc · data-ocp · 선택) · `drawTable`(orgBind) · fullscreenchange · CSS `.oc…`. 예전 `orgPill` 은 남아 있으나 조직도에서 쓰지 않음.
- 확인한 것: JS 문법. 임시 서버(1600×1000): 처음 가로 맞춤 · 김철수에 마우스 → 상세 '미리보기' · 홍길동 클릭 → '선택됨' · ＋ 두 번 74% · 끌어 이동 · 미니맵 상자 · 전체 보기 · [부서원 화면 열기] · 이영희 두 번 누름 → 부서원 화면 · 전체 화면 86% · 전체 화면에서 부서원 화면. 콘솔 오류 없음.
- 회사에서 확인할 것: 화면이 좁으면(왼쪽 메뉴 + 오른쪽 내 업무 띠) 조직도가 작게 보임 → [⛶ 전체 화면] 이나 왼쪽 메뉴 숨기기.

### 2026-11-04 (43) — 조직도에 [🏗 프로젝트별 · LE/RE] · [🌏 세계 지도] 보기 + 배경(낮 · 밤 · 플랜트) + 휠 = 확대/축소 (APP_VERSION 2026-11-04.4 / SERVER 그대로)
> server.py 안 바뀜 → 서버 재시작 필요 없음.
- 무엇을: 사용자 "프로젝트별 LE · RE 조직으로도 한눈에 · 휠로 줌인/줌아웃 · 구글어스처럼 프로젝트 위치별 국가 · 시간 · 날씨를 한눈에 보는 탭 · 배경 이미지/색".
  - 조직도 위에 파란 머리띠(플랜트 실루엣) + 보기 3개 **[🧩 유닛] [🏗 프로젝트별 · LE/RE] [🌏 세계 지도]** + 배경 3개 **[☀ 낮] [🌙 밤] [🏭 플랜트]**(고른 것은 PC 에 기억: localStorage `dept-oc-mode` · `dept-oc-bg`, 기본 = 유닛 · 플랜트). 보기마다 배율 · 위치를 따로 기억.
  - **휠 = 늘 커서 쪽 확대/축소** (전에는 휠 = 이동 · Ctrl+휠 = 확대). 이동은 끌어서.
  - **프로젝트별 · LE/RE**: 계장 투입인력 시트의 PJT 열 · 배정(투입률 · LE/RE) 기준 나무 — 맨 위 'PJT 조직' → 수행 / 입찰 / 기타 → PJT 상자(이름 · 수행/입찰 · 나라 · 인원 · 몇 명분) 안에 **LE 카드(위, 강조)** · RE 카드(아래). 카드 = 유닛 보기와 같은 카드(누르면 오른쪽 상세 · 두 번 = 부서원 화면).
  - **세계 지도**: Natural Earth 1:110m 나라 경계(공용 자료, 약 82KB)를 파일 안에 넣음(`<script id="deptWorld">`, 외부 지도 서버 안 씀). 진행 중 수행 · 입찰 PJT 의 나라를 **'국가'(또는 '위치') 열 → PJT명 → 발주처 → PJT 개요** 순서로 낱말에서 찾음(`CTRY`: 카타르 · Ras Laffan · 사우디 · Jubail · UAE · 하와이 · 대만 · Taichung · 싱가포르 · 호주 · 알제리 · 삼척 등 약 45개 나라/도시). 나라 칠하기(수행 파랑 · 입찰 주황 · 둘 다 보라) + 표시(PJT 수 · 나라 · **현지 시각 ☀/🌙** · 날씨). 표시는 확대해도 화면에서 같은 크기 · 이름표가 겹치면 옆 빈자리로(`mapPin`). 최대 1000% 까지 확대.
  - 지도 오른쪽: '한눈에' = 나라별 현지 시각 · 날씨 · PJT 수 · **위치 미상 PJT 목록**(PJT명에 나라/도시를 넣거나 '국가' 열을 추가하라는 안내). 나라 누르면 = 현지 시각(크게) · 날짜 · 낮/밤 · 한국과 시차 · 날씨 · 그 나라 PJT(누르면 그 행으로) · LE/RE 명단(누르면 부서원 화면).
  - **날씨**: 외부 open-meteo.com(무료 · 키 없음)에 **나라 대표 좌표만** 보냄 → 처음 [🌤 날씨 불러오기]를 눌러야 켜짐(`dept-wx-on`), 30분 보관, 6초 안에 답 없으면 '날씨 연결 안 됨 (사내망)'. 사내망에서 막혀도 나머지는 그대로.
  - 예전 꼬리표 `.oc`(PJT 칩) CSS 가 새 조직도 틀 `.oc` 와 이름이 겹쳐 `:is(.ochips,.pfl) .oc` 로 좁힘.
- 바뀐 곳: dashboard.html `APP_VERSION` · `orgHtml`(보기 · 배경 머리띠) · `ocMode` `ocBg` · `ocApply`(mapPin) · `ocZoom`(지도 최대 10배) · `orgBind`(휠 · 지도 마우스 올림) · `orgClick`(data-ocmode · data-ocbg · data-ctry · data-wxon · data-mjump) · 새 `projData` `projTreeHtml` `CTRY` `ctryOf` `worldData` `mxy` `mapProjects` `worldHtml` `mapPin` `ltime` `lhour` `mapTick` `WX` `wxLoad` `mapSide` · `<script id="deptWorld">` · CSS `.oc-hero` `.oc-modes` `.oc-bgs` `.bg-*` `.ot` `.oc-cat` `.oc-pjs` `.oc-pj` `.oc-le` `.oc-iso` `.wmap` `.mk` `.mrow` `.mhd` `.mtime` `.mwx` `.mp…`.
- 확인한 것: JS 문법. 임시 서버(가짜 PJT 이름에 카타르 · 사우디 Jubail · UAE · 하와이 · 대만 · 삼척 · 싱가포르 · 호주 · 미국 Texas, 투입인력 5개 PJT LE/RE): 유닛 보기 배경 3가지 · 프로젝트별 12개 상자(LE 위) · 휠 확대 58%→192% · 세계 지도 9개국 표시 · 현지 시각 · 카타르 누름 → 10:21 · 한국과 -6시간 · PJT 2개 · LE 홍길동 50% · 중동 1000% 확대(표시 크기 그대로) · [날씨 불러오기] → 시험 환경은 외부망 막힘 → '날씨 연결 안 됨'(오류 없이) · PJT 누름 → 수행 표로 이동. 페이지 오류 없음.
- 회사에서 확인할 것: 사내망에서 open-meteo.com 이 열리는지(막히면 날씨만 안 보임). 실제 PJT 이름에서 나라가 잘 잡히는지 — 안 잡히는 PJT 는 지도 오른쪽 '위치 미상'에 나옴 → 낱말 추가가 필요하면 `CTRY` 에 넣거나 수행/입찰 시트에 '국가' 열.

### 2026-11-04 (44) — 세계 지도 · 프로젝트별 조직도를 사용자 시안 수준으로 (APP_VERSION 2026-11-04.5 / SERVER 그대로)
> server.py 안 바뀜 → 서버 재시작 필요 없음.
- 무엇을: 사용자 "지도 너무 겹치고 가독성이 안 좋다 — 점 찍고 선으로 끌고 내용 안 겹치게" + 시안 그림(프로젝트 세계 지도) + 시안 zip(프로젝트별 조직 UI) "이 수준으로".
  - **세계 지도**: 짙은 남색 바다(그라데이션) · 빛나는 점(glow) · **점 → 선 → 이름표** 방식. 이름표 = 흰 둥근 상자에 **국기 · 나라 이름 · N PJT · 현지 시각(☀/🌙)**. 이름표는 실제 글자 폭을 재서(`mapLabelSize`) 이름표끼리 · 점 · 선과 **겹치지도 엇갈리지도 않는 가장 가까운 빈자리**를 24방향 × 거리별로 찾음(`mapPin`, 겹침·교차마다 벌점 → 최소). 확대해도 이름표·점은 화면에서 같은 크기. 나라를 고르면 점이 커지고 노란 테두리. **본사(한국) → 각 현장 점선 호(弧)**. 지도 위 오른쪽 [＋][－][⌖] · 왼쪽 아래 Overview · 오른쪽 아래 범례. 위 도구줄에 **금주 작성률 막대 · 전체/수행/입찰/미작성 칩 · [전체|수행|입찰] 거르기**. 지도 아래 **프로젝트 요약 타일**(전체 PJT · 수행 · 입찰 · 금주 작성 · 미작성).
  - 오른쪽 '국가별 프로젝트 현황' = 국기 · ISO · 나라 · N PJT · **금주 작성률 막대 · %** (시안의 진행률 자리). 나라를 누르면 국기 · 현지 시각 · 시차 · 날씨 · PJT(금주 작성/미작성 표시) · LE/RE.
  - **프로젝트별 · LE/RE**(시안 zip `DESIGN_SPEC.md` 기준): 수행/입찰 가지 없이 **같은 폭 카드 격자**(한 줄 최대 5개), 맨 위 남색 'PJT 조직' 상자(총 수행 N · 입찰 M) → 선 → 카드. 카드 머리 = PJT명(길면 말줄임 + 툴팁) · 국기 · **수행(파랑)/입찰(주황) 글자 라벨** · 인원 · 명분 · 나라. 인원 카드 = 이름 · LE/RE · 투입률 · 수행/입찰/업무 수. **한 사람의 모든 PJT 투입률 합이 100% 를 넘으면 '⚠ 합계 110%'**. 처음 열 때 전체가 한 화면에(fit). [전체|수행|입찰] 거르기. 시안의 '편집 모드 드래그'는 넣지 않음(배정은 계장 투입인력 시트에서 고침) · '인원 목록'은 유닛분장의 [📋 부서원 표]가 그 역할.
- 바뀐 곳: dashboard.html `APP_VERSION` · `flagOf` · `projTreeHtml`(새로) · `worldHtml`(호 · glow · 국기 이름표) · `mapLabelSize` `mapPin`(새로) · `mapStats`(새로) · `mapSide`(국가별 현황 막대) · `orgHtml`(도구줄 작성률 · 칩 · 거르기 · 지도 위 버튼 · 범례 · 요약 타일) · `orgClick`(data-mapf) · `orgBind`(첫 fit) · CSS `.ot2` `.oc-root` `.oc-pjs2` `.oc-pj` `.oc-pjh` `.oc-fil` `.oc-prog` `.oc-chips` `.wmap` `.arc` `.mk` `.mlb` `.oc-mctl` `.oc-mleg` `.oc-stats` `.oc-tile` `.mrow`.
- 확인한 것: JS 문법. 임시 서버(20개국 24 PJT 가짜 자료, 1600×1000): 지도 이름표 20개 **겹침 0**(전체 보기 · 118% 확대 · 입찰만 5개 모두 0) · 카타르 누름 → 오른쪽 상세 · 지도 점 강조 · 낮/밤 배경 · 프로젝트별 5개 카드 한 화면(65%) · ⚠ 합계 110% 표시 · 거르기. 페이지 오류 없음.

### 2026-11-04 (45) — 지도 이름표 'N PJT' 글자 크기 · 나라 상세에서 PJT 누르면 정보 펼침 (APP_VERSION 2026-11-04.6 / SERVER 그대로)
- 무엇을: 사용자 "PJT 폰트 너무 크다" → 이름표 안 'N PJT' 가 전역 `.cnt{font-size:12px}` 에 걸려 커졌음 → `.mlb .cnt` 에 7.5px 지정(현지 시각과 같은 크기). "그 지역 PJT 를 누르면 정보도 나오도록" → 오른쪽 나라 상세의 PJT 를 누르면 **그 자리에서 펼침**(▼/▲): 사업군 · Project Code · PJT 개요 · 주요 일정 · 담당자 · 업무 현황 · 현안(입력된 것만) · 마지막 수정 · 변경 없음 확인 + **[📋 표에서 보기] [✎ 편집]**(편집 권한일 때). 전에는 누르면 바로 표로 이동했음.
- 바뀐 곳: dashboard.html `APP_VERSION` · `mapSide`(data-mopen · data-medit · `.mpd`) · `orgClick` · CSS `.mlb .cnt` `.mp.open` `.mpd` `.mpf` `.mpb` `.mpa`.
- 확인한 것: JS 문법. 임시 서버: 카타르 → PJT 누름 → 정보 펼침(사업군 · Code · 개요 · 일정 · 담당자 · 업무 현황 · 마지막 수정 · 변경 없음 확인) → [편집] 창 열림 → [표에서 보기] #perform 이동. 오류 없음.

### 2026-11-05 (46) — 사용자 redesign-kit(DESIGN_SPEC · theme · mockup) 반영: 유닛분장 조직도 · 프로젝트별 · 세계 지도 · 내 업무 (APP_VERSION 2026-11-05.1 / SERVER 그대로)
> server.py 안 바뀜. 기능 · 데이터 · 이벤트는 그대로, 보이는 것만 바꿈 (키트 규칙). 기존 id · data-* 유지.
- 무엇을 (키트 STEP 3~7, 수치는 DESIGN_SPEC 그대로):
  - **머리**: 어두운 파란 띠 → 밝은 그라데이션(왼쪽 4px 파란 막대 + 제목 28/800 + 부제) + 오른쪽 플랜트 실루엣(인라인 SVG). 배경(낮/밤/플랜트) 버튼은 뺌(키트: 조직도는 밝은 점 격자, 지도는 어두운 패널 고정).
  - **도구줄**: 흰 둥근 줄(높이 56) — 보기 전환 segmented(유닛 / 프로젝트별 LE·RE / 세계 지도, 활성 = 파란 채움 + SVG 아이콘) · 거르기 · 줌 그룹 [⌕ − 100% + ⌕] · 맨 오른쪽 [내 정보]. [전체 보기] [1:1] [전체 화면] 은 캔버스 오른쪽 아래 **흰 원형 44px 떠 있는 버튼**(⌖ ⤢ ⛶)으로.
  - **캔버스**: #F7F9FD + 20px 점 격자, radius 16, Overview 미니맵 = 흰 카드(제목 파랑 13px). 범례 = 왼쪽 아래 알약 칩(유닛 색 · ★ 유닛장 / 수행 · 입찰).
  - **연결선** 1.5px #9DB4E6 직각. 부서원 사이 점선 제거.
  - **유닛 카드**: 부서색 머리 띠(높이 38, 유닛1 파랑 · 유닛2 초록 · 이후 보라/청록… · IEC 주황, `OC_BAND`) + 유닛장 카드가 같은 상자 안. 부서원 카드 = 아바타 48(흰 테두리 · 부서색 그라데이션) · 이름 15/700 · 역할 12.5 · **알약 칩**(수행 파랑 · 입찰 주황 · To Do 초록 · 요청 빨강 · 일반/표준 회색). hover 위로 2px, 선택 = 파란 2px 테두리 + 그림자. 그룹장 카드 340 · 파란 2px 테두리 · 그라데이션 · 왕관 · '그룹장' 칩.
  - **프로젝트별**: 같은 카드 · 머리 띠(수행 파랑 · 입찰 주황, 가운데 정렬). 카드 머리가 반쯤만 칠해지던 것(옛 `.oc-pj` flex 규칙 충돌) 고침.
  - **오른쪽 상세**(340px): 탭 **[ⓘ 상세 | 👥 멤버]**(활성 아래 3px 파란 줄). 상세 = 아바타 96 + **접속 중이면 초록 점**(접속자 목록 기준) · 직급 칩 · 이름 22/800 · 아이콘 key-value(행 40) · **수행/입찰 = PJT 칩, 없으면 '없음' 한 줄**(전에 빈 큰 상자로 보이던 것 — 옛 `.oc-pj` 클래스 이름 충돌 — 없앰) · 업무 수 3열 미니 카드 · '조직 정보' 연파랑 카드 · 테두리 버튼 [부서원 화면 열기 →]. 멤버 = 같은 유닛 사람(그룹장이면 그룹장 · 유닛장) 목록, 누르면 그 사람 선택.
  - **세계 지도**: 패널 #0B1F4D→#10306E, 대륙 #1E3F86 · 국경선 없음, 본사→현장 **실선 곡선** 1px, PJT 3개 이상 나라만 큰 점 + 펄스, 이름표 = 반투명 흰 칩. 국가 목록 = [국기][코드][나라 — 말줄임 없음, 길면 줄바꿈][n PJT][막대][%][›] · **10개 넘으면 [+ 더보기]**. 아래 KPI 카드 = 아이콘 원 36 · 숫자 30/800 · 라벨 13, 미작성 카드 = #FFF7ED.
  - **내 업무 위젯**(5-10): 폭 300 · 제목 **2줄까지**(그 뒤 말줄임) · 배지 색 통일(To Do 파랑 soft · 그룹장 요청 빨강 soft · 수행 PJT 파랑 · 입찰 PJT 주황 · 시수 보라) · **완료 항목은 아래 '완료됨 N ▾' 로 접음**.
- 넣지 않은 것: 키트 STEP 2(앱 전체를 왼쪽 네이비 사이드바 + 버튼 묶기(내보내기 ▾ 등)로 바꾸는 것) — 모든 메뉴 화면이 바뀌므로 사용자 확인 뒤. KPI 스파크라인 — 주별 추이 자료가 없어 지어내지 않음. Pretendard 글꼴 — CDN 금지라 기존 글꼴. 다크 모드 — 대시보드에 없음.
- 바뀐 곳: dashboard.html `APP_VERSION` · `OC_UC` `OC_BAND` · `orgHtml`(머리 · 도구줄 · 떠 있는 버튼 · 범례 칩 · `unitBox`) · `card`(칩) · `ocSide`(새로, 탭 · 멤버) · `ocApply`(미니맵 크기) · `worldHtml`(many) · `mapLabelSize` · `mapSide`(목록 · 더보기) · `mapStats`(warn) · `orgClick`(data-octab · data-ocpick · data-mmore) · `tkCls` · `renderTaskBar`(배지 · 완료 접기) · `taskBarClick`(done) · CSS 맨 끝 'redesign-kit 반영' 묶음(`.oc.rd …` · `#taskbar …`).
- 확인한 것: JS 문법. 임시 서버(1600×1000): 유닛 · 홍길동 선택(상세 · 접속 초록 점 · 수행 칩 4 · 입찰 칩 1) · 멤버 탭 · 프로젝트별(머리 띠 전체 폭) · 세계 지도(국가 목록 이름 안 잘림 · 더보기(10)) · 카타르 상세 · 내 업무(2줄 · 배지 · 완료됨 6 접힘). 페이지 오류 없음.

### 2026-11-07 (APP_VERSION 2026-11-07.1 / SERVER_VERSION 2026-11-07.1)
- 무엇을: 메뉴에 **🧊 3D 계측제어** 추가 (도서검토 바로 아래). 왜: 사용자 지시 — 세션 7 '3D 계측제어 도구'를 대시보드 메뉴로 연결. 도구 자체는 그 세션에서 만들고 P&ID 서버(run_lan_service.bat, 8000)의 `/ic3d` 에 붙음. 여기서는 연결(iframe)만.
- 바뀐 곳: dashboard.html `APP_VERSION` · `PID_ROUTES.ic3d`({ port:PID_PORT, path:'/ic3d', q:'embed=1&' }) · `ROUTES` · `renderMenu` · `QF_MENUS`(빠른 찾기) · `VOC_MENU` · `PZ_STATUS`('3D 계측제어 중...') / server.py `SERVER_VERSION` · `MENUS`(메뉴 권한 설정 열 · 기본 허용) · `VOC_MENUS`.
- 확인한 것: 임시 서버 + 가짜 P&ID 서버(8000): 메뉴 표시 · 누르면 `http://<호스트>:8000/ic3d?embed=1&user=본명` iframe · 메뉴 권한 설정 목록에 '3D 계측제어' · 페이지 오류 없음. 회사에서 확인할 것: P&ID 서버에 `/ic3d` 가 붙은 뒤 화면이 뜨는지 (붙기 전에는 P&ID 서버의 '없는 경로' 화면이 보임). server.py 가 바뀌었으므로 서버 재시작 필요.

### 2026-11-07 (APP_VERSION 2026-11-07.2 / SERVER_VERSION 그대로 2026-11-07.1)
- 무엇을: 왼쪽 메뉴 — 상위 메뉴 앞 이모지를 **번호 칸(1, 2, 3 …, 보이는 메뉴만 차례로)** 으로 바꾸고, 상위 메뉴를 강조(흰 글씨 15px · 위 간격 4px · 번호 칸은 반투명, 선택하면 흰 칸 + 파란 숫자). 하위 메뉴는 한 단계 흐리게(#b9c3e8). 왜: 사용자 지시 '메인 메뉴 더 하이라이트 · 이모지 대신 숫자'.
- 바뀐 곳: dashboard.html `APP_VERSION` · `renderMenu`(`no` 번호 · 라벨 이모지 뺌) · CSS `.mi.top` `.mi .mno` `.mi.subi:not(.on)`. 메뉴 권한에 따라 숨은 메뉴는 번호를 건너뛰지 않고 차례로 매김.
- 확인한 것: 임시 서버 — 홈 · 3D 계측제어 선택 화면 캡처, 페이지 오류 없음.

### 2026-11-07 (APP_VERSION 2026-11-07.3 / SERVER_VERSION 그대로 2026-11-07.1) — VALVE 세션 메뉴 병합
- 무엇을: VALVE 세션(브랜치 `ccr-efbe7e75-n915ze` · `claude/gracious-ride-26nqrf`, 커밋 1700284c · e39cfda2, APP_VERSION 2026-10-31.2 / 2026-11-01.1)이 v16.51 위에 넣은 **실행 프로젝트 › CO2 PJT › Datasheet › Ball Valve · Globe Valve · Butterfly Valve · PSV** 메뉴가 이 줄기(v16.52~v16.60)에 빠져 있었음 → 병합. 왜: 사용자 '실행프로젝트에 CO2 프로젝트를 추가했던 것 같은데'.
- 바뀐 곳: dashboard.html `APP_VERSION` · `MODULES`(globev · bflyv · psv + `note`) · `renderModule`(note 표시) · `PID_ROUTES.valve`(P&ID 서버 /valve/) · `ROUTES` · `RUN_LEAVES` · `menuOf` · `NAV_LS`(runpjt · runpjt-co2 · runpjt-co2-ds) · `renderMenu`(`fold` · `runTree`, 번호 메뉴 방식에 맞춤 — 폴더 줄 `.mfold`) · `QF_MENUS` · `PZ_STATUS.valve`.
- 확인한 것: 임시 서버 + 가짜 P&ID 서버: 실행 프로젝트 아래 CO2 PJT › Datasheet › 잎 4개, Ball Valve → `:8000/valve/?embed=1&project=CO2%20PJT&user=…` iframe, PSV → '🚧 준비 중' + 설명. 페이지 오류 없음.
- 회사에서 확인할 것: 회사 dashboard.html 이 VALVE 판(2026-11-01.1)이면 이 업데이트의 APPLY.bat 가 덮지 않고 `.new` 로 둘 수 있음 → 그때는 `.new` 를 dashboard.html 로 바꿔 넣으면 됨(이 판에 VALVE 메뉴가 모두 들어 있음).

### 2026-11-07 (APP_VERSION 2026-11-07.4 / SERVER_VERSION 2026-11-07.2) — 재무스타그램 메뉴 · DART 중계
- 무엇을: 메뉴 **재무스타그램**(실행 프로젝트 아래) 추가. 사용자 지시 '재무스타그램(회사 PC `C:\Users\백승욱\Desktop\해커톤\2day\dart_dashboard`)을 메뉴로 넣고 대시보드에 포함해 관리', 'API 키는 회사 PC 에 두고 그 경로를 연결'.
  - 화면: 운영 폴더 `apps\finstagram\index.html` 을 대시보드 서버가 `/apps/finstagram/` 으로 줌 (`APP_ROUTES.finstagram`, 본문 전체 iframe). **앱 파일은 아직 받지 못함** — 파일이 없으면 '화면 파일이 서버에 아직 없습니다 · apps\finstagram 폴더 필요' 안내.
  - DART 중계: `GET /api/dart/<이름>.json|xml?…` → 서버가 키를 붙여 `https://opendart.fss.or.kr/api/<이름>` 에 묻고 그대로 돌려줌(10분 기억, corpCode 는 하루). 키는 브라우저 · 배포물 · 로그에 나가지 않음. `GET /api/dart/_status` = 키 파일 경로 · 있는지 · 길이(값은 안 줌). 사내망 접속이면 누구나(DART 공개 자료).
  - 키 파일 위치(앞이 우선): ① `server.py --dart-key 경로` ② 운영 폴더 `dart_key_path.txt` 안에 적은 경로 ③ `C:\Claude\keys\dart_api_key.txt`. 내용 = 키 한 줄(`DART_API_KEY=…` 도 됨).
  - 메뉴 권한 '재무스타그램'(기본 허용) · VOC 메뉴 · 빠른 찾기.
  - make_patch: `apps/` 는 계속 빼되 `apps/finstagram/` 은 대시보드 zip 에 넣음(`KEEP_PREFIX`).
- 바뀐 곳: dashboard.html `APP_VERSION` · `APP_ROUTES` · `ROUTES` · `renderMenu` · `VOC_MENU` · `QF_MENUS` · `PZ_STATUS` / server.py `SERVER_VERSION` · `DART` `dart_key_path` `dart_key` `api_dart_status` `api_dart` · `api`('dart') · `MENUS` · `VOC_MENUS` · `main`(--dart-key) / dashboard_tools/make_patch.py `KEEP_PREFIX`.
- 확인한 것: 임시 서버 — 키 없음 → 503 안내(기본 경로 표시), dart_key_path.txt 로 임시 키 → _status 40자 · 이 환경은 외부 인터넷이 막혀 502 'DART 서버에 연결하지 못했습니다'(정상 안내), 이상한 이름 → 404/400. 메뉴 클릭 → 파일 없음 안내. 페이지 오류 없음.
- 회사에서 확인할 것: 서버 PC 에서 opendart.fss.or.kr 접속이 되는지(사내 방화벽), 키 파일 경로.

### 2026-11-07 (APP_VERSION 2026-11-07.5 / SERVER_VERSION 2026-11-07.3) — 재무스타그램 앱 넣음 · 자기 서버로 띄움
- 무엇을: 사용자가 올린 재무스타그램(dart_dashboard: server.py · extras.py · index.html · CLAUDE.md …)을 `apps/finstagram/` 에 넣음. 앱이 원래 자기 서버(표준 라이브러리, 8765)에서 DART · 네이버 증권 · FnGuide · Open-Meteo · 회사 IR 을 서버 쪽에서 부르므로, 바로 앞 판의 대시보드 `/api/dart` 중계는 **빼고**, 대시보드 서버가 앱 서버를 **함께 띄우는 방식**(계장 광장과 같음)으로 바꿈.
  - 대시보드 server.py: `FIN` · `dart_key_path` · `fin_info` · `fin_loop`(30초마다 확인, 꺼지면 다시 띄움, 3번 연속 실패면 10분 쉼, 기록 `finstagram.log`) · `fin_stop` · `--fin-port`(기본 8765, 0 = 안 띄움) · `/api/info` 에 `finPort`. 띄울 때 환경변수 `PORT` · `FIN_HOST=0.0.0.0` · `DART_KEY_FILE`(키 파일 경로 — 대시보드는 키 값을 읽지 않음) · `FIN_NETS_FILE`(대시보드 사내 대역 파일).
  - 앱 server.py(최소 수정, 앱 `APP_VERSION 2026-11-07.1`): 키 = `DART_API_KEY` → `DART_KEY_FILE` → `dart_api_key.txt`(`DART_API_KEY=…` 형식도), **키가 없어도 서버는 켜지고** 요청 때 안내 · corpCode 목록은 첫 검색 때 받음(인터넷이 없어도 켜지게) · `FIN_HOST` · **사내망 주소만 허용**(사설망 + 대시보드 대역 파일) · `/version`(대시보드 연결 확인용) · `/vendor/…` 정적 파일(상위 경로 차단) · 접속 로그 끔.
  - 앱 index.html: CDN 4곳 → `vendor/`(echarts 5.4.3 · world.json(echarts 4.9.0) · globe.gl 2.34.1 · three-globe 2.31.1 그림 3장, npm 꾸러미에서 꺼냄, 라이선스 파일 같이).
  - 대시보드 dashboard.html: 메뉴는 `PID_ROUTES.finstagram`({port:8765, path:'/', off:'…finstagram.log 확인'}) — P&ID 처럼 `/version` 확인 뒤 iframe. `pidConnect` 가 경로별 `off` 안내를 씀. `APP_ROUTES` 는 다시 빈 값.
- 확인한 것: 임시 서버 — 대시보드가 앱 서버를 띄움(finstagram.log '키 있음'), `/version` · `/vendor/echarts.min.js` 200, `/vendor/../server.py` 404, 메뉴 9 재무스타그램 → iframe `:8765/` 에 검색 첫 화면 · echarts 로드됨, 페이지 오류 없음. 이 환경은 외부 인터넷이 막혀 실제 검색(DART)은 확인 못 함.
- 회사에서 확인할 것: 서버 재시작 뒤 메뉴 재무스타그램 · Windows 방화벽이 python 8765 포트를 물으면 허용(계장 광장 8100 과 같음) · 키 파일 경로(운영 폴더 `dart_key_path.txt` 또는 `C:\Claude\keys\dart_api_key.txt`) · 서버 PC 에서 opendart.fss.or.kr · 네이버 증권 접속. IR PDF 카드는 pymupdf 가 없어 꺼짐(앱 원래 동작).

### 2026-11-07 (APP_VERSION 2026-11-07.6 / SERVER_VERSION 2026-11-07.4 / 재무스타그램 앱 2026-11-07.2) — 운영자가 DART 키 .env 경로 지정
- 무엇을: 사용자 지시 '운영자가 DART API 키가 있는 .env 파일 경로를 회사 PC 에서 지정하고, 그 .env 키 값으로 재무스타그램이 동작'. 재무스타그램 화면 머리줄 오른쪽 **⚙ DART 키(.env) 경로** (운영자 = 서버 PC 접속에만 보임) → 창: 지금 경로 · 출처 · 상태(파일 없음 / 키 못 찾음 / ✓ 키 확인 40자) · 앱 서버 켜짐 여부 · 경로 입력 · [저장 · 다시 띄우기]. 키 값은 화면 · 응답 · 로그 어디에도 안 나감(있는지 · 길이만). 키가 없으면 머리줄에 '⚠ DART API 키가 없습니다' 안내(부서원에게는 '운영자에게 요청').
  - .env 읽는 규칙(대시보드 `parse_dart_key` = 앱 `parse_key`, 고치면 둘 다): `DART_API_KEY=` (또는 OPENDART_API_KEY · DART_KEY · CRTFC_KEY, `export ` · 따옴표 · 줄 끝 # 주석 허용) 줄 먼저, 없으면 키만 적힌 한 줄. 폴더를 적으면 그 안의 `.env`.
- 바뀐 곳: server.py `SERVER_VERSION` · `FIN`(wake) · `parse_dart_key` · `api_finkey_get` · `api_finkey_put`(운영 폴더 `dart_key_path.txt` 에 원자적 저장, 비우면 지움 = 기본 위치, `--dart-key` 로 켰으면 409) · `fin_restart` · `fin_loop`(30초 대기를 Event 로 — 저장하면 바로 다시 띄움) · `api`('admin/finkey', `need_admin`) / dashboard.html `APP_VERSION` · `renderPid`(⚙ 단추 · `.pidnote`) · `pidConnect`(/version 의 key 로 안내) · `openFinKey`(새) · 클릭 처리 `[data-finkey]` · CSS `.finkey` `.finwarn` `.finok` `.finkv` / apps/finstagram/server.py `APP_VERSION` · `parse_key` · `load_key`.
- 확인한 것: 임시 서버 — 키 없음 → 머리줄 경고 · /version key:false, ⚙ 창에서 임시 .env(OTHER=1 · DART_API_KEY=40자) 경로 저장 → '✓ 키 확인 (40자)' · 앱 서버 다시 띄움 · /version key:true · 경고 사라짐 · 대시보드/앱 로그에 키 값 없음. parse 규칙 5가지 입력 확인. 페이지 오류 없음.
- 회사에서 확인할 것: 서버 PC 에서 대시보드를 열어(운영자) 재무스타그램 ⚙ → .env 경로 저장 → 삼성물산 검색.

### 2026-11-08 (APP_VERSION 2026-11-08.1 / SERVER_VERSION 그대로 2026-11-07.4) — 간략 메뉴(아이콘 막대) · 내 업무 접힘 = 헬멧 + 공
- 무엇을: 사용자 지시 '기존 UI/UX 로 돌아간다(유리 테마 시안은 넣지 않음) · 간소화 메뉴는 마우스를 올리거나 누르면 확장 · 숨기기 기능 유지 · 내 업무를 최소화하면 NFL 헬멧, 옆에서 공이 통통 튀고 마우스를 올리면 공만 회전'.
  - 간략 메뉴: 로고 아래 **[⇤ 간략]** → 왼쪽 메뉴가 72px 아이콘 막대(남색 그대로). 상위 메뉴마다 선 아이콘(`MENU_IC`), 지금 화면 = 파란 칸, 새 글 등 확인할 것 = 주황 점(`.mdot`), 아래 초록 점 = 서버 연결. **마우스를 올리면 240px 로 겹쳐 펼쳐짐**(본문은 안 밀림), **누르면(터치 포함) 펼친 채 유지**(`.peek`) → 메뉴를 고르거나 바깥을 누르면 다시 막대. **[⇥ 펼침]** = 원래 메뉴. 이 PC 에 기억(localStorage `dept-nav-rail`). 900px 이하 좁은 화면은 기존 동작. **◀ 숨기기 · ☰ 는 그대로**.
  - 내 업무 접힘: 남색 세로 탭 → **미식축구 헬멧**(직접 그린 일반 모양 — 실제 팀 로고 · NFL 표시는 넣지 않음, 은색 · 남색/빨강 줄 · 빨간 얼굴 보호대) + 왼쪽에서 **통통 튀는 공**(그림자 같이). **마우스를 올리면 공이 튀기를 멈추고 제자리 회전**. 아래 알약에 완료 수(0/13) · 접속자 · 새 쪽지. 누르면 펼침, 끌어서 옮기기 그대로. 움직임 줄이기 설정(prefers-reduced-motion)이면 멈춤.
- 바뀐 곳: dashboard.html `APP_VERSION` · `MI_P` `MENU_IC`(새) · `renderMenu`(btn 에 `.mic` · `data-tip` · `.mdot`) · `#sideRail` 단추 · `setNavRail`(새) · `#side` pointerdown/`#menu` click/document pointerdown(peek) · `TB_HELMET` `TB_BALL`(새) · `renderTaskBar`(접힘 탭) · CSS '간략 메뉴 · 헬멧' 묶음(`body.rail …` `#taskbar .helm …` `@keyframes fbBounce fbShadow fbSpin`). 주의: 메뉴 칸에 `.dot` 클래스를 쓰면 전역 `.dot{width:9px}` 와 부딪혀서 `.mdot` 사용.
- 확인한 것: 임시 서버 1500×950 — 간략 72px · 마우스 올림 240px · 펼침 단추로 되돌림, 아이콘 11개 가운데 정렬, 내 업무 접기 → 헬멧+공 · 마우스 올림 → 공 회전 · 누르면 다시 펼침. 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.2 / SERVER_VERSION 그대로 2026-11-07.4) — 홈 새 모습 (시안 1번 적용)
- 무엇을: 사용자가 시안을 보고 '적용' 지시. 홈 첫 화면에 계장 광장 · 최근 변경 이력 빼고 다 들어가게.
  - **톤**(`<style id="homeTone">`): 남보라 그라데이션 왼쪽 메뉴(둥근 떠 있는 판, 선택 = 흰 칸) · 흰 카드 radius 18 · 보라 강조(--accent #4f4ce0) · 숫자 카드 hover 떠오름 + › 칩. 숨기기는 여백까지 밀어 완전히 숨김, 900px 이하는 기존 서랍 메뉴.
  - **인사말** '좋은 아침이에요/오후예요/저녁이에요, 이름 님' + 이번 주 마감. **숫자 카드** 첫 칸(수행) 보라 채움, 수행 · 입찰 카드에 금주 작성률 막대(isDone/진행 PJT).
  - **[주간회의 전달사항 | 월간 캘린더]** 를 숫자 카드 바로 아래 한 줄(`.toprow`), 그 아래 그래프 4개 한 줄(캘린더 옆).
  - **전달사항 = Notion 페이지 느낌**(`<style id="homeNotion">`, `#npage`): 표지 띠 · 📌 · 경로 · 큰 제목 · 속성(회의일 요일 · 구분 태그 · 작성자 · 최종 수정) · 본문 전체(fmtText, 줄 hover 회색 + ⋮⋮) · 💡 이번 주 마감 · 이전 전달사항 3건(마우스 = 전체 내용 미리보기, 누르면 전달사항 메뉴) · [▾ 접기](localStorage `dept-notice-fold`, 접으면 제목 + 날짜 · 첫 줄). 카드 높이 = 화면의 약 30%(clamp 220~330px), 넘치면 안에서 스크롤.
  - **월간 캘린더**(`CAL` `calEvents` `renderCal` `CROWN`): 생일(BD 명단, 음력 → 양력) = 날짜 위 **왕관** · 매주 수 '마감' · 주간회의 전달사항 일자 · 통합 업무/To Do/기술공유 기한(지난 것 빨강). 날짜에 마우스 = 그날 일정 상세(data-tip), 누르면 아래 목록(업무 · 전달사항 줄 = 그 메뉴로). ‹ › 달 이동 · [오늘]. 공휴일은 자료가 없어 넣지 않음.
  - **막대 그래프 은은한 입체감**(`<script id="bar3d">`): svgBars 가 그린 rect.bar 에 좌→우 그라데이션(밝게 22% → 어둡게 20%) · 한 색 막대만 옅은 그림자 · 쌓은 막대는 틈 없이.
- 바뀐 곳: dashboard.html `APP_VERSION` · `renderHome`(hello · kpi hero/kbar · toprow · npage · 그래프 이동 · renderCal 호출) · `CAL` `CROWN` `calEvents` `CAL_K` `renderCal` `LS_NFOLD` `NFOLD`(새) · 문서 click(data-nfold) · CSS `homeNotion` `homeTone` 묶음 · `bar3d` 스크립트.
- 확인한 것: 임시 서버 1920×1080 · 1500×950 — 첫 화면에 게임 · 이력 빼고 다 보임, 캘린더 · 전달사항 · 입체 그래프 표시, 숨기기/☰/간략 메뉴 위치, 800px 폭 서랍 메뉴, 수행 · 유닛분장 · 게시판 화면 이동, 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.3 / SERVER_VERSION 그대로) — 홈 배치: 전달사항 가로 줄이고 그래프 키움
- 무엇을: 사용자 '주간전달사항이 너무 크다, 가로를 축소하고 다른 것들을 키워라'. 위 줄을 **[전달사항(.82fr) | 그래프 2×2(1.75fr) | 캘린더(23vw)]** 세 칸으로. 넓은 화면(1301px~)에서는 위 줄 높이 = 화면 높이 − 365px(440~780px)로 고정하고 세 칸 높이를 맞춤(전달사항 · 캘린더는 안에서 스크롤, 그래프 카드 2줄 균등). 1300px 이하는 [전달사항 | 캘린더] + 아래 그래프 2×2.
- 바뀐 곳: dashboard.html `APP_VERSION` · `renderHome`(`.tmid` 칸 추가, 그래프를 .tmid 로 옮김) · CSS `.toprow` `.tmid` `.npage` `.cd`.
- 확인한 것: 임시 서버 1920×1080 · 1500×950 — 계장 광장 · 이력 위까지 첫 화면에 들어옴, 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.4 / SERVER_VERSION 그대로) — 유닛분장 = 미식축구 팀 · 부서원 화면 머리 = 선수 화면
- 무엇을: 사용자 시안 확인 뒤 '전체 적용'.
  - **팀**: UNIT 1 = 🛡 수비 · UNIT 2 = 🏈 공격(유닛 제목 옆 표시). 유닛장 · 유닛원 모두 **패트리어츠 헬멧 그림**(사용자 제공, CSS `.oc-helmimg` 안 base64 PNG — file:// 사본에서도 보이게 파일로 떼지 않음) + **포지션 표시**(명단 순서: 수비 DE·DT·DT·DE·OLB·OLB·CB·CB·FS·SS / 공격 RB·WR·WR·TE·C·LG·RG·LT·RT·FB, 마우스 = 우리말 이름). 유닛장 = **MLB(수비의 쿼터백) / QB(쿼터백)** 금색 표시 + 통통 튀는 공(마우스 = 회전). 그룹장 = 감독 헤드셋(마이크). I&C ENG Group 은 그대로.
  - **부서원 화면(openProfile) 합침**: 팀 사람이면 머리 부분이 선수 화면 느낌(남색 · 사선 · 빨간 빛, 사진 위 헬멧 · 포지션 · 공, '공격 · UNIT 2 · QB = 쿼터백', 기울인 큰 이름) + 빨강 띠 'THIS WEEK · 이번 주 할 일 N건 · 마감'. 아래(동그라미 · 탭 · 카드 · 추가)는 그대로. 따로 만들었던 선수 화면 창은 넣지 않음.
  - 조직도 카드: 팀 사람은 **한 번 누름 = 0.28초 뒤 부서원 화면**(그 사이 두 번 누르면 바로 부서원 화면), 오른쪽 상세는 고정. 그 밖의 사람은 예전처럼(한 번 = 상세 고정, 두 번 = 부서원 화면).
- 바뀐 곳: dashboard.html `APP_VERSION` · `OC_TEAM` `OC_POSN` `OC_HEADSET` `ocGear`(새) · `orgHtml` 의 `card`(gear) · `unitBox`(tm · 포지션) · 범례 · `orgClick`(OC.gpT) · ondblclick · `openProfile`(머리 `.igh.team` · `.tm-week`) · CSS '유닛분장 = 미식축구 팀' · '부서원 화면 머리' 묶음.
- 확인한 것: 임시 서버 — 처음 화면 · 마우스 올림 미리보기 · 누름(부서원 화면 + 상세 고정) · 휠 확대 · 끌어서 이동/미니맵 · 전체 보기 · 두 번 누름 · 전체 화면 · 전체 화면에서 부서원 화면 · 세계 지도, 메뉴 27개 화면 캡처, 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.6 / SERVER_VERSION 그대로) — 일반업무 다시 통합 업무에 · 다크 모드
- 무엇을 ①: 사용자 '부서원 화면에서 To Do List · 기술공유 · 일반업무를 추가 · 수정하면 통합 업무에도 반영'. 부서원 화면의 추가 · 카드 편집은 원래 통합 업무(task 시트)와 같은 행을 씀 → To Do · 기술공유는 이미 반영. **일반업무**는 2026-11-04 에 통합 업무 메뉴에서 뺐던 것(TASK_HIDE)을 되돌려 다시 보이게 함(표준화 담당만 계속 뺌). 통합 업무 머리 설명 문구도 고침.
- 무엇을 ②: 사용자 '다크모드 반영'. 머리줄 **🌙 단추**(켜면 ☀️) · 이 PC 에 기억(localStorage `dept-dark`). 방식 = 화면 전체 `filter:invert(1) hue-rotate(180deg)`(색상은 유지, 밝기만 뒤집음) → 원래 어두운 곳(왼쪽 메뉴 · 부서원 화면 팀 머리 · 세계 지도 · 보라 카드 · 오늘 날짜) · 사진 · 헬멧 · 연결 도구 iframe · 계장 광장 게임 · 캔버스는 다시 뒤집어 원래대로. 창(dialog) · 전체 화면은 맨 위 층이라 따로 같은 반전.
- 바뀐 곳: dashboard.html `APP_VERSION` · `TASK_HIDE` · 통합 업무 머리 문구 · `#btnDark` · `setDark`(새) · CSS '다크 모드' 묶음.
- 확인한 것: 임시 서버 — 이영희 부서원 화면에서 To Do · 기술공유 · 일반업무 추가, To Do 수정 → 통합 업무 메뉴에 3건 모두 보임(수정 내용 포함). 다크 모드: 홈 · 수행 · 통합 업무 · 유닛분장 · 게시판 · Management · 세계 지도 · 부서원 화면 · 조직도 전체 화면, 스크롤해도 왼쪽 메뉴 고정, 페이지 오류 없음. 회사에서 확인할 것: 오래된 PC 에서 다크 모드 스크롤이 느리지 않은지.

### 2026-11-08 (APP_VERSION 2026-11-08.8 / SERVER_VERSION 그대로) — 세계 지도 = 3D 지구본(오픈소스) · 삼성물산 수주현황(재무스타그램)
- 무엇을 ①: 사용자 '웹에서 지도 오픈소스 찾아서 구글어스처럼 휠로 줌인/줌아웃, 상세 내용이 보이도록'. **globe.gl 2.34.1(MIT, three.js)** + **Natural Earth 국경(world-atlas 2.0.2 countries-50m)** + topojson-client + NASA Blue Marble 지구 그림을 `apps/globe/` 에 파일로 넣음(CDN 없음, 4.8MB). 유닛분장 [세계 지도] = 3D 지구본: 휠 = 확대/축소, 끌기 = 돌리기, ＋/－ · ⌖(처음 보기) 단추.
  - 가까이 갈수록 자세히(`glbLod`): 멀리(고도 >1.2) = 나라 이름표(국기 · PJT 수 · 현지 시각) · 중간 = PJT 점 + 이름(LE) · 가까이(<0.45) = 이름 + 마우스 · 선택 시 PJT 카드(수행/입찰 · 사업군 · 담당 · LE/RE · 금주 작성 · 업무 현황). PJT 있는 나라는 국경 색칠(수행 파랑 · 입찰 주황 · 둘 다 보라), 본사(한국) → 현장 움직이는 호. 나라 · PJT 를 누르면 그쪽으로 날아가고 오른쪽 목록(mapSide)이 그 나라로.
  - 라이브러리를 못 받으면(file:// 사본 · apps/globe 없음) 예전 평면 지도 그대로.
- 무엇을 ②: 사용자 '세계지도에서 삼성물산 재무스타그램 재무현황의 각 프로젝트 수주금액과 관련 정보를 불러와라'. 지도 도구줄 **[💰 삼성물산 수주현황]** → 재무스타그램 서버(8765) `/api/orders?corp_code=00149655`(DART 사업보고서 원문 '수주상황' 표 5년치) → 지구본에 금색 ◆(공사명 · 발주처 · 계약일 · 완공 · 도급액 · 잔액), 나라별 합계 띠, 오른쪽 나라 상세에 '삼성물산 수주현황' 상자. 우리 PJT 와 같은 나라 · 이름 단어가 겹치는 수주 건이 있으면 PJT 카드 · 목록에 **수주금액 · 잔액**(참고용 — 이름 맞추기라 틀릴 수 있음, 출처 공사명 표시). 처음에는 사업보고서를 받느라 1~2분.
- 바뀐 곳: dashboard.html `APP_VERSION` · `GLB` `ISO_N` `glbBase` `glbLoad` `glbLod` `glbFly` `glbSel` `glbEl` `glbLR` `globeMount` `glbResize` `ORD` `won` `ordLoad` `ordToks` `ordMatch` `ordCountry` `ordRow` `ordToggle` `ordPts`(새) · `orgBind`(지구본일 때 끌기/휠 넘김, 그린 뒤 globeMount) · `orgClick`(data-ord · 지구본 ＋/－/⌖) · 도구줄 · `mapSide`(수주 상자 · 수주금액) · fullscreenchange · CSS '세계 지도 3D 지구본' · '삼성물산 수주현황' / dashboard_tools/make_patch.py `KEEP_PREFIX`(apps/globe/) / 새 폴더 dashboard/apps/globe/.
- 확인한 것: 임시 서버(소프트웨어 WebGL) — 지구본 표시 · 휠 확대(2.1 → 1.7) · 나라 누름 → 날아감 · 가까이 PJT 카드(LE/RE · 금주 작성) · 오른쪽 목록, 수주현황은 **시험용 예시 자료(이름에 [예시])** 로 화면 확인(이 환경은 DART 접속 불가). 페이지 오류 없음. 회사에서 확인할 것: 회사 PC 그래픽에서 지구본이 부드러운지, 재무스타그램 키 설정 뒤 [💰 삼성물산 수주현황] 실제 자료.

### 2026-11-08 (APP_VERSION 2026-11-08.10 / SERVER_VERSION 그대로) — 왼쪽 계정 사진 · 프로젝트별 LE/RE 헬멧
- 무엇을: 사용자 '왼쪽에 사진 동그랗게' → 왼쪽 메뉴 계정 줄(이름 왼쪽)에 동그란 사진(내 정보 사진, 없으면 이름 첫 글자 · 인스타 테두리), 간략 메뉴 막대일 때는 숨김. '프로젝트별 LE, RE 도 헬멧' → 유닛분장 [프로젝트별 LE·RE] 카드에도 헬멧 + 역할 표시(LE = 빨강 · 금색 표시 + 통통 튀는 공 / RE = 남색), 마우스 = 'PJT 리드/담당 엔지니어'.
- 바뀐 곳: dashboard.html `APP_VERSION` · 계정 단추(`#acctAv` · `.atx`) · `renderMenu`(사진) · `projTreeHtml`(ocGear) · CSS '왼쪽 계정 줄 동그란 사진'.
- 확인한 것: 임시 서버 — 계정 사진 표시, 프로젝트별 카드 10장 헬멧 · LE/RE, 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.11 / SERVER_VERSION 그대로) — 웹 대시보드 관례 반영 (검색 검토)
- 무엇을: 사용자 '핀터레스트 · 웹 · GitHub 를 검토해서 개선할 것이 있으면'. 웹 자료(대시보드 UX 가이드 · Tabler/AdminLTE 등)에서 공통으로 권하는 것 중 우리에게 없던 것만:
  ① **키보드 단축키**: `/` = 찾기(Ctrl+K 와 같음), `g` 다음 글자 = 메뉴 이동(h 홈 · p 수행 · b 입찰 · t 통합 업무 · u 유닛분장 · n 전달사항 · r R&R · f 재무스타그램 · g 게시판), `?` = 단축키 도움말. 글 쓰는 칸 · 창이 열려 있으면 무시, 권한 없는 메뉴로는 안 감.
  ② **빈 화면에 할 일 하나**: 표에 행이 없으면 [＋ 첫 행 추가] 단추 + '필터를 걸었다면 [필터 초기화]' 안내 (편집 가능할 때만).
  ③ **홈 '나에게 필요한 것 먼저' 한 줄**: 인사말 아래 '○○ 님 이번 주 할 일 N건 — 업무 현황 미작성 PJT a · 업무 알림 b [목록 보기]' (내 업무 myTasks 기준), 다 했으면 '✅ 모두 마쳤습니다'.
  ④ **접근성**: 키보드로 움직일 때 초점 테두리(:focus-visible), 윈도 '애니메이션 끄기' 설정이면 모든 움직임 멈춤(prefers-reduced-motion).
- 바뀐 곳: dashboard.html `APP_VERSION` · `tableHtml`(빈 화면) · `KEYNAV` · 문서 keydown/click · `renderHome`(myline) · CSS '웹 대시보드 관례 반영'.
- 확인한 것: 임시 서버 — g→p #perform · g→u #unit · ? 도움말 · 프로젝트 이슈사항 빈 화면 단추 · 홈 한 줄(13건 = 미작성 PJT 5 · 알림 8), 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.12 / SERVER_VERSION 그대로) — 단추 · 아이콘 입체감
- 무엇을: 사용자 '모든 아이콘들에 입체감을 조금'. 단추(.btn · 주요 단추) · 배지 · 달력 · 지도 ＋/－ · 떠 있는 단추 · 메뉴 번호 칸 · 숫자 카드 › · 부서원 화면 동그라미 아이콘에 위쪽 밝은 테두리(inset) + 아래 그림자 + 은은한 세로 그라데이션, 마우스 = 1px 떠오름, 누름 = 들어감. 메뉴 · 동그라미 안 그림 아이콘은 아래 그림자(drop-shadow).
- 바뀐 곳: dashboard.html `APP_VERSION` · CSS '단추 · 아이콘 입체감' 묶음.
- 확인한 것: 임시 서버 — 홈 머리줄 · 배지 · 숫자 카드, 부서원 화면 동그라미 아이콘, 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.13 / SERVER_VERSION 그대로) — 홈 그래프가 카드를 꽉 채움
- 무엇을: 사용자 '그래프에 여백이 너무 많다, 80% 는 차도록'. 원인 = svgBars 가 고정 크기(520×230) 그림을 카드 폭에 맞춰 줄여서 위아래가 비었음. → `svgBars` 에 W·H(그릴 칸 실제 px) 옵션: 세로 막대 = 칸 높이만큼, 가로 막대 = 줄 높이를 칸 높이 ÷ 줄 수(16~40px) · 막대 두께 64%. 홈을 그린 뒤 `homeFit` 이 각 카드의 남는 칸을 재서 다시 그림(창 크기 바뀌면 다시). 도넛은 범례를 뺀 공간에 맞춰 크기 키움.
- 바뀐 곳: dashboard.html `APP_VERSION` · `svgBars`(W·H) · `HOMEFIT` `homeFit`(새) · `renderHome`(homeFit 호출) · CSS '홈 그래프 카드 꽉 채움'.
- 확인한 것: 임시 서버 1920×1080 · 1500×950 — 그래프 4개가 카드를 채움, 마우스 상세 · 입체감 유지, 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.14 / SERVER_VERSION 그대로) — 그래프 색 조화 · 입체감 더
- 무엇을: 사용자 '그래프 색을 조화롭게, 입체감을 조금 더'. 남보라 톤에 맞춰 수행 = 인디고 #5b63e8 · 입찰 = 앰버 #f2994a, 공용 팔레트(PALETTE)도 같은 결(청록 · 핑크 · 하늘 · 보라 …). 막대 그라데이션 5단(밝게 42% → 어둡게 32%) · 그림자 진하게(0 3px 3px), 쌓은 막대는 묶음 전체에 그림자, 도넛 = 빛 반사 링 + 가운데 흰 원 그림자. 세로 막대 왼쪽 여백(기울인 이름이 잘리지 않게).
- 바뀐 곳: dashboard.html `APP_VERSION` · `PALETTE` · `PJ_COL` · `svgBars`(LP) · `svgDonut`(dnHL) · `bar3d` 스크립트 · CSS '그래프 입체감 더'.
- 확인한 것: 임시 서버 1920×1080 — 그래프 4개 색 · 입체감 · 이름 잘림 없음, 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.15 / SERVER_VERSION 그대로) — 인사말이 계절 · 요일 · 시간대마다 바뀜
- 무엇을: 사용자 '인사말은 계절 요일마다 랜덤으로'. 시간대 인사(아침 5시~ · 점심 11시~ · 오후 14시~ · 저녁 18시~ · 늦은 시간 22시~) + 덧말 1개 = 날마다 요일 문장(월 '한 주의 시작' · 수 '오늘 11:59 마감' · 금 '불금' …) 또는 계절 문장(봄 · 여름 · 가을 · 겨울 각 3개) 중 무작위. 같은 날 같은 사람에게는 같은 문장(날짜 + 이름으로 고름 — 새로 고칠 때마다 바뀌지 않게), 다음 날 바뀜.
- 바뀐 곳: dashboard.html `APP_VERSION` · `GREET` `greetLine`(새) · `renderHome`(hello) · CSS `.hello h3 .gx`.
- 확인한 것: 임시 서버에서 시계를 바꿔(월 아침 · 수 아침 · 여름 금 오후 · 겨울 수 저녁 · 봄 화 점심) 5가지 다른 인사 확인, 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.16 / SERVER_VERSION 그대로) — 클로드 비서 (돌아다니는 캐릭터 + 작은 챗봇)
- 무엇을: 사용자 '기능은 그대로, 클로드 캐릭터가 화면을 자유롭게 돌아다니고, 누르면 물음표와 함께 작은 챗봇 — VOC 와 대시보드 모든 내용을 알고, 물어보면 설명하고 바로 이동하는 비서'.
  - 캐릭터: 직접 그린 주황 둥근 캐릭터(반짝이 · 눈 깜빡임 · 걷기 흔들림, 회사 로고 아님). 6~12초마다 화면 안 아무 곳으로 3초 걸어감, 마우스를 올리거나 창이 열려 있으면 멈춤, '움직임 줄이기' 설정이면 안 움직임. 마우스 = '?' 와 이름표, 누르면 '?' 튀어나오며 챗봇 창.
  - 챗봇(외부 AI · 인터넷 안 씀 — 사내 자료 밖으로 안 나감): ① `BOT_FAQ` 자주 묻는 것(마감 · 내 할 일 · 재무스타그램 · 세계 지도 · 유닛분장 · VOC · 다크 모드 · 단축키 · 메뉴 숨기기 · 캘린더/생일 · 전달사항 · 출장 시 서버 옮기기 · 인사) → 설명 + 단추(목록 창 · 메뉴 이동 · VOC 쓰기 …) ② 질문 단어로 빠른 찾기(qfSearch: 모든 시트 행 · 메뉴 · 게시판/VOC 글)를 돌려 최대 6건 → [바로 이동 ›](그 행 · 칸으로 이동 · 노란 표시). 처음 열면 예시 질문 단추 3개.
  - 숨기기: 창의 [숨기기] → 캐릭터 숨김(이 PC 기억), 머리줄 🤖 단추로 다시. Esc = 창 닫기. 인쇄에는 안 나옴.
- 바뀐 곳: dashboard.html `APP_VERSION` · `BOT` `BOT_SVG` `BOT_STOP` `BOT_FAQ` `botWords` `botAnswer` `botSay` `botToggle` `botAsk` `botDock` `botWander` `botInit`(새) · `render`(botInit) · CSS '클로드 비서'.
- 확인한 것: 임시 서버 — 캐릭터가 9초 사이 (1424,737) → (1132,259) 이동, 누르면 챗봇, '카타르 LNG' · '내 할 일' · '재무스타그램 어디' · '박민수' 답 + 바로 이동(#perform), 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.17 / SERVER_VERSION 그대로) — 클로드 비서: 픽셀 캐릭터 · 공 놀이 · 가장자리 순찰 · 찾기/VOC 단추
- 무엇을: 사용자가 보낸 픽셀 캐릭터 그림(주황 네모 몸 · 양팔 · 다리 4개) 결로 다시 그림(`botSvg`, 표정 7가지 `BOT_FACES`: 보통 · >< · 웃음 · 놀람 · 윙크 · 어질 · 하트). 'NFL 공을 가지고 놀면서 다양한 표정으로, 화면 맨 위 · 아래 · 왼쪽 · 오른쪽 위주로 왔다 갔다' → `botWander` 가 네 가장자리 중 하나의 무작위 지점으로 걸어감(거리에 맞춰 1.5~6초, 다리 번갈아 · 통통), 걷는 동안 공 드리블, 도착하면 공 저글링(머리 위로 튀김 · 회전) / 차기 / 쉬기 + 표정 바꿈. 누르면 놀란 표정 + '?'.
- '찾기 · VOC 등록 기능도' → 챗봇 창 위 단추 줄 [🔍 찾기](빠른 찾기 창) · [📣 VOC 등록](스크린 → VOC) · [📋 내 할 일] · [💬 VOC 목록], 질문 '찾기' · 'VOC 등록' 도 알아들음.
- 바뀐 곳: dashboard.html `APP_VERSION` · `BOT_FACES` `botSvg` `botFace`(새) · `botWander`(가장자리 · 공 놀이) · `botInit`(공 · 단추 줄) · `BOT_FAQ`(찾기 · VOC 등록) · CSS '클로드 비서'(다시 씀) · `window.__dashBot`(점검용).
- 확인한 것: 임시 서버 — 27초 동안 (940,6) 위 → (6,301) 왼쪽 → (789,870) 아래 … 가장자리 이동, 표정 7가지 · 저글/차기/드리블, 'VOC 등록' 답 · [🔍 찾기] → 찾기 창 열림, 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.18 / SERVER_VERSION 그대로) — 클로드 비서 패트리어츠 헬멧
- 무엇을: 사용자 '클로드 비서에 Patriot 헬멧'. 캐릭터 머리 위에 유닛분장과 같은 패트리어츠 헬멧 그림(`.oc-helmimg`)을 얹음 — 눈(표정)은 가리지 않게 몸 위쪽에만. 챗봇 창 머리의 작은 얼굴에도.
- 바뀐 곳: dashboard.html `APP_VERSION` · `botInit`(bhelm) · CSS '클로드 비서 패트리어츠 헬멧'.
- 확인한 것: 임시 서버 — 표정 7가지 + 저글/차기/드리블에서 헬멧 표시 · 표정 보임, 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.19 / SERVER_VERSION 그대로) — 클로드 비서가 대시보드 전체를 앎
- 무엇을: 사용자 '클로드 비서는 모든 내용을 학습해라'. 물을 때마다 `botIndex` 가 대시보드 전체를 색인: 메뉴 · 기능 설명(`MENU_HELP`) · 모든 시트 행의 모든 칸 · 게시판/VOC 글과 댓글(익명 작성자는 밝히지 않음) · 부서원(유닛 · 직책 · 담당 · 전화) · 프로젝트별 LE/RE · 생일. 질문 단어마다 점수(제목 3 · 내용 1)로 순위.
  - 사람 이름을 물으면 **사람 요약**(생일 · 유닛 · 담당 · 전화 · 담당 PJT · LE/RE · 진행 업무 수 + 부서원 화면 · PJT 바로가기), PJT 이름이면 **PJT 요약**(수행/입찰 · 사업군 · 담당 · 나라 현지 시각 · LE/RE · 금주 작성 · 업무 현황 2줄 + 표 · LE/RE 바로가기), '몇 개' 질문이면 **숫자**(수행 · 입찰 · 부서원 · VOC · 업무). 외부 AI · 인터넷 안 씀.
- 바뀐 곳: dashboard.html `APP_VERSION` · `MENU_HELP` `bTxt` `botIndex` `botRun` `botPerson` `botPjt` `botCount`(새) · `botAnswer`(다시 씀) · `BOT_STOP`(누가 · 몇 · 무슨 …).
- 확인한 것: 임시 서버 — '카타르 LNG 누가 해?' → LE 홍길동 50% · RE 김철수 40% · 이영희 10% · 금주 미작성, '박민수' → 생일 · 담당 · 전화 · PJT 2 · LE/RE 3, '수행 PJT 몇 개' → 18개, '판넬 VOC' → VOC 글, '이영희 생일' → 음력 9/20, 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.20 / SERVER_VERSION 그대로) — 클로드 비서에게 수정 요청 → 미리보기 → 적용 → 결과 화면
- 무엇을: 사용자 '저기에 수정 요청하면 클로드 비서가 수정하고 수정 화면 결과를 보여 주는 기능'. `botEdit` 가 요청 문장을 알아듣고 **바뀌는 내용(지금 / 바꾼 뒤)을 먼저 보여 준 뒤** [✔ 적용] 을 눌러야 저장(실수 방지, 한 번 누르면 단추 잠김) → 저장 · 다시 읽기 · **그 행 · 칸으로 이동해 노란 표시** · 챗봇에 '저장된 내용' 표시.
  - "<PJT> 업무 현황에 <내용> 추가"(맨 아래 '- 내용' 한 줄) · "<PJT> 업무 현황 <내용> 으로 수정"(통째로) · "<PJT> 변경 없음"(이번 주 변경 없음 기록) · "To Do 추가 <내용>"(담당 = 나 / '박민수 To Do 추가 …' = 그 사람, 통합 업무 맨 위) · "<업무 제목> 종결".
  - 저장은 일반 편집과 같은 `saveEdit` · `createRecord`(서버 권한 · 이력 · 충돌 확인 그대로). 비회원 · 지난 주 마감본 보기 · 권한 없음이면 고치지 않고 안내. '고치는 방법' 을 물으면 예시 안내.
- 바뀐 곳: dashboard.html `APP_VERSION` · `botPjtFind` `botTaskFind` `botEdit`(새) · `botAnswer`(먼저 botEdit) · `botSay`(적용 단추 한 번만) · `botAsk` · `BOT_FAQ`(고치는 방법) · CSS `.bdiff`.
- 확인한 것: 임시 서버 — '카타르 Ras Laffan 업무 현황에 11/8 도면 승인 완료 추가' → 미리보기 → 적용 → 수행 표 그 칸 노란 표시 · 저장 내용 일치, 'To Do 추가 HAZOP 자료 정리' → 통합 업무에 추가 · 이동, '카타르 NFE 변경 없음' → 기록, 'HAZOP 후속 조치 종결' → 미리보기, 페이지 오류 없음 (시험 자료는 시험 뒤 되돌림).

### 2026-11-08 (APP_VERSION 2026-11-08.21~23 / SERVER_VERSION 그대로) — 클로드 비서 전권(메뉴 권한 따름) · 계측제어 전문 지식 · 분석 메뉴 연결 · 파일 끌어놓기
- 무엇을: 사용자 '대시보드 모든 메뉴 읽기 · 쓰기 전권을 비서에게, 단 메뉴 권한이 막히면 권한 없다고', '계장 item 웹 내용을 학습해 답하게 · 계측제어 초전문가', '모든 분석 결과 접근 — Valve Datasheet 결과 엑셀 출력 · 요약, Panel 결과 CAD 출력, Equipment List 를 끌어다 놓고 새 프로젝트/룸/revision 생성'.
  - 전권(.21): `botGeneral` — 게시판 · VOC 글 쓰기, 댓글, 아무 시트 아무 칸 "… <칸> <값> 으로 수정" · "<칸> 에 … 추가", "<시트> 추가: 칸=값, …" 행 추가, 삭제(휴지통, 확인), "<행> 상세 보여줘". 모두 미리보기 → [✔ 적용] → 저장(saveEdit/createRecord, 서버 권한 · 이력 그대로). 모든 동작이 `can(menuOf(key))` 확인 → 없으면 "🔒 <메뉴> 메뉴 권한이 없어서 할 수 없어요". `botIndex` 도 권한 없는 시트 · 게시판은 색인하지 않음(답에 안 나옴).
  - 계측제어(.22): `ICKB` 약 50 항목(ISA 5.1 태그 · 4-20 mA/HART/FF/Modbus/OPC UA · 압력 · 온도 · 유량(오리피스 ISO 5167 · 마그 · 코리올리 · 와류 · 초음파) · 레벨 · 조절 밸브 IEC 60534 · 누설 등급 · PSV API 520/521/526 · ESD 밸브 · 분석기 · F&G · DCS · SIS IEC 61511 · SIL/LOPA · PLC · 압축기 제어 · API 670 · BMS · 방폭 IEC 60079 · IP · 케이블 · JB · 인스트루먼트 인덱스 · 데이터시트 · 루프도 · C&E · FAT/SAT · 교정 · PID 튜닝 · 경보 관리 ISA 18.2 · 계장 공기 · NE107 · 무선 · CO2 · 수소/암모니아 · LNG) + `isaDecode`(태그 풀이 "PDIC-101") + `icAnswer`. **실행 중 인터넷 검색은 하지 않음**(회사 PC 외부 접속 금지) — 공개 표준 · 실무 지식을 파일 안에 넣음. 대시보드 PJT · 사람이 콕 집히면 그쪽이 먼저(예: '카타르 LNG' = PJT 요약, 지식은 단추로).
  - 분석 메뉴(.23): `BOT_APPS` · `BOT_ACT` · `botApp` · `botBridge` · `botAppRun` · `botAppFallback` — 메뉴를 열고 iframe 에 `postMessage` 명령(dash-bot v1, **`BOT_BRIDGE.md`**). 앱이 export 를 못 하면 결과 표/도형을 받아 대시보드가 직접 .xlsx(`buildXlsx`) · .csv · .dxf(`botDxf`, R12) 를 만듦. 생성은 미리보기 → [✔ 생성 실행].
  - 시트 출력(.23): `botSheetOut` — "수행 PJT 요약"(행 수 · 담당별 · 금주 미작성 · 최근 수정), "입찰 엑셀로 출력".
  - 파일(.23): 비서 창(또는 캐릭터)에 끌어다 놓기 · 📎 → `botAddFiles`, .xlsx 는 브라우저 안에서 첫 시트 미리보기(`botXlsxPeek`, 내장 DecompressionStream), .csv 도. 다음 명령에 같이 보냄.
- 바뀐 곳: dashboard.html `APP_VERSION` · `botGeneral` `botDeny` `ICKB` `isaDecode` `icAnswer` `BOT_APPS` `BOT_ACT` `botApp` `botBridge` `botFrame` `botAppRun` `botAppFallback` `botDxf` `botTableXlsx` `botTableSum` `botSheetOut` `botXlsxPeek` `botAddFiles` `botFileChip`(새) · `botAnswer` `botAsk`(run) `botInit`(📎 · 끌어놓기) `botIndex`(권한) `BOT_FAQ`(도움말) · CSS. 새 문서 `BOT_BRIDGE.md`.
- 확인한 것: 임시 서버 + 약속을 받는 가짜 앱(/space · /valve) — 'PDIC-101' 태그 풀이, '오리피스 직관 길이' · 'SIL2 PFD' · '방폭 IIC' · 'PSV 사이징' 답, '카타르 LNG' = PJT 요약, '수행 PJT 요약' · 엑셀, 'Valve Datasheet 결과 엑셀' → 가짜 앱 표로 .xlsx(열림 확인), 'Ball Valve 결과 요약' → 앱 요약 글, 'Panel 결과 CAD' → .dxf, Equipment_List.xlsx 끌어놓기 → 미리보기 4행, '"CO2 PJT" 프로젝트 "MCC" 룸 "A" revision 으로 생성' → 미리보기 → 실행 → 앱이 project/room/revision + 파일(1067B) 받음. 권한 막은 부서원(LAN 접속) → Panel · Valve 🔒. 페이지 오류 없음.
- 회사에서 확인할 것: **ROOM SIZE 계산 · Valve Datasheet 등 실제 앱은 아직 dash-bot 을 받지 않음** → '2. PID 코드' 세션에서 `BOT_BRIDGE.md` 대로 받기 코드를 넣어야 실제 생성 · 내보내기가 됨(그 전에는 비서가 화면만 열고 안내). 회사 Chrome/Edge 에서 .xlsx 미리보기(DecompressionStream) 동작.

### 2026-11-08 (APP_VERSION 2026-11-08.24 / SERVER_VERSION 그대로) — 클로드 비서 첨삭(한국어 · 영어, 규칙 기반)
- 무엇을: 사용자 '한국어 · 영어 학습 기반 번역과 첨삭 기능, 이미지 속 영어 번역' 중 **첨삭**을 먼저 넣음. "첨삭: <글>"(교정 · 맞춤법 · proofread 도 됨) → 고친 글(지운 곳 빨강 · 넣은 곳 초록)과 '고친 것' · '검토해 보세요' 목록, [📋 고친 글 복사].
  - 한국어 `KO_FIX`: 맞춤법 · 띄어쓰기(되요/됬/몇일/할수/부탁 드립니다 …) 자동, 번역투 · AI 티(이중 피동 '~되어진다', '~에 있어서', '~와 관련하여', '~에 기반하여', 이중 완곡, '~다는 것이다', 연결어미 뒤 쉼표)는 확실한 것만 자동 · 나머지('가지고 있다', '~에 의해', 분열문, 결산 표현, '~를 통해' 3회+, '~할 수 있다' 4회+, 문장 길이 균일, 종결어미 단조 …)는 검토 표시만. 규칙 출처: 사용자가 참조하라 한 공개 룰북 **epoko77-ai/im-not-ai 'AI 티 분류 체계' quick 규칙(MIT)** — 규칙 내용만 옮겨 적음(코드 · 외부 호출 없음).
  - 영어 `EN_FIX`: 흔한 오타(recieve · seperate · untill …), 불가산(equipments · informations · datas), 관사 a/an, 같은 낱말 반복, 첫 글자 · 요일 대문자, 군더더기(in order to · due to the fact that · please kindly), between A and B, 범위 단위(4–20 mA); 사양서 관례(shall/should/must, 'as per', 수동태 잦음, 35단어 넘는 문장)는 검토 표시. `PROOF_TERMS` 계장 용어 표기 통일(P&ID · HAZOP · SIL 2 · 4–20 mA · °C · junction box).
  - 뜻 · 숫자 · 고유명사는 건드리지 않음(규칙에 없는 것은 그대로). 외부 AI · 인터넷 안 씀.
- 바뀐 곳: dashboard.html `APP_VERSION` · `KO_FIX` `EN_FIX` `KO_HINTS` `EN_HINTS` `PROOF_TERMS` `proofRead` `proofDiffHtml` `botProof`(새) · `botAnswer`(먼저 botProof) · `BOT_FAQ`(도움말) · CSS `.bproof` `.bplist`.
- 확인한 것: node 단위 시험 + 임시 서버 — 한국어 예문 고침 8곳(되요→돼요 · 몇일→며칠 · 보고 드립니다→보고드립니다 · 검토되어진다→검토된다 · 에 있어서→에서 …) · 검토 2건, 영어 예문 고침 9곳(equipments→equipment · a informations→information · the the → the · untill→until · friday→Friday · 4 to 20 mA→4–20 mA …) · 검토(should→shall) 1건, 바를 글은 '고칠 곳 없음'. 페이지 오류 없음.
- 아직 안 넣은 것(사용자 결정 대기): **학습 모델 번역(한↔영)** — Mozilla Firefox 번역 모델(공개, ko-en · en-ko 각 약 37MB)과 엔진 `fxtranslate`(MPL-2.0, 0.4MB, WebAssembly)를 `apps/translate/` 에 넣으면 회사 PC 안에서 동작. 외부 라이브러리 예외 추가 승인 + 이 세션에서 시험 실행 허용이 필요. **이미지 속 영어 번역** — OCR `tesseract.js`(Apache-2.0, 영어 학습 데이터 약 10MB) 같은 방식. 참조 요청 중 k-skill(한국 공공 서비스 호출 — 인터넷 필요)은 폐쇄망에서 못 씀, news.hada.io 는 이 환경에서 접속 불가.

### 2026-11-08 (APP_VERSION 2026-11-08.25 / SERVER_VERSION 그대로) — 첨삭 보강 (korean-skills 룰북 참고)
- 무엇을: 사용자가 참조하라 한 **DaleSeo/korean-skills(MIT)** 의 grammar-checker · humanizer · style-guide 규칙을 첨삭에 보탬(내용만 옮김, 코드 · 외부 호출 없음).
  - `koJosa`: 조사 받침 맞추기 — 받침 있는 낱말 뒤 '를 · 가 · 와 · 는' → '을 · 이 · 과 · 은', 받침 없는 낱말 뒤 '으로' → '로' **만**(반대 방향은 '마을 · 나이 · 효과 · 더 나은' 처럼 낱말 일부일 수 있어 손대지 않음, 동사 어간 + '는' 보존).
  - `KO_FIX2`: 안/않('않 해요' · '~지 안았다'), -읍니다→-습니다, 형용사+'-ㄴ지'('좋는지'), 던/든, 의존명사('하는것' · '할만큼' · '할줄'), 부사 띄어쓰기('매우좋다' · '더나은' · '하기위해'), 영어식 쉼표(조사 뒤 · '만약 ~면,' · 'A, B, 그리고 C'), 느낌표 · 물음표 겹침, 영어식 콜론('다음과 같습니다:'), 따옴표 짝, 마침표 누락, 숫자+한글 단위 붙임('5 명'→'5명'), 숫자+영문 단위 띄움('5kg'→'5 kg', % · ℃ 제외), 날짜 점 표기 공백.
  - `KO_HINTS2`(검토만): 경어체 혼용(합니다 · 해요 · 한다), 저희/우리, 격식 문장의 구어, 쉼표 과다(문장 60%+, KatFishNet), 느낌표 잦음, 숫자 · 날짜 · 시간 · 단위 형식 혼용, 대명사 · 지시어 잦음, 과장 어휘, '~적 N', '~것이다' 3회+, 영문 용어 단순 나열의 가운뎃점.
- 바뀐 곳: dashboard.html `APP_VERSION` · `hasBatchim` `endsRieul` `koJosa` `KO_FIX2` `KO_HINTS2`(새) · `proofRead`(합침, 조사는 맨 뒤에).
- 확인한 것: node 단위 시험 — '더나은 … 제공하기위해 시작되요. 판넬를 설치했읍니다. 하지 안았습니다. 다음과 같습니다: … 5 명이' → 모두 고침, '마을 · 나이 · 효과를 · 먹는 것 · 이것은' 은 그대로(오탐 없음), '일정가' → '일정이', '회의으로' → '회의로'. 임시 서버 화면 확인, 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.26~28 / SERVER_VERSION 그대로) — 클로드 비서 번역(한↔영) · 그림 속 영어 읽기 → 번역 (apps/translate/, 사용자 허락)
- 무엇을: 사용자 '한국어 · 영어 학습 기반 번역 · 이미지 속 영어 번역'. 외부 라이브러리 예외 + 시험 실행을 사용자가 허락("둘 다 허락")해 `apps/translate/` 를 새로 둠(CLAUDE.md 예외 기록).
  - 번역: Mozilla **Firefox 번역 모델**(공개, ko-en · en-ko base-memory, 각 약 37MB .gz) + 엔진 **fxtranslate 0.5.0** wasm(MPL-2.0). 대시보드가 Web Worker(`translate-worker.js`)를 띄워 **브라우저 안에서** 번역 — 글은 서버 · 인터넷으로 가지 않음. 처음 한 번 모델을 서버에서 받음(진행률 표시, 이후 브라우저 캐시).
  - 명령: "번역: …"(방향 자동) · "영어로: …" · "한국어로: …" · "… 번역해줘" · 40자 넘는 영어 글을 그냥 붙여 넣으면 [🌐 한국어로 번역] 단추. 결과 = 번역문 · [원문 보기] · [📋 복사] · (한→영이면) [✍ 영문 첨삭]. `TR_GLOSS` 계장 용어집으로 결과 바로잡음(제어 밸브→조절 밸브, 송신기→전송기, 공급 업체→벤더, 원인과 결과 다이어그램→C&E 도, regulating valve→control valve …).
  - 그림: 비서 창에 그림(png · jpg …)을 끌어다 놓거나 **붙여 넣기(Ctrl+V)** → **tesseract.js 7**(Apache-2.0, eng 학습 데이터, 브라우저 안 wasm)로 영어 글자 읽기 → 읽은 글(정확도 %) → 자동으로 한국어 번역. SIMD 되는 브라우저면 simd 코어.
  - 없을 때: 파일이 서버에 없으면 "apps\translate\ 필요" 안내, file:// 사본이면 "서버 주소로 연 대시보드에서만" 안내.
- 바뀐 곳: dashboard.html `APP_VERSION` · `TR` `TR_BASE` `trAvail` `trWorker` `trCall` `TR_GLOSS` `trGloss` `trDir` `botTranslate` `botTrCmd` `wasmSimd` `ocrWorker` `botImage`(새) · `botSay`(요소 반환) `botActs`(새) · `botAnswer`(botTrCmd) · `botAddFiles`(그림 분기) · `botInit`(paste) · `BOT_FAQ`(도움말) · CSS. 새 폴더 `apps/translate/`(README.txt · 라이선스 파일 포함, 약 83MB). make_patch `KEEP_PREFIX` + 'apps/translate/'. CLAUDE.md 예외.
- 확인한 것: node 에서 모델 직접 시험 — "The control valve shall fail closed on loss of instrument air." → 한국어, "이번 주 카타르 LNG 프로젝트 도면 승인이 완료되었습니다." → "This week, the Qatar LNG project drawing approval has been completed." (문장당 0.15~0.4초). 임시 서버 브라우저 시험(.28) — '번역: The control valve shall fail closed …' → '조절 밸브는 계장 공기(Instrument Air) 상실 시 닫힘 고장(Fail Close) 이어야 합니다. 벤더(공급사)는 ESD 시스템에 대한 Cause & Effect 도(C&E)을 제공해야 합니다.'(첫 번역 1.8초, 모델 받기 포함), '영어로: 이번 주 카타르 LNG …' → 'This week, the Qatar LNG project drawing approval has been completed. After reviewing the panel layout drawing, the aisle is lacking in width.', 긴 영어 글 붙여넣기 → [🌐 한국어로 번역] 단추, 데이터시트 캡처 그림 끌어놓기 → 글자 읽기 → '태그 번호: FCV-2001A 크기: 6 인치 압력 등급(Rating): 600# / 밸브는 … 닫힘 고장(Fail Close) 이어야 합니다. / 액추에이터: 공압 다이어프램, 스프링 리턴.'(2초). 페이지 오류 없음. 서버가 HEAD 를 안 받아 GET 으로 확인(.27), 용어집 보강(.28).
- 회사에서 확인할 것: 회사 Chrome/Edge 에서 첫 모델 받기 시간(LAN, 약 40MB) · 메모리(탭당 약 200~300MB) · 그림 글자 읽기 정확도(캡처 글자가 작으면 낮음). 기계 번역이므로 사양서 숫자 · 전문 용어는 사람이 확인.

### 2026-11-08 (APP_VERSION 2026-11-08.29 / SERVER_VERSION 2026-11-08.1) — 클로드 비서 '바이브'(운영자 권한) · 진행 현황 · 새창 · 최대화
- 무엇을: 사용자 '권한만 운영자로부터 받으면 대시보드 모든 기능을 비서에게 바이브로 시킬 수 있어야 하고, 진행 현황을 새창 또는 채팅창에 보여 줘야 한다. 비서 채팅은 새창 · 최대화도.'
  - **권한**: server.py `MENUS` 에 `('bot', '비서 바이브')` 추가(메뉴는 아니고 권한 키, 기본 없음 — `DEFAULT_PERMS`). 운영자의 ⚙ 메뉴 권한 설정 표에 '비서 바이브' 열이 생김(화면은 서버 MENUS 를 그대로 그리므로 자동). 운영자 · 그룹장은 기본으로 됨(`MGR()`). 화면 `can('bot')` 기본 false.
  - **바이브**(`botVibe` · `botVibeRun` · `botSteps` · `botRunStep`): 권한 있으면 미리보기를 보여 주되 [✔ 적용] 없이 바로 실행("⚡ 바이브: 자동 실행"). 줄바꿈 · '그리고' · '그 다음' · '이어서' · ';' 로 이어 적은 여러 일은 차례로 실행하고 **진행 현황 카드**(단계별 ⏳ → ✅ / ⚠ 권한 없음 / ❌) 를 채팅창에 올림. 권한 없는 사람이 여러 일을 한 번에 시키면 "운영자가 비서 바이브 권한을 켜 줘야" 안내, 하나씩은 예전처럼 미리보기 → [✔ 적용].
  - **새창**(머리줄 ↗): `?bot=1` 로 대시보드를 새창에 띄우되 비서만 보임(`BOT_ONLY`, body.botonly — 메뉴 · 본문 · 캐릭터 · 팝업 숨김). 새창 비서가 시키는 이동(`go` · `jumpTo`)은 `postMessage`(같은 origin)로 **원래 창**이 움직임(`botRelay`). 팝업 차단이면 안내.
  - **최대화**(머리줄 ⛶): 창 가득(`#botPanel.max`), 다시 누르면 원래 크기 · 위치.
- 바뀐 곳: dashboard.html `APP_VERSION` · `botVibe` `botSteps` `botRunStep` `botVibeRun` `BOT_ONLY` `botOpenWindow` `botRelay`(새) · `botAsk`(바이브 분기) · `can`('bot' 기본 false) · `botInit`(↗ ⛶ 단추 · botonly) · `botDock`(max 면 건너뜀) · `go` `jumpTo`(relay) · `openPerms` 안내문 · `BOT_FAQ`(도움말) · CSS. server.py `SERVER_VERSION` `MENUS` `DEFAULT_PERMS`.
- 확인한 것: 임시 서버 — 운영자(hong) "카타르 Ras Laffan 업무 현황에 11/8 비서 바이브 시험 추가 그리고 To Do 추가 바이브 시험 항목 그리고 수행 PJT 요약해줘" → 3단계 카드 모두 ✅(업무 현황 저장 · To Do 생성 · 요약), ⛶ → 1584×934, ↗ → `?bot=1` 새창(비서만, 팝업 숨김) 에서 '카타르 LNG' → [표에서 보기] 누르면 **원래 창**이 #perform 으로 이동(새창은 그대로). 권한 없는 부서원(kimcs, LAN) 여러 단계 → 안내문. /api/info perms 에 'bot' 포함. 페이지 오류 없음.
- 회사에서 확인할 것: 운영자가 ⚙ 메뉴 권한 설정에서 '비서 바이브' 를 켜 줄 사람 고르기. 새창은 브라우저 팝업 허용 필요. 시험 데이터(카타르 Ras Laffan 업무 현황 · To Do) 는 임시 서버에서만 바뀜(복원함).

### 2026-11-08 (APP_VERSION 2026-11-08.30 / SERVER_VERSION 그대로) — 번역 성능 평가 · 번역 전 용어 보호
- 무엇을: 사용자 '번역 성능 평가해 결과도 스크린 출력'. 계장 실무 문장 34개(영→한 18: 사양서 10 · 메일 5 · 일반 3 / 한→영 16: 주간보고 5 · 사양 5 · 메일 4 · 일반 2)에 사람이 쓴 기준 번역과 '꼭 있어야 할 계장 용어'를 붙여 평가. 지표 = chrF(문자 1~6-gram F, β=2, 0~100), 계장 용어 정확도, 속도.
  - 평가에서 드러난 약점: 영→한 전문 용어(positioner → '위치 입자', junction box → '접속점 상자', cable gland → '케이블 선', partial stroke → '부분적인 치기'), 한→영 '계장 공기' → 'muling air'.
  - 시도 1 — 원문에 번역어를 바로 넣기: 한→영은 크게 좋아짐(chrF 61.5 → 72.9, 용어 46/46), **영→한은 망가짐**(영어 원문에 한글을 섞으면 모델이 깨진 바이트 <0xEB>… 를 냄, chrF 33.4).
  - 시도 2 — 영→한은 **자리표**(ZX1Q …)로 용어를 지켰다가 번역 뒤 한국어 용어로 되돌리고, 뒤 조사를 받침에 맞춤('현장 방문로' → '현장 방문으로'). 자주 쓰는 말(control valve · instrument air)까지 자리표로 바꾸면 문장 뜻이 틀어져('종료되지 않습니다') 모델이 이미 잘하는 낱말은 빼고 **모델이 틀리는 드문 용어만** 자리표(`TR_PRE.enko` 26개).
  - 최종(대시보드 화면에서 실제 번역): **영→한 chrF 36.8 → 55.5, 계장 용어 32/48 → 48/48**, **한→영 chrF 61.5 → 72.9, 용어 41/46 → 46/46**, 문장당 약 0.9초(중앙값, 화면 왕복 포함), 첫 번역 3.7~4.6초(모델 받기 포함). Mozilla 공개 품질(같은 모델, flores200): COMET22 en-ko 0.871 · ko-en 0.864.
- 바뀐 곳: dashboard.html `APP_VERSION` · `TR_PRE` `trPre` `trPh` `TR_JP` `trUnPh`(새) · `botTranslate`(번역 전 보호 → 번역 → 되돌림 → 용어집).
- 확인한 것: node(엔진 직접) + 임시 서버 화면(34문장 비서 채팅으로 번역) — 위 수치, 페이지 오류 없음. 평가 문장 · 보고서는 작업 기록에만(저장소에 안 넣음).
- 회사에서 확인할 것: 회사 문서 문장으로 몇 개 더 번역해 보고 틀리는 용어를 알려 주면 `TR_PRE`(번역 전) · `TR_GLOSS`(번역 뒤)에 보탤 수 있음. 숫자 · 단위 · 태그는 번역 뒤 사람이 확인.

### 2026-11-08 (APP_VERSION 2026-11-08.31~33 / SERVER_VERSION 2026-11-08.2) — 번역 2차 개선: 계장 사전 2판 · 사양서 말투 · 부서원 학습(용어 · 고친 번역) · 처음 보는 문장으로 평가
- 무엇을: 사용자 '점수 더 올려라, 계속 학습해라, 80 이상 되도록'.
  - **사전 2판** `TR_PRE`: 계장 분야 넓게 약 170 용어(영→한 자리표 100여 개: 전송기 종류 · 유량계 · 밸브 · 방폭 · SIS · F&G · 문서(루프도 · 훅업 · 케이블 블록도 · IFC/IFA) · 업무(FAT · SAT · 시운전 · 인계) / 한→영 70여 개). 모델이 잘 옮기는 흔한 말(valve · pressure · instrument air)은 자리표에서 뺌 — 평가에서 자리표가 많으면 어순이 흔들리고 낱말이 빠지는 것을 확인(fail closed · two-week · the design 등은 빼고 후처리로).
  - **사양서 말투** `trPost`: 원문에 shall 이 있으면 '~일 것입니다 / ~가 될 것입니다 / ~를 가져야 합니다' → '~이어야 한다 / ~해야 한다' 문어체, 한→영은 기술 문장의 must → shall, 'until 금요일' → 'by', 'a earthing' → 'an'. 그 밖에 자주 틀리는 것(귀하의→귀사의 · 답변→회신 · 사이트→현장 · 악기→계기 · 디자인→설계 · 쟁반→트레이 · 보정→교정 · I / O → I/O · 2 주 → 2주).
  - **자리표 되돌리기** `trPh` `trUnPh` 고침: 함수형 치환 · 앞뒤 띄어쓰기(데이터시트제출 → 데이터시트 제출) · 조사는 조사일 때만 공백 삼킴 · 괄호 뒤 조사 붙임.
  - **학습**(server.py `api_tr_learn_get/put`, `/api/tr/learn`, `data/_meta/tr-learn.json`, 보기 누구나 · 가르치기 로그인): "용어 등록: positioner = 포지셔너"(방향 자동, 영→한은 자리표 · 한→영은 미리 치환) · 번역 직후 "번역 고쳐: <올바른 번역>"(문장 통째 기억 = 번역 메모리, 같은 문장은 다음부터 그 번역 📚) · "학습 목록" · "용어 삭제: …". 모든 부서원 공통, 서버 안에만 저장. 용어 등록은 장치 · 문서 이름 같은 명사에 쓰는 것이 좋음(전치사 같은 말은 어순을 흔듦 — 보고서 ③ 참고).
  - **평가 방법 보강**: 규칙을 고를 때 보지 않은 **처음 보는 문장 23개**(heldout.js, 기준 번역 2개씩)로도 재고, 단일 기준 · 다중 기준 chrF 둘 다 보고. 바이브 모드의 빈 말풍선(html 없는 답) 제거.
- 결과(대시보드 화면에서 실제 번역, v.33): **한→영 처음 보는 문장 chrF 82.2(다중 기준 86.2), 용어 29/29, 80점 이상 8/10문장** · 조정에 쓴 문장 72.9 → 74.8. **영→한 처음 보는 문장 40.1 → 58.8(다중 기준 62.1), 용어 29/37 → 37/37** · 조정에 쓴 문장 55.5 → 67.1. 영→한 80 은 현재 모델로는 못 넘음(한국어는 어순 · 어미가 다양해 같은 뜻도 점수가 낮게 나옴 — 뜻은 대부분 맞음, 보고서 표 참고). 학습 시험: 용어 등록 → 다음 번역에 반영, 번역 고쳐 → 같은 문장에 그대로 사용 확인.
- 바뀐 곳: dashboard.html `APP_VERSION` · `TR_PRE`(2판) `trPost` `trPh` `trUnPh` `TRL` `trLearnLoad` `trLearnTerms` `trTM` `trLearnPut` `botTrLearnCmd`(새) · `botTranslate`(학습 → 자리표 → 번역 → 되돌림 → 용어집 → 다듬기) · `botAnswer` · `botVibeRun` `botRunStep` `botAsk`(빈 말풍선) · 도움말. server.py `SERVER_VERSION` `TR_LEARN_MAX` `tr_learn_path` `api_tr_learn_get` `api_tr_learn_put` · 라우트 `tr/learn`.
- 회사에서 확인할 것: 서버 재시작(server.py 바뀜). 번역이 틀리면 비서에게 "용어 등록: A = B" · "번역 고쳐: …" 로 가르치기 — 쌓일수록 좋아짐. 평가 문장 · 보고서(translate_eval2.html)는 작업 기록에만.

### 2026-11-08 (APP_VERSION 2026-11-08.34~36 / SERVER_VERSION 그대로) — 긴 글 번역 고침 (입력 200자 제한 · 바이브 줄 나눔) · 한국어 띄어쓰기 다듬기
- 무엇을: 사용자가 영어 기사 두 문단(약 1,100자)을 비서로 번역 시험. ① 입력칸 `maxlength="200"` 때문에 200자에서 잘려 "fa에서 왔습니다" 로 끝남 → 입력칸을 **여러 줄 textarea**(최대 20,000자, Enter = 보내기 · Shift+Enter = 줄바꿈, 높이 자동 160px 까지)로. ② 운영자(바이브)는 줄바꿈 = 다음 일로 나눠 두 번째 문단이 따로 처리됨 → **번역 · 첨삭 · 번역 고쳐처럼 내용을 통째로 받는 명령은 나누지 않음**(`BOT_WHOLE`). ③ 모델의 띄어쓰기 실수(겪고있었습니다 · 묘사 될 수있는 · 5 백만 · 인터뷰 한 · 가족은이) 다듬기(`trPost` 영→한 끝). 신문 · 통신사 이름(국민일보 · 조선일보 · 중앙일보 · 동아일보 · 한겨레 · 연합뉴스 …) 자리표.
- 바뀐 곳: dashboard.html `APP_VERSION` · `botInit`(textarea · Enter 처리) · `BOT_WHOLE` `botSteps` · `trPost` · `TR_PRE.enko`(신문 이름) · CSS `.bin textarea`.
- 확인한 것: 임시 서버 — 기사 두 문단이 끝까지 번역(약 6초), 평가 점수 그대로(한→영 처음 보는 문장 82.2 · 영→한 58.8, 깨진 것 없음). 남은 한계: 일반 기사 문장의 관용 표현(take on debts → '떠담은/떠거나', indulgences → '면죄부', went into debt → '부채에 들어갔다')은 모델 한계 — "번역 고쳐: …" 로 가르치면 같은 문장은 고친 번역을 씀.

### 2026-11-08 (APP_VERSION 2026-11-08.37~39 / SERVER_VERSION 그대로) — 번역 3차: 일반 글(기사 · 메일) 성능
- 무엇을: 사용자 '더 성능을 올려라' (직전에 영어 기사 번역에서 관용 표현이 틀림). 일반 글 평가 세트를 새로 만듦 — 조정용(요청 기사 6문장 + 메일 · 경제 기사 4, 한→영 5) / **검증용(조정 때 안 본 문장, 영→한 8 · 한→영 5)**, 기준 번역 2개씩. 세 가지를 시험해 **검증 세트에서 나빠지지 않는 것만** 넣음.
  - ① `EN_SIMPLE` 번역 전 영어 관용구 → 쉬운 말: take on debts/loans → shoulder(→ '빚을 떠안다'), take out loans → get loans, went into debt → fell into debt, indulgences → luxuries, make ends meet → cover living expenses, posted (a record profit) → recorded, on their behalf, in the first place, snowballed, second jobs, laid off, ASAP · FYI · heads-up · touch base … 검증 세트를 떨어뜨린 4개(in charge of · plunged/soared · no later than · in debt)는 뺌.
  - ② `KO_FIX_TR` 번역 뒤 자주 틀리는 일반 표현(떠담은 → 떠안은 뒤, 부채에 들어갔 → 빚을 지게 됐, 면죄부 → 사치, 대출을 가했 → 받았, 영업 이익 → 영업이익, 3 분기 → 3분기, 게시했 → 기록했, 젊은이들 → 청년들, 끝을 맞추기 → 생계 …) + `trKoFinish`: 바꿔 넣은 낱말 뒤 조사 맞춤(`koJosa`, 기반가 → 기반이) · 문장 끝 말투를 다수에 맞춤(합니다체 글 속 '~했다.' → '~했습니다.', 사양서 shall 은 '~한다' 유지).
  - ③ 한→영 `KO_PRE_KOEN` 숫자 단위(10조 원 → 10 trillion won, 억 · 만 원), 초안 → draft, 학자금 대출, 전년 대비 / `EN_FIX_TR` ten trillion → 10 trillion, 15 percent → 15%.
  - ④ 되번역으로 후보 고르기(쉬운 말 O/X 두 후보를 다시 영어로 번역해 원문과 가까운 쪽) 는 시험 결과 **오히려 나빠서 넣지 않음**.
- 결과(대시보드 화면, 4세트 85문장): 영→한 일반 조정 33.1 → **45.3**(다중 기준 56.7), 일반 검증 62.7 → **64.0**, 계장 세트 그대로(67.1 / 58.8), 용어 129/129. 한→영 일반 조정 65.5 → **70.4**, 일반 검증 64.6 → **69.6**(다중 기준 82.5), 계장 그대로(74.8 / 82.2), 처음 보는 문장 전체 다중 기준 **85.0**. 요청 기사: 떠담은 → 떠안은 뒤 · 떠거나 → 떠안거나 · 부채에 들어갔다 → 빚을 지게 됐다 · 면죄부 → 사치 · 대출을 가했습니다 → 받았습니다.
- 바뀐 곳: dashboard.html `APP_VERSION` · `EN_SIMPLE` `KO_FIX_TR` `EN_FIX_TR` `KO_PRE_KOEN` `trRep` `trKoFinish`(새) · `botTranslate`(쉬운 말 → 학습 용어 → 자리표 → 번역 → 되돌림 → 용어집 → 다듬기 → 일반 표현 → 조사 · 말투).
- 회사에서 확인할 것: 회사에서 실제로 번역하는 글로 써 보고, 틀리는 문장은 "번역 고쳐: …" 로 가르치기. 평가 세트 · 보고서(translate_eval3.html)는 작업 기록에만.

### 2026-11-08 (APP_VERSION 2026-11-08.41~42 / SERVER_VERSION 그대로) — 비서 바이브로 대시보드 화면 기능 전부 · 엑셀형 표 가독성
- 무엇을: 사용자 ① '대시보드 모든 기능이 비서 바이브 명령으로 실행되는지 확인' ② '엑셀 형식 UI 는 고정 행 · 열 색감 등으로 가독성'.
  - ① 점검 결과 **시트 행 읽기 · 쓰기(추가 · 수정 · 삭제 · 종결 · 변경 없음 · 상세 · 편집 창) · 게시판 · VOC · 댓글 · 분석 메뉴(dash-bot) · 번역 · 첨삭 · 학습 · 엑셀/CAD 출력**은 이미 되고, **화면 단추 · 메뉴 · 필터**가 비어 있어 `botUI` 로 채움: 전체 저장 · 금주 마감(운영자 · 그룹장, 확인 뒤) · 휴지통 · 대기열 · 시트 CSV · 주간보고 엑셀 · 인쇄 · 새로고침 · 다크/밝은 모드 · 메뉴 간략/펼침/숨김 · 지난 주 마감본(주차 지정 가능)/현재 주 · 담당자 필터 · 내 업무만 · 진행 중/종결/전체 · 연도 탭 · 필터 해제 · 열 숨기기/다시 보이기 · 행 변경 이력 · "○○에게 쪽지: …"(접속한 적 있는 부서원) · 쪽지함 · 권한 설정(운영자) · 생일 추가 · 근무시간/시수 엑셀 올리기(비서 창에 끌어다 놓은 파일을 업로드 칸에 넣음) · 찾기 · "○○ 화면 열어". 권한은 각 기능의 원래 검사(can · readOnly · ADMIN · MGR)를 그대로 탐. 비서가 못 하는 것: 셀 끌어서 크기 조절 · 드래그 정렬 같은 마우스 동작, 운영자 PC 폴더 선택, 재무스타그램 ⚙ 키 경로(운영자가 화면에서).
  - ② `table.t` 공통: 머리글 진한 남색 글씨 · 두꺼운 밑줄, 짝수 행 줄무늬, 마우스 행 강조, **제목 열(PJT명 · 업무 내용 등) 가로 스크롤 때 고정**(`td.key` · `th.key`, 오른쪽 구분선), 열 종류별 옅은 색(`colKind`: 날짜 · 일정 = 초록, 담당 · 책임 · 작성자 = 주황, 숫자 · 율 · 금액 = 보라 + 오른쪽 정렬 + 고정폭 숫자, 긴 글 = 파랑 머리글). 바뀐 셀 노랑 · 종결 회색 · 새 행 노랑 · 선택 파랑은 그대로(줄무늬보다 우선). Management 표(투입 분석 · 시수 · 생일 · 부서원 표)도 같은 `table.t` 라 줄무늬 · 머리글이 함께 적용.
- 바뀐 곳: dashboard.html `APP_VERSION` · `botUiSheet` `botMenuOf` `botPersonOf` `botUI`(새) · `botAnswer`(botUI 를 botEdit 앞) · `BOT_WHOLE`(쪽지 본문은 안 나눔) · `colKind`(새) `cellHtml`(key · 종류 클래스) `tableHtml`(머리글 클래스) · CSS '엑셀형 표 가독성'.
- 확인한 것: 임시 서버(운영자 = 바이브) 25개 명령 모두 동작 — 휴지통 · 대기열 · 쪽지함 · 권한 설정 · 찾기 창 열림, 다크 ↔ 밝은, 메뉴 간략 ↔ 펼침, 수행 담당자 홍길동 필터 · 종결만 · 내 업무만 · 필터 해제(select 값 확인), 현안 열 숨김 ↔ 다시 보임(머리글 목록 확인), 카타르 LNG 변경 이력 창, 이영희 쪽지 창(본문 미리 채움), 생일 추가 창, 입찰 · 재무스타그램 · 수행 화면 이동, 2026-W45 마감본 ↔ 현재 주, 전체 저장 · CSV · 엑셀 내보내기. 표 화면 캡처: 수행 · 통합 업무 · 가로 스크롤(PJT명 고정) · 투입 분석. 페이지 오류 없음.

### 2026-11-08 (APP_VERSION 2026-11-08.43~44 / SERVER_VERSION 그대로) — 번역 4차: 공개 말뭉치 학습 · Claude 검증 · 배포 번역 메모리
- 무엇을: 사용자 '인터넷의 한글 · 영어로 수천 번 학습하고 Claude 가 검증해서 90점까지'. 구글 · 허깅페이스는 이 환경에서 막혀 접근 가능한 **공개 한·영 병렬 말뭉치 Korean-English Park**(94,123 쌍, CC BY-SA 3.0, github.com/jungyeul/korean-parallel-corpora)을 받아, 검증 600쌍(test) + 학습 1,000쌍(train)을 엔진(대시보드 파이프라인 그대로)으로 양방향 번역 → **Claude 가 문장마다 읽고 판정(좋음 · 뜻 맞음 · 틀림) · 바른 번역 작성 · 반복 오류 패턴 기록**(검토 에이전트 16개 × 100문장).
  - Claude 판정(1,600문장 × 2방향): 영→한 좋음 13% · 뜻 맞음 46% · 틀림 41% / 한→영 22% · 39% · 39% (기사 문장, 고유명사 · 숫자 · 관용구 많음).
  - 검토에서 반복된 **기계적 오류를 코드로 고침**(`trSrcClean` `trKoSpace` `enWordsToDigits`, `KO_PRE_KOEN` 숫자 · 날짜, `trKoFinish` 합니다체 기본): 영→한 '적 인 · 설명 할 · 에있는 · 도움이되었다' 띄어쓰기, 깨진 따옴표(¡° ¡±) · HTML 엔티티, 숫자+단위 · % 붙이기, 했다 → 했습니다 / 한→영 만 · 억 · 조 숫자(910만 → 9.1 million), N월 N일 → Month D, 'two hundred and fifty' → 250, 'a earthing' → 'an'.
  - **배포 번역 메모리** `apps/translate/tm-seed.json`(교정 문장 2,598개, 867KB) · **패턴** `patterns.json`(270개 — 띄어쓰기 · 엔티티는 모두, 그 밖은 4회 이상 반복만, 고유명사 제외) → 대시보드가 읽어(`trSeedLoad` `trTM` `trSeedPat`) 같은 문장은 교정본(📚), 번역 뒤 패턴 적용. 부서원이 가르친 것(서버 tr-learn)이 우선. 메모리는 문장 단위(여러 문장 글은 모두 맞을 때만).
  - **측정(처음 보는 600문장, Claude 교정본 기준 chrF)**: 영→한 50.3 → **51.8**(기계 규칙), 한→영 69.6 → 69.5. 학습 문장에서 뽑은 패턴 270개를 처음 보는 문장에 적용 → **+0.0** (같은 문장이 아니면 안 맞음). 즉 **새 문장 품질은 모델 한계**(영→한 ≈ 52, 한→영 ≈ 70)이고, 90 은 이 모델(브라우저 안 Firefox 번역 모델)로는 불가 — 보고서 ④에 솔직히 적음. 회사 업무 문장(3차 보고)은 한→영 82~85 · 영→한 60대, 자주 쓰는 문장은 "번역 고쳐" 로 100.
  - 보고서 translate_eval4.html(작업 기록) · 출처 · 라이선스는 apps/translate/README.txt.
- 바뀐 곳: dashboard.html `APP_VERSION` · `trSrcClean` `trKoSpace` `enWordsToDigits` `EN_NUM` `koNum` `KO_MON`(새) · `KO_PRE_KOEN` `trKoFinish` `EN_FIX_TR` · `botTranslate`(입력 정리 · 숫자 말). apps/translate/tm-seed.json · patterns.json(새) · README.txt. make_patch 는 apps/translate/ 를 이미 포함.
- 확인한 것: 임시 서버 — 메모리 적중(📚) 영→한 · 한→영 각 1문장 교정본 그대로, '10조 원 · 250명' → '10 trillion won · 250', 처음 보는 기사 문장 번역 깨짐 없음, 페이지 오류 없음. 도메인 평가 세트(1~3차) 점수 변화 없음.
- 회사에서 확인할 것: 첫 번역 때 tm-seed.json(867KB)도 받음(LAN 이라 빠름). 번역 메모리는 뉴스 문장이라 회사 문장엔 거의 안 맞음 — 회사 문장은 부서원이 "번역 고쳐" 로 쌓는 것이 효과적.

### 2026-11-09 (APP_VERSION 2026-11-09.1~3 / SERVER_VERSION 2026-11-09.1) — 비서 대화형 · 창 크기 조절 · DART 키 이름 · 지구본 성능(전체 느려짐 원인)
- 무엇을: 사용자 사진 · 요청 4건.
  - **"위 내용 번역해줘 · 첨삭해줘" 가 안 됨**: 메일 본문을 붙여 넣고 마지막 줄에 "위 영어로 번역" 을 적으면 바이브가 줄마다 다른 일로 나눠 "못 찾았어요" 가 반복됨 → `botInstr`: 여러 줄 글의 첫/마지막 줄이 "(위/아래 내용) (영어로/한국어로) 번역·첨삭·요약·정리(해줘)" 면 나머지 글 전체에 그 일을 함. `botSummary`(핵심 문장 3개 고르기 — 숫자 · 요청 표현 우선) 추가. 명령 없이 글만 붙여 넣으면(`botLooksProse`: 줄 대부분이 문장) 줄을 나누지 않고 "어떻게 해 드릴까요?" 로 되묻고 [영어로 번역 · 첨삭 · 요약 · VOC 등록] 단추.
  - **대화하듯이 · 이동은 조금만**: 찾기 결과는 요구("찾아 · 어디 · 보여")가 없으면 3개(직접 답이 있으면 2개)까지만, 말투 "이것도 관련 있어 보여요 👇", 단추를 눌러도 "이동했어요" 말풍선을 더 띄우지 않음, 못 찾았을 때 긴 글이면 되묻기.
  - **채팅창 크기 조절(마우스)**: 오른쪽 아래 모서리를 끌어 크기(CSS resize, 최소 280×300), 머리줄을 끌어 위치 이동, 크기는 이 PC 에 기억(`dept-bot-size`). 최대화(⛶)·새창은 그대로.
  - **DART 키**: 운영자가 .env 에 `DATA_API_KEY=` 로 적어 키를 못 찾음 → `parse_dart_key`(server.py) · `parse_key`(apps/finstagram/server.py): 이름에 API_KEY · DART · CRTFC 가 들어가면 받고, 이름=값 줄이 하나뿐이면 그것을 키로, 값의 `{ }` 따옴표 제거. 저장 뒤 재무스타그램 서버를 다시 띄우는 것은 그대로(화면 ⚙ 에서 "✓ 키 확인 (40자)" 가 나와야 함).
  - **세계 지도 느림 · 검은 화면 · 전체 느려짐**: 측정 결과 3D 지구본을 한 번 켜고 다른 메뉴로 가도 **떼어진 캔버스가 계속 그려져**(fps 10 · 3초에 긴 작업 32개) 대시보드 전체가 느려졌음 → `render()` 마다 떼어진 지구본은 `glbKill`(완전 종료). 지구본은 **만질 때만** 그리고 2.5초 뒤 멈춤(`glbWake`/`pauseAnimation`), 픽셀 비율 1, 요철(bump) 지도 생략. **그래픽 가속 없는 PC(SwiftShader 등)·2초 동안 16프레임 미만이면 자동으로 평면 지도**로 바꾸고 기억(`dept-globe-off`), 필터 줄에 [🌍 3D / 🗺 평면] 단추로 언제든 전환.
- 바뀐 곳: dashboard.html `APP_VERSION` · `BOT_INSTR` `botInstr` `botSummary` `botLooksProse` `BOT_CMD_RE` `botFreeText`(새) · `botAsk` `botAnswer`(rest · 말투) `botSay`(이동 말풍선 제거) · `botInit`(크기 기억 · 머리줄 끌기) `botDock` · CSS `#botPanel`(resize) · `glbKill` `glbOff` `glbSetOff` `glbWebgl` `glbWake` `glbFpsCheck`(새) `globeMount` `glbFly` `glbResize` `render` · 유닛분장 필터 줄 `data-glb3d`. server.py `SERVER_VERSION` `parse_dart_key` · apps/finstagram/server.py `parse_key`.
- 확인한 것: 임시 서버 — 메일 4줄 + "위 영어로 번역" → 한 번에 영어 4문장, "첨삭해줘" → 첨삭, "위 내용 요약해줘" → 3문장 요약, 명령 없이 붙여 넣기 → 되묻기(단추 4개), '카타르 LNG' 답은 관련 2개만. 창 끌기(1252,330 → 932,165) · 크기(340×440 → 520×600) · 기억 저장 확인. 성능: 지도 켠 뒤 fps 2 → 61(평면 자동), 홈 fps 10 → 60, 긴 작업 32 → 0, JS 메모리 146MB → 8MB. DART 파서: `DATA_API_KEY={abc}` → abc, `DART_API_KEY=xyz`, 이름=값 한 줄, 키만 한 줄 모두 통과. 도메인 평가 점수 변화 없음.
- 회사에서 확인할 것: 재무스타그램 ⚙ 에서 경로 다시 저장 → "✓ 키 확인 (40자)" 표시 · 검색 동작(서버 재시작 필요). 세계 지도가 검게 나오던 PC 에서 2초 뒤 평면 지도로 바뀌는지, [🌍 3D] 로 다시 켰을 때 모습.

### 2026-11-09 (APP_VERSION 2026-11-09.4~6 / SERVER_VERSION 2026-11-09.2) — 실행 프로젝트 › CO2 PJT › Schedule (구매 일정 현황판 · PSR) · 공종별 품목 일정판 · 비서 연결 · 첨삭 보강
- 무엇을: 사용자 'CO2 PJT 하위 메뉴로 Schedule — PSR 엑셀을 끌어다 놓거나 골라 올리면 구매 일정 현황판(다른 대시보드 UI 참고)', '각 공종을 누르면 공종 품목별 일정을 한눈에(참고 그림: 달력 줄 위 연한 색 블록)'. 시안 스크린샷 → 사용자 확인 뒤 적용.
  - **메뉴**: 실행 프로젝트 › CO2 PJT › Schedule (`co2sched`, RUN_LEAVES · 권한 runpjt, 메뉴 옆 품목 수).
  - **읽기**(`xlsxOpen` `schParse`, 브라우저 안 · 외부 라이브러리 없음): 시트 중 'Seq.' 머리글이 있는 것만(회의용 · 발주처용 · 이전 · PSR_ 빈 양식은 같은 품목이 겹쳐 건너뜀 — 회사 파일은 Tagged 48 · Bulk 41품목). 13 · 14행 두 줄 머리글을 합친 이름으로 열을 찾음(열 위치가 바뀌어도 됨): MR · RFQ · Bid Closing · TBE 시작/발주처/완료 · CBE 시작 · Final Quote · Award Rec./승인 · PO 품의 · PO · KOM · VDLI · Key V/D · Sub-Order · 자재 입고 · PIM · 제작 시작/50%/완료 · 검사 요청 · FAT · 선적(50%/100%) · 현장 도착. 품목마다 Baseline/Forecast/Actual 3줄. 기준일 = 어느 시트든 'As of' 옆 날짜(없으면 올린 날). 원본 엑셀은 저장하지 않고 읽은 일정만 서버에 저장(`/api/sched/co2`, data/_meta/sched-co2.json, 보기 · 올리기 모두 runpjt 권한, 올리기는 로그인) → 모든 부서원이 같은 현황판.
  - **현황판**(`renderSched`, 수행 PJT 보드와 같은 whero · wk · card 스타일): Tagged/Bulk · 공종 칩, 카드(조달 준수율 = 기준일까지 계획된 12단계 마일스톤 중 실적 비율 · PO 발행 · 현장 도착 지연(전망이 계획보다 30일+) · 일정 지남(다음 일정이 지났는데 실적 미입력) · 주의 · 현장 도착), 단계별 진척(계획 대비 실적 막대), 공종별 PO 발행, 다가오는 30일, 품목별 일정 표(현재 단계 · 다음 일정 · 현장 도착 계획→전망 · 지연 일수 · 간트: 회색 계획 / 색 전망 / 진한 실적 / ◆ PO · FAT · 현장 / 빨간 선 기준일), 줄 누르면 마일스톤 전체 계획 · 전망 · 실적 표(늦은 칸 빨강) + Buyer · Vendor · PO No, 검색 · 정렬 · 상태 필터 · [⬇ 엑셀로](`schXlsx`).
  - **공종 일정판**(`schDiscBoard`): 공종 칩 · 막대를 누르면 그 공종 품목을 달력 줄에 단계 블록으로(입찰 MR→Award · 발주 Award→KOM · 설계/제작 KOM→제작 완료 · 검사/선적 제작 완료→선적 · 운송 선적→현장, 실적 → 전망 → 계획 순으로 날짜), 진한 블록 = 끝난 단계 · 테두리 = 진행 중 · ⚠ = 계획보다 늦음 · 🧾 PO 🔍 FAT 🏁 현장 · 기준일 빨간 선, 줄 누르면 아래 표 상세로.
  - **비서**(`botSched`): "구매 일정 지연 품목" → 현장 도착 지연 품목 목록 + [지연 품목만 보기], "J0400 일정 어때?" → 그 품목 단계 · 다음 일정 · 현장 도착 + [현황판에서 보기], "PSR 현황 · PO 몇 개" → 요약. 권한 없으면 🔒.
  - **비서 번역 · 첨삭 보강**: "한국어로: …" 한 줄 긴 글이 되묻기로 빠지던 것 고침(`BOT_WHOLE` 이면 되묻기 안 함, `BOT_CMD_RE` 에 영어로 · 한국어로). 첨삭 `KO_FIX2`: 영문 약어 뒤 조사를 읽는 소리에 맞게('PO은' → 'PO는', 'MR는' → 'MR은'), '나가는건' → '나가는 건', '무의미 해보입니다' → '무의미해 보입니다'.
- 바뀐 곳: dashboard.html `APP_VERSION` · `SCH` `SCH_MS` `SCH_KEY` `SCH_PH` `xlsxOpen` `schParse` `schCalc` `schLoad` `schSave` `schUpload` `renderSched` `schDiscBoard` `schBind` `schXlsx` `botSched`(새) · `ROUTES` `RUN_LEAVES` 메뉴 `runTree` `render` `QF_MENUS` `MENU_HELP` · `botAnswer` `botAsk` `BOT_CMD_RE` `ACR_B` `KO_FIX2` · CSS. server.py `SERVER_VERSION` `SCHED_KEYS` `api_sched_get` `api_sched_put` · 라우트 `sched/{key}`.
- 확인한 것: 임시 서버 — 회사 PSR 파일 끌어놓기 → 89품목(Tagged 48 · Bulk 41) · 기준일 2026-11-02 · 서버 저장 · 새로고침 뒤 유지, 시연용 예시 PSR(임의 데이터 33품목, 작업 기록에만) → 카드 · 표 · 상세 · I&C · Mech 일정판 화면 확인, 비서 "구매 일정 지연 품목" · "J0400 일정 어때?" 답, 메일 붙여넣기 + "위 영어로 번역" → 영어 4문장, "첨삭해줘" → PO는 · 나가는 건 · 무의미해 보입니다, "한국어로: The vendor shall …" → 번역. 번역 평가 점수 변화 없음. 페이지 오류 없음.
- 회사에서 확인할 것: 서버 재시작(server.py 바뀜). 회사 PSR 을 올려 기준일 · 품목 수 확인. '현장 도착 지연' 기준(30일) · '일정 지남' 카드가 실제 운영(Actual 입력 시점)과 맞는지.

### 2026-11-09 (APP_VERSION 2026-11-09.7 / SERVER_VERSION 그대로) — v16.99
- 무엇을: 클로드 비서에 글 뒤에 명령을 붙여도 알아듣게 함 — `"…" 번역해줘` · `"…" 영어로 번역해 주세요` · `… 한국어로 번역 부탁해요` · `"…" 첨삭해줘`. 따옴표(" “ ” ' ‘ ’ 「 」)는 떼고 번역/첨삭. 바이브에서도 글 속 '그리고' · 줄바꿈으로 쪼개지 않음. '위 내용 번역해줘' 는 예전처럼 botInstr 가 처리.
- 무엇을: Schedule 품목 이름을 굵은 남색 이름표(입체 그림자 · 그라데이션)로 강조 — 품목표 · 공종별 일정판 · 다가오는 일정 목록 (`.snm`).
- 무엇을: 첨삭 규칙 추가 — '못할것' → '못할 것'(의존명사 것), '드릴께요' → '드릴게요'. 번역: '계장 사양서' → instrument specification 이 나오게 앞처리, 'next week Tuesday' → 'Tuesday next week'.
- 바뀐 곳: dashboard.html `BOT_TAIL` · `botUnq` · `botTail` · `botWhole` (새), `botTrCmd` · `botProof` · `botSteps` · `botAsk`, `KO_FIX2`, `EN_FIX_TR`, 한→영 앞처리 표, `renderSched` 품목 칸 · `schDiscBoard` · 다가오는 일정, CSS `.snm`
- 확인한 것: 시험 서버에서 hong(바이브)로 번역해줘 2건 · 첨삭해줘 1건 화면 확인, Schedule 화면 캡처, 콘솔 오류 없음 / 회사에서 확인할 것: 실제 PSR 파일로 이름표가 긴 품목명에서 줄바꿈이 자연스러운지.

### 2026-11-09 (APP_VERSION 2026-11-09.8 / SERVER_VERSION 그대로) — v17.00
- 무엇을: 실행 프로젝트 › CO2 PJT › **Schedule** 을 Datasheet 와 같은 단의 폴더(▾ Schedule)로 바꾸고, 그 아래 `구매 일정 현황판`(co2sched) · `PSR 업로드`(co2psr, 새 화면) 두 잎. PSR 업로드 화면 = 큰 끌어다 놓기 칸 + 지금 올라와 있는 PSR(파일 · 기준일 · 시트 · 품목 수 · 올린 사람) + 현황판 보기. 올리면 바로 현황판으로 이동. 권한 = 실행 프로젝트(runpjt), 서버 API 는 그대로(`/api/sched/co2`).
- 무엇을: 비서 — 여러 줄 글 + 마지막(또는 첫) 줄에 `영어로` · `한국어로` · `영문` · `English` 만 적어도 번역(전에는 바이브가 줄마다 나눠 실행해 엉뚱한 검색 결과가 나옴, 회사 PC 제보). 글 앞뒤 따옴표는 떼고 번역. '계장에서/계장은 …' → I&C team 으로 번역되게 앞처리(전: 'syring'), 'Lee Hyung-joon's professional' → 'Pro Lee Hyung-joon'.
- 바뀐 곳: dashboard.html `NAV_LS` · `runTree` · `ROUTES` · `RUN_LEAVES` · `render` · `renderPsrUp`(새) · `schUpload` · 메뉴 설명 표, `BOT_INSTR` · `botInstr`, `TR_GLOSS.koen`, 한→영 앞처리 표
- 확인한 것: 시험 서버에서 메뉴 펼침 · PSR 업로드(파일 고르기) → 현황판 33품목 이동, 회사 제보 문장 그대로 '영어로' 번역 확인, 번역 평가 점수 그대로(한→영 82.2 · 영→한 58.8) / 회사에서 확인할 것: 부서원(비관리자, 실행 프로젝트 권한) 계정으로 PSR 업로드.

### 2026-11-09 (APP_VERSION 2026-11-09.9 / SERVER_VERSION 그대로) — v17.01
- 무엇을: 사용자 지시 "실행 프로젝트 → CO2 PJT 의 하위 메뉴로 Schedule" — v17.00 의 Schedule 폴더(구매 일정 현황판 · PSR 업로드 두 잎)를 없애고, **CO2 PJT 바로 아래 `📅 Schedule` 한 메뉴**(Datasheet 와 같은 단, 같은 굵기)로. 누르면 구매 일정 현황판, PSR 올리기는 현황판 위 [PSR 엑셀 새로 올리기] · 끌어다 놓기(없을 때는 큰 올리기 칸). 현황판 제목 위에 경로 '실행 프로젝트 › CO2 PJT › Schedule'. 실행 프로젝트 화면(잎)을 열면 접혀 있던 실행 프로젝트 · CO2 PJT 폴더를 자동으로 펼침. `co2psr` 화면은 남겨 둠(메뉴에는 없음, #co2psr 로만).
- 바뀐 곳: dashboard.html `runTree` · `renderMenu`(폴더 자동 펼침) · `renderSched` 제목 · CSS `.mi.mlv2`
- 확인한 것: 폴더를 접어 둔 상태에서 #co2sched 열기 → 자동 펼침 · Schedule 강조 화면 확인, 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.10 / SERVER_VERSION 그대로) — v17.02
- 무엇을: 어느 메뉴 화면이든 열면(해시 이동 · 비서 이동 · 새로고침) 그 메뉴의 접힌 상위 폴더(주간업무보고 · LOGIC · 실행 프로젝트 › CO2 PJT · Management)를 펼치고, 선택된 메뉴가 사이드바 밖이면 가운데로 스크롤. 이미 보이면 그대로, 같은 화면에서 다시 그릴 때는 스크롤하지 않음(사용자 스크롤 방해 X). 왜: 오케스트레이터 전달 — 현황판을 열어도 사이드바가 맨 위에 머물러 CO2 PJT 하위 메뉴인 줄 몰랐음.
- 바뀐 곳: dashboard.html `menuReveal`(새) · `MENU_SHOWN` · `renderMenu`(상위 폴더 자동 펼침)
- 확인한 것: 1600x900, 폴더를 접어 둔 상태에서 #co2sched → Schedule 보임(scrollTop 552), #mgbday(이미 보임 → 그대로), #work, 새로고침 후 유지. 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.11 / SERVER_VERSION 2026-11-09.4 / 재무스타그램 APP_VERSION 2026-11-09.1) — v17.03
- 재무스타그램 동작 안 함: DART 접속이 실패하면 `/api/search` 가 오류를 돌려주는데 화면이 그냥 넘겨서(칩 눌러도 무반응, 드롭다운 '결과 없음') 이유를 알 수 없었음.
  - apps/finstagram/server.py `dart_get` — 인터넷 오류를 한국어 이유로(회사 프록시가 막음 403/407 · SSL 인증서 검사 · DNS · 시간 초과 · 거부), DART 상태 코드(010 키 미등록 · 011 · 012 IP · 020 한도 · 901 …)를 오류로. 새 `/api/diag`(키 유무 · 길이만, 프록시, DART 접속 시험, 회사 목록 캐시). 프록시 `FIN_PROXY` · `FIN_PROXY_FILE`(대시보드가 운영 폴더 `fin_proxy.txt` 를 넘김) — 있으면 extras(주가 · 날씨)까지 같은 프록시. `FIN_DART_BASE` 는 시험용.
  - apps/finstagram/index.html — 검색 · 칩 · 불러오기 오류를 빨간 상자로 + [연결 점검] 단추, `?q=회사명` 으로 열면 바로 검색.
  - 대시보드 ⚙ DART 키 창: 프록시 칸(선택) + [🔎 DART 연결 점검] (server.py `api_findiag` = admin/findiag, `fin_proxy`, `api_finkey_put` 의 proxy).
- 비서: "재무스타그램 삼성물산 검색" → 비서가 직접 재무스타그램 서버에 물어 매출 · 영업이익 · 순이익 · 자산 · 부채 + 요약을 보여 주고 **"이동할까요?"** [네, 이동] = 재무스타그램을 그 회사로 검색한 채 엶 (`botFin`, `FIN_Q`, `pidUrl`). 실패하면 이유 그대로.
- 비서: "주간업무보고에서 수행에서 카타르 PJT 내 담당 현황 띄워줘" · "입찰에서 싱가포르 보여줘" → 그 표로 이동 + 내용 검색 걸기 + 행 단추 (`botNav`). 주간업무보고 안의 '실행' = 수행 표(안내 문구), '실행 프로젝트 … Schedule/Datasheet 열어줘' = 실행 프로젝트 메뉴. 표에 없는 말은 빼고 알려 줌. 필터 · 열 · 저장 · 고치기 · 질문(몇/언제/지연)은 원래 처리로(`NAV_SKIP`). 바이브 단계 실행에서 단추가 빠지던 것 고침(`botRunStep`).
- 비서 창 끌기: 마우스가 iframe(재무스타그램 · P&ID) 위를 지나면 놓쳐서 '삐끗' → `setPointerCapture` + rAF, 끄는 동안 iframe 마우스 막음(`body.bdragging`).
- 세계 지도: 느린 이유 = 240개 나라 경계를 모두 3D 로 만듦 · 0.9MB 하늘 그림 · 모든 PJT 이름표를 매 프레임 이동 · 서버가 apps 파일을 no-store 로 줘서 매번 4.5MB(번역 모델은 75MB) 다시 받음 · 처음 그리는 동안 프레임을 재서 '느림'으로 평면 지도에 고정.
  - PJT 있는 나라만 경계, 하늘은 그 자리에서 그린 별(작고 선명), 지형 요철(bump)은 뜬 뒤, 멀리서는 나라 이름표만 · 가까이 가면 PJT 카드(`glbHtml`), 처음엔 멀리서 다가오며(구글 어스처럼), 유닛분장 화면에서 쉬는 틈에 미리 받기(`glbPrefetch`).
  - 프레임 측정은 준비 끝나고 1초 뒤부터, 자동 평면 전환은 이 창에서만(sessionStorage) — 예전 자동 기억 `dept-globe-off` 는 지움. 사용자가 [🌍 3D/🗺 평면] 으로 고른 것만 `dept-globe-flat` 에 기억.
  - server.py `send_app_file`: ETag + 304, `private, max-age=3600, must-revalidate`, js · json gzip(지구본 1.47MB → 0.41MB). `send` 는 extra 에 Cache-Control 이 있으면 no-store 를 안 붙임.
- 다크모드 가독성: 화면 전체를 뒤집는 방식에 맞춰 카드(창)가 바탕보다 살짝 밝게 떠 보이도록 — 얇은 밝은 테두리 · 윗변 빛 · 바깥 은은한 빛(반투명 유리 느낌), 입력칸 테두리, 큰 색 카드(whero · kpi.hero)는 채도 · 밝기를 낮춤.
- 확인한 것: 시험 서버(가짜 DART · 실제로 막힌 DART 둘 다) — 재무스타그램 오류 이유 · 연결 점검 · ⚙ 점검 · 비서 검색 → 이동 시 iframe `?q=삼성물산` 검색됨, 비서 이동/검색 4종, 비서 수정(바이브) · 전체 저장, 비서 창을 iframe 위로 빠르게 끌기(놓은 자리 정확), 지구본 준비 약 2초(소프트웨어 그래픽), 304 · gzip, 다크모드 화면. 콘솔 오류 없음.
- 회사에서 확인할 것: 재무스타그램 ⚙ › [DART 연결 점검] 결과 문구 — '회사 프록시가 막음'이면 IT 에 opendart.fss.or.kr 허용 요청 또는 프록시 주소 입력, 'SSL 인증서'면 회사 인증서 문제. 지구본은 업데이트 뒤 처음 한 번은 3D 로 다시 시도함.

### 2026-11-09 (APP_VERSION 2026-11-09.13 / SERVER_VERSION 2026-11-09.5 / 재무스타그램 서버 오류 문구 · 수주 6시간 갱신) — v17.04
- 유닛분장 · 프로젝트별 LE/RE 배경(빈 점 무늬였음) → 미식축구 경기장(패트리어츠 팀 색: 네이비 · 레드 엔드존, 실버 별 · 'I&C ENG', 야드 라인 · 숫자, 가운데 별). 공식 로고 · 사진은 상표라 넣지 않음. 운영 폴더 `apps\theme\oc-bg.jpg` 를 두면 그 그림이 배경(/api/info `ocBg`). 다크모드에서는 경기장을 뒤집지 않음(세계 지도와 같은 방식).
  - 바뀐 곳: dashboard.html CSS `.oc.rd.bg-pat …`, `ocBgImg` · `OC_BGIMG`, 조직도 틀(#oc 에 bg-pat) / server.py `/api/info` 의 ocBg
- 세계 지도 '삼성물산 현황'(재무스타그램 실시간): 지도 왼쪽 위 칸 — 주가(네이버, 전일 대비) · 최근 사업보고서 매출 · 영업이익(DART) · 수주잔고 · 진행/해외 건수(DART 사업보고서 수주상황) + 갱신 시각, 지도를 열어 두면 10분마다 다시 받음, ↻ = 바로. 💰 수주 점은 기본 켬(끄면 `dept-ord-off` 에 기억). 받지 못하면 칸마다 이유.
  - 바뀐 곳: dashboard.html `SAM` · `samLoad` · `samPaint` · `samTick`, `OC.ordOn` 기본값, `ordToggle` / apps/finstagram/extras.py `orders` 6시간마다 새로(`ORD_AT`), server.py 바깥 사이트 연결 오류도 한국어 이유(`net_reason(e, host)`, 경로별 사이트 이름)
- 달력: 대한민국 공휴일 이름 표기(빨간 날 · 칸 아래 이름 · 날짜 누르면 이름). 공휴일 목록을 이름 있는 규칙으로 바꿈 — 양력 공휴일 + 음력 표(`HOL_LUNAR` 2024~2030: 설 · 추석 · 부처님오신날) + 대체공휴일 규칙(설 · 추석 = 일요일 · 다른 공휴일과 겹치면, 나머지 = 토 · 일 · 겹치면, 같은 날 두 공휴일은 하루) + 선거일 · 임시공휴일(`HOL_EXTRA`). 근로자의 날(5/1)은 옅게만(근무시간 계산 제외). 예전 목록과 비교해 2026-09-28 하루가 빠짐(추석 9/24~26 은 일요일과 안 겹쳐 대체공휴일 없음 — 근무시간 소정 계산에 반영됨).
  - 바뀐 곳: dashboard.html `HOL_LUNAR` · `HOL_EXTRA` · `HOL_NAME` · `HOLIDAYS` · `HOL_SOFT`, `renderCal`, CSS `.cd.hol` · `.ec.hn` · `.calhol`
- 확인한 것(시험 서버, 가짜 DART · 실제로 막힌 DART 둘 다): 1 재무스타그램 오류 이유 · 연결 점검 · ⚙ 점검 / 가짜 DART 로 검색 · 불러오기, 2 비서 창을 iframe 위로 빠르게 끌기(놓은 자리 정확), 3 비서 "재무스타그램 삼성물산 검색" → 요약 → 이동할까요 → iframe `?q=` 검색됨, 4 비서 메뉴 이동 · 수정(바이브) · 전체 저장, 5 수행/입찰 표 이동 + 검색('카타르' · '싱가포르'), 주간업무 '실행' = 수행 안내, 실행 프로젝트 Schedule 열기, 6 지구본 약 2초 · 304 · gzip, 7 유닛 · LE/RE 배경(밝은 · 다크), 8 삼성물산 현황 칸(주가 · 수주는 이 환경에서 못 받아 가짜 응답으로) · ↻ 다시 받기 · DART 막힘일 때 이유 표시, 달력 2026-05 · 09 · 10 공휴일, 사이드바 자동 스크롤, 번역 · 첨삭, PSR 업로드. 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.14 / SERVER_VERSION 2026-11-09.6 / 재무스타그램 2026-11-09.2) — v17.05
- 무엇을: DART 키 기본 위치 = `C:\Claude\시크릿\.env` (사용자 지시 — 그 파일의 `DART_API_KEY={키}` 줄을 실행할 때 읽고, 키 값은 코드 · 배포물 · 화면 · 로그에 넣지 않음). 없으면 예전 `C:\Claude\keys\dart_api_key.txt`. 순서: --dart-key → 운영 폴더 dart_key_path.txt(⚙ 지정) → 위 기본 위치.
- 키 읽기 규칙 강화(대시보드 `parse_dart_key` = 재무스타그램 `parse_key`): ① DART_API_KEY · OPENDART_API_KEY · DART_KEY · CRTFC_KEY ② 이름에 DART · CRTFC ③ 이름에 API_KEY 인 줄이 하나뿐일 때만 — 한 .env 에 다른 API 키(ANTHROPIC_API_KEY 등)가 같이 있어도 DART 키를 고름(예전엔 첫 *_API_KEY 를 잡을 수 있었음). 값의 { } · 따옴표 · 줄 끝 주석 뗌. 파일 인코딩 UTF-8(BOM) · UTF-16(메모장) · ANSI 모두(`read_key_text`).
- 바뀐 곳: server.py `DART_DEFAULT_KEYS` · `dart_key_path` · `parse_dart_key` · `read_key_text` · `api_finkey_get` / apps/finstagram/server.py `parse_key` · `read_key_text` · `load_key` / dashboard.html ⚙ 창 안내 문구
- 확인한 것: 가짜 40자 키로 6가지 쓰는 법(중괄호 · 다른 키와 함께 · 따옴표 + 주석 · DATA_API_KEY · 키만 · export) × 두 프로그램 모두 정상, UTF-16 · UTF-8 · ANSI 파일, 기본 위치 고르기, ⚙ 응답 · /api/diag · 로그에 키 값 없음.
- 회사에서 확인할 것: 업데이트 뒤 재무스타그램 ⚙ 창 '지금 경로' 가 C:\Claude\시크릿\.env 이고 상태 '✓ 키 확인 (40자)' 인지 → [DART 연결 점검]. (⚙ 에서 다른 경로를 지정해 둔 적이 있으면 그 경로가 우선 — 칸을 비우고 저장하면 기본 위치로)

### 2026-11-09 (APP_VERSION 2026-11-09.15 / SERVER_VERSION 2026-11-09.7 / 재무스타그램 2026-11-09.3) — v17.06
- 회사 제보: 재무스타그램 검색 → `<urlopen error [WinError 10054] 현재 연결은 원격 호스트에 의해 강제로 끊겼습니다>` (영어 원문 그대로).
  - 원인 ① 업데이트를 적용해도 **옛 재무스타그램 프로그램이 계속 떠 있었음** — fin_loop 는 8765 에 무엇이든 떠 있으면 새로 띄우지 않았음(그래서 한국어 이유 표시도 안 나옴). → `fin_replace_stale`: 떠 있는 판(/version ver) ≠ 파일 판(APP_VERSION)이면 끔(내가 띄운 것 = fin_stop, 아니면 /api/quit → 그래도 살아 있으면 윈도 `netstat -ano` 로 8765 LISTEN PID → `tasklist` 가 python 이면 `taskkill /F`) 후 새 판을 띄움. 재무스타그램 /version 에 pid, 새 `/api/quit`(이 PC 에서만). fin_info 는 프록시를 거치지 않음.
  - 원인 ② 10054 = 회사망이 opendart.fss.or.kr 로 바로 나가는 연결을 끊음 — 회사 PC 브라우저는 '자동 프록시 설정 스크립트(PAC)' 로 프록시를 쓰는데 파이썬 urllib 는 PAC 을 못 읽음. → 재무스타그램 `net_open`: 길 후보를 차례로 시도하고 되는 길을 기억(⚙ 지정 프록시 → 윈도 · 환경 프록시 → **윈도 레지스트리 AutoConfigURL 의 PAC 파일 안 `PROXY 주소:포트` 들** → 직접 → 직접(TLS 1.2)), 찾은 길은 주가 · 날씨에도(install_opener). 407(프록시 로그인)은 다음 길로. 다 안 되면 시도한 길마다 이유 + 할 일(⚙ 프록시 칸 · IT 요청). ⚙ '인터넷 프록시' 칸에 `.pac` 주소를 넣어도 됨. 10054 · 연결 끊김 문구 추가.
  - /api/diag · ⚙ [DART 연결 점검] · 재무스타그램 [연결 점검] 에 판 · PAC 주소 · PAC 안 프록시 · 연결 길 · 시도한 길 표시.
- 바뀐 곳: server.py `fin_loop` · `fin_replace_stale` · `fin_file_ver` · `fin_info` · `api_finkey_put`(PAC 주소 허용) / apps/finstagram/server.py `proxy_setting` · `is_pac` · `proxy_url` · `pac_url` · `pac_proxies` · `routes` · `net_open` · `net_reason` · `diag` · `/version` · `/api/quit` / dashboard.html `finDiagShow`, ⚙ 안내 / apps/finstagram/index.html `runDiag`
- 확인한 것(시험 장치: 바로 끊는 서버 = 10054 흉내, 죽은 프록시 + 되는 프록시가 적힌 PAC, 가짜 DART): PAC 없음 → 두 길 모두 '회사망이 연결을 끊음(10054)' + 할 일 / PAC 있음 → 죽은 프록시 건너뛰고 되는 프록시로 검색 · 재무제표 성공 / ⚙ 칸에 .pac 주소 → 같은 결과 / 8765 에 옛 판(2026-11-07.2)이 떠 있는 채로 대시보드 서버 시작 → 끄고 새 판(2026-11-09.3) 띄움 / 윈도 netstat 출력에서 PID 고르기. 
- 여기서 못 한 것: 윈도 taskkill 경로(이 환경은 리눅스), 실제 회사 PAC · 프록시. 회사에서: 업데이트 적용 후 **대시보드 서버를 다시 켜기**(start_server.bat) → 재무스타그램 [연결 점검] 의 '판' 이 2026-11-09.3 인지, '연결 길' · '시도한 길' 문구 확인.

### 2026-11-09 (APP_VERSION 2026-11-09.16 / SERVER_VERSION 2026-11-09.8) — v17.07 Schedule: 구매 전반(MR · TBE · CBE) 중심 · 입력 · 차트 상세
- 사용자 지시: Schedule 에서 계획 · 전망 · 실적을 사용자가 입력 / 계획 대비 공종 · 품목별로 무엇이 얼마나 지연됐는지 / 지금 중요 = MR · TBE · CBE 하이라이트, 그 시점이 다 끝나면 설계 · 제작 · 운송 / 가독성 / 차트 가독성 + 누르면 상세.
- 구매 전반 계산 `SCH_FOCUS` · `schFocus`: MR(MR Issue) · TBE(TBE 완료, 없으면 발주처 · 시작) · CBE(Award Recommendation, 없으면 Final Quote · CBE 시작). 단계마다 상태(완료 · 전망 · 날짜 지남 · 계획만)와 지연일 = (실적 또는 전망) − 계획, 실적 없이 날짜가 지났으면 기준일까지. 15일+ 빨강 · 1~14일 노랑 · 계획대로 초록. `schCalc` 에 fo · front(모두 완료) · fmax · flate.
- 화면: KPI = MR 지연 · TBE 지연 · CBE 지연(누르면 그 품목만) · 구매 전반 완료 · (나중) 현장 도착 지연. **보기 단계** [🎯 구매 전반 MR·TBE·CBE | 🏭 설계·제작·운송] — 구매 전반이 모두 끝나면 자동으로 설계·제작·운송. **기준일** [파일 | 오늘] (화면에서 입력이 있으면 기본 오늘). 새 카드 **🎯 공종별 지연 — 계획 대비**(공종 × MR · TBE · CBE · 나중 단계, 칸마다 지연 건수 · 완료 · 최대 지연 · 늦은 품목 번호 +일, 누르면 그 공종 · 단계 품목만). 품목표: MR · TBE · CBE 칸(주황 머리 '지금 중요'), 현재 단계 · 다음, 나중 단계(현장 도착) 흐리게, 정렬 기본 'MR · TBE · CBE 지연 큰 순', 상태에 'MR/TBE/CBE 지연' 추가, 간트에 구매 전반 구간(주황/빨강/초록 바탕). 상세에 '지연' 줄 · 직접 입력 표시(●).
- 입력: 상세의 [✏ 계획 · 전망 · 실적 입력] → 마일스톤 28개 × 계획/전망/실적 날짜 칸 → [💾 저장]. 저장 때 서버 최신 판을 받아 그 품목만 고침(`schEditSave`), 고친 칸 `it.ed`, 기록 `d.log`(누가 · 언제 · 무엇을, 최근 500), `d.edited`. PSR 를 다시 올릴 때 직접 입력이 있으면 '다시 적용할까요?' 확인. server.py `api_sched_put` 이 log · edited · asOfFrom 도 저장. 권한 = 실행 프로젝트(runpjt) · 편집 가능 상태.
- 공종 일정판(차트): 블록 크게 · 진하게 · 행 가운데, 좁으면 짧은 이름, 블록에 '+지연일' · ✔, 계획은 블록 아래 가는 줄, 15일+ 빨간 테두리 · 1~14일 노란 테두리, 구매 전반 보기에서는 나중 단계 흐리게 + 구매 블록 강조, 품목 이름 아래 MR · TBE · CBE 칩. **블록을 누르면 상세 카드**(`schPop` — 그 단계의 마일스톤별 계획 · 전망 · 실적 · 지연, [✏ 입력] · [표에서 보기]), 품목표 간트 막대도 누르면 전체 상세.
- 엑셀 내보내기: MR · TBE · CBE 지연(일) 열 추가.
- 확인한 것: 시연 PSR 33품목 — KPI(MR 0/33 · TBE 19/33 최대 +101 · CBE 20/33 최대 +98), 공종별 지연 표, 칸 눌러 필터, 공종 일정판 블록 → 상세 카드 → 입력 → 저장 → 새로고침 후에도 값 · 기록(by 홍길동) 유지, 설계·제작·운송 보기, 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.17 / SERVER_VERSION 그대로) — v17.08 Schedule 품목 가독성
- 무엇을: 품목 이름을 테두리 이름표 대신 크고 진한 글씨(13.5px · 800, 최대 두 줄 · 마우스 = 전체 이름), 품목 칸 왼쪽에 공종 색 띠, 공종은 같은 색 칩, 업체는 아래 작은 회색(🏭 업체 · 나라 / 👤 Buyer), 품목 칸 넓힘(230 → 270px), 줄 간격 · 줄 구분선 · 마우스 올림 강조, No 아래 Tagged/Bulk · LLI. 공종 일정판 이름 · 다가오는 30일 목록도 같은 방식(공종 색 점).
- 바뀐 곳: dashboard.html `SCH_DC` · `schDc`(공종 색, 모르는 공종은 이름으로 정해진 색), `renderSched` 품목 줄 · 다가오는 일정, `schDiscBoard` 이름 칸, CSS `.sinm` · `.sven` · `.sdc` · `.schtab td.sitem` · `.dbl`
- 확인한 것: 품목표 · I&C 일정판 화면, 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.18 / SERVER_VERSION 그대로) — v17.09 Schedule 더블클릭 입력 · 공종별 품목 현황 요약
- 더블클릭 입력: 품목 상세 표의 계획 · 전망 · 실적 칸을 더블클릭하면 그 자리에서 날짜 칸으로 바뀜(Enter · 다른 곳 누름 = 저장, Esc = 취소). 품목표의 MR · TBE · CBE 칸을 더블클릭하면 그 마일스톤의 계획 · 전망 · 실적 작은 입력 창(`schCellPop`). 한 번 누름(줄 열기)은 그대로 — MR · TBE · CBE 칸은 더블클릭과 구분하려고 0.26초 기다림. 저장은 모두 `schSaveCells`(서버 최신 판에 그 칸만 반영 · 기록 남김). 권한 = 실행 프로젝트 · 편집 가능.
- 공종별 품목 현황 요약 카드(예전 '공종별 PO 발행' 자리): 공종마다 머리(품목 수 · PO 발행 · MR·TBE·CBE 지연 수 · PO 막대, 누르면 그 공종만) + 품목 한 줄씩(상태 점 · No · 이름 · 지금 단계 '+지연일' · 전망/다음 일정), 늦은 것부터, 품목을 누르면 표에서 상세.
- 바뀐 곳: dashboard.html `schSaveCells` · `schEditSave` · `schCellPop` · `schBind`(ondblclick · 클릭 구분) · `renderSched`(fcell · 상세 칸 data-sc · 요약 카드 brief/sumHtml), CSS `.sce` · `.scp` · `.isg` · `.isr`
- 확인한 것: 상세 칸 더블클릭 → 입력 → Enter → 서버 저장 · 기록, MR/TBE/CBE 칸 더블클릭 → 입력 창, 한 번 누름 = 줄 열기, 요약 카드 화면. 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.19 / SERVER_VERSION 그대로) — v17.10 Schedule 카드 크게 보기 · 크기 조절
- 무엇을: Schedule 의 각 현황 카드(단계별 진척 · 공종별 품목 현황 · 다가오는 30일 · 공종별 지연 · 공종 일정판 · 품목별 일정)에 [⛶ 크게] — 화면 가득 크게(글자 · 막대도 조금 크게, 목록 높이 제한 없음), [✕ 닫기] · Esc · 바깥 누름 = 원래대로. 카드 오른쪽 아래 모서리를 끌어 높이 조절, 높이는 이 PC 에 기억(`dept-sch-size`, 다시 그려도 유지).
- 바뀐 곳: dashboard.html `schCardTools` · `SCH_SZ` · `SCH.big` · `schBind`(data-schbig), Esc 처리, CSS `#schv section.card.schrs` · `.big` · `.schbig`
- 확인한 것: 카드 5개에 단추, 공종별 품목 현황 · I&C 일정판 크게 → Esc 로 닫힘, 높이 300px 로 바꾼 뒤 다시 그려도 유지. 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.20 / SERVER_VERSION 그대로) — v17.11 품목별 일정판(간트) 새 디자인
- 무엇을: 사용자 "웹에서 더 가독성 있는 UI · 디자인 적용" — 웹 타임라인 도구(Linear · Asana · TeamGantt 류)에서 흔한 방식으로 `schDiscBoard` 를 새로 그림(gt* 클래스).
  - 머리: 연도 줄 + 월 줄 두 줄, 해가 바뀌는 곳 굵은 선 · 분기 점선, 달마다 옅은 띠(번갈아), 기준일 = 빨간 세로선 + '기준일 MM.DD' 알약. 가로 · 세로 스크롤 때 머리와 이름 열이 고정(sticky).
  - 이름 열(268px, 고정): No · 지금 단계 알약 · 품목 이름(굵게, 두 줄) · MR/TBE/CBE · 현장 지연 칩, 왼쪽 공종 색 띠.
  - 막대: 끝난 단계 = 진한 색 + 흰 글씨 + ✓, 진행 중 = 옅은 색에 기준일까지 채움, 앞으로 = 옅은 색 빗금, 계획보다 늦으면 막대 안 끝에 '+일' 알약(빨강 15일+ · 노랑), 계획 = 아래 회색 가는 줄, 마일스톤 = ◆(PO 파랑 · FAT 분홍 · 현장 도착 검정, 속 찬 = 실적 · 빈 = 전망). 구매 전반 보기에서는 나머지 단계를 옅은 색 + 진한 글씨(읽히게), 구매 막대 주황 테두리.
  - 도구 줄: 범례 · 확대/축소 [− 맞춤 · 월 크게 · 월 더 크게 · 주 단위 +] (가로 스크롤, 화면 가운데 유지) · [◎ 기준일] 로 이동. 막대 누름 = 단계 상세(그대로), 이름 누름 = 아래 표 상세.
- 바뀐 곳: dashboard.html `schDiscBoard`(다시 씀) · `schGtToday` · `schBind`(data-gz · data-gtoday · 확대 뒤 스크롤 위치), CSS `.gt*`
- 확인한 것: I&C 일정판 맞춤 · 크게 · 확대 2단계 · 기준일 이동 · 막대 상세 · 설계/제작/운송 보기, 확대 상태에서 가로 스크롤해도 이름 열에 막대가 비치지 않음. 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.21 / SERVER_VERSION 그대로) — v17.12 품목 이름 입체감
- 무엇을: Schedule 품목 이름(품목표 · 일정판 · 공종별 품목 현황 · 다가오는 30일)을 진한 남색 + 아래로 겹친 그림자(돋을새김)로 입체감, 마우스를 올리면 1px 떠오르며 그림자 진해짐. 다크모드용 그림자 따로.
- 바뀐 곳: dashboard.html CSS `.sinm` · `.gtnm` · `.isi` · `.sinm1`
- 확인한 것: 품목표 · I&C 일정판 화면, 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.22 / SERVER_VERSION 그대로) — v17.13 일정판 직접 조작(끌기)
- 무엇을: 품목별 일정판에서 막대를 좌우로 끌면 그 단계 안의 (실적 없는) 마일스톤 전망을 같은 날수만큼 옮김(시작 마일스톤 = 앞 단계 끝이라 그대로), 막대 오른쪽 끝(손잡이)을 끌면 끝 마일스톤 전망만 바꿈. 끄는 동안 '+N일 · 새 시작 → 끝' 안내, 놓으면 바로 저장(`schSaveCells`, 기록 남음) + [↶ 되돌리기](마지막 1번). 끝난 단계(✓, 실적)는 고정. 짧게 누르면 예전처럼 단계 상세. 마우스 위치 날짜 안내선(점선 + 날짜). 권한 = 실행 프로젝트 · 편집 가능.
- 바뀐 곳: dashboard.html `schGtDrag`(새) · `schDiscBoard`(data-gs/ge · .drag · .gtrz · .gthv · 안내 줄 · 되돌리기 단추) · `schBind`(SCH.noClick · data-gtundo), CSS `.gtb.drag` · `.gtrz` · `.gtdtip` · `.gthv` · `.gthelp`
- 확인한 것: J0730 운송 막대 +65일 끌기 → 현장 도착 전망 27.05.19 → 27.07.23 저장, 끝 손잡이 끌기 → 27.09.08, 되돌리기 → 27.07.23, 끌기 뒤 상세 팝업 안 뜸 · 짧게 누름 = 상세. 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.24 / SERVER_VERSION 그대로) — v17.14 일정판 마우스 휠 확대 · 축소(해상도 단계)
- 무엇을: 품목별 일정판 위에서 마우스 휠 위 = 확대, 아래 = 축소(마우스 아래 날짜가 제자리). 한 달 너비(ppm)에 따라 머리 두 줄이 바뀜: 년 · 분기(30px 미만) → 년 · 월 → 월 · 주(110px+, 월요일 날짜 · 주 점선) → 월 · 일(420px+, 날마다 · 주말 빨강 · 아주 크게면 요일). 맞춤보다 더 축소하면 앞뒤로 기간을 넓혀 여러 해를 보여 줌(빈칸으로 줄어들지 않음). Shift + 휠 · 이름 열 위 휠 = 보통 스크롤. [− 단계 + 맞춤] 단추도 같은 방식. 일정판만 다시 그려 빠름(`schGtRedraw`).
- 바뀐 곳: dashboard.html `schDiscBoard`(기간 넓히기 · 단계별 머리 · 주말 띠) · `schGtRedraw` · `schGtZoom` · `schGtWheel` · `SCH.gppm` · `SCH.gtArgs`, CSS `.gtmh.gwk` · `.gtmh.dy` · `.gtmh.we` · `.gtbd.we` · `.gtbd.gwk` (`.wk` 는 KPI 카드 이름과 겹쳐 gwk 로)
- 확인한 것: 맞춤(년 · 월) → 휠 확대 년 · 월 → 월 · 주 → 월 · 일, 화면 가운데 날짜 2026-06-01~03 유지, 다시 축소 → 맞춤 → 년 · 분기(2019~2033). 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.25 / SERVER_VERSION 그대로) — v17.15 확대하면 상세 일정(마일스톤 전부)
- 무엇을: 일정판을 월 · 주 / 월 · 일 단위로 확대하면 품목마다 PSR 마일스톤(MR · RFQ · Bid Closing · TBE 시작/발주처/완료 · CBE 시작 · Final Quote · Award Rec./승인 · PO 품의 · PO · KOM · VDLI · Key V/D · Sub-Order · 자재 입고 · PIM · 제작 시작/50%/완료 · 검사 요청 · FAT · 선적 · 현장 도착 …) 하나하나를 막대 아래에 표시: ● 실적 · ○ 전망/계획, 이름 · 날짜 · 계획 대비 +일(빨강 15일+ · 노랑), 주황 = 구매 전반(MR~CBE), 점선 테두리 = 날짜 지났는데 실적 없음, 계획 날짜는 회색 눈금. 겹치면 아래 줄로(줄 수만큼 행 높이 자동). 누르면 그 품목 전체 일정 상세. 년 · 월 이하로 축소하면 단계 막대만.
- 바뀐 곳: dashboard.html `schDiscBoard` line(det · 줄 배치), CSS `.gtr.det` · `.gtk` · `.gtkp`
- 확인한 것: 월 · 주 / 월 · 일 단위 화면에서 I&C 14품목 마일스톤 364개 표시, 겹침 없이 줄 나눔. 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.26 / SERVER_VERSION 그대로) — v17.16 일정판 휠 확대 · 축소 렉 / '페이지 응답 없음' 고침
- 회사 제보: 줌인 · 줌아웃에서 렉 → '페이지가 응답하지 않습니다'. 원인: 휠 한 칸마다 일정판 전체를 다시 그림 + 일 단위에서 날짜 칸 · 주말 띠 · 마일스톤 이름표가 수천 개(품목 89개 × 마일스톤 28개) + 확대 한계 없음(한 달 2400px).
- 고친 것:
  - 한계: 한 달 최대 700px(하루 약 23px), 일정판 전체 너비 최대 36000px, 축소 한 달 최소 8px (`SCH_GMAX` · `SCH_GWMAX` · `SCH_GMIN`).
  - 휠 도중에는 일정판 너비만 바꿔 미리 보기(위치가 % 라 그대로 늘어남), 이름표 · 날짜 칸은 잠깐 숨김(`.gtw.zooming`), 휠을 멈추고 0.26초 뒤 한 번만 다시 그림. 한 번에 굴리는 양 제한.
  - 주 · 일 단위에서는 화면 근처(앞뒤 한 화면씩)의 날짜 칸 · 주말 띠 · 마일스톤 이름표만 그림(`SCH.gtWin`), 좌우로 멀리 옮기면 그 근처를 다시 그림(멈추고 0.14초). 화면 밖 줄은 그리지 않음(`content-visibility:auto`). 다시 그릴 때 세로 스크롤 유지.
- 바뀐 곳: dashboard.html `schGtZoom` · `schGtWheel`(onscroll) · `schGtRedraw` · `schDiscBoard`(inW 거르기 · 한계), CSS `.gtbody>.gtr` · `.gtw.zooming`
- 확인한 것: 시험 서버에서 I&C 84품목(화면 시험용으로 늘린 자료)으로 휠 40칸 확대(일 단위) · 60칸 축소(년 · 분기) · 일 단위 좌우 이동 — 긴 멈춤(longtask) 최대 약 550ms·여러 번 → 70ms 이하, 일 단위 이름표 2184 → 690(화면 근처만). 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.27 / SERVER_VERSION 그대로) — v17.17 Schedule '구매 현황 보고' (주간업무보고 업무 현황 양식) · 상태창 반영
- 사용자 지시: 스케줄 현황에 주간업무보고(수행)에 쓰는 보고 양식으로 MR · TBE 등 현황 — "1. MR issue 지연 3건 / - item 원래 기한, 지연 사유, 캐치업 일정, 특이사항 / 2. TBE to Company …", 상태창에도 반영.
- 새 카드 📝 구매 현황 보고: 1. MR Issue · 2. TBE to Company(TBE 발주처 제출) · 3. TBE 완료 · 4. CBE(Award Recommendation) · 5. Award 승인 (설계·제작·운송 보기면 PO · KOM · 제작 완료 · FAT · 현장 도착까지). 마일스톤마다 '지연 N건'(없으면 ✔ 계획대로), 품목마다 '- No 이름 공종 +일' + 원래 기한(계획) · 현재(실적 / 전망 · 지남) · 지연 사유 · 캐치업 일정 · 특이사항 · 입력한 사람/시각. [✏ 사유 · 캐치업 입력] (Enter = 저장, Esc = 취소) → `it.rn[마일스톤] = { r 사유, c 캐치업 날짜, s 특이사항, by, at }` 서버 저장(`schSaveNote`, 기록 남김), 새 PSR 을 올려도 메모 유지. [📋 보고 글 복사] = 위 양식 그대로 글로, [📤 주간업무보고(수행)에 붙이기] = 복사 + 수행 표를 'CO2' 로 찾아 엶. 공종 필터 · 기준일(파일/오늘) 따라감.
- 상태창(📋 공종별 품목 현황) 품목 줄에 최근 보고 메모(📝 마일스톤 사유 · 캐치업) 표시.
- 바뀐 곳: dashboard.html `schSaveNote` · `schUpload`(rn 유지) · `renderSched`(RPT · rptG · rptLine · rptText · rptCard · 상태창 nt) · `schBind`(data-rne/rnx/rns/rpgo/rpcopy/rpweekly), CSS `.rp*` · `.isnt`
- 확인한 것: 시연 PSR — 1. MR Issue 0건(계획대로) · 2. TBE to Company 14건 · 3. TBE 완료 20건 · 4. CBE 20건 · 5. Award 승인 20건, E0210 사유 · 캐치업 · 특이사항 입력 → 저장 · 상태창 반영, 보고 글 복사 내용, 주간업무보고 수행 표로 이동(검색 CO2). 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.28 / SERVER_VERSION 그대로) — v17.18 구매 현황 보고 표 · 보고체(~음/~임/~중)
- 무엇을: 구매 현황 보고를 마일스톤마다 표로 — # · 품목(No + 이름, 공종 색 띠) · 공종 · 원래 기한 · 현재(실적/전망 · 지남) · 지연(+일 알약, 빨강 15일+) · 상태(✔ 늦게 완료함 / ⚠ 기한 지남 · 실적 미입력임 / ⏳ 지연 진행 중) · 지연 사유 · 캐치업 · 특이사항 · ✏(같은 줄에서 입력, Enter 저장 · Esc 취소). 머리줄 '지연 N건 발생함 (최대 +N일 · 진행 중 N건)' / '지연 없음, 계획대로 진행 중'. 보고 글 복사도 보고체: '원래 기한 26.10.04 대비 +35일 지연 중 (…)', '늦게 완료함 (실적 …)', '캐치업 : 26.11.20 완료 예정임', 캐치업이 없으면 '일정 협의 중'.
- 바뀐 곳: dashboard.html `renderSched`(rptSt · rptHead · rptRow · rptText · rptCard) · `schBind`(입력 줄 저장 위치), CSS `.rpt` · `.rpgt` · `.rpgn` · `.rpgs` · `.rps`
- 확인한 것: TBE to Company 14건 표, E0210 사유 · 캐치업 · 특이사항 입력 · 저장 · 상태창 반영, 복사 글. 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.29 / SERVER_VERSION 그대로) — v17.19 구매 현황 보고 글자 크기 · 가독성
- 무엇을: 표 글자 12.5 → 14px(품목 이름 14.5px 굵게, 머리 13px, 날짜 14px 굵게, 지연 알약 13.5px), 줄 간격 · 칸 여백 넓힘, 마일스톤 제목 16px · 번호 칸 크게, 표 너비 100% + 열 너비 다시 나눔(지연 사유 24% · 특이사항 17% · 상태 176px), 행 구분선 진하게.
- 바뀐 곳: dashboard.html `rptCard` colgroup, CSS '구매 현황 보고 글자 크기 · 가독성 조율'
- 확인한 것: TBE to Company 표 화면, 콘솔 오류 없음.

### 2026-11-09 (APP_VERSION 2026-11-09.31 / SERVER_VERSION 그대로) — v17.20 필터
- 구매 현황 보고 필터 줄: 검색(No · 품목 · 업체 · 사유 · 특이사항) · 마일스톤 · 상태(⏳ 지연 진행 중 / ⚠ 기한 지남 · 실적 미입력 / ✔ 늦게 완료함) · 지연 크기(15일 이상 / 30일 초과 / 14일 이하) · 공종 · 사유 입력(미입력만 / 입력됨만) · [✕ 필터 해제] · 건수. 필터 중엔 빈 마일스톤 숨김, 보고 글 복사도 필터 결과대로(`SCH.rf`, `rfOk`).
- 품목별 일정 표 필터 줄에 공종 · 구분(Tagged/Bulk) 선택 추가(기존 검색 · 정렬 · 상태와 함께).
- 바뀐 곳: dashboard.html `renderSched`(RF · rfOk · rfBar · fbar), `schBind`(select[data-rf] · input[data-rf=q] · data-rfx · #schDisc · #schType), CSS `.rpflt` · `.rpfc`
- 확인한 것: 보고 74건 → 진행 중 8 → +15일 5 → Mech 3, 검색 TRANSMITTER 6, 사유 입력됨 1 / 품목표 Mech + Tagged 6품목. 콘솔 오류 없음.

### 2026-11-10 (APP_VERSION 2026-11-10.1 / SERVER_VERSION 그대로) — v17.21 Schedule 설계 관리 포인트 · 보고 표 엑셀식 · 확대/축소 렉
- 사용자 지시 6: 설계 단의 지연 관리 포인트 = **MR · RFQ · TBE 발주처(to Company) · TBE 완료** — 첫 화면 요약(KPI 4칸 · 공종별 지연 표 · 품목표 칸 · 공종별 품목 현황 · 구매 현황 보고 기본 마일스톤)을 이 4개 기준으로(`SCH_FOCUS` · `SCH_FRONT` 바꿈, CBE · Award 는 설계·제작·운송 보기에서만). 화면 글 'MR · TBE · CBE' → 'MR · RFQ · TBE', '구매 전반' → '설계 관리'.
- 1 확대 · 축소 렉: 정해진 단계만(한 달 8 · 14 · 24 · 45 · 80 · 140 · 240 · 420px = 년 ↔ 일, 하루 최대 약 14px), 휠 한 칸 = 한 단계, 다 그린 뒤 0.2초 지나야 다음 단계(느린 PC 에서 쌓이지 않음), 다시 그릴 때 카드 전체가 아니라 도구 줄 · 일정판 안쪽만 바꿈(`schGtRedraw`, `.gtw{contain:content}`), 마일스톤 이름표는 일 단위(또는 주 단위 크게)에서만 · 화면 근처(0.5 + 1 + 0.5 화면)만. 시험(84품목): 한 단계 약 70~110ms(소프트웨어 그래픽), 화면 가운데 날짜 유지.
- 2 구매 현황 보고 표: 열 머리마다 ▾ 엑셀식 필터(검색 · 모두 선택 · 값별 체크 · 건수, 적용 중인 열은 파란 머리) — 품목 · 공종 · 원래 기한 · 현재 · 지연 · 상태 · 지연 사유 · 캐치업 · 특이사항. 필터 해제 단추로 모두 풂(`SCH.cf`, `schColFilter`, `rcfb`/`data-rcf` — 시트 표의 `.cfb` 와 이름이 겹쳐 따로).
- 3 열 너비: 날짜(원래 기한 · 현재 · 캐치업) 96px 로 통일, 지연 사유 320px · 특이사항 260px 로 넓게. 표 너비 = 열 합(넘치면 가로 스크롤).
- 4 셀 더블클릭 = 그 자리 입력(Enter 저장 · Esc 취소 · 다른 곳 누름 = 저장): 원래 기한 = 계획(B), 현재 = 오늘까지 날짜면 실적(A) · 뒤면 전망(F, 실적 지움), 캐치업 · 지연 사유 · 특이사항 = 보고 메모(rn). 저장은 같은 품목 데이터 하나라 품목표 · 일정판 · 상태창 · 보고에 모두 반영, 품목 상세에도 '📝 마일스톤 보고' 표시(`schRptEdit`). ✏ 열은 없앰.
- 5 열 너비 조절: 머리 오른쪽 끝을 끌면 그 열(모든 마일스톤 표 함께), 이 PC 에 기억(`dept-rpt-colw`).
- 바뀐 곳: dashboard.html `SCH_FOCUS` · `SCH_FRONT` · `SCH_GSTEPS` · `schGtZoom` · `schGtWheel` · `schGtRedraw` · `schColFilter` · `schRptEdit` · `renderSched`(RC · cv · CF · rptRow · rptCard · KPI · 품목표 colgroup) · `schBind`(data-rz · data-rc 더블클릭 · data-rcf), CSS `.rpt` · `.rcfb` · `.rpz` · `.cfp` · `.gtw`
- 확인한 것: KPI MR 0/33 · RFQ 12/33 · TBE 제출 14/33 · TBE 완료 20/33, 보고 공종 열 필터 I&C → 18건, 지연 사유 · 캐치업 더블클릭 입력 → 서버 저장, 사유 열 너비 +120 → 모든 표 반영 · 기억, 확대 · 축소 렉 측정. 콘솔 오류 없음.

### 2026-11-10 (APP_VERSION 2026-11-10.2 / SERVER_VERSION 그대로) — v17.22 확대는 월까지 · 막대 미리보기 · 보고 접기
- 일정판 확대 단계를 월 단위까지만(한 달 8 · 14 · 24 · 45 · 75 · 105px — 년 ↔ 월). 일 · 주 단위에서 렉이 있어 없앰. 대신 **막대에 마우스를 올리면 미리보기 카드**(그 단계 마일스톤별 계획 · 전망 · 실적 · 지연 + 보고 메모, 마우스를 따라감, 누르면 고정 팝업 · 입력)(`schPopBody` 공용 · `schHover`).
- 구매 현황 보고: 마일스톤마다 접기 · 펼치기(머리 줄 누름), **처음엔 모두 접힘**, [▾ 모두 펼치기] · [▸ 모두 접기], 위 요약 칩을 누르면 그 마일스톤을 펼치고 이동(`SCH.rpOpen`).
- 바뀐 곳: dashboard.html `SCH_GSTEPS` · `SCH_GMAX` · `schPopBody` · `schHover` · `schPop` · `schGtDrag`(onpointerover/move/leave) · `renderSched`(rptCard 접기) · `schBind`(data-rptog · data-rpall · data-rpgo), CSS `.gthov` · `.rptg` · `.rpgt[data-rptog]`
- 확인한 것: 보고 처음 표 0개 → TBE to Company 펼침 1 → 모두 펼침 3 → 모두 접기 0, 휠 12칸 확대 = 년 · 월에서 멈춤, J0730 구매 막대 마우스 → 미리보기 카드. 콘솔 오류 없음.

### 2026-11-10 (APP_VERSION 2026-11-10.3 / SERVER_VERSION 2026-11-10.1) — v17.23 달력 일정 입력 · 나의 예정 일정
- 무엇을: 홈 달력에서 날짜마다 일정 입력(예: 11/11 14:00 'Globe Valve TBE — Emerson 과 회의'). 날짜 더블클릭 또는 아래 [＋ M/D 일정 추가] → 창: 날짜 ~ 끝 날짜(여러 날) · 시간 · 일정 · 함께하는 사람(부서원 이름 자동 완성, 쉼표) · 장소 · 상대 · 메모 · 나만 보기. 저장하면 모든 부서원 달력에 보임(나만 보기는 본인만). 달력 점 = 하늘색 '내 일정'(내가 쓰거나 함께하는 사람) · 청록 '부서 일정', 날짜를 누르면 목록(시간 · 장소 · 함께 · 쓴 사람 · 메모), 내 일정을 누르면 고치기 · 지우기(쓴 사람 또는 운영자).
- 접속(로그인 · 화면 열기)하면 오른쪽 아래 **'○○님의 예정 일정'** 카드 — 오늘부터 2주 안의 내 일정(내가 쓴 것 + 함께하는 사람에 내 이름), 오늘/내일/날짜 · 시간 · 장소 · 함께 · 등록한 사람, 누르면 달력 그 날로, [오늘 그만 보기] · [＋ 일정 추가].
- 서버: `/api/cal` GET(나만 보기는 본인만) · POST(로그인) · `/api/cal/{id}` PUT · DELETE(쓴 사람 또는 운영자), 저장 `data/_meta/cal-events.json`(`api_cal_get` · `api_cal_save` · `api_cal_del` · `cal_clean`).
- 바뀐 곳: dashboard.html `CEV` · `cevLoad` · `cevMine` · `cevOn` · `cevDlg` · `cevMyCard` · `calEvents`(사용자 일정) · `CAL_K`(my · ev) · `renderCal`(목록 · 추가 단추 · 더블클릭 · 고치기) · `afterAuth` · 시작(o.warm 아닐 때), CSS `.ev-my` · `.ev-ev` · `.cevf` · `.cevmy` / server.py 위 함수 · 라우트 `cal`
- 확인한 것: 11/11 더블클릭 → 일정 저장(함께 홍길동 · 이영희, 메모), 11/13~14 여러 날 일정, 달력 점 · 목록, 새로고침 → 예정 일정 카드(내일 14:00 · 11/13), /api/cal 저장 내용. 콘솔 오류 없음.
- 회사에서: 서버 버전이 바뀌므로 업데이트 뒤 대시보드 서버 다시 켜기.

### 2026-11-10 (APP_VERSION 2026-11-10.4 / SERVER_VERSION 그대로) — v17.24 일정 달력은 Schedule 에만
- 사용자 지시: 일정 입력 달력은 Schedule 메뉴에만, 주간업무보고 첫 화면 달력(부서 공용)과 연동하지 않음.
- 무엇을: 실행 프로젝트 › CO2 PJT › Schedule 화면에 '📅 CO2 PJT Schedule 달력' 카드(보기 단계 위) — 사용자 일정(내 일정 · 부서원 일정, 날짜 더블클릭 · [＋ 일정 추가] · 고치기 · 지우기) + PSR 마일스톤(설계 관리 MR · RFQ · TBE 제출 · TBE 완료 + PO · FAT · 현장 도착: 실적 = 남색, 예정 · 전망 = 주황, '지남(실적 없음)' · 계획 대비 +일, 누르면 그 품목 상세). 생일 · 주간 마감 · 전달사항 · 업무 기한은 넣지 않음. 첫 화면 달력은 예전 그대로(사용자 일정 · 추가 단추 · 더블클릭 없음). '나의 예정 일정' 카드는 실행 프로젝트 권한이 있는 부서원에게만, 누르면 Schedule 달력 그 날로.
- 바뀐 곳: dashboard.html `renderCal(mode)`(home · sch, 달력 상태 `CAL1` · `CAL2`) · `calEvents(y, m, mode)` · `CAL_K`(ms · mso) · `renderSched`(#schCalCard) · `cevMyCard` · `cevDlg`, CSS `.ev-ms` · `.ev-mso` · `.schcal`
- 확인한 것: 첫 화면 11/11 = 주간업무 마감만 · 더블클릭해도 창 안 뜸, 예정 일정 카드 → Schedule 달력 11/11 일정, Schedule 달력 더블클릭 → 추가 창, PSR 마일스톤 점. 콘솔 오류 없음.

### 2026-11-10 (APP_VERSION 2026-11-10.5 / SERVER_VERSION 2026-11-10.2) — v17.25 Schedule 달력 작게 · 일정 / 특이사항
- 무엇을: Schedule 달력을 작게(왼쪽 달력 최대 460px · 칸 높이 34px, 오른쪽에 그날 목록 — 카드 높이 약 560 → 275px), 머리에 [＋ 일정 추가], 목록 아래 [📅 일정 추가] · [📝 특이사항 쓰기]. 날짜 더블클릭 창에서 **📅 일정 / 📝 특이사항** 고르기(특이사항 = 그날 있었던 일 · 메모, 보라 점 · '📝 특이'). 서버 `cal_clean` 에 kind(ev · note).
- 바뀐 곳: dashboard.html `cevDlg(date, ev, kind)` · `calEvents`(nte) · `CAL_K` · `renderCal`(머리 단추 · 아래 단추 2개), CSS `.schcal` 다시 · `.cevadd2` · `.cevk` · `.ev-nte` / server.py `cal_clean`
- 확인한 것: 11/12 더블클릭 → 특이사항 'J0730 Vendor 도면 회신 2주 지연 통보' 저장 → 그날 목록에 📝 특이 + PSR PO 마일스톤, 카드 높이 275px. 콘솔 오류 없음.

### 2026-11-10 (APP_VERSION 2026-11-10.6 / SERVER_VERSION 그대로) — v17.26 Schedule 일정 → 내 업무
- 무엇을: Schedule 달력에서 쓴 내 일정(내가 썼거나 함께하는 사람에 내 이름, 특이사항 제외)을 오른쪽 '📌 내 업무' 목록과 내 업무 팝업에 '📅 일정' 으로 추가 — 지난 7일 ~ 앞으로 14일, 날짜가 지나면 완료, 설명 = 오늘/내일/날짜 · 시간 · 끝 날짜 · 장소 · 등록한 사람. 누르면 Schedule 달력 그 날로 이동. 실행 프로젝트 권한이 있는 부서원만. 일정을 불러오거나 저장하면 내 업무 목록 바로 갱신.
- 바뀐 곳: dashboard.html `myTasks`(__cev) · `startTask`(__cev) · `cevLoad`(renderTaskBar)
- 확인한 것: 내 업무 15 → 19건(일정 4건 미완료), 내 업무의 일정 누름 → #co2sched 달력 11/11. 콘솔 오류 없음.

### 2026-11-10 (APP_VERSION 2026-11-10.7 / SERVER_VERSION 2026-11-10.3) — v17.27 Schedule 달력 공종 필터
- 무엇을: Schedule 상단 공종(I&C · Mech · Elec …)을 누르면 Schedule 달력도 그 공종만 — PSR 마일스톤은 그 공종 품목만(구분 Tagged/Bulk 도), 사용자 일정 · 특이사항은 그 공종 것만. 일정의 공종 = 입력 창의 '공종' 칸(기본 = 지금 고른 공종, '공통 · 전체' 가능), 비어 있으면 글 속 품목 번호(예: J0730 → I&C) 또는 공종 이름으로 판단(`cevDisc`). 달력 제목에 '🔧 I&C 만 ✕'(누르면 해제), 목록에 '🔧 공종' 표시. 서버 `cal_clean` 에 disc.
- 바뀐 곳: dashboard.html `cevDisc` · `calEvents`(sch 거르기) · `renderCal`(제목) · `cevDlg`(공종 칸), CSS `.calfd` / server.py `cal_clean`
- 확인한 것: 11/18 I&C · Mech 일정 2건 → I&C 고르면 1건, 11/12 특이사항(J0730) I&C 로 남고 Elec PO 마일스톤 숨김, ✕ 로 해제. 콘솔 오류 없음.

### 2026-11-10 (APP_VERSION 2026-11-10.8 / SERVER_VERSION 2026-11-10.4) — v17.28 PSR 변경 표시 · 캐치업 강조
- 무엇을: 새 PSR 을 올리면 이전 PSR 대비 바뀐 계획 · 전망 · 실적 칸을 **노랑 음영 + 파랑 글씨**(`.pchg`)로 표시, 마우스를 올리면 "이전 PSR 전망 26.07.19 → 26.07.28". 이전에 없던 품목은 `NEW` 표. 머리글에 "🟨 이전 PSR 대비 변경 N칸 · 새 품목 M개". 화면에서 직접 고친 칸은 변경 표시를 지움(● 표시로 바뀜). 구매 현황 보고의 캐치업 날짜는 붉은 굵은 입체 글씨(`.rpcu`).  왜: 사용자 지시.
- 바뀐 곳: dashboard.html `schUpload`(it.chg · it.isNew · d.prev 계산) · `schSaveCells`(고친 칸 chg 삭제) · `schChg`/`schChgT`/`schChgW` 새 함수 · `renderSched` 의 `fcell` · 품목 상세표 · `rptRow` · CSS / server.py `api_sched_put` (`prev` 저장)
- 확인한 것: 예시 PSR → 날짜 54칸 바꾼 PSR 순서로 올려 54칸 표시, 품목표 · 상세 · 보고표 캡처, 캐치업 2건 입력 후 붉은 굵은 글씨 확인, 콘솔 오류 없음 / 회사에서 확인할 것: 실제 PSR 개정판 업로드 시 변경 칸 수가 맞는지.

### 2026-11-10 (APP_VERSION 2026-11-10.9 / SERVER_VERSION 그대로) — v17.29 구매 현황 보고 열 정렬
- 무엇을: 구매 현황 보고 표의 머리글(# · 품목 · 공종 · 원래 기한 · 현재 · 지연 · 상태 · 지연 사유 · 캐치업 · 특이사항)을 누르면 오름차순 ▲ → 내림차순 ▼ → 원래 순서(⇅). 빈 값은 늘 맨 아래. # 은 지연 큰 순 번호(x.i0)로 고정해 정렬해도 그대로. 정렬은 모든 마일스톤 표에 같이 적용, 보고 글 복사도 그 순서. 묶음 제목 '최대 +N일' 은 정렬과 상관없이 최댓값.  왜: 사용자 지시.
- 바뀐 곳: dashboard.html `renderSched` 안 `RS`/`rsKey`/`rsSort` · 머리글 `data-rso` · `schBind` 클릭 처리 · `rptHead` · CSS `.rso`
- 확인한 것: 7개 열 오름/내림 결과 확인, ▾ 필터 버튼 · 열 너비 끌기와 겹치지 않음, 콘솔 오류 없음 / 회사에서 확인할 것: 없음.

### 2026-11-10 (APP_VERSION 2026-11-10.10 / SERVER_VERSION 그대로) — v17.30 캐치업 날짜 노랑 음영 · 파랑 글씨
- 무엇을: 구매 현황 보고의 캐치업 날짜를 붉은 글씨 → **노랑 음영 + 파랑 굵은 글씨**(입체 그림자 유지)로.  왜: 사용자 재지시 ("캐치업이 노랑색 음영 파랑색 글씨가 되어야 하고 현재는 그냥 검정").
- 바뀐 곳: dashboard.html CSS `.rpt td.rpdt b.rpcu`
- 확인한 것: 캐치업 입력된 칸 색(rgb 29,78,216 · 굵기 900) · 캡처 / 회사에서 확인할 것: 회사 화면이 v2026-11-10.10 인지(그 전 판이면 캐치업이 검정 굵은 글씨로 보임).

### 2026-11-10 (APP_VERSION 2026-11-10.11 / SERVER_VERSION 그대로) — v17.31 '현재' 날짜는 검정만
- 무엇을: 구매 현황 보고의 '현재' 칸 날짜는 PSR 변경이 있어도 노랑 음영 · 파랑 글씨를 쓰지 않고 검정으로만 표기. 변경 표시는 원래 기한 · 품목표 · 품목 상세표에는 그대로.  왜: 사용자 지시.
- 바뀐 곳: dashboard.html `rptRow` 의 cur 칸(`rpcur`) · CSS `.rpt td.rpcur`
- 확인한 것: 변경된 PSR 올린 상태에서 '현재' 칸 검정 · 줄무늬 배경 유지 캡처 / 회사에서 확인할 것: 없음.

### 2026-11-10 (APP_VERSION 2026-11-10.12 / SERVER_VERSION 그대로) — v17.32 보고 표 글자 서식(색 · 굵게 · 기울임)
- 무엇을: 구매 현황 보고 표의 칸을 **우클릭**하면 글자 서식 창 — 색(기본 · 검정 · 빨강 · 파랑 · 초록 · 주황 · 보라 · 회색 + 🎨 아무 색), B 굵게, I 기울임, 서식 지우기, 미리보기. 적용하면 서버에 저장돼 모든 부서원에게 같게 보이고 새 PSR 을 올려도 유지. 실행 프로젝트 권한(runpjt)이 있는 부서원만.  왜: 사용자 지시 ("글자색은 사용자가 변경할수있도록 또한 굵게, 기울기도 가능하도록").
- 바뀐 곳: dashboard.html `rptRow`(모든 칸 `data-cc` · 서식 class `rfc/rfb/rfi` · `--rfc`) · 새 `SCH_FCOL` · `schFmtPop` · `schSaveFmt` · `schBind` 의 `oncontextmenu` · `schUpload`(it.rfm 이어받기) · CSS. 저장 위치 = items[].rfm['MR|cur'] = {c,b,i} (server.py 는 items 를 그대로 저장하므로 수정 없음)
- 확인한 것: 4칸에 색 · 굵게 · 기울임 적용 → 계산된 글자색/굵기/기울임 확인, 새로고침 후 유지, 콘솔 오류 없음 / 회사에서 확인할 것: 없음.

### 2026-11-10 (APP_VERSION 2026-11-10.13 / SERVER_VERSION 그대로) — v17.33 Globe · Butterfly · PSV 메뉴 연결
- 무엇을: 실행 프로젝트 › CO2 PJT › Datasheet 의 Globe Valve · Butterfly Valve · PSV 를 '준비 중' 대신 P&ID 서버의 `/valve/` 화면(`kind=globe|butterfly|psv`)으로 연결. 화면은 세션 5 valve37 이 만듦(브랜치 claude/new-session-v23o67 커밋 3d46af2c, dist/valve_kinds/dashboard_valve_menus.patch 내용 그대로). MODULES 의 '준비 중' 항목은 남겨 둠(PID_ROUTES 가 먼저 잡힘).  왜: 오케스트레이터 세션 경유 사용자 요청.
- 바뀐 곳: dashboard.html `PID_ROUTES` (globev · bflyv · psv)
- 확인한 것: P&ID 서버(8000) 꺼진 상태에서 네 메뉴 모두 Ball Valve 와 같은 PID_OFF 안내, '새 창으로 열기' 주소에 kind= 붙음 / 회사에서 확인할 것: P&ID 서버가 valve37 판일 때 세 메뉴가 각 밸브 종류로 열리는지.

### 2026-11-10 (APP_VERSION 2026-11-10.14 / SERVER_VERSION 그대로) — v17.34 지연 사유 · 특이사항 줄바꿈 + 글씨 서식
- 무엇을: 구매 현황 보고의 지연 사유 · 특이사항 칸을 더블클릭하면 여러 줄 입력창(Enter = 줄바꿈, Ctrl+Enter = 저장, Esc = 취소, 밖을 누르면 저장). 위쪽 도구줄로 고른 글자만 **굵게 · 기울임 · 밑줄 · 색(7가지)** · 서식 지우기. 표에도 줄바꿈 · 서식 그대로 보임. 붙여넣은 글도 허용한 서식만 남김. 보고 글 복사는 평문(줄바꿈은 들여쓰기 맞춰).  왜: 사용자 지시 ("더블클릭하고 입력칸의 열바꿈되게하고 … 글씨 서식 바꿀수잇게해").
- 바뀐 곳: dashboard.html 새 `RT_OK` · `rtClean`(허용 태그 b/i/u/br/div/span + color · 굵기 · 기울임 · 밑줄만) · `rtShow` · `RT_COL` · `schRptRich` / `schRptEdit`(글 칸은 schRptRich) · `schSaveNote`(rH · sH 유지 규칙) · `rptRow` r · s 칸 · `rptText` · CSS `.rte/.rtb/.rted/.rtf/.rtx`. 저장 = it.rn[마일스톤].r · s (평문, 검색 · 필터 · 복사용) + rH · sH (서식 HTML, 서식 없으면 안 둠)
- 확인한 것: 3줄 입력 + 일부 글자 빨강 굵게 · 파랑 기울임 → 저장 → 새로고침 후 줄바꿈 · 서식 유지, 콘솔 오류 없음 / 회사에서 확인할 것: 회사 Edge 에서 서식 버튼 동작.

### 2026-11-10 (APP_VERSION 2026-11-10.15 / SERVER_VERSION 그대로) — v17.35 스스로 검토 · 보완 (캐치업 추적 · PSR 개정 추이 · 보고 표 엑셀)
- 무엇을 (웹의 EPC 구매 현황 보고 · 지연 보고서 사례를 참고해 지금 없는 것만):
  1. 캐치업 추적 — 캐치업 날짜 아래에 `D-N`(남음) · `⚠ N일 지남`(캐치업 지났는데 실적 없음) · `✔ 만회함`(실적이 캐치업 안) · `+N일 늦음`. 보고 도구줄에 `사유 미입력 N` · `캐치업 미입력 N` · `⚠ 캐치업 지남 N` 칩(누르면 그것만, 다시 누르면 전체) + 필터 선택지 추가.
  2. PSR 개정 간 추이 — 머리글 "이전 PSR 대비 변경" 을 버튼으로: `▲ 늦어짐 N · ▼ 당겨짐 M`, 누르면 바뀐 품목만(F.late = 'chg'). 바뀐 칸 툴팁에 "(▲ 9일 늦어짐)".
  3. 구매 현황 보고 `⬇ 엑셀로` — 지금 필터 · 정렬 그대로 xlsx (마일스톤 · 품목 · 기한 · 현재 · 지연 · 상태 · 사유 · 캐치업 · 캐치업 상태 · 특이사항).
- 바뀐 곳: dashboard.html `renderSched`(`lateOk` · 머리글 pchgi · `cuSt` · `rfOk` · rptool 칩) · `schChgT` · 새 `schRptXlsx` · `schBind`(`data-rfnote` · `data-rpxls`) · CSS
- 확인한 것: 변경 품목만 33 → 18, 캐치업 과거/미래 입력 후 D-18 · 7일 지남 · 만회함 표시, 칩 필터 1건, xlsx 53행 열 확인, 콘솔 오류 없음 / 회사에서 확인할 것: 없음.

### 2026-11-10 (APP_VERSION 2026-11-10.16 / SERVER_VERSION 2026-11-10.5) — v17.36 Schedule 품목에서 Datasheet 검토(세션 6) 값 보기
- 무엇을: Schedule 품목 상세(줄을 눌러 펼침)에, 품목 이름으로 밸브 종류를 알아내(BALL → Ball · GLOBE → Globe · BUTTERFLY → Butterfly · PSV/SAFETY/RELIEF VALVE → PSV, 여러 개면 모두) 그 종류의 **Datasheet 검토 값**을 붙임:
  - 머리: 프로젝트('CO2 PJT' / 'CO2 PJT · Globe Valve' …) · 최신 Rev 기준 Tag 수 · 검토 완료 · 미결 Issue(Major) · 읽은 시각 · ↻ 다시 읽기 · 검토 화면 ↗
  - **타입별 × Area별 수량 표**(행 = Valve Type, 열 = Area North·South·Brownfield·W15 순, 합계) — 숫자 · 타입 · Area 를 누르면 그 Tag 만
  - **Tag 값 · 속성 표**: Tag · Type · Area · Unit · Rev · 검토 상태 · Issue + Service · Size · Rating · Body Type · Connections · Body Material · Piping Class · Actuator · Fail Position · Manufacturer · Model (☑ 모든 속성 열 = 검토 화면 Grid 의 모든 열), 값 검색, 검토 필요 값은 주황, 30개씩 더 보기
  - 아직 그 종류 프로젝트가 없으면 안내, P&ID 서버가 꺼져 있으면 안내.
- 왜: 사용자 지시 ("세션 6 Datasheet 검토에서 값을 불러와서 해당 item 의 값 또는 속성을 볼수잇게하고 그 값에는 타입별 수량 area별 수량이 보이도록").
- 어떻게: P&ID 서버는 다른 포트에서 브라우저가 /api/valve 를 직접 부르는 것을 막아 두었으므로(CORS 없음), 대시보드 서버에 **읽기 전용 중계** `GET /api/vds/…` 를 둠 — 허용 경로 3개(`projects` · `projects/{id}/valve-summary` · `projects/{id}/grid`)만, 같은 PC `127.0.0.1:8000`(PID_PORT)으로, 실행 프로젝트(runpjt) 권한 필요, 결과는 저장하지 않음. 세션 6 쪽 코드는 고치지 않음.
- 바뀐 곳: dashboard.html 새 `VDS_KIND` · `VDS_COLS` · `vdsKinds` · `vdsLoad` · `vdsPaint` · `vdsBlock`, 품목 상세 `detail`, `schBind`(`data-vdsf` · `data-vdsre` · `data-vdsgo` · `data-vdsmore` · `oninput` · `onchange`), CSS `.vds*` / server.py 새 `PID_PORT` · `VDS_PATHS` · `api_vds_get`, `api()` 의 `vds` 분기
- 확인한 것: 가짜 P&ID 서버(46 Tag · 4타입 · 4 Area)로 수량표 · 필터 · 검색(입력 중 커서 유지) · 모든 속성 열, Globe 프로젝트 없음 안내, 서버 꺼짐 안내, 콘솔 오류 없음 / 회사에서 확인할 것: 실제 P&ID 서버(valve36/37)에서 프로젝트 이름이 'CO2 PJT' 인지, Tag 수 · Area 가 검토 화면 Valve Summary 와 같은지.

### 2026-11-11 (APP_VERSION 2026-11-11.1 / SERVER_VERSION 2026-11-11.1) — v17.37 P&ID 서버가 옛 판일 때 날 JSON 대신 안내
- 무엇을: 3D 계측제어 등 P&ID 서버 화면을 iframe 에 열기 전에 그 주소가 P&ID 서버에 있는지 확인. 없으면 `{"detail":"없는 주소입니다"}` 대신 "⚠ P&ID 서버가 옛 판입니다 (지금 업데이트 134) — 이 화면은 ② 통합 업데이트 hotfix135 이상에서 열립니다" + 다시 시도 · 그래도 열기.
  - 판단 1: P&ID `/version` 의 `update.rev`(없으면 name 의 숫자) < 메뉴의 `minRev` (ic3d 135 · Globe/Butterfly/PSV 134).
  - 판단 2: 대시보드 서버 `GET /api/pidprobe?p=<경로>` 가 같은 PC P&ID 서버에 그 경로를 물어 상태 번호만 돌려줌 → 404 면 옛 판 (minRev 없는 books · space · logic 등도). 내용은 읽지 않음. file:// 이거나 다른 PC 면 판단 1만.
- 왜: 오케스트레이터 경유 사용자 지시(2026-11-11, 회사 PC 사진) — 회사 P&ID 서버 hotfix134 에서 '6 3D 계측제어' 가 날 JSON 만 보임.
- 바뀐 곳: dashboard.html `PID_ROUTES`(minRev) · `pidConnect` · 클릭 처리(`data-pidforce`) / server.py 새 `api_pid_probe` · `api()` 의 `pidprobe`
- 확인한 것: 가짜 P&ID 서버 rev134 → ic3d · books 안내(그래도 열기 = iframe), valve · globev · psv 정상 iframe / rev135 → 다섯 메뉴 모두 iframe, 콘솔 오류 없음 / 회사에서 확인할 것: hotfix134 에서 3D 계측제어 안내, hotfix135 적용 후 정상.

### 2026-11-12 (APP_VERSION 2026-11-12.1 / SERVER_VERSION 그대로) — v17.38 Instrument Datasheet 검토 메뉴 연결
- 무엇을: 실행 프로젝트 › CO2 PJT › Datasheet 아래(Valve 4개 다음)에 **▸ Instrument** 하위 폴더(처음엔 접힘, 그 화면을 열면 자동 펼침) — 📊 현황판(`kind=all`) · FT · PT / PDT · LT · GWR · TT · TG · PG · DPG · Mag. Level Gauge · RO · Analyzer · Control Valve · On-Off Valve(`kind=ft|pt|lt|gwr|tt|tg|pg|dpg|mlg|ro|analyzer|cv|onoff`). 모두 P&ID 서버 `/valve/?embed=1&project=CO2 PJT&kind=…` (세션 6 valve40 `instrument.js` · valve.js 의 `?kind=` 처리, kind=all → Instrument 현황판). minRev 138 (그 전 판이면 v17.37 안내). 권한 = runpjt. Instrument PSV(kind=psv)는 Valve 쪽 PSV 메뉴와 키가 겹쳐 메뉴에 넣지 않음.
- 왜: 오케스트레이터 경유 사용자 지시 (Instrument Datasheet 자동 검토 화면이 세션 6 valve40 에 생김).
- 바뀐 곳: dashboard.html 새 `INST_KINDS` · `INST_ROUTES`, `PID_ROUTES`(inst · inst<kind>) · `ROUTES` · `RUN_LEAVES` · `NAV_LS`/`NAV_OPEN`(runpjt-co2-inst 처음 접힘) · `renderMenu` runTree · CSS `.minst`
- 확인한 것: 가짜 P&ID 서버 rev134 → 옛 판 안내(hotfix138), rev138 → iframe 주소 kind=all/pt/onoff, 메뉴 접힘/펼침, 콘솔 오류 없음 / 회사에서 확인할 것: hotfix138 적용 후 각 메뉴가 그 계기 종류로 열리는지.
- ⚠ 주의(통합 시): valve40 의 valve.js 는 `kind` 가 'valve' 가 아니면 모두 Instrument 화면으로 보냄 → S5 valve37 의 Globe · Butterfly · PSV 메뉴(`kind=globe|butterfly|psv`, 프로젝트 이름 접미사 방식)와 충돌. 두 판을 합칠 때 P&ID 쪽에서 구분 필요 (대시보드는 고치지 않음).

### 2026-11-12 (APP_VERSION 2026-11-12.2 / SERVER_VERSION 그대로) — v17.39 Instrument List · IO List 메뉴
- 무엇을: '▸ Instrument' 폴더에 📋 Instrument List(`kind=instindex`) · 📋 IO List(`kind=iolist`) 추가 — 순서 📊 현황판 · Instrument List · IO List · Item 13개. 같은 /valve/ 화면, minRev 138, 권한 runpjt.  왜: 오케스트레이터 경유 (세션 6 valve40 c0f4cd8c 가 Item 별 메뉴로 나누며 주소 2개 추가).
- 바뀐 곳: dashboard.html `INST_KINDS` · runTree 아이콘(`.minl`)
- 확인한 것: 가짜 P&ID rev138 에서 두 메뉴 iframe 주소 kind=instindex / iolist, 메뉴 순서, 콘솔 오류 없음 / 회사에서 확인할 것: hotfix138 적용 후 두 화면.

### 2026-11-12 (APP_VERSION 2026-11-12.3 / SERVER_VERSION 2026-11-12.1) — v17.40 CO2 PJT 현황판 · VALVE/INSTRUMENT 메뉴 · Schedule 계기 블록 (세션 6 과 합의)
- 무엇을 (세션 6 '6. Datasheet 자동 검토' 와 send_message 로 합의 · 사용자에게 샘플 사진 확인 후 적용):
  1. **메뉴**: Datasheet › ▸ VALVE (Ball · Globe · Butterfly · PSV) / ▸ INSTRUMENT (Instrument 현황판 · Instrument List · IO List · FT · Flow Transmitter … On-Off Valve — 이름 · 순서 = 세션 6 valve 페이지 왼쪽 메뉴, 긴 이름은 두 줄). PSV 는 VALVE 쪽만.
  2. **CO2 PJT 현황판**(`#co2pjt`, 사용자 지시: CO2 PJT 메뉴를 누르면 나옴 — 처음 누르면 현황판 + 폴더 펼침): Datasheet 검토 현황(VALVE 4종 Tag · 검토 완료 · 미결/Major, INSTRUMENT 13종 Tag · 지적 · 누락/불일치/검토 필요 막대 · PDS 없음, 합계에서 CV · On-Off · PSV 제외 = Valve 쪽에서 셈) + 구매 일정(PSR) 요약. 칸을 누르면 그 메뉴.
  3. **Schedule 품목 상세 계기 블록**: PSR 품목 이름으로 계기 종류(FT · PT · LT · GWR · MLG · TT · TG · PG · DPG · RO · Analyzer) → 타입(Tag 앞 글자) × Area(North · South · North/South Brownfield · W15 · Area 미상, Area 정보가 없으면 Piping Class) 수량 + Tag 검토 결과(누락 · 불일치 · 검토 필요 · PDS). **Tag ↗** = 검토 화면의 그 Tag (계기 `&sheet=<id>`, 밸브 `&ds=<id>`, `PID_ONCE`).
- 데이터: 세션 6 valve40(ec7d1548~) `/api/valve/projects/{pid}/inst/summary` · `/inst/sheets?kind=` (행에 area · unit · loc_basis 추가됨) — 대시보드 서버 `/api/vds` 중계에 두 경로 추가(+ kind 쿼리, 소문자 12자). 5분 캐시(세션 6 측정: 0.04 s 이하).
- 바뀐 곳: dashboard.html `INST_KINDS`(표기) · `PID_ONCE` · `pidUrl` · `renderPid` · 새 `HUB_VALVE` · `hubLoad` · `renderRunHub` · `instBody` · `VDS_KIND`(계기 11종) · `vdsLoad` · `vdsBlock` · runTree(`fold(…, hub)`, VALVE 폴더) · 메뉴 클릭(`data-hub`) · `ROUTES`/`RUN_LEAVES`(co2pjt) · CSS `.hb*` `.vdtag` `.minsti` / server.py `VDS_PATHS` · `api_vds_get(kind)`
- 확인한 것: 가짜 P&ID(Valve 2 프로젝트 · 계기 14종 · Area 일부 빈 값)로 현황판 · 메뉴 펼침 · Area/Piping Class 두 경우 · Tag ↗ 주소(kind=pt&sheet=0) · 콘솔 오류 없음 / 회사에서 확인할 것: hotfix138 + 대시보드 서버 재시작 후 현황판 숫자가 Instrument 현황판 · Valve Summary 와 같은지.

### 2026-11-12 (APP_VERSION 2026-11-12.4 / SERVER_VERSION 그대로) — v17.41 실제 세션 6 서버(valve40 ae484423)로 확인 · 계기 블록 버그 2개
- 무엇을: 세션 6 브랜치(ccr-efbe7e75-n915ze ae484423)를 임시 폴더에 띄우고 세션 6 시험 자료(spike/valve_inst_scenario.py, 계기 14종 × 2 Tag, 심은 오류 74/74)로 대시보드 전체를 돌려 봄 (저장소에는 병합하지 않음). 드러난 것:
  1. `/inst/sheets` 의 `counts` 이름이 `Missing` · `Mismatch` · `Review Required` (가짜 서버의 소문자와 다름) → Schedule 계기 블록의 누락 · 불일치 · 검토 필요가 늘 0 이던 것 고침 (두 꼴 모두 읽음).
  2. Tag 가 `71PT9100A` 처럼 Unit 숫자로 시작 → 타입을 못 읽어 '기타' 로 묶이던 것 고침 (앞 숫자 떼고 PT).
- 바뀐 곳: dashboard.html `instBody` (`tp` · `CK`/`cc`)
- 확인한 것: 실제 서버로 CO2 PJT 현황판(계기 13종 숫자 = /inst/summary) · Instrument 현황판 · PT 페이지(세션 6 전용 메뉴 Dashboard · Document Management · Datasheet Review · Reports & Export) · Instrument List · IO List · Ball Valve · Schedule PT 블록(71PT9100B 누락 1 · 불일치 5 · 검토 필요 1) · Tag ↗ → `kind=pt&sheet=22` 로 그 Tag 검토 화면, 콘솔 오류 없음 / 회사에서 확인할 것: 실제 Datasheet 로 Area 가 채워지는지(시험 자료는 Area 비어 Piping Class 로 나눔).

### 2026-11-12 (APP_VERSION 2026-11-12.5 / SERVER_VERSION 그대로) — v17.42 Datasheet 현황판 · Instrument List · IO List 를 Datasheet 바로 아래로
- 무엇을: 사용자 지시 "Instrument 현황판, Instrument List, IO List 는 CO2 PJT 와 Datasheet 상위 메뉴에 있어야 하고 Valve 와 Instrument 를 모두 아울러야 한다" →
  메뉴 = CO2 PJT › Datasheet › 📊 Datasheet 현황판 · 📋 Instrument List · 📋 IO List · ▸ VALVE (4) · ▸ INSTRUMENT (계기 Type 13개만).
  'Datasheet 현황판'(`#dshub`) = 대시보드 화면 (CO2 PJT 현황판의 Datasheet 부분 = VALVE 4종 + INSTRUMENT 13종, PSR 빼고). 세션 6 Instrument 현황판(kind=all)은 현황판 안 '📊 계기 상세 현황' 버튼으로.
  Instrument List · IO List 는 세션 6 화면(kind=instindex · iolist) 그대로 — Valve Tag 도 대조에 넣는 것은 세션 6 에 요청.
- 바뀐 곳: dashboard.html runTree(Datasheet 머리 3개 + INSTRUMENT 에서 all · instindex · iolist 뺌) · `renderRunHub(c, dsOnly)` · `ROUTES`/`RUN_LEAVES`(dshub) · 폴더 자동 펼침
- 확인한 것: 실제 세션 6 서버(ae484423)로 메뉴 순서 · Datasheet 현황판 · Instrument List 열림, 콘솔 오류 없음.

### 2026-11-12 (APP_VERSION 2026-11-12.6 / SERVER_VERSION 그대로) — v17.43 Instrument List · IO List 제목
- 무엇을: 두 화면 머리 제목을 'CO2 PJT · Datasheet · Instrument List / IO List' 로 (v17.42 에서 Datasheet 바로 아래로 옮김). 세션 6 1247cc8e 로 두 대조에 Valve Tag(Ball · Globe · Butterfly · PSV 최신 Rev)도 들어감 — 주소 그대로라 대시보드 변경은 제목만.
- 확인한 것: 실제 세션 6 서버(1247cc8e)로 Instrument List '대조한 Datasheet: Instrument 28 Tag · Valve 0 Tag' 표시 (시험 자료엔 Valve Datasheet 없음).

### 2026-11-12 (APP_VERSION 2026-11-12.7 / SERVER_VERSION 2026-11-12.2) — v17.44 📚 문서 · Revision 현황 (Datasheet 현황판과 같은 레벨)
- 무엇을: 사용자 지시 "CO2 의 모든 입력된 최신, 검토된 최신 Datasheet, List, PMS 의 Revision, Doc. No. 등을 한눈에 볼 수 있는 메뉴를 현황판과 같은 레벨로 · 세션 6 에 알리고 세션 6 도 맞게 동작" →
  CO2 PJT › Datasheet › 📚 문서 · Revision 현황(`#dsdocs`). 문서마다 한 줄: 구분(Datasheet · List · PMS · Process Data · Line List) · 종류 · Doc. No. · Tag · **입력된 최신 Rev**(날짜 · 파일 · 올린 날/사람) · **검토된 최신 Rev**(상태 · 날/사람) · Rev 이력(최신 = 파랑, 검토된 = 초록) · 미결 · 열기↗(그 Tag 검토 화면). 구분 칩 · ⏳ 검토 대기(입력된 최신 ≠ 검토된 최신) · 종류 · 검색 · ⬇ 엑셀.
- 세션 6 계약(send_message 로 요청): `GET /api/valve/docreg?project=CO2 PJT` → rows[{group, kind, kind_name, doc_no, title, tag, latest{rev,date,file,uploaded_at,uploaded_by}, reviewed{rev,status,reviewed_at,reviewed_by}|null, revs[], open, link{project,kind,ds|sheet}}]. 대시보드는 이것을 먼저 쓰고, 없으면(404) 간이 집계 = 프로젝트마다 `/summary`(documents · tags) + `/inst/sheets` (검토된 Rev 는 최신이 검토 완료일 때만, 화면에 '⚠ 간이 집계' 표시).
- 바뀐 곳: dashboard.html 새 `DR_GROUPS` · `drDone` · `docRegLoad` · `docRegFallback` · `drOpen` · `renderDocReg` · `drBind` · `drXlsx`, runTree(📚), `ROUTES`/`RUN_LEAVES`(dsdocs), CSS `.dr*` / server.py `VDS_PATHS`(+ docreg · projects/{id}/summary) · `api_vds_get(project)`
- 확인한 것: 실제 세션 6 서버(1247cc8e, docreg 없음 → 간이 집계)로 33건(Datasheet 28 · List 2 · PMS 1 · Process Data 1 · Line List 1) · 검토 대기 28 · 칩 필터 · 엑셀 · 열기 → `kind=dpg&sheet=6`, 콘솔 오류 없음 / 할 것: 세션 6 docreg 가 오면 실제 서버로 다시 확인.

### 2026-11-12 (APP_VERSION 2026-11-12.8 / SERVER_VERSION 그대로) — v17.45 문서 · Revision 현황이 세션 6 docreg 를 씀
- 무엇을: 세션 6 b3123fa3 의 `GET /api/valve/docreg?project=CO2 PJT` 에 맞춤 — `pending`(검토 대기) 그대로 사용, `open` 이 없으면 '-', PMS · PDS · Line List · Valve List 의 link.view(pms · proc · docs · list) → 세션 6 화면 그 메뉴로(`PID_ONCE` 에 '#view' → `pidUrl` 끝에 #), 표 머리글이 Doc. No. 칸 아래로 가려지던 것.
- 확인한 것: 실제 세션 6 서버(b3123fa3)로 33건 · 간이 집계 표시 사라짐 · 시험 Datasheet 2개 Accepted 로 바꾸니 검토된 최신 A · Accepted · 시각 표시 · 검토 대기 28 → 26 · PMS '열기' → /valve/?…&project=CO2%20PJT…#pms, 콘솔 오류 없음 / 회사에서 확인할 것: 실제 PMS · PDS · List 의 Doc. No. · Rev 가 채워지는지(시험 문서는 개정표가 없어 '-').

### 2026-11-12 (APP_VERSION 2026-11-12.9 / SERVER_VERSION 그대로) — v17.46 문서 · Revision 현황 Item 별 필터
- 무엇을: 사용자 지시 "Item 별로 필터할 수 있도록 필터 기능 추가, 6번에도 공지" → 구분 칩 아래에 **Item 칩 줄**(Ball · Globe · Butterfly · PSV · FT … On-Off · Valve List · Instrument Index · IO List · PMS · PDS · Line List 순, 개수 + 노랑 = 검토 대기 수). 누르면 그 Item 만, **여러 개 함께** 고를 수 있음, '전체' = 해제. 구분을 바꾸면 Item 선택 초기화. 예전 '종류' 드롭다운은 칩으로 바뀜. 엑셀도 필터 그대로.
- 바뀐 곳: dashboard.html `renderDocReg`(`F.ks` · `KO` 순서 · `.dri` 칩) · `drBind`(`data-dri`) · CSS
- 확인한 것: 실제 세션 6 서버(d11a0dad)로 PT + DPG + PMS 고르면 5건, PT 빼면 3건, 콘솔 오류 없음. 세션 6 에 같은 필터를 Document · Revision 화면에 넣도록 알림.

### 2026-11-13 (APP_VERSION 2026-11-13.1 / SERVER_VERSION 2026-11-13.1) — v17.47 세션 6 변경(86fc51dc ~ 49be281e) 반영
- 무엇을: 사용자 지시 "6 세션 수정된 사항 모두 확인하고 세션 1 업데이트가 필요하면 해라" → 세션 6 최신(49be281e)을 띄워 확인하고 반영:
  1. **📂 공통 자료** 메뉴(`#dsref` → `/valve/?…&kind=refdocs`, minRev 138) — Datasheet › 현황판 · 문서 · Revision 현황 다음. PDS · PMS · Line List · Instrument Index/IO List 는 여기서만 올림(6721b591).
  2. **Datasheet 현황판 / CO2 PJT 현황판**: 계기 Type 칸마다 '검토 n · 대기 n · 지적 n', 머리에 검토 완료 · 대기 · 종결 · 무시 합계(/inst/summary reviewed · pending · closed · dismissed), 아래에 **지적 분류**(categories) 막대 · **주별 검토 진행**(/inst/progress weeks: 받은 DS · 남은 지적 · 결정/종결) — 세션 6 Instrument 현황판과 같은 숫자.
  3. **Schedule 계기 블록**: Area 옆 sub_area, **Code** 열(review_code, 없으면 '제안 n' = suggested_code, 기본 코드 이름 툴팁).
  4. 간이 집계(docreg 없는 옛 판)에서 공통 자료(`shared: true`)를 프로젝트마다 다시 세지 않음.
  - counts 의 Dismissed · Closed 는 지적 수에서 이미 빠져 나오므로 대시보드 계산 변경 없음.
- 바뀐 곳: dashboard.html `PID_ROUTES.dsref` · runTree(📂) · `ROUTES`/`RUN_LEAVES` · `hubLoad`(progress) · 새 `hubExtra` · `renderRunHub` · `instBody`(sub_area · Code) · `RC_NAME` · `docRegFallback` · CSS(`.hbq*` — 홈 그래프 `.hbx` 와 이름이 겹쳐 hbq 로) / server.py `VDS_PATHS`(+ inst/progress · inst/codes)
- 확인한 것: 실제 세션 6 서버(49be281e, 시험 자료)로 공통 자료 화면(올린 문서 5개) · 현황판 분류 막대 · 주별 W46 · Schedule PT Code '제안 4 / 제안 2', 콘솔 오류 없음.

### 2026-11-13 (APP_VERSION 2026-11-13.2 / SERVER_VERSION 그대로) — v17.48 Area 이름 QN · QS · W15
- 무엇을: 세션 6 709467e3 — Area 값이 QN · QN Brownfield N1 · QN Brownfield N2 · QN Brownfield · QS · W15 로 바뀜 → Schedule Valve · 계기 블록의 Area 열 순서를 공통 `AREA_ORD`(QN → QS → W15, 예전 North · South · Brownfield 도 뒤에 남김, 'Area 미상' 맨 끝)로.
- 바뀐 곳: dashboard.html 새 `AREA_ORD` · `areaOrd`, `vdsBlock` · `instBody` 정렬
- 확인한 것: 정렬 W15 · Area 미상 · QS · QN Brownfield N2 · QN · QN Brownfield N1 → QN > QN Brownfield N1 > QN Brownfield N2 > QS > W15 > Area 미상, 콘솔 오류 없음.

### 2026-11-13 (APP_VERSION 2026-11-13.3 / SERVER_VERSION 그대로) — v17.49 Area 'QN Greenfield'
- 무엇을: 세션 6 99f26adc — Brownfield 가 아닌 QN Tag 의 Area 가 'QN' → 'QN Greenfield'. `AREA_ORD` 맨 앞에 'QN Greenfield' 추가 (순서 QN Greenfield · QN · QN Brownfield N1 · N2 · QN Brownfield · QS · W15).
- 바뀐 곳: dashboard.html `AREA_ORD`

### 2026-11-13 (APP_VERSION 2026-11-13.4 / SERVER_VERSION 그대로) — v17.50 Schedule: 지연 중만 · RFQ 알람 없음 · 일정판 접힘 · PSR 이 수기 입력 덮어씀
- 무엇을 (사용자 지시, 회사 화면 사진과 함께):
  1. **지연 중인 것만**: 구매 현황 보고에 실적이 있는(늦게 끝난) 품목은 뺌 — 묶음 제목 '지연 중 N건 (최대 +N일 · 기한 지남 N건)', 상태 필터에서 '늦게 완료함' 뺌.
  2. **RFQ = 구매 역무 → 지연 알람 없음**: 보고 묶음에서 RFQ Issue 뺌, KPI 'RFQ 지연' · 공종별 지연 표 RFQ 열 뺌, 지연 계산(fmax · flate · 설계 관리 완료)에서 RFQ 뺌, 다음 단계가 RFQ 일 때 '일정 지남' 안 띄움, 일정판 칩 RFQ 회색. CO2 PJT 현황판 PSR 요약도 MR · TBE 만.
  3. **품목별 일정판(간트) 기본 접힘** — '▸ 펼치기' / '▾ 접기' (SCH.gtOpen).
  4. **품목별 일정 표 하이라이트 = MR · TBE 발주처 · TBE 완료만** — RFQ 열 머리 회색 '구매 역무', 칸은 날짜만(색 · ⚠ 없음). 품목 상세 표 주황(SCH_FRONT)에서도 RFQ 뺌.
  5. **PSR 업로드가 수기 입력을 덮어씀** — 예전 '직접 입력 값 다시 적용할까요?' 물음 없앰, 새 파일 값 그대로(바뀐 칸은 노랑 변경 표시로 보임), 직접 입력 ● 표시 지움, 입력 기록(log) · 보고 메모(사유 · 캐치업 · 특이사항) · 글자 서식은 그대로 이어감.
- 바뀐 곳: dashboard.html `schFocus`(RFQ noAlarm) · `schCalc` · `SCH_FRONT`(RFQ 뺌) · 새 `SCH_ALARM` · KPI · 공종별 지연 표 · `fcell` · 표 머리 · 일정판(`data-gttog`, 접힌 카드) · 보고 `RPT`/`rptG`/`rptHead`/상태 필터 · `schUpload` · 팝업 · 달력 마일스톤 목록(RFQ 날짜는 그대로 보임) · 문구 'MR · TBE' · CSS
- 확인한 것: 시험 PSR 4품목(MR 지연 진행 · MR 늦게 완료 + RFQ 지연 · TBE 완료 지남 · 정상)으로 KPI(MR · TBE 제출 · TBE 완료), 보고 MR 1건(늦게 완료한 J0820 빠짐) · TBE 제출 2 · TBE 완료 4, 일정판 접힘/펼침, RFQ 칸 회색 날짜, 콘솔 오류 없음 / 회사에서 확인할 것: 실제 PSR 다시 올려 수기 입력 칸이 파일 값으로 바뀌는지(여기서는 PSR 엑셀 시험 파일이 없어 업로드는 코드 확인만).
