# MANIFEST — 36회차 출력

담긴 파일 21개

* 0_요약.md
* 1_보고서.md
* 2_progress.md
* 3_type_map.md
* 4_gatekeeper.md
* 5_unit_token.md
* 6_delete.md
* 7_remaining.md
* 8_regression_4p.json
* 8_regression_4p_start.json
* 8_regression_4p_BC.json
* 8_regression_4p_E1.json
* 8_regression_4p_E2.json
* 기록/unit_token_survey.json
* 기록/unit_format_probe.json
* 기록/b2_anchors_probe.json
* 기록/lists.json
* 기록/order_swap.json
* 기록/synthetic_runs.json
* 사전조사/round36_multiplier_vocab.md
* 9_캡처/README.md

## 뺀 것

* 네 프로젝트 결과 json 전문 (`out/regression_3p/*.json`) — 행 내용이 들어 있다
* 발주처 도면·리스트 (`data/`, `app/_data/`)
* 35회차 worktree (`/tmp/r35_strip`) — [B-2] 탐침에 다시 썼다 · 남겨 둔다
