계장도서검토 (S5) — 회사 PC 배포 꾸러미 2026-10-24.1 (2026-11-07)

내용
  new\apps\books\index.html      화면 + 검색 엔진 + 계장 용어 사전 (한 파일, 외부 의존성 없음)
  new\apps\books\kb.js           발전·플랜트 계장 지식 베이스 + 학습 지식 노트
  new\apps\books\vendor\pdf.min.js, pdf.worker.min.js   pdf.js 3.11.174 (Apache-2.0, 파일로 포함)
  new\apps\books\INTEGRATION.md  DASHBOARD 연결 안내 (server.py · dashboard.html 고칠 곳)
  new\books_api.py                공용 도서관 API — Python 3.11 표준 라이브러리만
  APPLY.bat                        위 파일을 DASHBOARD 설치 폴더에 복사

적용
  1) zip 을 풀고 APPLY.bat "C:\Claude\계장ENG그룹 주간업무 Dashboard" 실행 (경로는 실제 설치 위치)
  2) S1 DASHBOARD 담당이 INTEGRATION.md 2장대로 server.py(books_api 연결) · dashboard.html(APP_ROUTES 에 books) 수정 후 server.py 재시작
  3) 대시보드 메뉴 '계장도서검토' → [📚 도서관] 에서 운영자가 서버 PC 의 도서 폴더 경로 지정 → 색인 → 부서원 검색

주의
  - 번역의 Claude 엔진은 기본 꺼짐. 켜려면 운영자가 books/config.json 에 API 키를 넣는다 (배포물에 키 없음). 브라우저 내장 번역·용어 풀이는 키 없이 동작.
  - 자동 검색·설명·학습 지식은 참고용이며 사람 검토 전 확정본이 아니다.
