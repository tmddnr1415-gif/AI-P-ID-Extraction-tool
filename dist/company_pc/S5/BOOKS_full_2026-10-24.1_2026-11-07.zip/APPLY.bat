@echo off
chcp 65001 >nul
REM 계장도서검토(S5) 회사 PC 적용 — DASHBOARD 설치 폴더 안에 apps\books 와 books_api.py 를 복사합니다.
REM 사용법: APPLY.bat "C:\Claude\계장ENG그룹 주간업무 Dashboard"   (인수가 없으면 이 bat 가 있는 폴더의 상위를 대시보드 폴더로 봅니다)
setlocal
set "DST=%~1"
if "%DST%"=="" set "DST=%~dp0.."
if not exist "%DST%\server.py" (
  echo [오류] "%DST%" 에 server.py 가 없습니다. DASHBOARD 설치 폴더를 인수로 주세요.
  pause & exit /b 1
)
echo 대상: %DST%
if exist "%DST%\apps\books" (
  if not exist "%DST%\apps\books_backup_%date:~0,4%%date:~5,2%%date:~8,2%" xcopy /E /I /Q /Y "%DST%\apps\books" "%DST%\apps\books_backup_%date:~0,4%%date:~5,2%%date:~8,2%" >nul
)
xcopy /E /I /Q /Y "%~dp0new\apps\books" "%DST%\apps\books" >nul || goto :fail
copy /Y "%~dp0new\books_api.py" "%DST%\books_api.py" >nul || goto :fail
echo 완료: apps\books (index.html · kb.js · vendor\pdf.js) · books_api.py 복사됨.
echo 남은 일(S1 DASHBOARD 쪽): server.py 에 books_api 연결 + dashboard.html APP_ROUTES 에 books 메뉴 추가 (new\apps\books\INTEGRATION.md 2장) 후 server.py 재시작.
pause
exit /b 0
:fail
echo [오류] 복사에 실패했습니다. 대시보드 서버(server.py)가 파일을 쓰고 있으면 멈춘 뒤 다시 실행하세요.
pause
exit /b 1
