/* Valve Datasheet Review — screen.  Data: /api/valve/* (app/valve/api.py).
 * Screens: Dashboard · Document Management · Valve List · Datasheet Review · Revision Comparison ·
 *          Process Data Verification · PMS Compliance · Reports & Export · Settings.
 * Everything shown comes from the server, except the Process Data / PMS reference values, which are
 * MOCK until the Phase 3 / 4 engines exist — those are labelled MOCK wherever they appear. */
(() => {
'use strict';
const Q = new URLSearchParams(location.search);
// valve37 — one screen for every valve kind: ?kind=globe|butterfly|psv opens the project '<project> · <Kind>' (its own
// uploads · Process Data · review), the Ball menu (no kind) works exactly as before.
const KIND_NAMES = { ball: 'Ball Valve', globe: 'Globe Valve', butterfly: 'Butterfly Valve', psv: 'PSV' };
const VKIND = KIND_NAMES[(Q.get('kind') || '').toLowerCase()] ? (Q.get('kind') || '').toLowerCase() : 'ball';
const KIND_NAME = KIND_NAMES[VKIND];
function wantProject() {
  const p = Q.get('project');
  if (VKIND === 'ball') return p;
  const base = (p || 'CO2 PJT').replace(/\s*·\s*(Globe Valve|Butterfly Valve|PSV)$/, '');
  return `${base} · ${KIND_NAME}`;
}
{ const cb = document.querySelectorAll('#crumb b'); if (cb.length > 1) cb[cb.length - 1].textContent = KIND_NAME;
  if (VKIND !== 'ball') document.title = `${KIND_NAME} Datasheet Review`; }
const LS = {
  get(k, d) { try { const v = localStorage.getItem('valve.' + k); return v === null ? d : JSON.parse(v); } catch (_) { return d; } },
  set(k, v) { try { localStorage.setItem('valve.' + k, JSON.stringify(v)); } catch (_) {} },
};
const USER = Q.get('user') || LS.get('user', '');
const EMBED = Q.get('embed') === '1';
/* valve29 — new windows, live-linked.  Windows of the same browser talk over a BroadcastChannel: no server round-trip, no
   polling.  A window follows another's tag / field / finding while its '연동' (link) switch is on, and refreshes what a
   decision or edit changed.  POP = 'pdf' is the light PDF-only window for a second monitor. */
const POP = Q.get('pop') || '';
const BUS = 'BroadcastChannel' in window ? new BroadcastChannel('valve-link') : null;
const WIN_ID = Math.random().toString(36).slice(2);
let LINKING = false;                                       // applying a message from another window: do not echo it back
const linkOn = () => LS.get('linkon', 1) === 1;
function link(m) { if (BUS && !LINKING && linkOn() && typeof S !== 'undefined' && S.pid) BUS.postMessage({ ...m, from: WIN_ID, pid: S.pid }); }
function popOut(kind) {                                    // ⧉ — the PDF alone, or this view, in its own window
  const u = new URL(location.href); u.hash = kind === 'pdf' ? '' : '#' + S.view;
  if (kind === 'pdf') { u.searchParams.set('pop', 'pdf'); if (S.ds) u.searchParams.set('ds', S.ds.id); } else { u.searchParams.delete('pop'); u.searchParams.delete('ds'); }
  const w = window.open(u.toString(), kind === 'pdf' ? 'valve-pop-pdf' : 'valve-' + Date.now(), 'popup=yes,width=1100,height=900');
  if (!w) toast('새 창이 막혔습니다 — 브라우저의 팝업 허용을 켜 주세요', 1); else w.focus();
}
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const cls = s => String(s || 'none').replace(/[^A-Za-z]/g, '');
const pill = (s, label) => `<span class="pill p-${cls(s)}">${esc(label ?? s)}</span>`;

const MOCK = '<span class="mock" title="예시 데이터 — 실제 판정이 아닙니다. 판정에 쓰지 마세요">DEMO DATA</span>';

async function api(method, path, body, raw) {
  const opt = { method, headers: { 'X-Author': encodeURIComponent(USER || '') } };
  if (body instanceof FormData) opt.body = body;
  else if (body !== undefined) { opt.body = JSON.stringify(body); opt.headers['Content-Type'] = 'application/json'; }
  if (method !== 'GET') { PRE.clear(); S.wgen = (S.wgen || 0) + 1; }   // any write: forget prefetched datasheets · lists
  let r;
  try { r = await fetch('/api/valve' + path, opt); } catch (e) { throw new Error('서버에 닿지 못했습니다 — P&ID 서버(8000)가 켜져 있는지 확인하세요'); }
  if (method !== 'GET' && r.ok) { const m = path.match(/^\/datasheets\/(\d+)/); link({ t: 'changed', id: m ? +m[1] : null }); }   // other windows refresh
  const why = j => (j.error || j.detail || '') + (j.log ? ` — 기록: ${j.log}` : '');   // valve37: the server's reason, not a bare status
  const fail = (j, m) => { const e = new Error(m); e.data = j; return e; };            // valve38: the screen can read code · diag
  if (raw) { if (!r.ok) { const j = await r.json().catch(() => ({})); throw fail(j, why(j) || `HTTP ${r.status}`); } return r; }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw fail(j, why(j) || `HTTP ${r.status}${r.status >= 500 ? ' — P&ID 서버 창(검은 창)의 마지막 글을 보내 주세요' : ''}`);
  if (j && j.review_error && !api.warned?.[path]) { (api.warned ||= {})[path] = 1; setTimeout(() => toast(`이 Tag 의 검토 계산에 실패해 지적 없이 열었습니다 — ${j.review_error}${j.review_error_log ? ' · 기록: ' + j.review_error_log : ''}`, 1), 50); }
  return j;
}
function toast(msg, bad) {
  const t = $('#toast'); t.textContent = msg; t.className = 'on' + (bad ? ' bad' : '');
  clearTimeout(toast.t); toast.t = setTimeout(() => { t.className = ''; }, bad ? 6000 : 2600);
}
/* valve29 — every dialog can be moved (drag the title) and resized (drag the lower-right corner).  With a key, the dialog
   opens where and as big as it was left last time (e.g. the comment editor). */
function placeModal(key) {
  const box = $('.mbox'), st = key ? LS.get('mpos.' + key, null) : null;
  box.style.position = box.style.left = box.style.top = box.style.margin = box.style.height = '';
  if (!box.style.width || !box.dataset.keepw) box.style.width = '';
  if (st) { Object.assign(box.style, { position: 'fixed', margin: '0', left: Math.max(0, Math.min(innerWidth - 120, st.x)) + 'px',
    top: Math.max(0, Math.min(innerHeight - 60, st.y)) + 'px', width: Math.min(st.w, innerWidth - 8) + 'px', height: Math.min(st.h, innerHeight - 8) + 'px' });
    requestAnimationFrame(keepOnScreen); }
  box.dataset.mkey = key || '';
}
function keepOnScreen() {                               // the whole dialog (and its buttons) stays visible
  const box = $('.mbox'); if (box.style.position !== 'fixed') return;
  const r = box.getBoundingClientRect();
  if (r.bottom > innerHeight) box.style.top = Math.max(0, innerHeight - r.height - 4) + 'px';
  if (r.right > innerWidth) box.style.left = Math.max(0, innerWidth - r.width - 4) + 'px';
}
function saveModal() {
  keepOnScreen();
  const box = $('.mbox'), key = box.dataset.mkey; if (!key) return;
  const r = box.getBoundingClientRect(); LS.set('mpos.' + key, { x: Math.round(r.left), y: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height) });
}
function modalDrag() {
  const t = document.getElementById('mTitle'); if (!t) return;
  t.addEventListener('pointerdown', e => {
    if (e.button !== 0) return;
    const box = $('.mbox'), r = box.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top;
    Object.assign(box.style, { position: 'fixed', margin: '0', left: r.left + 'px', top: r.top + 'px', width: r.width + 'px' });
    const mv = ev => { box.style.left = Math.max(0, Math.min(innerWidth - 80, ev.clientX - dx)) + 'px'; box.style.top = Math.max(0, Math.min(innerHeight - 40, ev.clientY - dy)) + 'px'; };
    const up = () => { removeEventListener('pointermove', mv); removeEventListener('pointerup', up); saveModal(); };
    addEventListener('pointermove', mv); addEventListener('pointerup', up); e.preventDefault();
  });
  new ResizeObserver(() => { const box = $('.mbox'); if (box && !$('#modal').hidden && box.style.position === 'fixed') saveModal(); }).observe($('.mbox'));
}
modalDrag();
function modal(title, html, buttons, key) {
  return new Promise(res => {
    placeModal(key);
    $('#mTitle').textContent = title; $('#mBody').innerHTML = html; $('#mAct').innerHTML = '';
    for (const [label, val, pri] of buttons) {
      const b = document.createElement('button'); b.textContent = label; if (pri) b.className = 'pri';
      b.onclick = () => { $('#modal').hidden = true; res(val === 'form' ? Object.fromEntries($$('#mBody [name]').map(i => [i.name, i.value])) : val); };
      $('#mAct').append(b);
    }
    $('#modal').hidden = false;
    const f = $('#mBody input, #mBody textarea'); if (f) setTimeout(() => f.focus(), 30);
  });
}
/* valve29 — engineer decision on a finding: decision · reason category · reason · conclusion (Modified: wording · severity).
   The decision maps onto the old status server-side; Open / Resolved stay plain status changes. */
const DECIDE = ['Open', 'Confirmed', 'Modified', 'Dismissed', 'Deferred', 'Not Applicable', 'Resolved'];
const REASONS = ['Project Specification Exception', 'Vendor Clarification', 'Incorrect Rule Logic', 'Incorrect Data Extraction', 'Not Applicable', 'Duplicate Finding', 'Other'];
const NEEDS_REASON = new Set(['Dismissed', 'Not Applicable', 'Modified']);
const ISSKEYS = ['no', 'tag', 'doc_no', 'rev', 'sheet', 'page', 'field', 'value', 'type', 'description', 'expected', 'severity', 'status'];
const ISSCOLS = { no: i => i.no, tag: i => i.tag, doc_no: i => i.doc_no, rev: i => i.rev, sheet: i => i.sheet ? `${i.sheet} of ${i.of || ''}` : '', page: i => i.page,
  field: i => i.field, value: i => i.value || '(blank)', type: i => i.type, description: i => i.description, expected: i => i.expected, severity: i => i.severity, status: i => decShown(i) };
const decShown = i => i.status === 'Resolved' ? 'Resolved' : (i.decision && DECIDE.includes(i.decision) ? i.decision : i.status);
const decSelect = (attr, i) => `<select ${attr} aria-label="engineer decision" title="Engineer Decision${i.reason_cat ? ' · ' + esc(i.reason_cat) : ''}${i.conclusion ? ' · ' + esc(i.conclusion) : ''}">${DECIDE.map(x => `<option ${x === decShown(i) ? 'selected' : ''}>${x}</option>`).join('')}</select>`;
async function askDecision(choice, n = 1, issue = null) {
  if (choice === 'Open') return { status: 'Open', note: '' };
  if (choice === 'Resolved') { const r = await modal(`Resolved${n > 1 ? ` × ${n}건` : ''} — 설계사가 고침`, '<input name="note" placeholder="예) Rev B 에서 값 보완">', [['취소', null], ['저장', 'form', 1]]); return r ? { status: 'Resolved', note: r.note || '' } : null; }
  const need = NEEDS_REASON.has(choice);
  const html = `<label class="dfl"><span>사유 분류${need ? ' <b style="color:var(--bad)">*</b>' : ''}</span><select name="reason_cat"><option value="">${need ? '— 골라 주세요 —' : '(선택 안 함)'}</option>${REASONS.map(x => `<option ${choice === 'Not Applicable' && x === 'Not Applicable' ? 'selected' : ''}>${x}</option>`).join('')}</select></label>
    <label class="dfl"><span>사유</span><input name="note" placeholder="예) Project spec 3.2 에 따라 허용 / Vendor 회신 확인"></label>
    <label class="dfl"><span>최종 결론 <span class="soft">(선택)</span></span><input name="conclusion" placeholder="예) Vendor 에 PEEK 시트 요청"></label>
    ${choice === 'Modified' ? `<label class="dfl"><span>고친 지적 문구</span><textarea name="modified_text" rows="3">${esc(issue?.original_description || issue?.description || '')}</textarea></label>
      <label class="dfl"><span>Severity</span><select name="modified_severity">${['Major', 'Minor', 'Info'].map(x => `<option ${x === (issue?.severity) ? 'selected' : ''}>${x}</option>`).join('')}</select></label>` : ''}
    <p class="soft hint">Dismissed 는 규칙이 틀렸다는 뜻이 아닐 수 있습니다 — 사유 분류가 Rule Performance 에 그대로 쓰입니다.</p>`;
  const r = await modal(`${choice}${n > 1 ? ` × ${n}건` : ''} — Engineer Decision`, html, [['취소', null], ['저장', 'form', 1]], 'decision');
  if (!r) return null;
  if (need && !r.reason_cat) { toast('사유 분류를 골라 주세요', 1); return null; }
  return { decision: choice, reason_cat: r.reason_cat || '', note: r.note || '', conclusion: r.conclusion || '', modified_text: r.modified_text || '', modified_severity: r.modified_severity || '' };
}
/* Issue Type picker — shown before every contractor export (Issue List Excel · Mark-up PDF). The last choice is kept. */
const TYPE_KO = { 'Data Missing': '누락 · 빈 값', 'Open Item': 'HOLD / TBC', 'Data Error': '데이터 오류', 'PMS Non-Compliance': 'PMS 부적합',
  'PMS Review': 'PMS 확인', 'Process Mismatch': 'Process Data 불일치', 'Material Review': '재질 검토', 'Valve Review': '설계 · 다른 DS 대비 검토',
  'Revision Change': 'Revision 변경', 'Reviewer Correction': '검토자 수정', 'Reviewer Comment': '검토자 의견', 'Extraction Review': '도구 내부 확인 (설계사용 아님)' };
/* valve31 — 코멘트 언어: 화면 표시(clang) 와 출력(outlang) 따로.  en · ko · both.  한글은 서버가 규칙별 고정 문장으로 붙임(description_ko) */
const clang = () => LS.get('clang', 'both'), outLang = () => LS.get('outlang', 'en');
const descText = i => { const ko = i.description_ko, l = clang(); return l === 'ko' ? (ko || i.description) : l === 'both' && ko ? `${i.description}\n${ko}` : i.description; };
const descHTML = i => { const ko = i.description_ko, l = clang(); if (l === 'ko') return esc(ko || i.description);
  return esc(i.description) + (l === 'both' && ko ? `<div class="dko">${esc(ko)}</div>` : ''); };
const LANGS = [['en', 'English'], ['ko', '한국어'], ['both', 'English + 한국어']];
const pdfq = () => { const o = LS.get('pdfopt', { margin: 1, flatten: 1 }); return `&margin=${o.margin ? 1 : 0}&flatten=${o.flatten ? 1 : 0}`; };   // valve25
async function loadIssues() {                      // valve29: compact list — per-datasheet fields sent once, merged here
  const r = await api('GET', `/projects/${S.pid}/issues?compact=1`);
  for (const i of r.issues) Object.assign(i, r.ds[i.ds_id]);
  return r;
}
async function pickTypes(title, { tag = '', preset = null, note = '', pdf = /PDF/.test(title) } = {}) {
  const r = S.issues && S.issueTypes ? { issues: S.issues, types: S.issueTypes } : await loadIssues();
  const live = r.issues.filter(i => i.status !== 'Dismissed' && (!tag || i.tag === tag));
  const cnt = t => live.filter(i => i.type === t).length;
  const contractor = r.types.filter(t => t !== 'Extraction Review');
  const saved = LS.get('xtypes', null);
  const on = new Set(preset || saved || contractor);
  const row = t => `<label class="tp ${cnt(t) ? '' : 'zero'}"><input type="checkbox" data-ty="${esc(t)}" ${on.has(t) ? 'checked' : ''}> <b>${esc(t)}</b>
      <span class="soft">${esc(TYPE_KO[t] || '')}</span><span class="n">${cnt(t)}</span></label>`;
  const html = `${note ? `<p class="soft">${esc(note)}</p>` : ''}<div class="tpbar"><button type="button" data-tpall="1">전체</button><button type="button" data-tpall="0">모두 끄기</button>
      <button type="button" data-tpdef="1">설계사용 기본</button><span class="sp"></span><span id="tpsum" class="soft"></span></div>
    <div class="tplist">${r.types.map(row).join('')}</div><p class="soft" style="margin:6px 0 0">Dismissed 는 넣지 않습니다. 고른 종류는 다음 출력 때도 그대로 기억합니다.</p>
    <div class="olang"><b>코멘트 언어</b>${LANGS.map(([k, l]) => `<label><input type="radio" name="olang" value="${k}" ${outLang() === k ? 'checked' : ''}> ${l}</label>`).join('')}
      <span class="soft">· 한글은 규칙별 고정 문장 · 검토자가 쓴 코멘트는 쓴 그대로</span></div>
    <label class="olang" style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="poG" style="width:auto;flex:none;margin:0" ${LS.get('outgroup', 1) ? 'checked' : ''}> <b style="white-space:nowrap">코멘트 정리</b><span class="soft">— PDF: 한 쪽에 붙어 있는 Data Missing 을 한 박스 · 한 코멘트로 · Excel: 맨 앞에 'Comments (Typical)' 시트 (같은 코멘트는 Tag 를 모아 한 줄) · 낱개 목록도 그대로 들어감</span></label>
    ${pdf ? (o => `<div style="margin-top:8px;padding-top:6px;border-top:1px solid var(--line,#e3e6ec);display:grid;gap:4px">
      <label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="poM" style="width:auto;flex:none;margin:0" ${o.margin ? 'checked' : ''}> <b style="white-space:nowrap">코멘트를 쪽 옆에 인쇄</b><span class="soft">— 번호마다 지적 · 검토자 의견이 그 쪽 오른쪽에</span></label>
      <label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="poF" style="width:auto;flex:none;margin:0" ${o.flatten ? 'checked' : ''}> <b style="white-space:nowrap">마크업 고정</b><span class="soft">— 어느 뷰어 · 인쇄에서도 화면 그대로 (끄면 Acrobat 에서 고칠 수 있는 주석)</span></label></div>`)(LS.get('pdfopt', { margin: 1, flatten: 1 })) : ''}`;
  const done = modal(title, html, [['취소', null], ['만들기', 'go', 1]]);
  const box = $('#mBody'), sum = () => { const ts = $$('input[data-ty]:checked', box).map(x => x.dataset.ty);
    $('#tpsum', box).textContent = `${ts.length}종 · ${ts.reduce((a, t) => a + cnt(t), 0)}건`; const b = [...$$('#mAct button')].pop(); if (b) b.disabled = !ts.length; };
  box.onclick = e => { const a = e.target.closest('[data-tpall]'), d = e.target.closest('[data-tpdef]');
    if (a) $$('input[data-ty]', box).forEach(x => { x.checked = a.dataset.tpall === '1'; });
    if (d) $$('input[data-ty]', box).forEach(x => { x.checked = contractor.includes(x.dataset.ty); });
    sum(); };
  box.onchange = sum; sum();
  const res = await done;
  box.onclick = box.onchange = null;
  if (res !== 'go') return null;
  const ts = $$('input[data-ty]:checked', box).map(x => x.dataset.ty);
  if (!preset) LS.set('xtypes', ts);
  const ol = $('input[name="olang"]:checked', box); if (ol) LS.set('outlang', ol.value);
  if ($('#poG', box)) LS.set('outgroup', $('#poG', box).checked ? 1 : 0);
  if (pdf) LS.set('pdfopt', { margin: $('#poM', box).checked ? 1 : 0, flatten: $('#poF', box).checked ? 1 : 0 });
  return ts.join(',');
}
function chunkRows(tbody, rows, first = 80, empty = '') {    // 80 rows ≈ one screen; the rest never blocks a keystroke   // big tables: first rows now, the rest in idle batches (no freeze)
  const html = (a, b) => rows.slice(a, b).map(x => typeof x === 'function' ? x() : x).join('');   // valve26: rows may be lazy builders
  if (!tbody) return;
  const wrap = tbody.closest('.xg-wrap, .vscroll');
  if (wrap && rows.length > 400) return virtualRows(tbody, wrap, rows, html);   // valve29: big grids draw only what is in view
  tbody.innerHTML = rows.length ? html(0, first) : empty; let i = first;
  const idle = window.requestIdleCallback || (f => setTimeout(f, 0));
  const more = dl => {                                // valve29: fill the idle time, then yield — fast and never a long freeze
    if (!tbody.isConnected) return;
    do { if (i >= rows.length) return; const e = Math.min(i + 40, rows.length); tbody.insertAdjacentHTML('beforeend', html(i, e)); i = e; }
    while (dl && dl.timeRemaining && dl.timeRemaining() > 12);
    idle(more);
  };
  if (i < rows.length) idle(more);
}
/* valve29 — virtual rows for the Excel-like grids (one-line rows, table-layout fixed).  With thousands of rows in the page the
   browser re-laid out the whole table on every insert (500 DS issue list: 0.6–0.7 s per step).  Only the rows in view
   (+ a margin) exist; two spacer rows keep the scroll bar and the sticky header / columns exactly as before. */
const VR_H = {};                            // measured row height per grid: re-draws skip the measuring pass
function virtualRows(tbody, wrap, rows, html) {
  const n = rows.length, OVER = 20, tid = tbody.closest('table')?.id || '';   // valve29: 20-row margin is enough at 60 fps scroll
  const ncol = tbody.closest('table')?.tHead?.rows[0]?.cells.length || 1;
  const sp = h => `<tr class="vsp" aria-hidden="true"><td colspan="${ncol}" style="height:${Math.max(0, Math.round(h))}px;padding:0;border:0"></td></tr>`;
  let rh = VR_H[tid] || 22, a = 0, b = 0;
  const paint = force => {
    if (!tbody.isConnected) return;
    const headH = tbody.closest('table')?.tHead?.offsetHeight || 0;
    const top = Math.max(0, wrap.scrollTop - headH), vs = Math.floor(top / rh), ve = Math.min(n, vs + Math.ceil(wrap.clientHeight / rh) + 1);
    if (!force && vs >= a && ve <= b) return;
    a = Math.max(0, vs - OVER); b = Math.min(n, ve + OVER);
    tbody.innerHTML = sp(a * rh) + html(a, b) + sp((n - b) * rh);
  };
  paint(true);
  const real = VR_H[tid] ? [] : [...tbody.rows].filter(r => !r.classList.contains('vsp'));      // measure the real row height once per grid
  if (real.length) {
    const h = (real[real.length - 1].offsetTop + real[real.length - 1].offsetHeight - real[0].offsetTop) / real.length;
    if (h > 4 && Math.abs(h - rh) > 0.5) { rh = h; VR_H[tid] = h; paint(true); }
  }
  let raf = 0;
  if (wrap._vr) wrap.removeEventListener('scroll', wrap._vr);
  wrap._vr = () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; paint(false); }); };
  wrap.addEventListener('scroll', wrap._vr, { passive: true });
}
async function download(path, method = 'GET', body) {
  if (/\/(issues\.xlsx|markup\.pdf)(\?|$)/.test(path) && !/[?&]lang=/.test(path)) path += (path.includes('?') ? '&' : '?') + 'lang=' + outLang();   // valve31
  if (/\/(issues\.xlsx|markup\.pdf)(\?|$)/.test(path) && !/[?&]group=/.test(path) && LS.get('outgroup', 1)) path += '&group=1';   // valve35: Typical · block
  const r = await api(method, path, body, true);
  const cd = r.headers.get('Content-Disposition') || '';
  const m = cd.match(/filename\*=UTF-8''([^;]+)/) || cd.match(/filename=([^;]+)/);
  const name = m ? decodeURIComponent(m[1]) : 'download';
  const url = URL.createObjectURL(await r.blob());
  const a = document.createElement('a'); a.href = url; a.download = name; document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  r.filename = name;
  return r;
}

/* ── state ─────────────────────────────────────────────────────────────── */
const S = { pid: null, projects: [], sum: null, grid: null, ds: null, dsId: null, view: 'dash', compare: null };
const COLL = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });
/* valve29 — Excel-style column filter on every list (▾ in a column header): values with counts · search · sort A→Z / Z→A ·
   (Select All) · Clear.  Big lists filter their DATA (xfApply: virtual / batched rows filter every row at once); small
   tables that are drawn whole are decorated automatically (xfDom) — dashboard cards, documents, rules, revision rows … */
const XF = {}, XFR = {};                    // key -> {f: {col: Set | null}, s: {k, d} | null} · key -> {rows, cols, redraw}
const xfState = key => XF[key] ||= { f: {}, s: null };
const xfVal = (g, r) => { const v = g(r); return v == null || String(v).trim() === '' ? '(Blanks)' : String(v).trim(); };
function xfApply(key, rows, cols, redraw) {
  XFR[key] = { rows, cols, redraw };
  const st = xfState(key);
  for (const k of Object.keys(st.f)) if (!cols[k]) delete st.f[k];
  const act = Object.entries(st.f).filter(([, v]) => v);
  let out = act.length ? rows.filter(r => act.every(([k, set]) => set.has(xfVal(cols[k], r)))) : rows;
  if (st.s && cols[st.s.k]) {                 // sort the distinct values once (collator), then rows by rank (integers): 17k rows ≈ 20 ms
    const g = cols[st.s.k], d = st.s.d, kv = out.map(r => xfVal(g, r));
    const rank = new Map([...new Set(kv)].sort((a, b) => a === '(Blanks)' ? 1 : b === '(Blanks)' ? -1 : COLL.compare(a, b)).map((v, n) => [v, n]));
    const idx = out.map((_, n) => n).sort((a, b) => d * (rank.get(kv[a]) - rank.get(kv[b])) || a - b);
    out = idx.map(n => out[n]);
  }
  return out;
}
function xfBtn(key, k) {
  const st = xfState(key), on = !!st.f[k], so = st.s?.k === k;
  return `<button class="xfb ${on ? 'on' : ''}" data-xf="${esc(key)}" data-xk="${esc(k)}" title="필터 · 정렬 (Excel 처럼)">${so ? (st.s.d > 0 ? '↑' : '↓') : ''}▾</button>`;
}
function xfMark(key) {                       // after a rows-only redraw: the header buttons show what is filtered / sorted
  const st = xfState(key);
  $$(`.xfb[data-xf="${CSS.escape(key)}"]`).forEach(b => { const k = b.dataset.xk; b.classList.toggle('on', !!st.f[k]); b.textContent = (st.s?.k === k ? (st.s.d > 0 ? '↑' : '↓') : '') + '▾'; });
}
function xfClear(key) { XF[key] = { f: {}, s: null }; }
const xfActive = key => !!XF[key] && (Object.values(XF[key].f).some(Boolean) || !!XF[key].s);
function xfPop(btn) {
  xfClose();
  const key = btn.dataset.xf, k = btn.dataset.xk, R = XFR[key]; if (!R?.cols[k]) return;
  const st = xfState(key), g = R.cols[k];
  const others = Object.entries(st.f).filter(([c, v]) => v && c !== k && R.cols[c]);          // like Excel: values left by the OTHER filters
  const base = others.length ? R.rows.filter(r => others.every(([c, set]) => set.has(xfVal(R.cols[c], r)))) : R.rows;
  const cnt = new Map(); for (const r of base) { const v = xfVal(g, r); cnt.set(v, (cnt.get(v) || 0) + 1); }
  const vals = [...cnt.keys()].sort((a, b) => a === '(Blanks)' ? 1 : b === '(Blanks)' ? -1 : COLL.compare(a, b));
  const cur = st.f[k], sel = new Set(cur ? vals.filter(v => cur.has(v)) : vals);
  const box = document.createElement('div'); box.className = 'xfpop';
  box.innerHTML = `<div class="xfs"><button data-s="1">↑ 오름차순</button><button data-s="-1">↓ 내림차순</button></div>
    <input type="search" placeholder="검색" class="xfq"><label class="xfall"><input type="checkbox"> (모두 선택)</label><div class="xfl"></div>
    <div class="xfa"><button class="xfc" title="이 열의 필터 · 정렬 지우기">지우기</button><span class="sp"></span><button class="xfx">취소</button><button class="pri xfok">확인</button></div>`;
  document.body.append(box);
  const r = btn.getBoundingClientRect(); box.style.left = Math.max(6, Math.min(innerWidth - 276, r.left - 120)) + 'px'; box.style.top = Math.min(innerHeight - 380, r.bottom + 4) + 'px';
  const list = $('.xfl', box), all = $('.xfall input', box), q = $('.xfq', box);
  let shown = vals;
  const paint = () => {
    const t = q.value.trim().toLowerCase(); shown = t ? vals.filter(v => v.toLowerCase().includes(t)) : vals;
    const lab = (a, b) => shown.slice(a, b).map((v, n) => `<label><input type="checkbox" data-n="${a + n}" ${sel.has(v) ? 'checked' : ''}> <span>${esc(v)}</span> <small>${cnt.get(v)}</small></label>`).join('');
    const tail = (shown.length > 1500 ? `<div class="soft">… ${shown.length - 1500}개 더 — 검색으로 좁히세요</div>` : '') + (shown.length ? '' : '<div class="soft">없음</div>');
    list.innerHTML = lab(0, 120) + (shown.length <= 120 ? tail : '');            // what the box shows now; the rest a moment later
    clearTimeout(list._t); if (shown.length > 120) list._t = setTimeout(() => { if (list.isConnected) list.insertAdjacentHTML('beforeend', lab(120, 1500) + tail); }, 30);
    all.checked = shown.length > 0 && shown.every(v => sel.has(v));
  };
  paint(); q.focus();
  q.oninput = () => { clearTimeout(q._t); q._t = setTimeout(() => { if (q.value.trim()) { sel.clear(); vals.filter(v => v.toLowerCase().includes(q.value.trim().toLowerCase())).forEach(v => sel.add(v)); } else vals.forEach(v => sel.add(v)); paint(); }, 60); };
  list.onchange = e => { const v = shown[+e.target.dataset.n]; if (v === undefined) return; e.target.checked ? sel.add(v) : sel.delete(v); all.checked = shown.every(x => sel.has(x)); };
  all.onchange = () => { shown.forEach(v => all.checked ? sel.add(v) : sel.delete(v)); paint(); };
  const done = () => { xfClose(); R.redraw(); xfMark(key); };
  $('.xfs', box).onclick = e => { const b = e.target.closest('[data-s]'); if (!b) return; st.s = { k, d: +b.dataset.s }; done(); };
  $('.xfc', box).onclick = () => { st.f[k] = null; if (st.s?.k === k) st.s = null; done(); };
  $('.xfx', box).onclick = xfClose;
  const ok = () => { st.f[k] = sel.size === vals.length ? null : new Set(sel); done(); };
  $('.xfok', box).onclick = ok;
  box.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); ok(); } else if (e.key === 'Escape') { e.stopPropagation(); xfClose(); } };
}
function xfClose() { $$('body > .xfpop').forEach(x => x.remove()); }
document.addEventListener('click', e => {                    // capture: a header ▾ never sorts / drags / opens the card behind it
  const b = e.target.closest('.xfb');
  if (b) { e.stopPropagation(); e.preventDefault(); const open = $('body > .xfpop'); if (open && open._b === b) { xfClose(); return; } xfPop(b); const p = $('body > .xfpop'); if (p) p._b = b; return; }
  if (!e.target.closest('.xfpop')) xfClose();
}, true);
/* tables drawn whole (≤ 3000 rows, not a data-filtered list): ▾ on each header, filter = hide rows, sort = reorder rows */
function xfDom(table) {
  if (table.dataset.xfd || table.closest('.xfpop') || table.querySelector('thead .xfb')) return;
  const tb = table.tBodies[0], hr = table.tHead?.rows[table.tHead.rows.length - 1]; if (!tb || !hr || tb.rows.length > 3000) return;
  table.dataset.xfd = '1';
  const view = table.closest('.view, .card.big, .mbox')?.id || table.closest('.card')?.querySelector('h3')?.textContent || 'x';
  const heads = [...hr.cells], key = 'dom:' + view + ':' + heads.map(h => h.textContent.trim()).join('|');
  const cols = {}; heads.forEach((h, i) => { const t = h.textContent.trim(); if (!t || h.querySelector('input,button,select') || h.colSpan > 1) return; cols[i] = tr => tr.cells[i]?.textContent; h.insertAdjacentHTML('beforeend', ' ' + xfBtn(key, String(i))); });
  if (!Object.keys(cols).length) return;
  const rows = () => [...tb.rows].filter(r => r.cells.length >= heads.length - 1 && !r.querySelector('td.empty') && !r.classList.contains('tot'));
  const redraw = () => {
    const all = rows(), keep = new Set(xfApply(key, all, cols, redraw)), st = xfState(key);
    all.forEach(r => { r.hidden = !keep.has(r); });
    if (st.s) { const tot = [...tb.rows].filter(r => r.classList.contains('tot')); xfApply(key, all, cols, redraw).forEach(r => tb.append(r)); tot.forEach(r => tb.append(r)); }
  };
  XFR[key] = { rows: rows(), cols, redraw };
  const st0 = XF[key]; if (st0 && xfActive(key)) redraw();            // the table was redrawn: keep its filter
  table.addEventListener('pointerenter', () => { XFR[key] = { rows: rows(), cols, redraw }; }, { passive: true });   // rows that arrived later count
}
function xfDecorate(root = document) { $$('table.t:not([data-xfdata]):not([data-xfd])', root).forEach(xfDom); }
new MutationObserver(() => { cancelAnimationFrame(xfDecorate._r); xfDecorate._r = requestAnimationFrame(() => xfDecorate()); })
  .observe(document.body, { childList: true, subtree: true });

const VIEWS = ['dash', 'docs', 'list', 'review', 'rev', 'proc', 'pms', 'rules', 'export', 'settings'];
const STATUSES = ['Not Reviewed', 'Under Review', 'Accepted', 'Rejected', 'Commented', 'Resolved'];
const NOT_PROCESS = new Set(['body_size', 'rating', 'body_material', 'ball_material', 'seat_material', 'seal_material', 'stem_material',
  'bolting_gasket', 'packing_material', 'packing_type', 'connections', 'line_size_inlet', 'line_size_outlet', 'piping_class', 'pipe_material']);
const SECTION_NAMES = { general: 'General Information', basis: 'Design Basis', process: 'Process Data', mechanical: 'Valve Mechanical Data',
  trim: 'Valve Trim', material: 'Materials', sizing: 'Sizing', actuator: 'Actuator', positioner: 'Positioner',
  special: 'Special Requirements', accessories: 'Accessories' };

/* ── PDF viewer (server-rendered pages + overlays in PDF points) ───────── */
const pageInfo = {};
function brokenPdfHTML(e) {                          // valve38: the PDF cannot be shown — say why and where to fix it
  const d = e?.data || {}, g = d.diag || {};
  const det = d.code === 'stored_pdf' ? `<details><summary>자세히 (원인 확인용 — 파일 내용은 싣지 않음)</summary><div class="mono">파일 ${esc(g.file || '')} · 있음 ${g.exists ? '예' : '아니오'}
    ${g.size != null ? ` · 크기 ${g.size.toLocaleString()} B` : ''}${g.sha_match != null ? ` · 올린 파일과 같음 ${g.sha_match ? '예' : '<b>아니오</b>'}` : ''} · PDF 머리 ${g.pdf_header ? '예' : '<b>아니오</b>'}
    <br>앞 32바이트: ${esc(g.head_hex || '')}<br>글자: ${esc(g.head_txt || '')}${d.log ? `<br>기록 파일: ${esc(d.log)}` : ''}</div></details>` : '';
  return `<div class="vbroken"><b>PDF 를 보여 줄 수 없습니다</b><p>${esc(d.code === 'stored_pdf' ? '서버에 저장된 원본 PDF 를 열 수 없습니다. Document Management 에서 같은 파일을 다시 올리면 저장본을 새로 씁니다 — Tag · 지적 · 검토 기록은 그대로입니다.' : e?.message || '')}</p>
    ${d.code === 'stored_pdf' ? `<button class="pri" onclick="(window.opener && window.opener.location.pathname === location.pathname ? window.opener : window).location.hash = 'docs'">Document Management 열기</button>` : ''}${det}</div>`;
}
async function sizes(docId) { return pageInfo[docId] ||= (await api('GET', `/documents/${docId}/pageinfo`)).sizes; }
class Viewer {
  constructor(host, opts = {}) {
    this.host = host; this.opts = opts; this.zoom = LS.get('zoom', 1.15); this.pages = []; this.docId = null;
    this.ovs = []; this.show = Object.assign({ error: true, missing: true, revision: true, comment: true, extract: true }, LS.get('ovshow2', {}));
    const LAYERS = [['error', 'E', 'Error — 빨강: 데이터 오류 · PMS 부적합', 'var(--pms)'], ['missing', 'M', 'Missing — 주황: 누락 · HOLD/TBC', 'var(--proc)'],
      ['revision', 'R', 'Rev — 노랑: 이전 Revision 대비 변경', 'var(--rev)'], ['comment', 'C', 'Comment — 파랑: 검토자 수정 · 의견 · Mark-up', 'var(--usr)']];
    host.innerHTML = `<div class="tbar">
      <button data-a="prev" title="이전 쪽 (PgUp)">◀</button><input class="pno" value="1" aria-label="쪽"><span class="lbl tot">/ 0</span><button data-a="next" title="다음 쪽 (PgDn)">▶</button>
      <span class="sep"></span><button data-a="out" title="축소 (-)">−</button><span class="lbl zl">100%</span><button data-a="in" title="확대 (+)">＋</button><button data-a="fit" title="폭 맞춤">↔</button>
      <span class="sep"></span><input class="q" placeholder="PDF 검색 (F)" aria-label="PDF 검색"><button data-a="find" title="검색">⌕</button>
      ${opts.tools ? `<span class="sep"></span><button data-a="mk" class="${LS.get('mkbar', 1) ? 'on' : ''}" title="Mark-up 도구 줄 보이기/숨기기 (M)">✎ Mark-up</button>` : ''}
      <span class="sep"></span><span class="lay" title="표시 레이어 켜기/끄기">${LAYERS.map(([c, l, t, col]) => `<button data-c="${c}" title="${t}" style="--lc:${col}">${l}</button>`).join('')}</span>
      <span style="flex:1"></span>${opts.extra || ''}</div>${opts.tools ? MKBAR : ''}<div class="stage"></div>`;
    this.stage = $('.stage', host);
    const layBtns = $$('.lay button', host);
    const paintLay = () => layBtns.forEach(b => b.classList.toggle('on', !!this.show[b.dataset.c]));
    paintLay();
    host.querySelector('.tbar').addEventListener('click', e => {
      const lb = e.target.closest('.lay button');
      if (lb) { this.show[lb.dataset.c] = !this.show[lb.dataset.c]; LS.set('ovshow2', this.show); paintLay(); this.paintOv(); this.paintMarks(); return; }
      const a = e.target.closest('button')?.dataset.a; if (!a) return;
      if (a === 'mk') { this.showMkbar(!LS.get('mkbar', 1)); return; }
      if (a === 'prev') this.step(-1); else if (a === 'next') this.step(1);
      else if (a === 'in') this.setZoom(this.zoom * 1.2); else if (a === 'out') this.setZoom(this.zoom / 1.2);
      else if (a === 'fit') this.fit(); else if (a === 'find') this.find();
      else if (a === 'draw') this.toggleDraw();
    });
    $('.q', host).addEventListener('keydown', e => { if (e.key === 'Enter') this.find(); });
    $('.pno', host).addEventListener('change', e => { const i = (+e.target.value || 1) - 1; this.goIndex(i); });
    this.stage.addEventListener('scroll', () => { this.syncNo(); this.opts.onScroll?.(this); });
    this.stage.addEventListener('mousedown', e => this.mkDown(e));
    // valve30: Ctrl + 휠 = 마우스 자리를 중심으로 확대/축소 (브라우저 전체 확대 대신) — 여러 칸을 한 번에 모아 한 번만 그림
    this.stage.addEventListener('wheel', e => {
      if (!e.ctrlKey) return;
      e.preventDefault();
      const r = this.stage.getBoundingClientRect();
      this._wz = (this._wz || 1) * Math.exp(-e.deltaY * 0.0015);
      this._wp = [e.clientX - r.left, e.clientY - r.top];
      if (this._wr) return;
      this._wr = requestAnimationFrame(() => { this._wr = 0; const f = this._wz; this._wz = 1; this.zoomAt(this.zoom * f, ...this._wp); });
    }, { passive: false });
    this.marks = []; this.tool = 'select'; this.mkCat = LS.get('mkcat', 'comment');
    this.style = Object.assign({ color: '', width: 1.6 }, LS.get('mkstyle', {})); this.stamp = LS.get('mkstamp', 'APPROVED'); this.quick = !!LS.get('mkquick', 1);
    if (opts.tools) {
      const bar = $('.mkbar', host);
      bar.addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return;
        if (b.dataset.tool) this.setTool(b.dataset.tool); else if (b.dataset.mk === 'fav') this.favAdd(); else if (b.dataset.mk) this.opts.onMarkCmd?.(b.dataset.mk); });
      $('.mkcols', bar).onclick = e => { const i = e.target.closest('[data-col]'); if (!i) return; this.setStyle({ color: i.dataset.col }); };
      $('.mkw', bar).value = String(this.style.width); $('.mkw', bar).onchange = e => this.setStyle({ width: +e.target.value });
      const st = $('.mkst', bar); if (![...st.options].some(o => o.value === this.stamp)) st.add(new Option(this.stamp, this.stamp, true, true)); st.value = this.stamp;
      st.onchange = async e => { let v = e.target.value;
        if (v === '__custom') { const r = await modal('스탬프 글', '<input name="t" placeholder="예) FOR CONSTRUCTION" maxlength="40">', [['취소', null], ['확인', 'form', 1]]); v = (r?.t || '').trim().toUpperCase(); if (!v) { st.value = this.stamp; return; } st.add(new Option(v, v, true, true)); }
        this.stamp = v; LS.set('mkstamp', v); if (this.tool !== 'stamp') this.setTool('stamp'); };
      $('.mkquick', bar).checked = this.quick; $('.mkquick', bar).onchange = e => { this.quick = e.target.checked; LS.set('mkquick', this.quick ? 1 : 0); };
      $('.mkfav', bar).oncontextmenu = e => { const c = e.target.closest('[data-fav]'); if (!c) return; e.preventDefault(); const L = LS.get('mkfavs', []); L.splice(+c.dataset.fav, 1); LS.set('mkfavs', L); this.favPaint(); };
      $('.mkfav', bar).onclick = e => { const c = e.target.closest('[data-fav]'); if (!c) return; const f = LS.get('mkfavs', [])[+c.dataset.fav]; if (!f) return;
        this.setStyle({ color: f.color, width: f.width }); if (f.stamp) { this.stamp = f.stamp; LS.set('mkstamp', f.stamp); $('.mkst', bar).value = f.stamp; } this.setTool(f.tool); };
      this.favPaint(); this.stylePaint();
      $('.mkcat', bar).value = this.mkCat;
      $('.mkcat', bar).onchange = e => { this.mkCat = e.target.value; LS.set('mkcat', this.mkCat);
        const m = this.marks.find(m => m.sel); if (m && m.editable) this.opts.onMarkChange?.(m, { category: this.mkCat }); };
      this.setTool('select'); this.showMkbar(!!LS.get('mkbar', 1));
    }
  }
  showMkbar(on) {                                   // the Mark-up tool row folds away to give the page more height
    const bar = $('.mkbar', this.host); if (!bar) return;
    bar.hidden = !on; LS.set('mkbar', on ? 1 : 0); $('[data-a="mk"]', this.host)?.classList.toggle('on', on);
    if (!on && this.tool !== 'select') this.setTool('select');
  }
  async load(docId, pages) {
    this.docId = docId; this.pages = pages;
    try { this.size = await sizes(docId); }
    catch (e) { delete pageInfo[docId]; $('.tot', this.host).textContent = '/ 0'; this.stage.innerHTML = brokenPdfHTML(e); return; }   // valve38
    $('.tot', this.host).textContent = `/ ${pages.length}`;
    this.render();
  }
  imgZoom() {                                 // valve30: picture pixels ≥ 1.25 × screen pixels (was ≈ 1.0 — soft text in previews)
    const need = this.zoom * 1.3333 * (window.devicePixelRatio || 1) * 1.25;
    return Math.min(4, Math.max(1.5, Math.ceil(need * 4) / 4));
  }
  render() {
    const z = this.zoom, imgZ = this.imgZoom();
    this.stage.innerHTML = this.pages.map(p => {
      const [w, h] = this.size[p - 1] || [595, 842];
      return `<div class="pg" data-p="${p}" style="width:${w * z * 1.3333}px;height:${h * z * 1.3333}px"><span class="lab">p.${p}</span>
        <img loading="lazy" decoding="async" alt="page ${p}" src="/api/valve/documents/${this.docId}/page/${p}.png?zoom=${imgZ}"></div>`;
    }).join('') || '<div class="empty" style="color:#d6dbe5">표시할 쪽이 없습니다</div>';
    $('.zl', this.host).textContent = Math.round(z * 100) + '%';
    this.paintOv(); this.paintMarks();
  }
  zoomAt(z, px, py) {                         // keep the point under the mouse where it is
    const old = this.zoom, nz = Math.max(0.4, Math.min(4, z)); if (Math.abs(nz - old) < 1e-3) return;
    const cx = this.stage.scrollLeft + px, cy = this.stage.scrollTop + py;
    this.zoom = nz; LS.set('zoom', nz); this.render();
    this.stage.scrollLeft = cx * nz / old - px; this.stage.scrollTop = cy * nz / old - py;
  }
  setZoom(z) { const p = this.current(); this.zoom = Math.max(0.4, Math.min(4, z)); LS.set('zoom', this.zoom); this.render(); this.goPage(p, null, false); }
  fit() { const w = this.size[(this.pages[0] || 1) - 1]?.[0] || 595; this.setZoom((this.stage.clientWidth - 40) / (w * 1.3333)); }
  current() {
    const top = this.stage.scrollTop + 20;
    let cur = this.pages[0];
    for (const el of $$('.pg', this.stage)) { if (el.offsetTop <= top) cur = +el.dataset.p; }
    return cur;
  }
  syncNo() { const i = this.pages.indexOf(this.current()); $('.pno', this.host).value = i + 1; }
  step(d) { const i = this.pages.indexOf(this.current()); this.goIndex(i + d); }
  goIndex(i) { if (i >= 0 && i < this.pages.length) this.goPage(this.pages[i]); }
  goPage(p, bbox, smooth = true) {
    const el = $(`.pg[data-p="${p}"]`, this.stage); if (!el) return;
    let y = el.offsetTop - 10, x = this.stage.scrollLeft;
    if (bbox) {
      const z = this.zoom * 1.3333;
      y = el.offsetTop + bbox[1] * z - this.stage.clientHeight / 3;
      x = el.offsetLeft + bbox[0] * z - this.stage.clientWidth / 3;
    }
    this.stage.scrollTo({ top: Math.max(0, y), left: Math.max(0, x), behavior: smooth ? 'smooth' : 'auto' });
  }
  setOverlays(list) { this.ovs = list; this.paintOv(); }
  focus(page, bbox, label) {          // one blinking box for 'where was this read'
    this.ovs = this.ovs.filter(o => o.cat !== 'field').concat(bbox ? [{ cat: 'field', page, bbox, title: label }] : []);
    this.paintOv(); this.goPage(page, bbox);
  }
  paintOv() {
    $$('.ov', this.stage).forEach(e => e.remove());
    const z = this.zoom * 1.3333;
    this.ovs.forEach((o, i) => {
      if (o.cat !== 'field' && o.cat !== 'search' && !(this.show[o.cat] ?? this.show[o.cat === 'process' ? 'missing' : o.cat] ?? true)) return;
      const el = $(`.pg[data-p="${o.page}"]`, this.stage); if (!el || !o.bbox) return;
      const [x0, y0, x1, y1] = o.bbox, d = document.createElement('div');
      d.className = `ov ${o.cat}${o.sel ? ' sel' : ''}`;
      d.style.cssText = `left:${x0 * z - 2}px;top:${y0 * z - 2}px;width:${(x1 - x0) * z + 4}px;height:${(y1 - y0) * z + 4}px`;
      d.title = [o.title, o.text].filter(Boolean).join('\n');
      if (o.tip) d.innerHTML = `<span class="tip">${esc(o.tip)}</span>`;
      if (o.no) d.insertAdjacentHTML('beforeend', `<span class="ovno">${o.no}</span>`);
      d.onclick = ev => { ev.stopPropagation(); this.opts.onOverlay?.(o, i); };
      el.append(d);
    });
  }
  async find() {
    const q = $('.q', this.host).value.trim(); if (!q || !this.docId) return;
    const hits = [];
    for (const p of this.pages) hits.push(...(await api('GET', `/documents/${this.docId}/search?q=${encodeURIComponent(q)}&page=${p}`)).hits);
    this.ovs = this.ovs.filter(o => o.cat !== 'search').concat(hits.map(h => ({ cat: 'search', page: h.page, bbox: h.bbox, title: q })));
    this.paintOv();
    if (hits.length) { this.goPage(hits[0].page, hits[0].bbox); toast(`'${q}' ${hits.length}곳`); } else toast(`'${q}' 없음`);
  }
  /* ── user mark-up (SVG in PDF points over each page; saved as comments, exported as real PDF annotations) ── */
  setStyle(ch) {                                     // colour / width for the next mark-up — and for the selected one
    Object.assign(this.style, ch); LS.set('mkstyle', this.style); this.stylePaint();
    if (this.tool !== 'select') return;                 // with a drawing tool the palette is for the NEXT mark only
    const m = this.marks.find(x => x.sel); if (!m || !m.editable) return;
    const nx = Object.assign({}, m.style || {}); delete nx.color; delete nx.width; Object.assign(nx, this.styleFor('')); // colour · width only — a stamp keeps its text
    this.opts.onMarkChange?.(m, { style: Object.keys(nx).length ? nx : null }, { style: m.style || null });
  }
  stylePaint() { const bar = $('.mkbar', this.host); if (!bar) return; $$('.mkcols i', bar).forEach(i => i.classList.toggle('on', (i.dataset.col || '') === (this.style.color || ''))); $('.mkw', bar).value = String(this.style.width); }
  styleFor(kind) { const o = {}; if (this.style.color) o.color = this.style.color; if (this.style.width !== 1.6) o.width = this.style.width; if (kind === 'stamp') o.stamp = this.stamp; return o; }
  favAdd() { const L = LS.get('mkfavs', []); const f = { tool: this.tool === 'select' || this.tool === 'eraser' ? 'pen' : this.tool, color: this.style.color, width: this.style.width, stamp: this.tool === 'stamp' ? this.stamp : '' };
    if (!L.some(x => JSON.stringify(x) === JSON.stringify(f))) L.push(f); LS.set('mkfavs', L.slice(-8)); this.favPaint(); toast('즐겨찾기에 넣었습니다 — 우클릭으로 지움'); }
  favPaint() { const el = $('.mkfav', this.host); if (!el) return; const ic = Object.fromEntries(MKTOOLS.map(([k, i]) => [k, i]));
    el.innerHTML = LS.get('mkfavs', []).map((f, n) => `<button data-fav="${n}" title="${f.tool}${f.stamp ? ' ' + f.stamp : ''} · ${f.color || '분류 색'} · ${f.width}" style="color:${f.color || '#dbe2ee'}">${f.stamp ? esc(f.stamp.slice(0, 4)) : ic[f.tool] || f.tool}</button>`).join(''); }
  setTool(t) {
    if (this.poly && t !== this.poly.kind) this.polyEnd(true);
    this.tool = t; this.stage.classList.toggle('drawing', t !== 'select');
    this.stage.classList.toggle('erasing', t === 'eraser'); const stb = $('.mkst', this.host); if (stb) stb.style.display = t === 'stamp' ? '' : 'none';
    $$('.mkbar [data-tool]', this.host).forEach(b => b.classList.toggle('on', b.dataset.tool === t));
    this.stage.dataset.tool = t; this.paintMarks();
  }
  toggleDraw(on) { this.setTool((on ?? this.tool === 'select') ? 'rect' : 'select'); }
  setMarks(list) { this.marks = list; this.paintMarks(); }
  paintMarks() {
    $$('svg.mk', this.stage).forEach(e => e.remove());
    const z = this.zoom * 1.3333, hs = 4.5 / z;
    const byPage = {};
    for (const m of this.marks) if (m.page && m.bbox && this.show[MKCAT[m.category] || 'comment'] !== false) (byPage[m.page] ||= []).push(m);
    for (const [p, list] of Object.entries(byPage)) {
      const el = $(`.pg[data-p="${p}"]`, this.stage); if (!el) continue;
      const [w, h] = this.size[p - 1] || [595, 842];
      const svg = document.createElementNS(SVGNS, 'svg');
      svg.setAttribute('class', 'mk' + (this.tool === 'select' || this.tool === 'eraser' ? ' sel-mode' : '')); svg.setAttribute('viewBox', `0 0 ${w} ${h}`);
      svg.innerHTML = MKDEFS + list.map(m => mkSvg(m, hs)).join('');
      el.append(svg);
    }
  }
  pt(pg, e) { const r = pg.getBoundingClientRect(), z = this.zoom * 1.3333; return [Math.round((e.clientX - r.left) / z * 10) / 10, Math.round((e.clientY - r.top) / z * 10) / 10]; }
  mkDown(e) {
    if (e.button !== 0) return;
    const pg = e.target.closest('.pg'); if (!pg) return;
    const page = +pg.dataset.p, p0 = this.pt(pg, e), t = this.tool;
    if (t === 'select') return this.mkSelectDown(e, pg, page, p0);
    if (t === 'eraser') { const id = +e.target.closest('[data-mid]')?.dataset.mid; if (id) { e.preventDefault(); this.opts.onMarkErase?.(id); } return; }
    e.preventDefault();
    if (t === 'note') { this.opts.onMark?.({ page, kind: 'note', bbox: [p0[0], p0[1], p0[0] + 16, p0[1] + 16] }); return; }
    if (t === 'typewriter') { this.opts.onMark?.({ page, kind: 'typewriter', bbox: [p0[0], p0[1] - 2, p0[0] + 180, p0[1] + 14], style: this.styleFor('typewriter') }); return; }
    if (t === 'polyline' || t === 'polygon') { this.polyClick(pg, page, p0, t); return; }
    if (t === 'stamp') { const lab = this.stamp, gl = lab.length <= 1, h = gl ? 18 : 20, w = gl ? 18 : Math.max(40, lab.length * 8.2 + 14);
      this.opts.onMark?.({ page, kind: 'stamp', bbox: [p0[0] - w / 2, p0[1] - h / 2, p0[0] + w / 2, p0[1] + h / 2], style: this.styleFor('stamp') }); return; }
    const tmp = { page, kind: t, category: this.mkCat, style: this.styleFor(t), bbox: [...p0, ...p0], points: t === 'pen' ? [[p0]] : [p0, p0], tmp: true };
    // the mark being drawn lives in its own small SVG: the page's other marks are not redrawn on every mouse move
    const [w, h] = this.size[page - 1] || [595, 842], tsvg = document.createElementNS(SVGNS, 'svg');
    tsvg.setAttribute('class', 'mk mk-tmp'); tsvg.setAttribute('viewBox', `0 0 ${w} ${h}`); pg.append(tsvg);
    let raf = 0; const paint = () => { raf = 0; tsvg.innerHTML = MKDEFS + mkSvg(tmp, 0); };
    const move = ev => {
      const q = this.pt(pg, ev);
      if (t === 'pen') { const st = tmp.points[0], l = st.at(-1); if (Math.hypot(q[0] - l[0], q[1] - l[1]) > 1.2) st.push(q); tmp.bbox = bboxOf(st); }
      else { tmp.points = [p0, q]; tmp.bbox = [Math.min(p0[0], q[0]), Math.min(p0[1], q[1]), Math.max(p0[0], q[0]), Math.max(p0[1], q[1])]; }
      if (!raf) raf = requestAnimationFrame(paint);
    };
    const up = () => {
      removeEventListener('mousemove', move); removeEventListener('mouseup', up); if (raf) cancelAnimationFrame(raf); tsvg.remove();
      const [x0, y0, x1, y1] = tmp.bbox, line = t === 'line' || t === 'arrow', flat = t === 'underline' || t === 'strike' || t === 'squiggle';
      if (t === 'callout') {                           // anchor = where the drag started · box = where it ended
        const q = tmp.points[1], a = tmp.points[0], bw = 150, bh = 30, bx = q[0] >= a[0] ? q[0] : q[0] - bw, by = q[1] - bh / 2;
        if (Math.hypot(q[0] - a[0], q[1] - a[1]) < 8) return;
        this.opts.onMark?.({ page, kind: 'callout', bbox: [bx, by, bx + bw, by + bh].map(v => Math.round(v * 10) / 10), points: [a, calloutAttach(a, [bx, by, bx + bw, by + bh])], style: this.styleFor('callout') });
        return;
      }
      if (t === 'pen' ? tmp.points[0].length < 3 : line ? Math.hypot(x1 - x0, y1 - y0) < 5 : flat ? x1 - x0 < 4 : (x1 - x0 < 4 || y1 - y0 < 4)) {
        if (t === 'text') this.opts.onMark?.({ page, kind: 'text', bbox: [p0[0], p0[1], p0[0] + 140, p0[1] + 28], style: this.styleFor('text') });
        return;
      }
      const g = { page, kind: t, bbox: tmp.bbox.map(v => Math.round(v * 10) / 10), style: this.styleFor(t) };
      if (flat && g.bbox[3] - g.bbox[1] < 6) g.bbox[3] = g.bbox[1] + 10;          // a dragged line of text gets a thin box
      if (t === 'pen') g.points = tmp.points.map(st => st.map(([x, y]) => [Math.round(x * 10) / 10, Math.round(y * 10) / 10])); else if (line) g.points = tmp.points;
      this.opts.onMark?.(g);
    };
    addEventListener('mousemove', move); addEventListener('mouseup', up);
  }
  polyClick(pg, page, p0, t) {                      // polyline / polygon: one click per vertex, double-click or Enter ends, Esc cancels
    const P = this.poly;
    if (P && (P.page !== page || P.kind !== t)) this.polyEnd(false);
    if (!this.poly) {
      const [w, h] = this.size[page - 1] || [595, 842], tsvg = document.createElementNS(SVGNS, 'svg');
      tsvg.setAttribute('class', 'mk mk-tmp'); tsvg.setAttribute('viewBox', `0 0 ${w} ${h}`); pg.append(tsvg);
      this.poly = { page, kind: t, pts: [p0], tsvg, cur: p0 };
      const mv = ev => { if (!this.poly) return; this.poly.cur = this.pt(pg, ev); if (!this.poly.raf) this.poly.raf = requestAnimationFrame(() => { if (this.poly) { this.poly.raf = 0; this.polyPaint(); } }); };
      const dbl = ev => { ev.preventDefault(); this.polyEnd(true); };
      const key = ev => { if (ev.key !== 'Enter' && ev.key !== 'Escape') return; ev.preventDefault(); ev.stopImmediatePropagation();   // not also 'edit selected' / 'cancel'
        this.polyEnd(ev.key === 'Enter'); };
      addEventListener('mousemove', mv); this.stage.addEventListener('dblclick', dbl); addEventListener('keydown', key, true);
      this.poly.off = () => { removeEventListener('mousemove', mv); this.stage.removeEventListener('dblclick', dbl); removeEventListener('keydown', key, true); };
    } else {
      const l = this.poly.pts.at(-1); if (Math.hypot(p0[0] - l[0], p0[1] - l[1]) > 2) this.poly.pts.push(p0);
    }
    this.polyPaint();
  }
  polyPaint() { const P = this.poly; if (!P) return; P.tsvg.innerHTML = mkSvg({ kind: P.kind, category: this.mkCat, style: this.styleFor(P.kind), points: P.pts.concat([P.cur]), bbox: bboxOf(P.pts.concat([P.cur])) }, 0); }
  polyEnd(save) {
    const P = this.poly; if (!P) return; this.poly = null; P.off(); P.tsvg.remove();
    const pts = P.pts.filter((p, i, a) => !i || Math.hypot(p[0] - a[i - 1][0], p[1] - a[i - 1][1]) > 2).map(([x, y]) => [Math.round(x * 10) / 10, Math.round(y * 10) / 10]);
    if (!save || pts.length < (P.kind === 'polygon' ? 3 : 2)) return;
    this.opts.onMark?.({ page: P.page, kind: P.kind, points: pts, bbox: bboxOf(pts), style: this.styleFor(P.kind) });
  }
  mkSelectDown(e, pg, page, p0) {
    const hEl = e.target.closest('[data-hd]'), sEl = e.target.closest('[data-mid]');
    const id = +(hEl || sEl)?.closest('[data-mid]')?.dataset.mid;
    const m = this.marks.find(x => x.id === id);
    this.marks.forEach(x => x.sel = x === m); this.paintMarks();
    this.opts.onMarkSelect?.(m || null);
    if (!m) { this.opts.onPagePoint?.(page, p0); return; }        // valve29: an empty spot of the page → the field printed there
    e.preventDefault(); e.stopPropagation();
    if (!m.editable) return;
    const before = { bbox: [...m.bbox], points: m.points ? JSON.parse(JSON.stringify(m.points)) : null }, hd = hEl?.dataset.hd;
    let moved = false;
    const move = ev => {
      const q = this.pt(pg, ev), dx = q[0] - p0[0], dy = q[1] - p0[1];
      if (!moved && Math.hypot(dx, dy) < 2) return; moved = true;
      Object.assign(m, mkTransform(before, m.kind, hd, dx, dy)); this.paintMarks();
    };
    const up = () => {
      removeEventListener('mousemove', move); removeEventListener('mouseup', up);
      if (moved) this.opts.onMarkChange?.(m, { bbox: m.bbox, points: m.points }, before);
    };
    addEventListener('mousemove', move); addEventListener('mouseup', up);
  }
}

const SVGNS = 'http://www.w3.org/2000/svg';
const MKDEFS = `<defs><marker id="mkar" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10" fill="none" stroke="context-stroke" stroke-width="1.8"/></marker></defs>`;
const calloutAttach = (a, [x0, y0, x1, y1]) => a[0] < x0 ? [x0, (y0 + y1) / 2] : a[0] > x1 ? [x1, (y0 + y1) / 2] : a[1] < y0 ? [(x0 + x1) / 2, y0] : [(x0 + x1) / 2, y1];
const penPath = pts => {                             // smooth hand-writing: quadratic curves through the mid-points
  if (pts.length < 3) return 'M' + pts.map(p => p.join(',')).join(' L');
  let d = `M${pts[0][0]},${pts[0][1]}`;
  for (let i = 1; i < pts.length - 1; i++) { const [x, y] = pts[i], [nx, ny] = pts[i + 1]; d += ` Q${x},${y} ${(x + nx) / 2},${(y + ny) / 2}`; }
  return d + ` L${pts.at(-1)[0]},${pts.at(-1)[1]}`;
};
const MKCAT = { comment: 'comment', question: 'comment', error: 'error', missing: 'missing' };
const MKCOL = { comment: '#2e66e6', question: '#2e66e6', error: '#db2626', missing: '#ff8c00' };
const MKTOOLS = [['select', '⬚', '선택 · 옮기기 · 크기 (V)'], ['stamp', '✔', '스탬프 — 누르는 자리에 (I)'], ['note', '🗨', '메모 · 붙임쪽지 (N)'],
  ['typewriter', 'Aa', '타자기 — 누른 자리에 바로 글 (Y)'], ['text', 'T', '글상자 (T)'], ['callout', '💬', '말풍선 — 가리킬 곳에서 상자 자리까지 끌기 (B)'],
  ['highlight', '▆', '형광펜 (H)'], ['strike', '<s>S</s>', '취소선 (S)'], ['underline', '<u>U</u>', '밑줄 (U)'], ['squiggle', '〰', '물결 밑줄 (G)'],
  ['arrow', '↗', '화살표 (W)'], ['line', '╱', '선 (L)'], ['rect', '▭', '사각형 (R)'], ['ellipse', '◯', '원 (E)'],
  ['polyline', '⦚', '꺾은선 — 점을 차례로 누르고 두 번 누르거나 Enter 로 끝 (O)'], ['polygon', '⬠', '다각형 — 점을 차례로 누르고 두 번 누르거나 Enter 로 닫기 (Q)'],
  ['cloud', '☁', '구름 (C)'], ['pen', '✎', '펜 — 손글씨 (P)'], ['eraser', '⌫', '지우개 — 표시를 누르면 지움 (X)']];
const MKCOLORS = [['', '분류 색'], ['#111111', '검정'], ['#db2626', '빨강'], ['#ff8c00', '주황'], ['#f5d400', '노랑'], ['#1aa35a', '초록'], ['#2e66e6', '파랑'], ['#8e3fd6', '보라']];
const MKSTAMPS = ['DRAFT', 'APPROVED', 'REJECTED', 'HOLD', 'CONFIRM', 'REVISE', 'CHECKED', 'AS BUILT', 'VOID', '✓', '✗', '?', '!', '★'];
const MKBAR = `<div class="tbar mkbar">${MKTOOLS.map(([k, i, t]) => `<button data-tool="${k}" title="${t}">${i}</button>`).join('')}
  <span class="sep"></span><select class="mkcat" title="분류 — 색과 Issue 종류가 정해집니다 (Comment 파랑 · Error 빨강 · Missing 주황 · Question 파랑)" aria-label="Mark-up 분류">
  <option value="comment">● Comment</option><option value="error">● Error</option><option value="missing">● Missing</option><option value="question">● Question</option></select>
  <span class="mkcols" title="색 (분류 색 = Comment 파랑 · Error 빨강 · Missing 주황)">${MKCOLORS.map(([c, t]) => `<i data-col="${c}" title="${t}" style="background:${c || 'linear-gradient(135deg,#2e66e6 50%,#db2626 50%)'}"></i>`).join('')}</span>
  <select class="mkw" title="선 굵기"><option value="0.8">얇게</option><option value="1.6" selected>보통</option><option value="3">굵게</option><option value="5">아주 굵게</option></select>
  <select class="mkst" title="스탬프 종류 (I)">${MKSTAMPS.map(x => `<option>${x}</option>`).join('')}<option value="__custom">직접 입력…</option></select>
  <label class="chk mkq" title="켜면 의견을 묻지 않고 바로 그립니다 (글상자 · 메모는 항상 묻습니다). 의견은 나중에 Enter 로"><input type="checkbox" class="mkquick"> 바로</label>
  <span class="mkfav" title="즐겨찾기 — ★ 로 지금 도구·색·굵기를 저장, 누르면 적용, 우클릭 지움"></span><button data-mk="fav" title="지금 도구 · 색 · 굵기를 즐겨찾기에 저장">★</button>
  <span class="sep"></span><button data-mk="undo" title="되돌리기 (Ctrl+Z)">↶</button><button data-mk="redo" title="다시 하기 (Ctrl+Y)">↷</button>
  <button data-mk="edit" title="선택한 표시의 의견 고치기 (Enter)">✎</button><button data-mk="del" title="선택한 표시 지우기 (Delete)">🗑</button></div>`;
const bboxOf = pts => { const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]); return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)]; };
function mkTransform(b, kind, hd, dx, dy) {          // move (no handle) or resize by a corner / line end
  const [x0, y0, x1, y1] = b.bbox;
  if (!hd) return { bbox: [x0 + dx, y0 + dy, x1 + dx, y1 + dy], points: b.points && (kind === 'pen' ? b.points.map(st => st.map(([x, y]) => [x + dx, y + dy])) : b.points.map(([x, y]) => [x + dx, y + dy])) };
  if (hd === 'p0' || hd === 'p1') { const pts = b.points.map(p => [...p]); const i = hd === 'p0' ? 0 : pts.length - 1; pts[i] = [pts[i][0] + dx, pts[i][1] + dy]; return { points: pts, bbox: bboxOf(pts) }; }
  let n = [x0, y0, x1, y1];
  if (hd.includes('w')) n[0] += dx; if (hd.includes('e')) n[2] += dx; if (hd.includes('n')) n[1] += dy; if (hd.includes('s')) n[3] += dy;
  n = [Math.min(n[0], n[2]), Math.min(n[1], n[3]), Math.max(n[0], n[2]), Math.max(n[1], n[3])];
  if (n[2] - n[0] < 4) n[2] = n[0] + 4; if (n[3] - n[1] < 4) n[3] = n[1] + 4;
  let pts = b.points;
  if ((kind === 'polyline' || kind === 'polygon') && pts) {
    const sx = (n[2] - n[0]) / Math.max(1e-6, x1 - x0), sy = (n[3] - n[1]) / Math.max(1e-6, y1 - y0);
    pts = pts.map(([x, y]) => [n[0] + (x - x0) * sx, n[1] + (y - y0) * sy]);
  }
  if (kind === 'pen' && pts) {                       // scale the strokes with the box
    const sx = (n[2] - n[0]) / Math.max(1e-6, x1 - x0), sy = (n[3] - n[1]) / Math.max(1e-6, y1 - y0);
    pts = pts.map(st => st.map(([x, y]) => [n[0] + (x - x0) * sx, n[1] + (y - y0) * sy]));
  }
  return { bbox: n, points: pts };
}
function cloudPath([x0, y0, x1, y1]) {             // scalloped edge, arcs bulging outwards (clockwise)
  const r = Math.max(3, Math.min(8, Math.min(x1 - x0, y1 - y0) / 4)), corners = [[x0, y0], [x1, y0], [x1, y1], [x0, y1], [x0, y0]];
  let d = `M${x0},${y0}`;
  for (let k = 0; k < 4; k++) {
    const [ax, ay] = corners[k], [bx, by] = corners[k + 1], n = Math.max(1, Math.round(Math.hypot(bx - ax, by - ay) / (r * 1.6)));
    for (let j = 1; j <= n; j++) { const x = ax + (bx - ax) * j / n, y = ay + (by - ay) * j / n, rr = Math.hypot(bx - ax, by - ay) / n / 2 * 1.15; d += ` A${rr},${rr} 0 0 1 ${x},${y}`; }
  }
  return d;
}
function mkSvg(m, hs) {
  const sty = m.style || {}, c = sty.color || MKCOL[m.category] || MKCOL.comment, [x0, y0, x1, y1] = m.bbox, w = x1 - x0, h = y1 - y0, sw = sty.width || 1.6;
  const st = `stroke="${c}" stroke-width="${sw}" vector-effect="non-scaling-stroke"`;
  const hit = `fill="transparent" stroke="transparent" stroke-width="10" vector-effect="non-scaling-stroke"`;
  let g = '';
  if (m.kind === 'highlight') g = `<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="${c}" fill-opacity=".32"/>`;
  else if (m.kind === 'line' || m.kind === 'arrow') { const [[a, b], [cx, cy]] = [m.points[0], m.points.at(-1)];
    g = `<line x1="${a}" y1="${b}" x2="${cx}" y2="${cy}" ${hit}/><line x1="${a}" y1="${b}" x2="${cx}" y2="${cy}" ${st} fill="none"${m.kind === 'arrow' ? ' marker-end="url(#mkar)"' : ''}/>`; }
  else if (m.kind === 'pen') g = (m.points || []).map(s => { const d = penPath(s); return `<path d="${d}" ${hit}/><path d="${d}" ${st} fill="none" stroke-linecap="round" stroke-linejoin="round"/>`; }).join('');
  else if (m.kind === 'polyline' || m.kind === 'polygon') { const d = 'M' + (m.points || []).map(p => p.join(',')).join(' L') + (m.kind === 'polygon' ? ' Z' : '');
    g = `<path d="${d}" ${hit}/><path d="${d}" ${st} fill="${m.kind === 'polygon' ? c : 'none'}" fill-opacity=".05" stroke-linejoin="round"/>`; }
  else if (m.kind === 'typewriter') g = `<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="transparent" ${m.sel ? `stroke="${c}" stroke-dasharray="2 2" stroke-width=".6" vector-effect="non-scaling-stroke"` : ''}/>
    <foreignObject x="${x0}" y="${y0}" width="${w}" height="${h}"><div xmlns="http://www.w3.org/1999/xhtml" class="mktx tw" style="color:${c}${sty.size ? `;font-size:${sty.size}px` : ''}">${esc(m.text || '')}</div></foreignObject>`;
  else if (m.kind === 'callout') { const a = (m.points || [])[0] || [x0, y0], at = calloutAttach(a, m.bbox);
    g = `<line x1="${at[0]}" y1="${at[1]}" x2="${a[0]}" y2="${a[1]}" ${hit}/><line x1="${at[0]}" y1="${at[1]}" x2="${a[0]}" y2="${a[1]}" ${st} marker-end="url(#mkar)"/>
    <rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="#fff" stroke="${c}" stroke-width="${Math.max(.8, sw * .6)}" vector-effect="non-scaling-stroke"/>
    <foreignObject x="${x0}" y="${y0}" width="${w}" height="${h}"><div xmlns="http://www.w3.org/1999/xhtml" class="mktx" style="color:${c}">${esc(m.text || '')}</div></foreignObject>`; }
  else if (m.kind === 'underline' || m.kind === 'strike') { const y = m.kind === 'strike' ? (y0 + y1) / 2 : y1 - 0.6;
    g = `<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="transparent"/><line x1="${x0}" y1="${y}" x2="${x1}" y2="${y}" ${st}/>`; }
  else if (m.kind === 'squiggle') { let d = `M${x0},${y1 - 1}`; for (let x = x0 + 2, k = 0; x <= x1; x += 2, k++) d += ` L${x},${y1 - 1 + (k % 2 ? 1.6 : -1.6)}`;
    g = `<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="transparent"/><path d="${d}" ${st} fill="none"/>`; }
  else if (m.kind === 'stamp') { const lab = sty.stamp || m.text || 'STAMP', gl = lab.length <= 1;
    g = gl ? `<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="transparent"/><text x="${x0 + w / 2}" y="${y0 + h * .82}" text-anchor="middle" font-size="${h * .95}" font-weight="700" fill="${c}" style="font-family:sans-serif">${esc(lab)}</text>`
      : `<rect x="${x0}" y="${y0}" width="${w}" height="${h}" rx="2" fill="#fff" fill-opacity=".85" stroke="${c}" stroke-width="${Math.max(1.2, sw)}" vector-effect="non-scaling-stroke"/><text x="${x0 + w / 2}" y="${y0 + h * .7}" text-anchor="middle" font-size="${Math.min(h * .6, (w - 8) / Math.max(1, lab.length) * 1.75)}" font-weight="700" fill="${c}" style="font-family:sans-serif;letter-spacing:.06em">${esc(lab)}</text>`; }
  else if (m.kind === 'cloud') g = `<path d="${cloudPath(m.bbox)}" ${st} fill="${c}" fill-opacity=".04"/>`;
  else if (m.kind === 'ellipse') g = `<ellipse cx="${x0 + w / 2}" cy="${y0 + h / 2}" rx="${w / 2}" ry="${h / 2}" ${st} fill="${c}" fill-opacity=".04"/>`;
  else if (m.kind === 'text') g = `<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="#fff" stroke="${c}" stroke-width=".8" vector-effect="non-scaling-stroke"/>
    <foreignObject x="${x0}" y="${y0}" width="${w}" height="${h}"><div xmlns="http://www.w3.org/1999/xhtml" class="mktx" style="color:${c}">${esc(m.text || '')}</div></foreignObject>`;
  else if (m.kind === 'note') g = `<path d="M${x0},${y0} h16 v11 h-9 l-4,4 v-4 h-3 z" fill="${c}" stroke="#fff" stroke-width=".8"/><path d="M${x0 + 3},${y0 + 4} h10 M${x0 + 3},${y0 + 7.5} h7" stroke="#fff" stroke-width="1.1"/>`;
  else g = `<rect x="${x0}" y="${y0}" width="${w}" height="${h}" ${st} fill="${c}" fill-opacity=".04"/>`;
  let hd = '';
  if (m.sel && m.editable) {
    const H = (x, y, k) => `<rect data-hd="${k}" class="hd hd-${k}" x="${x - hs}" y="${y - hs}" width="${hs * 2}" height="${hs * 2}"/>`;
    hd = (m.kind === 'line' || m.kind === 'arrow') ? H(...m.points[0], 'p0') + H(...m.points.at(-1), 'p1')
      : m.kind === 'note' || (m.kind === 'stamp' && (m.style?.stamp || '').length <= 1) ? '' : H(x0, y0, 'nw') + H(x1, y0, 'ne') + H(x1, y1, 'se') + H(x0, y1, 'sw');
  }
  const no = m.no ? `<g class="mkno"><rect x="${x0 - 15}" y="${y0 - 1}" width="13" height="10" rx="1.5" fill="${c}"/><text x="${x0 - 8.5}" y="${y0 + 6.8}" text-anchor="middle">${m.no}</text></g>` : '';
  return `<g data-mid="${m.id ?? ''}" class="mkg${m.sel ? ' sel' : ''}"><title>${esc((m.no ? '#' + m.no + ' ' : '') + (m.text || '') + (m.by ? `\n— ${m.by}` : ''))}</title>${m.sel ? `<rect class="selbox" x="${x0 - 2}" y="${y0 - 2}" width="${w + 4}" height="${h + 4}"/>` : ''}${g}${no}${hd}</g>`;
}

/* ── navigation ────────────────────────────────────────────────────────── */
function go(v, push = true) {
  if (!VIEWS.includes(v)) v = 'dash';
  S.view = v;
  $$('#menu button').forEach(b => b.classList.toggle('on', b.dataset.v === v));
  $$('.view').forEach(s => s.classList.toggle('on', s.id === 'v-' + v));
  if (push && location.hash !== '#' + v) history.replaceState(null, '', location.pathname + location.search + '#' + v);
  LS.set('view', v);
  RENDER[v]?.();
}
$('#menu').addEventListener('click', e => { const b = e.target.closest('button'); if (b) go(b.dataset.v); });
addEventListener('hashchange', () => { const v = location.hash.slice(1); if (v && v !== S.view) go(v, false); });

async function loadProjects() {
  S.projects = (await api('GET', '/projects')).projects;
  const want = wantProject();
  let p = want ? S.projects.find(x => x.name === want) : null;
  if (want && !p) { p = await api('POST', '/projects', { name: want }); S.projects.push(p); }
  if (!p) p = S.projects.find(x => x.id === LS.get('pid')) || S.projects[0];
  if (!p) { p = await api('POST', '/projects', { name: 'CO2 PJT' }); S.projects.push(p); }
  $('#projSel').innerHTML = S.projects.map(x => `<option value="${x.id}">${esc(x.name)}</option>`).join('');
  await selectProject(p.id);
}
async function selectProject(pid) {
  S.pid = +pid; LS.set('pid', S.pid); $('#projSel').value = S.pid;
  $('#crumbProj').textContent = S.projects.find(p => p.id === S.pid)?.name || '';
  S.grid = null; S.ds = null; S.dsId = LS.get('tag.' + S.pid, null);
  await refresh();
}
async function refresh() {
  S.sum = await api('GET', `/projects/${S.pid}/summary`); S.sumStamp = Date.now(); S.issues = null; S.reqs = null; S.grid = null; S.pmsRows = null; S.procRows = null;
  $('#navfoot').innerHTML = `${esc(S.sum.project.name)} · Tag ${S.sum.kpi.tags} · DS ${S.sum.kpi.datasheets}<br>${esc(USER || '이름 없음')} <span class="soft" id="navver"></span>`;
  if (!S.ver) api('GET', '/version').then(v => { S.ver = v.version; const x = $('#navver'); if (x) x.textContent = '· ' + v.version; }).catch(() => {}); else { const x = $('#navver'); if (x) x.textContent = '· ' + S.ver; }
  S.vsum = null;
  RENDER[S.view]?.();
  warmClient();
}
function warmClient() {               // valve29: the big lists the user opens next are fetched while the screen is idle
  if (POP) return;
  const pid = S.pid, g0 = S.wgen || 0, stamp = S.sumStamp, ok = () => S.pid === pid && (S.wgen || 0) === g0 && S.sumStamp === stamp;
  const idle = window.requestIdleCallback || (f => setTimeout(f, 300));
  idle(async () => {
    try {
      if (!S.grid && ok()) { const g = await api('GET', `/projects/${pid}/grid`); if (ok() && !S.grid) S.grid = g; }
      if (!S.issues && ok()) { const r = await loadIssues(); if (ok() && !S.issues) { S.issues = r.issues; S.issueTypes = r.types; } }
    } catch (_) { /* the screen fetches it itself when opened */ }
  }, { timeout: 3000 });
}
$('#projSel').onchange = e => selectProject(e.target.value);
$('#projNew').onclick = async () => {
  const r = await modal('새 프로젝트', '<input name="name" placeholder="예) CO2 PJT">', [['취소', null], ['만들기', 'form', 1]]);
  if (!r?.name) return;
  try { const p = await api('POST', '/projects', { name: r.name }); S.projects = (await api('GET', '/projects')).projects;
    $('#projSel').innerHTML = S.projects.map(x => `<option value="${x.id}">${esc(x.name)}</option>`).join(''); selectProject(p.id); }
  catch (e) { toast(e.message, 1); }
};

/* ── 1. Dashboard ──────────────────────────────────────────────────────── */
function donut(parts) {
  const tot = parts.reduce((a, p) => a + p.n, 0) || 1; let a0 = -Math.PI / 2;
  const arcs = parts.filter(p => p.n).map(p => {
    const a1 = a0 + 2 * Math.PI * p.n / tot, large = a1 - a0 > Math.PI ? 1 : 0;
    const P = a => [60 + 48 * Math.cos(a), 60 + 48 * Math.sin(a)];
    const [x0, y0] = P(a0), [x1, y1] = P(a1 - 0.0001); a0 = a1;
    return `<path d="M${x0} ${y0} A48 48 0 ${large} 1 ${x1} ${y1}" stroke="${p.c}" stroke-width="16" fill="none"/>`;
  }).join('');
  return `<svg width="120" height="120" viewBox="0 0 120 120" role="img" aria-label="review status"><circle cx="60" cy="60" r="48" stroke="#edf0f5" stroke-width="16" fill="none"/>${arcs}
    <text x="60" y="58" text-anchor="middle" font-size="20" font-weight="700" fill="#1b2333">${tot === 1 && !parts.some(p => p.n) ? 0 : tot}</text><text x="60" y="74" text-anchor="middle" font-size="11" fill="#5b6475">Tags</text></svg>`;
}
/* valve29 — 첫 화면: 검토가 기준으로 삼는 최신 Datasheet · Process Data · PMS 의 Rev · 날짜 (문서 자체의 개정표에서 읽음 — docrev) */
/* valve30 — PMS · Process 화면: 표 ↔ 아래 미리보기 높이, 왼쪽 ↔ 오른쪽 미리보기 폭을 마우스로 (값은 기억) */
function splitPanes(el, key, viewers) {
  const bot = $('.pvbot', el), hs = $('.hsplit', el), vs = $('.vsplit', el), left = $('#' + key, el);
  if (!bot || !hs || !vs || !left) return;
  const box = () => bot.parentElement.getBoundingClientRect();
  const drag = (on, move, done) => on.onmousedown = e => {
    e.preventDefault(); document.body.classList.add('dragging');
    const mv = ev => move(ev), up = () => { removeEventListener('mousemove', mv); removeEventListener('mouseup', up); document.body.classList.remove('dragging'); done(); };
    addEventListener('mousemove', mv); addEventListener('mouseup', up);
  };
  drag(hs, ev => { const b = box(); const h = Math.max(15, Math.min(85, (b.bottom - ev.clientY) / b.height * 100)); bot.style.height = h + '%'; LS.set('pvh_' + key, Math.round(h)); },
    () => viewers.forEach(v => v?.paintOv()));
  drag(vs, ev => { const b = bot.getBoundingClientRect(); const w = Math.max(15, Math.min(85, (ev.clientX - b.left) / b.width * 100)); left.style.flex = `0 0 ${w}%`; LS.set('pvw_' + key, Math.round(w)); },
    () => viewers.forEach(v => v?.paintOv()));
}
function refDocs(L) {
  const up = x => x?.uploaded_at ? `올린 날 ${esc(x.uploaded_at.slice(0, 10))}` : '';
  const revs = o => Object.entries(o || {}).map(([r, n]) => `Rev ${esc(r)} <b>${n}</b>`).join(' · ');
  const none = (t, what) => `<div class="card refdoc none"><h3>${t}</h3><div class="soft">${what} 없음 — Document Management 에서 올리세요</div></div>`;
  const D = L.datasheet, P = L.process, M = L.pms;
  const ds = D ? `<div class="card refdoc" title="Tag 마다 가장 새 Revision 기준 · 날짜 = 그 Revision 의 개정표 날짜"><h3>Datasheet</h3>
      <div class="rd1"><span class="rdrev">${revs(D.by_rev)}</span></div>
      <div class="rd2">최신 개정일 <b>${esc(D.date || '—')}</b>${D.date ? ` <span class="soft">(${D.date_tags}/${D.tags} Tag)</span>` : ''}</div>
      <div class="rd3 soft">${esc(D.filename)} · ${up(D)}</div></div>` : none('Datasheet', 'Datasheet');
  const ms = M ? `<div class="card refdoc" title="${esc(M.filename)}"><h3>PMS</h3>
      <div class="rd1"><b>${esc(M.doc_no || M.filename)}</b> <span class="rdrev">Rev. <b>${esc(M.rev || M.header_rev || '—')}</b></span></div>
      <div class="rd2">${M.date ? `<b>${esc(M.date)}</b> · ${esc(M.desc)}` : '<span class="soft">개정표 날짜를 못 읽음 — 원본 확인</span>'}</div>
      <div class="rd3 soft">${esc(M.filename)} · ${up(M)}</div></div>` : none('PMS', 'PMS');
  const np = P?.newest_part;
  const ps = P ? `<div class="card refdoc" title="${esc(P.filename)} — 표지/표제를 누르면 공정 데이터시트별 Rev 목록"><h3>Process Data</h3>
      <div class="rd1"><b>${esc(P.doc_no || P.filename)}</b> <span class="rdrev">Rev. <b>${esc(P.rev || P.header_rev || '—')}</b></span>${P.parts?.length ? ` <span class="soft">· Process DS ${P.parts.length}종: ${revs(P.part_revs)}</span>` : ''}</div>
      <div class="rd2">${np ? `최신 <b>${esc(np.date)}</b> · ${esc(np.doc_no)} Rev ${esc(np.rev)} · ${esc(np.desc)}` : P.date ? `<b>${esc(P.date)}</b> · ${esc(P.desc)}` : '<span class="soft">개정표 날짜를 못 읽음 — 원본 확인</span>'}</div>
      <div class="rd3 soft">${esc(P.filename)} · ${up(P)}</div>
      ${P.parts?.length ? `<table class="t rdparts"><thead><tr><th>Process DS Doc. No.</th><th>Rev</th><th>Date</th><th>Description</th><th>Page</th></tr></thead><tbody>
        ${P.parts.map(x => `<tr><td>${esc(x.doc_no)}</td><td>${esc(x.rev || '—')}</td><td>${esc(x.date || '—')}</td><td>${esc(x.desc)}</td><td>${x.page}</td></tr>`).join('')}</tbody></table>` : ''}</div>` : none('Process Data', 'Process Data');
  return `<div class="refdocs">${ds}${ps}${ms}</div>`;
}
/* valve33 — 첫 화면 'Valve Summary' (Valve List Excel 의 Summary 시트와 같은 수): 묶는 기준 바꾸기 · 숫자 누르면 그 Tag 들 ·
   Valve List / Issue List 로 바로 거르기 · 비율 · 빈 열 숨기기 · 특수요구 열 고르기 · 접기 · Excel */
const VS = { by: LS.get('vs_by', 'asu'), pct: false, all: LS.get('vs_all', false), open: LS.get('vs_open', true) };
const VS_MAIN = ['PFP', 'Fugitive Emission (ISO 15848)', 'Fire Safe', 'Dense Phase CO2', 'NACE / Sour'];
async function drawVsum() {
  const box = $('#vsum'); if (!box) return;
  if (!S.vsum) { try { S.vsum = await api('GET', `/projects/${S.pid}/valve-summary`); } catch (e) { box.innerHTML = `<h3>Valve Summary</h3><div class="soft">${esc(e.message)}</div>`; return; } }
  const D = S.vsum, T = D.tags;
  const keyOf = { asu: t => [t.area, t.site, t.unit], a: t => [t.area], t: t => [t.type, t.area] }[VS.by];
  const keyHead = { asu: ['Area', 'Site', 'Unit'], a: ['Area'], t: ['Valve Type', 'Area'] }[VS.by];
  const reqs = VS.all ? D.reqs : D.reqs.filter(h => VS_MAIN.includes(h));
  const reqShort = h => ({ 'Fugitive Emission (ISO 15848)': 'Fugitive', 'NACE / Sour': 'NACE / Sour', 'Dense Phase CO2': 'Dense CO2', 'Partial Stroke Test': 'PST',
    'Tightness / Leakage': 'Tightness', 'Blow-out Proof Stem': 'Blow-out', 'Material Cert. (EN 10204)': 'Mat. Cert', 'Painting / Coating': 'Painting' }[h] || h);
  // columns: [id, title, tags-of-group → tags counted, kind]  (kind: n = count of tags · s = sum)
  const cols = [...(VS.by === 't' ? [] : D.types.map(c => [`ty:${c}`, c, L => L.filter(t => t.type === c)])),
    ['tot', 'Total', L => L], ['open', 'Open Issues', L => L.filter(t => t.open), 's'], ['major', 'Major', L => L.filter(t => t.major), 'sm'],
    ['act', 'Tags with Action', L => L.filter(t => t.action)], ...(D.has_valvelist ? [['new', 'New Tags', L => L.filter(t => t.new)]] : []),
    ['revs', 'Rev B 이상', L => L.filter(t => t.revs > 1)], ['done', '검토 완료', L => L.filter(t => t.status === 'Accepted' || t.status === 'Resolved')],
    ...reqs.map(h => [`rq:${h}`, reqShort(h), L => L.filter(t => t.req.includes(h)), 'r'])];
  const groups = []; const gi = new Map();
  T.forEach(t => { const k = keyOf(t).join('\u0001'); if (!gi.has(k)) { gi.set(k, groups.length); groups.push({ key: keyOf(t), tags: [] }); } groups[gi.get(k)].tags.push(t); });
  const AO = { North: 0, South: 1, Brownfield: 2, W15: 3 };
  if (VS.by === 't') groups.sort((a, b) => D.types.indexOf(a.key[0]) - D.types.indexOf(b.key[0]) || (AO[a.key[1]] ?? 9) - (AO[b.key[1]] ?? 9));
  const val = (c, L) => { const sel = c[2](L); return c[3] === 's' ? sel.reduce((a, t) => a + t.open, 0) : c[3] === 'sm' ? sel.reduce((a, t) => a + t.major, 0) : sel.length; };
  const show = cols.filter(c => groups.some(g => val(c, g.tags)) || c[0] === 'tot');
  const max = Object.fromEntries(show.map(c => [c[0], Math.max(1, ...groups.map(g => val(c, g.tags)))]));
  VS.groups = groups; VS.cols = show;
  const cell = (c, L, gi, tot) => { const v = val(c, L); if (!v) return '<td class="vz">·</td>';
    const shade = tot ? '' : ` style="--h:${(0.08 + 0.42 * v / max[c[0]]).toFixed(2)}"`;
    const txt = VS.pct && c[0] !== 'tot' && !c[3]?.startsWith('s') ? `${Math.round(100 * v / Math.max(1, L.length))}%` : v;
    return `<td class="vc ${c[3] === 'r' ? 'vr' : ''}"${shade}><button class="vsn" data-g="${gi}" data-c="${esc(c[0])}" title="${esc(c[1])} — 눌러서 Tag 보기">${txt}</button></td>`; };
  box.classList.toggle('closed', !VS.open);
  box.innerHTML = `<div class="vsbar"><h3>Valve Summary <span class="soft" style="font-weight:400">Tag ${T.length} · 최신 Revision · Valve List Excel 'Summary' 와 같은 수</span></h3>
      <span class="segtab">${[['asu', 'Area · Site · Unit'], ['a', 'Area'], ['t', 'Valve Type × Area']].map(([k, l]) => `<button data-vsby="${k}" class="${VS.by === k ? 'on' : ''}">${l}</button>`).join('')}</span>
      <label class="soft"><input type="checkbox" id="vspct" ${VS.pct ? 'checked' : ''}> 비율(%)</label>
      <label class="soft" title="SIL · PST · Anti-static … 까지"><input type="checkbox" id="vsall" ${VS.all ? 'checked' : ''}> 특수요구 모두</label>
      <span class="sp"></span><button id="vsx" title="이 표가 'Summary' 시트로 들어 있는 Valve List Excel">⇩ Excel</button><button id="vstog" title="접기 / 펼치기">${VS.open ? '▾' : '▸'}</button></div>
    ${VS.open ? `<div class="vswrap"><table class="t vsumt" data-xfdata="1"><thead><tr><th>No.</th>${keyHead.map(h => `<th>${h}</th>`).join('')}${show.map(c => `<th class="${c[3] === 'r' ? 'vr' : ''}" title="${esc(c[1])}">${esc(c[1])}</th>`).join('')}</tr></thead><tbody>
      ${groups.map((g, i) => `<tr><td class="vk">${i + 1}</td>${g.key.map(x => `<td class="vk"><b>${esc(x || '—')}</b></td>`).join('')}${show.map(c => cell(c, g.tags, i)).join('')}</tr>`).join('')}
      <tr class="tot"><td class="vk"></td><td class="vk" colspan="${keyHead.length}"><b>Total</b></td>${show.map(c => cell(c, T, -1, 1)).join('')}</tr></tbody></table></div>
      <div class="soft vsnote">숫자를 누르면 그 Tag 목록 → Datasheet 열기 · Valve List / Issue List 에서 그 Tag 들만 보기. 'New Tags' = Valve List(TBE)에 없는 Tag · 'Updated Tags' 는 Valve List Excel 에서.</div>` : ''}`;
  box.onclick = e => {
    const by = e.target.closest('[data-vsby]'); if (by) { VS.by = by.dataset.vsby; LS.set('vs_by', VS.by); drawVsum(); return; }
    if (e.target.closest('#vstog')) { VS.open = !VS.open; LS.set('vs_open', VS.open); drawVsum(); return; }
    if (e.target.closest('#vsx')) { exportValveList(); return; }
    const b = e.target.closest('.vsn'); if (b) { const c = VS.cols.find(x => x[0] === b.dataset.c), gi = +b.dataset.g;
      const L = c[2](gi < 0 ? S.vsum.tags : VS.groups[gi].tags); vsTags(L, `${gi < 0 ? 'Total' : VS.groups[gi].key.filter(Boolean).join(' · ')} — ${c[1]}`); }
  };
  $('#vspct', box) && ($('#vspct', box).onchange = e => { VS.pct = e.target.checked; drawVsum(); });
  $('#vsall', box) && ($('#vsall', box).onchange = e => { VS.all = e.target.checked; LS.set('vs_all', VS.all); drawVsum(); });
}
function vsTags(L, title) {                   // the tags behind one number
  const html = `<div class="vstags"><table class="t"><thead><tr><th>Tag</th><th>Type</th><th>Rev</th><th>Area · Unit</th><th>Open</th><th>Major</th><th>Status</th></tr></thead><tbody>
    ${L.map(t => `<tr class="click" data-vtag="${t.id}"><td><b>${esc(t.tag)}</b></td><td>${esc(t.type)}</td><td>${esc(t.rev)}</td><td>${esc(t.area)} · ${esc(t.unit)}</td>
      <td>${t.open || ''}</td><td>${t.major || ''}</td><td>${pill(t.status)}</td></tr>`).join('')}</tbody></table></div>
    <p class="soft" style="margin:6px 0 0">Tag 를 누르면 Datasheet Review 로 · 아래 단추는 목록 화면에서 이 ${L.length}개 Tag 만 걸러 보여 줍니다 (열 필터 ▾ 로 풀 수 있음).</p>`;
  const p = modal(`${title} · Tag ${L.length}`, html, [['닫기', null], ['Issue List 에서 보기', 'iss'], ['Valve List 에서 보기', 'grid', 1]], 'vstags');
  $('#mBody').onclick = e => { const tr = e.target.closest('[data-vtag]'); if (tr) { $('#mAct button')?.click(); openDs(+tr.dataset.vtag); } };
  p.then(r => { if (!r) return; const set = new Set(L.map(t => t.tag));
    if (r === 'grid') { xfClear('grid'); xfState('grid').f.tag = set; G.mode = 'grid'; }
    else { xfClear('iss'); xfState('iss').f.tag = set; G.mode = 'issues'; IF.type = IF.st = IF.area = IF.sev = ''; }
    go('list'); });
}
function renderDash() {
  const s = S.sum, k = s.kpi, el = $('#v-dash'); el.classList.add('dashv');
  const tiles = [                               // [label, value, icon, bg, go, sub, accent(exception tile)]
    ['Total Valve Tags', k.tags, '▣', '#e8eefc', 'list'], ['Total Datasheets', k.datasheets, '▤', '#e8eefc', 'docs'],
    ['New Tags', s.has_valvelist ? k.new_tags : null, '✚', '#fff1d6', 'list', s.has_valvelist ? '' : 'Valve List 없음', '#b26a00'],
    ['Revision Changes', k.revision_changes, '⇆', '#fff4c2', 'rev', k.not_addressed ? `미반영 ${k.not_addressed} (이전 Rev 에서 Confirmed · 그대로)` : '', k.not_addressed ? 'var(--bad)' : '#8a6a00'],
    ['Data Errors', k.data_errors ?? 0, '✖', '#fbe3e1', 'list:issues:Data Error', '', 'var(--bad)'], ['Data Missing', k.data_missing ?? 0, '◌', '#ffe8cc', 'list:issues:Data Missing', '', '#a35400'],
    ['PMS Non-Compliant', s.has_pms ? k.pms_noncompliant : null, '⛭', '#fbe3e1', 'pms', 'PMS 없음', 'var(--bad)'],
    ['Process Data Mismatch', s.has_process ? k.process_mismatch : null, '∿', '#ffe8d6', s.has_process ? 'list:issues:Process Mismatch' : 'proc', 'Process Data 없음', 'var(--proc)'],
  ];                                            // review progress lives in the donut below (valve20: 8 tiles, not 10)
  const by = {}; s.tags.forEach(t => { by[t.review_status] = (by[t.review_status] || 0) + 1; });
  const cols = { 'Not Reviewed': '#c4cad6', 'Under Review': '#f0a43a', Accepted: '#1aa35a', Rejected: '#d9443a', Commented: '#2f5bd8', Resolved: '#0f7a43' };
  const cats = [['Data Error', k.data_errors ?? 0, 'var(--bad)', 'list:issues:Data Error'], ['Data Missing', k.data_missing ?? 0, 'var(--proc)', 'list:issues:Data Missing'],
    ['Open Item (HOLD/TBC)', k.open_items ?? 0, '#f0a43a', 'list:issues:Open Item'], ['PMS Non-Compliance', s.has_pms ? (k.pms_noncompliant ?? 0) : null, 'var(--pms)', 'list:issues:PMS Non-Compliance'],
    ['PMS Review', s.has_pms ? (k.pms_review ?? 0) : null, '#e07a5f', 'list:issues:PMS Review'], ['Process Mismatch', s.has_process ? (k.process_mismatch ?? 0) : null, '#f2730d', 'list:issues:Process Mismatch'],
    ['Revision Change', k.revision_changes ?? 0, '#e0b400', 'list:issues:Revision Change']];
  const cmax = Math.max(1, ...cats.map(c => c[1] || 0));
  el.innerHTML = `<div class="vh"><h2>Project Dashboard</h2><span class="soft">${esc(s.project.name)} · ${KIND_NAME} Datasheet</span><span class="sp"></span>
      <button data-go="docs">자료 올리기</button><button class="pri" data-go="review">Datasheet Review 열기</button></div>
    ${refDocs(s.latest_docs || {})}
    ${!k.datasheets ? `<div class="banner info">아직 데이터시트가 없습니다 — <b>Document Management</b> 에서 Datasheet PDF · Valve List · Process Data · PMS 를 올리세요.</div>` : ''}
    <div class="kpis">${tiles.map(([l, n, ic, bg, v, sub, ac]) => `<div class="kpi ${ac && n ? 'warn' : ''}" data-go="${v}" tabindex="0" style="--ac:${ac || 'var(--blue)'}"><div class="ic" style="background:${bg}">${ic}</div>
      <div class="l">${l}</div><div class="n ${n === null ? 'na' : ''}">${n === null ? (sub || '—') : n}</div></div>`).join('')}</div>
    ${k.datasheets ? '<div class="card vsum" id="vsum"><h3>Valve Summary</h3><div class="soft">불러오는 중…</div></div>' : ''}
    <div class="dashrow">
      <div class="card"><h3>Review Status by Tag</h3><div class="donut">${donut(STATUSES.map(st => ({ n: by[st] || 0, c: cols[st] })))}
        <div class="legend">${STATUSES.map(st => `<div data-go="review::${st}" class="click" title="이 상태의 Tag 만 보기"><i style="background:${cols[st]}"></i>${st}<b style="margin-left:auto;padding-left:10px">${by[st] || 0}</b></div>`).join('')}</div></div>
        <p class="soft hint" style="margin:10px 0 0">검토 필요 칸(라벨·값 짝이 불확실) <b>${k.review_required}</b>개 — 판정은 사용자가 확정합니다.</p></div>
      ${k.verification?.tags ? `<div class="card"><h3>Verification Coverage</h3><div class="chk-sum"><b>${k.verification.total}</b> 검사 (${k.verification.tags} Tag × ${Math.round(k.verification.total / k.verification.tags)} 항목) · <span class="ok">✓ ${k.verification.pass}</span> · <span class="bad">✗ ${k.verification.fail}</span> · <span class="soft">– ${k.verification.na}</span></div>
        ${Object.entries(k.verification.na_reasons || {}).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([r, n]) => `<div class="soft" style="font-size:11.5px">– ${esc(r)}: ${n}</div>`).join('')}
        <p class="soft hint">Issue List Excel 의 'Verification' 시트에 Tag × 항목 표가 있습니다.</p></div>` : ''}
      <div class="card"><h3>Issues by Category</h3><div class="cats">${cats.map(([l, n, c, v]) => `<div class="cat ${n === null ? 'na' : ''}" ${n === null ? '' : `data-go="${v}"`} title="${n === null ? 'PMS 없음' : 'Issue List 에서 보기'}">
        <span>${l}</span><i><b style="width:${n ? Math.max(4, 100 * n / cmax) : 0}%;background:${c}"></b></i><em>${n === null ? '—' : n}</em></div>`).join('')}</div>
        ${!s.has_process ? '<p class="soft" style="margin:4px 0 0">Process Mismatch — Process Data PDF 를 올리면 셉니다.</p>' : ''}
        <p class="soft hint" style="margin:8px 0 0">Dismissed 제외 · 최신 Revision 기준. 누르면 Issue List 가 그 종류로 걸러집니다.</p></div>
      <div class="card"><h3>By Area</h3><table class="t"><thead><tr><th>Area</th><th>Units</th><th>Tags</th><th>Open Issues</th><th>Major</th></tr></thead><tbody>
        ${(s.by_area || []).map(a => `<tr class="click" data-go="list:issues::${esc(a.area)}"><td><b>${esc(a.area)}</b></td><td>${esc(a.units.join(', '))}</td><td>${a.tags}</td><td>${a.issues}</td><td>${a.major}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">없음</td></tr>'}</tbody></table></div>
      <div class="card" data-big="tags"><h3>Review Status Table</h3>
        <table class="t"><thead><tr><th>Tag Number</th><th>Type</th><th>Rev.</th><th>Review Status</th><th>Issues</th></tr></thead><tbody>
        ${dashTagRows(s.tags, 200) || '<tr><td colspan="5" class="empty">없음</td></tr>'}</tbody></table></div>
      <div class="card"><h3>Recent Activity</h3>
        <table class="t"><thead><tr><th>When</th><th>Tag</th><th>Action</th><th>By</th></tr></thead><tbody>
        ${s.activity.map(a => `<tr ${a.datasheet_id ? `class="click" data-ds="${a.datasheet_id}"` : ''}><td class="mono nw" title="${esc(a.at)}">${esc(a.at.replace('T', ' ').slice(5, 16))}</td><td class="nw">${esc(a.tag || '-')}</td>
          <td>${esc(a.action)}${a.field_key ? ' · ' + esc(a.field_key) : ''}${a.after && a.action !== 'comment' ? ` <span class="soft">→ ${esc(String(a.after).slice(0, 40))}</span>` : ''}</td><td class="nw">${esc(a.by)}</td></tr>`).join('') || '<tr><td colspan="4" class="empty">기록이 없습니다</td></tr>'}</tbody></table></div>
    </div>`;
  drawVsum();
}
function dashTagRows(tags, max) {          // Review Status Table: problems first; the big view (⤢) shows every tag
  return tags.slice().sort((a, b) => (b.problems - a.problems) || (b.issues - a.issues) || a.tag_key.localeCompare(b.tag_key)).slice(0, max).map(t => `<tr class="click" data-ds="${t.id}"><td><b>${esc(t.tag_key)}</b></td><td>${esc(t.valve_type)}</td>
          <td class="nw">${esc(t.revs.join(' → '))}</td><td>${pill(t.review_status)}</td><td>${t.problems ? pill('bad', t.problems) : ''}${t.issues ? ' ' + pill('ReviewRequired', '⚠' + t.issues) : ''}${!t.problems && !t.issues ? '0' : ''}</td></tr>`).join('');
}
/* valve29 — a dashboard card opens big: click its title or an empty spot (rows · chips · links keep their own action).
   The big view is a copy over the page (the grid behind does not move); Esc · ✕ · a click outside closes it. */
function bigCard(card) {
  closeBig();
  const c = card.cloneNode(true); c.classList.add('big'); c.removeAttribute('style');
  $$('.xfb', c).forEach(b => b.remove()); $$('table[data-xfd]', c).forEach(t => { delete t.dataset.xfd; $$('tr[hidden]', t).forEach(r => { r.hidden = false; }); });   // its own filter
  if (card.dataset.big === 'tags') { const tb = $('tbody', c); if (tb) tb.innerHTML = dashTagRows(S.sum.tags, Infinity); }
  const x = document.createElement('button'); x.className = 'bigx'; x.textContent = '✕'; x.title = '닫기 (Esc)'; x.onclick = closeBig; c.prepend(x);
  const bg = document.createElement('div'); bg.className = 'bigbg'; bg.onclick = closeBig;
  document.body.append(bg, c);
}
function closeBig() { $$('body > .card.big, body > .bigbg').forEach(x => x.remove()); }
document.addEventListener('keydown', e => { if (e.key === 'Escape' && $('body > .card.big')) { e.stopPropagation(); closeBig(); } }, true);
document.addEventListener('click', e => {
  const dc = e.target.closest('#v-dash .card');
  if (dc && !e.target.closest('a, button, input, select, label, tr.click, tr[data-ds], [data-go], .kpi')) { bigCard(dc); return; }
  if (e.target.closest('body > .card.big [data-go], body > .card.big tr[data-ds]')) closeBig();     // a row in the big view opens its screen
  const rt = e.target.closest('[data-retry]'); if (rt) { S.grid = null; S.issues = null; go(rt.dataset.retry); return; }
  const g = e.target.closest('[data-go]'); if (g && !e.target.closest('.tbar')) {
    const [v, m, f, ar] = g.dataset.go.split(':'); if (m) G.mode = m;
    if (v === 'list' && m === 'issues') { IF.type = f || ''; IF.st = ''; IF.area = ar || ''; }
    if (v === 'review' && f !== undefined) W.st = f;
    go(v); return; }
  const d = e.target.closest('tr[data-ds]'); if (d && !e.target.closest('#v-list')) openDs(+d.dataset.ds);
});

/* ── 2. Document Management ───────────────────────────────────────────── */
const KIND = { datasheet: ['Valve Datasheet PDF', '필수', '.pdf', true], valvelist: ['Valve List (TBE)', '선택', '.xlsx,.xlsm,.xls', false],
  process: ['Process Data', '선택', '.pdf,.xlsx,.xls', true], pms: ['Piping Material Spec (PMS)', '선택', '.pdf', false] };
function renderDocs() {
  const el = $('#v-docs'), docs = S.sum.documents;
  el.innerHTML = `<div class="vh"><h2>Document Management</h2><span class="soft">원본은 서버에 그대로 보관되고 절대 덮어쓰지 않습니다.</span></div>
    <div class="drops">${Object.entries(KIND).map(([k, [t, req, acc, multi]]) => `<label class="drop" data-k="${k}">
      <b>${t} <span class="${req === '필수' ? 'req' : 'opt'}">${req}</span></b><small>${acc.replace(/,/g, ' · ')}${multi ? ' · 여러 개' : ''}</small>
      <div class="soft" style="margin-top:6px">여기에 놓거나 <u>파일 선택</u></div><input type="file" hidden accept="${acc}" ${multi ? 'multiple' : ''}></label>`).join('')}</div>
    <div class="banner info">Valve Datasheet 는 수십~수백 장을 한 번에 넣어도 됩니다 (개별 PDF · 병합 PDF 모두). Tag 번호로 나누고, 같은 Tag 의 새 Revision 은 이전 판과 따로 보관됩니다.
      Valve List 는 <b>.xlsx</b> 를 그대로 고칩니다 (.xls 는 회사 PC 의 Excel 로 자동 변환 · 안 되면 Excel 에서 .xlsx 로 저장해 넣으세요).</div>
    <div id="jobs"></div>
    <div class="card"><h3>Uploaded Documents (${docs.length})</h3><table class="t"><thead><tr><th>#</th><th>Kind</th><th>File</th><th>Pages</th><th>Result</th><th>Status</th><th>By</th><th>Uploaded</th><th></th></tr></thead><tbody>
    ${docs.map(d => `<tr><td>${d.id}</td><td>${esc(KIND[d.kind]?.[0] || d.kind)}</td><td><b>${esc(d.filename)}</b></td><td>${d.pages || '-'}</td>
      <td>${d.kind === 'datasheet' && d.info ? `${d.info.datasheets ?? '-'} datasheets${d.info.scanned_pages ? ` · <span style="color:var(--bad)">스캔 쪽 ${d.info.scanned_pages}</span>` : ''}` :
        d.kind === 'valvelist' && d.info?.sheets ? d.info.sheets.filter(s => s.kind === 'appendix').map(s => `${esc(s.sheet)} (${s.tags.length})`).join(' · ') : esc(d.info?.note || '')}</td>
      <td>${pill(d.status === 'done' ? 'ok' : d.status === 'error' ? 'bad' : 'UnderReview', d.status)}${d.error ? `<div style="color:var(--bad)">${esc(d.error)}</div>` : ''}${d.stored_ok === false ? `<div class="stbad" title="서버에 저장된 원본이 올린 파일과 달라 열리지 않습니다 — 같은 파일을 위 칸에 다시 올리면 저장본을 새로 씁니다 (Tag · 지적 · 검토 기록은 그대로)">⚠ 원본 손상 — 같은 파일 다시 올리기</div>` : ''}</td>
      <td>${esc(d.uploaded_by)}</td><td class="mono">${esc((d.uploaded_at || '').replace('T', ' ').slice(0, 16))}</td>
      <td>${d.status === 'error' ? `<button data-retry="${d.id}">재처리</button>` : d.kind === 'datasheet' && d.status === 'done' ? `<button data-retry="${d.id}" title="개선된 읽기로 다시 읽습니다 — 검토자 수정 · 의견 · Mark-up · 상태는 그대로">다시 읽기</button>` : ''}${d.kind !== 'valvelist' ? ` <a href="/api/valve/documents/${d.id}/file" target="_blank">원본</a>` : ''}${d.status === 'queued' || d.status === 'running' ? '' : ` <button class="ghost ddel" data-del="${d.id}" title="이 문서를 프로젝트에서 지웁니다 — 휴지통에서 되돌릴 수 있음">🗑</button>`}</td></tr>`).join('') || '<tr><td colspan="9" class="empty">아직 없습니다</td></tr>'}
    </tbody></table></div><div id="trashc"></div>`;
  (S.jobEls || []).filter(b => b.isConnected || !b.dataset.gone).forEach(b => $('#jobs').append(b));
  jobsBar();
  drawTrash();
  $$('.drop', el).forEach(d => {
    const inp = $('input', d);
    inp.onchange = () => upload(d.dataset.k, [...inp.files]);
    d.ondragover = e => { e.preventDefault(); d.classList.add('over'); };
    d.ondragleave = () => d.classList.remove('over');
    d.ondrop = e => { e.preventDefault(); d.classList.remove('over'); upload(d.dataset.k, [...e.dataTransfer.files]); };
  });
  $$('[data-retry]', el).forEach(b => b.onclick = async () => { try { watch(await api('POST', `/documents/${b.dataset.retry}/retry`)); } catch (e) { toast(e.message, 1); } });
  $$('[data-del]', el).forEach(b => b.onclick = () => deleteDoc(+b.dataset.del));
}
/* valve32 — 올린 문서 지우기: 함께 지워지는 것을 먼저 보여 주고, 휴지통에 넣는다 (되돌리기 가능 · 원본 파일은 그대로) */
async function deleteDoc(id) {
  let m; try { m = await api('GET', `/documents/${id}/impact`); } catch (e) { toast(e.message, 1); return; }
  const kindName = KIND[m.kind]?.[0] || m.kind;
  const lines = [`<b>${esc(m.filename)}</b> <span class="soft">(${esc(kindName)})</span>`];
  if (m.kind === 'datasheet') {
    lines.push(`이 문서에서 읽은 데이터시트 <b>${m.datasheets}</b>개 (Tag ${m.tags}개)가 함께 빠집니다.`);
    if (m.tags_gone) lines.push(`<span style="color:var(--bad)">그중 <b>${m.tags_gone}</b>개 Tag 는 다른 Revision 이 없어 목록에서 사라집니다.</span>`);
    else if (m.tags) lines.push('같은 Tag 의 다른 Revision 이 남아 있어 그 Revision 으로 돌아갑니다.');
    if (m.comments || m.decisions) lines.push(`검토자 코멘트 · Mark-up <b>${m.comments}</b>개, 지적 결정 <b>${m.decisions}</b>개도 함께 휴지통으로 갑니다.`);
  } else lines.push(m.other_same_kind ? `같은 종류의 다른 문서(${m.other_same_kind}개) 중 가장 최근 것으로 검토가 다시 계산됩니다.` : `이 종류의 문서가 없어지므로 ${esc(kindName)} 대조는 빠집니다.`);
  lines.push('<span class="soft">휴지통에서 되돌릴 수 있습니다. 원본 파일은 지우지 않습니다. 변경 이력(Audit)은 남습니다.</span>');
  const r = await modal('문서 지우기', `<div style="display:grid;gap:6px">${lines.map(l => `<div>${l}</div>`).join('')}</div>`, [['취소', null], ['휴지통으로', 'go', 1]]);
  if (r !== 'go') return;
  const btn = $(`[data-del="${id}"]`); if (btn) { btn.disabled = true; btn.textContent = '지우는 중…'; }
  try { const x = await api('DELETE', `/documents/${id}`); toast(`지웠습니다 — 휴지통에서 되돌릴 수 있습니다 (데이터시트 ${x.datasheets}개)`);
    if (S.ds && !S.sum.tags.some(t => t.id === S.ds.id)) S.ds = null; S.dsId = null; await refresh(); }
  catch (e) { toast(e.message, 1); }
}
async function drawTrash() {
  const box = $('#trashc'); if (!box) return;
  let t; try { t = await api('GET', `/projects/${S.pid}/trash`); } catch (_) { return; }
  if (!t.items.length) { box.innerHTML = ''; return; }
  box.innerHTML = `<div class="card" style="margin-top:12px"><h3>휴지통 (${t.items.length}) <span class="soft" style="font-weight:400">— 지운 문서 · 되돌리면 데이터시트 · 코멘트 · 결정이 그대로 돌아옵니다</span></h3>
    <table class="t"><thead><tr><th>File</th><th>Kind</th><th>Datasheets</th><th>Comments</th><th>지운 사람</th><th>지운 시각</th><th></th></tr></thead><tbody>
    ${t.items.map(x => `<tr><td><b>${esc(x.filename)}</b></td><td>${esc(KIND[x.kind]?.[0] || x.kind)}</td><td>${x.datasheets}</td><td>${x.comments}</td><td>${esc(x.by || '')}</td>
      <td class="mono">${esc((x.deleted_at || '').replace('T', ' ').slice(0, 16))}</td><td><button data-restore="${esc(x.name)}">되돌리기</button></td></tr>`).join('')}</tbody></table></div>`;
  $$('[data-restore]', box).forEach(b => b.onclick = async () => {
    b.disabled = true; b.textContent = '되돌리는 중…';
    try { const r = await api('POST', `/projects/${S.pid}/trash/${encodeURIComponent(b.dataset.restore)}/restore`); toast(`되돌렸습니다 — ${r.filename}`); await refresh(); }
    catch (e) { toast(e.message, 1); } });
}
async function upload(kind, files) {
  if (!files.length) return;
  const fd = new FormData(); fd.append('kind', kind); files.forEach(f => fd.append('files', f));
  try { const j = await api('POST', `/projects/${S.pid}/upload`, fd); if (j.skipped?.length) toast(j.skipped.join(' / '), 1); watch(j); }
  catch (e) { toast(e.message, 1); }
}
function closeJob(box) {
  box.dataset.gone = '1'; box.remove(); S.jobEls = (S.jobEls || []).filter(b => b !== box); jobsBar();
}
function jobsBar() {                                 // 상태 창이 둘 이상이면 '모두 닫기'
  const host = $('#jobs'); if (!host) return;
  let bar = $('#jobsall', host); const n = $$('.jobc', host).length;
  if (n < 2) { bar?.remove(); return; }
  if (!bar) { bar = document.createElement('div'); bar.id = 'jobsall'; bar.innerHTML = '<button class="ghost">✕ 상태 창 모두 닫기</button>'; host.prepend(bar);
    bar.onclick = () => $$('.jobc', host).forEach(closeJob); }
  $('button', bar).textContent = `✕ 상태 창 모두 닫기 (${n})`;
}
function watch(job) {
  const box = document.createElement('div'); box.className = 'card jobc'; box.style.marginBottom = '12px';
  (S.jobEls ||= []).unshift(box);                   // kept across re-renders of this screen
  $('#jobs')?.prepend(box);
  box.addEventListener('click', e => { if (e.target.closest('.jx')) closeJob(box); });   // valve34: 상태 창 닫기
  jobsBar();
  const tick = async () => {
    let j; try { j = await api('GET', `/jobs/${job.id}`); } catch (e) { box.innerHTML = `<button class="jx ghost" title="닫기">✕</button><b style="color:var(--bad)">${esc(e.message)}</b>`; return; }
    const pct = Math.round(100 * j.done / Math.max(1, j.total));
    box.innerHTML = `<button class="jx ghost" title="이 상태 창 닫기 (작업은 계속됩니다)">✕</button><b>처리 중</b> <span class="soft">${esc(j.file)} · ${esc(j.msg)}</span><div class="prog"><i style="width:${pct}%"></i></div>${pct}% (${j.done}/${j.total} 쪽)
      ${j.warn ? `<div style="color:var(--warn)">${esc(j.warn)}</div>` : ''}${j.errors.map(e => `<div style="color:var(--bad)">✖ ${esc(e.file)} — ${esc(e.error)}</div>`).join('')}`;
    if (j.status === 'done') {
      box.querySelector('b').textContent = j.errors.length ? '끝 (오류 있음 — 아래 표에서 재처리)' : '분석 끝';
      if (j.exports?.length) {                        // the Excel lists made with the analysis — downloaded right away
        box.insertAdjacentHTML('beforeend', `<div style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap;align-items:center"><b>결과 파일</b>${j.exports.map(f => `<a class="btnlink" href="${f.url}" download>⇩ ${esc(f.kind)}</a>`).join('')}
          <button data-go="list">Excel List 보기 (PDF 미리보기 연동)</button><button id="jmk">⇩ Mark-up PDF</button><span class="soft">Excel 의 칸 · 링크를 누르면 이 도구가 그 PDF 장 · 위치를 엽니다</span></div>`);
        if (!j.errors.length) j.exports.forEach((f, n) => setTimeout(() => { const a = document.createElement('a'); a.href = f.url; a.download = f.name; document.body.append(a); a.click(); a.remove(); }, 300 + n * 900));
        $('#jmk', box).onclick = async () => { const t = await pickTypes('Mark-up PDF — 넣을 Issue Type'); if (t == null) return;
          toast('Mark-up PDF 를 만드는 중…'); download(`/projects/${S.pid}/markup.pdf?types=${encodeURIComponent(t)}${pdfq()}`).catch(e => toast(e.message, 1)); };
        await refresh(); return;
      }
      await refresh(); setTimeout(() => { box.dataset.gone = '1'; box.remove(); }, j.errors.length ? 20000 : 5000);
    } else setTimeout(tick, 700);
  };
  tick();
}

/* ── 3. Valve List (Excel-like grid) ──────────────────────────────────── */
const G = { sort: LS.get('gsort', { k: 'tag', d: 1 }), flt: {}, sel: new Set(), last: null };
/* live PDF preview beside the lists: one click on a cell / issue -> that page, that point */
function mountPreview() {
  const host = $('#lpv'); if (!host) return;
  S.pv = new Viewer(host, { extra: '<span class="lbl" id="pvcap"></span>', onOverlay: o => { if (o.iss && G.mode === 'issues') { G.selIss = o.iss; renderList(); } } });
  S.pvLoaded = null;
  const sp = $('#lpsplit');
  if (sp) sp.onmousedown = e => {
    e.preventDefault(); const box = $('.lp').getBoundingClientRect();
    const mv = ev => { const w = Math.max(22, Math.min(70, (box.right - ev.clientX) / box.width * 100)); host.style.width = w + '%'; LS.set('pvw', w); };
    const up = () => { removeEventListener('mousemove', mv); removeEventListener('mouseup', up); S.pv?.paintOv(); };
    addEventListener('mousemove', mv); addEventListener('mouseup', up);
  };
  if (S.pvTarget) preview(S.pvTarget);
  else $('#pvcap').textContent = '셀이나 지적 사항을 누르면 그 장 · 그 위치를 보여 줍니다';
}
async function preview(t) {
  S.pvTarget = t; if (!S.pv) return;
  const key = t.doc + ':' + t.pages.join(',');
  if (S.pvLoaded !== key) { await S.pv.load(t.doc, t.pages); S.pvLoaded = key; S.pv.fit(); }
  S.pv.setOverlays(t.ovs || []);
  if (t.bbox) S.pv.focus(t.page, t.bbox, t.label); else S.pv.goPage(t.page || t.pages[0]);
  const c = $('#pvcap'); if (c) c.textContent = t.label + (t.page ? ` · p.${t.page}` : '');
}
async function dsIssues(dsId) {                     // issues of one datasheet as preview overlays
  if (!S.issues) { const r = await loadIssues(); S.issues = r.issues; S.issueTypes = r.types; }
  S.pv?.setMarks(S.issues.filter(i => i.ds_id === dsId && i.comment_id && i.bbox && i.status !== 'Dismissed').map(i => ({ id: i.comment_id, page: i.page, bbox: i.bbox,
    kind: i.kind || 'rect', points: i.points, category: i.category || 'comment', text: i.text_raw ?? i.description, by: i.by, no: i.no })));
  return S.issues.filter(i => i.ds_id === dsId && i.bbox && i.status !== 'Dismissed' && !i.comment_id && (IF.internal || i.type !== 'Extraction Review'))
    .map(i => ({ cat: i.color, page: i.page, bbox: i.bbox, no: i.no, iss: i.ikey, title: `#${i.no} ${i.type} · ${i.field}`, text: descText(i), sel: G.selIss === i.ikey }));
}
const listTop = () => `<span class="segtab"><button data-lm="grid" class="${G.mode !== 'issues' && G.mode !== 'req' ? 'on' : ''}">Valve List</button><button data-lm="issues" class="${G.mode === 'issues' ? 'on' : ''}">Issue List${S.sum?.kpi ? ` (${(S.sum.kpi.data_errors || 0) + (S.sum.kpi.data_missing || 0) + (S.sum.kpi.open_items || 0) + (S.sum.kpi.pms_noncompliant || 0) + (S.sum.kpi.pms_review || 0)})` : ''}</button><button data-lm="req" class="${G.mode === 'req' ? 'on' : ''}" title="PFP · Fugitive · Fire Safe · Dense CO2 · NACE … 한눈에">Special Req.</button></span>`;
const lpWrap = inner => `<div class="lp"><div class="lp-left">${inner}</div><div class="split" id="lpsplit" title="끌어 너비 조절"></div><div class="lp-right" id="lpv" style="width:${LS.get('pvw', 42)}%"></div></div>`;
async function renderList() {
  const el = $('#v-list');
  if (G.mode === 'issues') return renderIssues();
  if (G.mode === 'req') return renderReq();
  if (!S.grid) { el.innerHTML = '<div class="empty">불러오는 중…</div>'; try { S.grid = await api('GET', `/projects/${S.pid}/grid`); } catch (e) { S.grid = null; el.innerHTML = `<div class="empty">목록을 불러오지 못했습니다 — ${esc(e.message)}<br><button data-retry="list">다시 시도</button></div>`; return; } }
  if (!S.grid?.columns) { S.grid = null; el.innerHTML = '<div class="empty">목록 응답이 비었습니다 <button data-retry="list">다시 시도</button></div>'; return; }
  const base = [{ key: 'tag', title: 'Tag Number', w: 120 }, { key: 'area', title: 'Area', w: 76 }, { key: 'unit', title: 'Unit', w: 46 }, { key: 'valve_type', title: 'Valve Type', w: 80 }, { key: 'rev', title: 'Rev.', w: 50 },
    { key: 'status', title: 'Review Status', w: 110 }, { key: 'doc_no', title: 'DS Document No.', w: 150 }];
  const all = base.concat(S.grid.columns.filter(c => c.key !== 'valve_type').map(c => ({ key: c.key, title: c.title, w: 130 }))).concat([{ key: 'notes', title: 'Notes', w: 60 }]);
  const order = LS.get('gorder', null), widths = LS.get('gw', {});
  let cols = order ? order.map(k => all.find(c => c.key === k)).filter(Boolean).concat(all.filter(c => !order.includes(c.key))) : all;
  cols = cols.map(c => ({ ...c, w: widths[c.key] || c.w }));
  const val = (r, k) => k in r ? r[k] : (r.cells[k]?.v ?? '');
  const types = [...new Set(S.grid.rows.map(r => r.valve_type))].sort();
  let rows = S.grid.rows.filter(r => Object.entries(G.flt).every(([k, q]) => !q || String(val(r, k)).toLowerCase().includes(q.toLowerCase())));
  const tq = ($('#gq')?.value || '').trim().toUpperCase().replace(/[^0-9A-Z]/g, '');
  if (tq) rows = rows.filter(r => r.tag.includes(tq));
  const ft = $('#gt')?.value, fs = $('#gs')?.value;
  if (ft) rows = rows.filter(r => r.valve_type === ft);
  if (fs) rows = rows.filter(r => r.status === fs);
  const coll = COLL, sk = rows.map(r => [String(val(r, G.sort.k)), r]); sk.sort((a, b) => G.sort.d * coll.compare(a[0], b[0])); rows = sk.map(x => x[1]);
  rows = xfApply('grid', rows, Object.fromEntries(cols.map(c => [c.key, r => val(r, c.key)])), () => { G.rowsOnly = true; renderList(); });
  const keepQ = $('#gq')?.value || '', keepT = ft || '', keepS = fs || '';
  const oldWrap = $('.xg-wrap', el), keepX = oldWrap?.scrollLeft || 0, keepY = oldWrap?.scrollTop || 0;
  const __grows = rows.map((r, n) => () => `<tr data-id="${r.id}" class="${G.sel.has(r.id) ? 'sel' : ''}"><td class="fz" style="left:0"><input type="checkbox" ${G.sel.has(r.id) ? 'checked' : ''} aria-label="선택"></td><td class="fz" style="left:30px">${n + 1}</td>
        ${cols.map((c, i) => {
          if (c.key === 'tag') return `<td class="fz fzl" style="left:70px" data-tagcell="1"><span class="tag" style="color:var(--blue);font-weight:600">${esc(r.tag)}</span> <a href="#review" data-open="${r.id}" title="Datasheet Review 로 열기">↗</a></td>`;
          if (c.key === 'status') return `<td>${pill(r.status)}</td>`;
          if (c.key in r) return `<td>${esc(r[c.key])}</td>`;
          const x = r.cells[c.key]; if (!x) return '<td class="ph">—</td>';
          return `<td data-fid="${x.id}" data-k="${c.key}" class="${x.ed ? 'ed' : ''} ${x.st === 'placeholder' || x.st === 'blank' ? 'ph' : ''} ${x.st === 'review' ? 'rv' : ''}" title="${esc(x.v + (x.u ? ' ' + x.u : ''))}${x.ed ? ' (사용자 수정)' : ''} · p.${x.p} — 두 번 눌러 고치기">${esc(x.v || (x.st === 'blank' ? 'Not Found' : ''))}${x.u && x.v ? ' <small>' + esc(x.u) + '</small>' : ''}</td>`;
        }).join('')}</tr>`), __gfb = `<tr><td colspan="${cols.length + 2}" class="empty">조건에 맞는 행이 없습니다 — 필터를 지우세요</td></tr>`;
  const fast = G.rowsOnly && $('#xg tbody', el); G.rowsOnly = false;
  if (fast) {                                                // valve29: a keystroke in a filter redraws only the rows
    chunkRows($('#xg tbody', el), __grows, 80, __gfb); G.rows = rows;
    const c = $('#gcnt', el); if (c) c.textContent = `${rows.length} / ${S.grid.rows.length} rows`; return;
  }
  G.rows = rows;
  el.innerHTML = `<div class="vh">${listTop()}<input type="search" id="gq" placeholder="Search Tag Number…" style="width:180px" value="${esc(keepQ)}">
      <select id="gt"><option value="">All Valve Types</option>${types.map(t => `<option ${t === keepT ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select>
      <select id="gs"><option value="">All Status</option>${STATUSES.map(t => `<option ${t === keepS ? 'selected' : ''}>${t}</option>`).join('')}</select>
      <span class="soft"><span id="gcnt">${rows.length} / ${S.grid.rows.length} rows</span> · 선택 <b id="gsel">${G.sel.size}</b></span><span class="sp"></span>
      <select id="gbulk" ${G.sel.size ? '' : 'disabled'}><option value="">선택 행 상태 바꾸기…</option>${STATUSES.map(t => `<option>${t}</option>`).join('')}</select>
      <button id="greset" title="열 순서·너비 처음대로">열 초기화</button>
      <button id="gopen" ${G.sel.size ? '' : 'disabled'}>Open Datasheet</button><button class="pri" id="gx">⇩ Export Excel</button></div>
    ${lpWrap(`<div class="xg-wrap"><table class="xg" id="xg" style="width:${70 + cols.reduce((a, c) => a + c.w, 0)}px"><colgroup><col style="width:30px"><col style="width:40px">${cols.map(c => `<col style="width:${c.w}px">`).join('')}</colgroup>
      <thead><tr><th class="fz" style="left:0"><input type="checkbox" id="gall" aria-label="전체 선택"></th><th class="fz" style="left:30px">#</th>${cols.map((c, i) => `<th draggable="true" data-k="${c.key}" ${i === 0 ? 'class="fz fzl" style="left:70px"' : ''} title="${esc(c.title)} — 눌러 정렬 · 끌어 순서 바꾸기">${esc(c.title)}${G.sort.k === c.key ? (G.sort.d > 0 ? ' ▲' : ' ▼') : ''} ${xfBtn('grid', c.key)}<span class="rz"></span></th>`).join('')}</tr>
      <tr class="flt"><th class="fz" style="left:0"></th><th class="fz" style="left:30px"></th>${cols.map((c, i) => `<th ${i === 0 ? 'class="fz fzl" style="left:70px"' : ''}><input data-f="${c.key}" value="${esc(G.flt[c.key] || '')}" placeholder="filter" aria-label="${esc(c.title)} filter"></th>`).join('')}</tr></thead>
      <tbody></tbody></table></div>`)}`;
  chunkRows($('#xg tbody'), __grows, 80, __gfb);
  const wrap = $('.xg-wrap', el); wrap.scrollLeft = keepX; wrap.scrollTop = keepY;
  $$('[data-lm]', el).forEach(b => b.onclick = () => { G.mode = b.dataset.lm; renderList(); });
  mountPreview();
  const re = () => renderList(), reRows = () => { G.rowsOnly = true; renderList(); };
  $('#gq').oninput = () => { clearTimeout(G.t); G.t = setTimeout(reRows, 90); };
  $('#gt').onchange = reRows; $('#gs').onchange = reRows;
  $('#greset').onclick = () => { LS.set('gorder', null); LS.set('gw', {}); re(); };
  $('#gx').onclick = exportValveList;
  $('#gopen').onclick = () => openDs([...G.sel][0]);
  $('#gbulk').onchange = async e => {
    const st = e.target.value; if (!st) return;
    for (const id of G.sel) await api('PUT', `/datasheets/${id}/status`, { status: st, comment: 'bulk (Valve List)' });
    toast(`${G.sel.size}개 → ${st}`); S.grid = null; await refresh(); renderList();
  };
  $('#gall').onchange = e => { G.rows.forEach(r => e.target.checked ? G.sel.add(r.id) : G.sel.delete(r.id)); paintSel(); };
  $$('thead tr.flt input', el).forEach(i => i.oninput = () => { G.flt[i.dataset.f] = i.value; clearTimeout(G.t); G.t = setTimeout(reRows, 90); });
  const tb = $('#xg tbody');
  tb.onclick = e => {
    const a = e.target.closest('[data-open]'); if (a) { e.preventDefault(); openDs(+a.dataset.open); return; }
    const tr = e.target.closest('tr'); if (!tr) return;
    const id = +tr.dataset.id, ids = G.rows.map(r => r.id);
    if (e.shiftKey && G.last) { const [i0, i1] = [ids.indexOf(G.last), ids.indexOf(id)].sort((a, b) => a - b); ids.slice(i0, i1 + 1).forEach(x => G.sel.add(x)); }
    else if (e.ctrlKey || e.metaKey || e.target.type === 'checkbox') G.sel.has(id) ? G.sel.delete(id) : G.sel.add(id);
    else { G.sel.clear(); G.sel.add(id); }
    G.last = id; paintSel(); const tdk = e.target.closest('td[data-k]');
    const near = ids.slice(ids.indexOf(id) + 1, ids.indexOf(id) + 3).concat(ids.slice(Math.max(0, ids.indexOf(id) - 1), ids.indexOf(id)));
    link(tdk ? { t: 'field', id, key: tdk.dataset.k, near } : { t: 'ds', id, near });     // valve29: the PDF window shows that tag / cell (+ prefetches the next rows)
    const row = S.grid.rows.find(r => r.id === id), td = e.target.closest('td');   // live preview
    $$('td.hit', tb).forEach(x => x.classList.remove('hit')); td?.classList.add('hit');
    const x = td?.dataset.k ? row.cells[td.dataset.k] : null, col = cols.find(c => c.key === td?.dataset.k);
    dsIssues(row.id).then(ovs => preview({ doc: row.document_id, pages: row.pages, page: x?.p || row.page, bbox: x?.b, ovs,
      label: `${row.tag}${col ? ' · ' + col.title + ': ' + (x?.v || 'Not Found') : ''}` }));
  };
  function paintSel() {                     // selection without re-rendering (a re-render would eat the double-click)
    $$('tr[data-id]', tb).forEach(tr => { const on = G.sel.has(+tr.dataset.id); tr.classList.toggle('sel', on); $('input', tr).checked = on; });
    $('#gsel').textContent = G.sel.size; $('#gbulk').disabled = $('#gopen').disabled = !G.sel.size;
  }
  tb.onmousedown = e => { if (e.detail > 1) e.preventDefault(); };   // no text selection on double-click
  tb.ondblclick = e => {
    const td = e.target.closest('td[data-fid]'); if (!td || td.querySelector('input')) return;
    const tr = td.closest('tr'), row = S.grid.rows.find(r => r.id === +tr.dataset.id), x = row.cells[td.dataset.k];
    td.innerHTML = `<input class="cell" value="${esc(x.v)}">`; const inp = $('input', td); inp.focus(); inp.select();
    const save = async () => {
      if (inp.value === x.v) { re(); return; }
      try { await api('PUT', `/datasheets/${row.id}/fields/${x.id}`, { value: inp.value, comment: 'Valve List grid' });
        x.v = inp.value; x.ed = true; toast('저장 — 감사 기록에 남았습니다'); } catch (err) { toast(err.message, 1); }
      re();
    };
    let done = false;
    const once = f => () => { if (!done) { done = true; f(); } };
    inp.onkeydown = ev => { if (ev.key === 'Enter') once(save)(); if (ev.key === 'Escape') once(re)(); };
    inp.onblur = once(save);
  };
  // sort · reorder · resize
  let dragK = null;
  $$('#xg thead tr:first-child th[data-k]').forEach(th => {
    th.onclick = e => { if (e.target.classList.contains('rz')) return; const k = th.dataset.k; G.sort = { k, d: G.sort.k === k ? -G.sort.d : 1 }; LS.set('gsort', G.sort); re(); };
    th.ondragstart = e => { dragK = th.dataset.k; th.classList.add('drag'); e.dataTransfer.effectAllowed = 'move'; };
    th.ondragend = () => th.classList.remove('drag');
    th.ondragover = e => { e.preventDefault(); th.classList.add('dropL'); };
    th.ondragleave = () => th.classList.remove('dropL');
    th.ondrop = e => { e.preventDefault(); const keys = cols.map(c => c.key), from = keys.indexOf(dragK), to = keys.indexOf(th.dataset.k);
      if (from < 0 || to < 0 || from === to) return; keys.splice(to, 0, keys.splice(from, 1)[0]); LS.set('gorder', keys); re(); };
    $('.rz', th).onmousedown = e => {
      e.preventDefault(); e.stopPropagation(); th.draggable = false;
      const k = th.dataset.k, x0 = e.clientX, col = $$('#xg col')[cols.findIndex(c => c.key === k) + 2], w0 = parseFloat(col.style.width);
      const mv = ev => { col.style.width = Math.max(40, w0 + ev.clientX - x0) + 'px'; };
      const up = () => { removeEventListener('mousemove', mv); removeEventListener('mouseup', up); const w = LS.get('gw', {}); w[k] = parseFloat(col.style.width); LS.set('gw', w); th.draggable = true; };
      addEventListener('mousemove', mv); addEventListener('mouseup', up);
    };
  });
}
const IF = { type: '', sev: '', st: '', q: '', area: '', internal: false, dg: LS.get('issdg', 1), open: new Set() };
/* valve35 — 정리 보기: touching Data Missing on one page = one block, the same comment on several tags = one Typical row
   (server: app/valve/digest.py).  Every finding stays; '▸ 상세' opens its rows.  Filters work on the findings themselves. */
async function loadDigest() {
  if (S.dgFor === S.issues && S.dg) return S.dg;
  const r = await api('GET', `/projects/${S.pid}/issues/digest`);
  S.dg = r.entries; S.dgFor = S.issues; S.dgIdx = new Map(S.issues.map(i => [i.ds_id + '|' + i.ikey, i]));
  return S.dg;
}
function digestRows(L) {
  const vis = new Set(L.map(i => i.ds_id + '|' + i.ikey));
  return S.dg.map((e, k) => ({ e, k, ms: e.m.filter(x => vis.has(x)).map(x => S.dgIdx.get(x)).filter(Boolean) })).filter(g => g.ms.length);
}
/* valve29 — Special Requirements at a glance: Area totals (click a number to filter) + every valve × requirement, Excel */
const RQ = { area: '', req: '', q: '' };
const reqShort = h => ({ 'Fugitive Emission (ISO 15848)': 'Fugitive', 'NACE / Sour': 'NACE', 'Partial Stroke Test': 'PST', 'Tightness / Leakage': 'Tightness',
  'Blow-out Proof Stem': 'Blow-out', 'Material Cert. (EN 10204)': 'Cert. 3.1/3.2', 'DBB / Cavity Relief': 'DBB / Cavity', 'Painting / Coating': 'Painting' }[h] || h);
function reqCell(v, on) {                                 // 'Yes — Class A type tested (GN 31)' → '● Class A type tested'
  if (!v) return '';
  if (!on) return '<span class="rqx">Not Req.</span>';
  let t = String(v); for (let k = 0; k < 4 && /\([^()]*\)/.test(t); k++) t = t.replace(/\s*\([^()]*\)/g, '');   // nested '(… (PFP) …)' sources
  t = t.replace(/^Yes\s*—\s*/i, '').replace(/^Required\s*(—\s*)?/i, '').replace(/\s*·\s*notes:.*$/, '').trim();
  if (/^yes$/i.test(t) || !t) t = '';
  return `● ${esc(t.slice(0, 28))}${t.length > 28 ? '…' : ''}`;
}
async function renderReq() {
  const el = $('#v-list');
  if (!S.reqs) { el.innerHTML = '<div class="empty">특수 요구사항을 모으는 중…</div>'; S.reqs = await api('GET', `/projects/${S.pid}/requirements`); }
  const R = S.reqs, cols = R.columns, q = RQ.q.toUpperCase().replace(/[^0-9A-Z]/g, '');
  const L = xfApply('req', R.tags.filter(t => (!RQ.area || t.area === RQ.area) && (!RQ.req || t.on.includes(RQ.req)) && (!q || t.tag.includes(q))),
    { tag: t => t.tag, area: t => t.area, unit: t => t.unit, type: t => t.valve_type, n: t => t.on.length,
      ...Object.fromEntries(cols.map(h => [h, t => !t.cells[h] ? '' : t.on.includes(h) ? 'Required' : 'Not Required'])) }, () => renderReq());
  const num = (n, a, h) => n ? `<button class="rqn ${RQ.area === a && RQ.req === h ? 'on' : ''}" data-ra="${esc(a)}" data-rr="${esc(h)}" title="${esc(a || '전체')} · ${esc(h)} — 이 Tag 들만">${n}</button>` : '<span class="soft">·</span>';
  const keepY = $('.xg-wrap', el)?.scrollTop || 0;
  const rows = L.map((t, n) => () => `<tr data-id="${t.ds_id}"><td class="fz" style="left:0">${n + 1}</td><td class="fz fzl" style="left:34px"><b>${esc(t.tag)}</b></td><td>${esc(t.area)}</td><td>${esc(t.unit)}</td><td>${esc(t.valve_type)}</td><td>${t.on.length}</td>
    ${cols.map(h => { const v = t.cells[h] || ''; const on = t.on.includes(h); return `<td class="${on ? 'rqon' : v ? 'rqno' : ''}" title="${esc(h)}: ${esc(v)}">${reqCell(v, on)}</td>`; }).join('')}</tr>`);
  el.innerHTML = `<div class="vh">${listTop()}<input type="search" id="rqq" placeholder="Tag 검색" value="${esc(RQ.q)}" style="width:150px">
      <span class="soft">${RQ.area || RQ.req ? `거른 것: <b>${esc(RQ.area || '전체 Area')}</b> · <b>${esc(RQ.req ? reqShort(RQ.req) : '모든 요구사항')}</b> <button id="rqclr">지우기</button> · ` : ''}${L.length} / ${R.tags.length} Tag</span>
      <span class="sp"></span><button class="pri" id="rqx" title="Summary by Area · Summary by Unit · By Tag (지금 거른 대로)">⇩ Special Requirements Excel</button></div>
    <div class="card rqsum"><table class="t" data-xfdata="1"><thead><tr><th>Area</th><th>Units</th><th>Tags</th>${cols.map(h => `<th><button class="rqh ${!RQ.area && RQ.req === h ? 'on' : ''}" data-ra="" data-rr="${esc(h)}" title="${esc(h)}">${esc(reqShort(h))}</button></th>`).join('')}</tr></thead><tbody>
      ${R.by_area.map(a => `<tr><td><button class="rqa ${RQ.area === a.area && !RQ.req ? 'on' : ''}" data-ra="${esc(a.area)}" data-rr="">${esc(a.area)}</button></td><td class="soft">${esc(a.units.join(', '))}</td><td>${a.tags}</td>${cols.map(h => `<td>${num(a.counts[h], a.area, h)}</td>`).join('')}</tr>`).join('')}
      <tr class="tot"><td><b>Total</b></td><td></td><td><b>${R.total.tags}</b></td>${cols.map(h => `<td><b>${num(R.total.counts[h], '', h)}</b></td>`).join('')}</tr></tbody></table>
      <p class="soft hint">숫자 = 그 요구사항이 적용되는 Tag 수 (데이터시트 칸이 먼저 · 없으면 Notes / General Notes). 숫자를 누르면 아래 표가 그 Tag 들로 걸러집니다.</p></div>
    ${lpWrap(`<div class="xg-wrap rqwrap"><table class="xg rqt" id="rqt" style="width:${34 + 130 + 80 + 46 + 56 + 50 + cols.length * 104}px"><colgroup><col style="width:34px"><col style="width:130px"><col style="width:80px"><col style="width:46px"><col style="width:56px"><col style="width:50px">${cols.map(() => '<col style="width:104px">').join('')}</colgroup>
      <thead><tr><th class="fz" style="left:0">#</th><th class="fz fzl" style="left:34px">Tag Number ${xfBtn('req', 'tag')}</th><th>Area ${xfBtn('req', 'area')}</th><th>Unit ${xfBtn('req', 'unit')}</th><th>Type ${xfBtn('req', 'type')}</th><th title="적용되는 요구사항 수">Count ${xfBtn('req', 'n')}</th>${cols.map(h => `<th title="${esc(h)}">${esc(reqShort(h))} ${xfBtn('req', h)}</th>`).join('')}</tr></thead>
      <tbody></tbody></table></div>`)}`;
  chunkRows($('#rqt tbody'), rows, 80, `<tr><td colspan="${6 + cols.length}" class="empty">조건에 맞는 Tag 가 없습니다</td></tr>`);
  const wrap = $('.rqwrap', el); if (wrap) wrap.scrollTop = keepY;
  $$('[data-lm]', el).forEach(b => b.onclick = () => { G.mode = b.dataset.lm; renderList(); });
  mountPreview();
  el.querySelector('.rqsum').onclick = e => { const b = e.target.closest('[data-ra]'); if (!b) return;
    const a = b.dataset.ra, r = b.dataset.rr; if (RQ.area === a && RQ.req === r) { RQ.area = RQ.req = ''; } else { RQ.area = a; RQ.req = r; } renderReq(); };
  $('#rqclr') && ($('#rqclr').onclick = () => { RQ.area = RQ.req = ''; renderReq(); });
  $('#rqq').oninput = e => { RQ.q = e.target.value; clearTimeout(RQ.t); RQ.t = setTimeout(() => { renderReq().then(() => { const f = $('#rqq'); f.focus(); f.setSelectionRange(f.value.length, f.value.length); }); }, 200); };
  $('#rqx').onclick = () => download(`/projects/${S.pid}/requirements.xlsx?area=${encodeURIComponent(RQ.area)}&req=${encodeURIComponent(RQ.req)}`).then(() => toast('Special Requirements Excel 을 내려받았습니다')).catch(e => toast(e.message, 1));
  const tb = $('#rqt tbody');
  tb.onclick = async e => { const tr = e.target.closest('tr[data-id]'); if (!tr) return; $$('tr.sel', tb).forEach(x => x.classList.remove('sel')); tr.classList.add('sel');
    const id = +tr.dataset.id; link({ t: 'ds', id }); const d = await api('GET', `/datasheets/${id}`);
    preview({ doc: d.document_id, pages: d.pages, page: d.pages[0], ovs: [], label: `${d.tag} · Special Requirements` }); };
  tb.ondblclick = e => { const tr = e.target.closest('tr[data-id]'); if (tr) openDs(+tr.dataset.id); };
}
async function renderIssues(rowsOnly) {
  const el = $('#v-list');
  if (!S.issues) { el.innerHTML = '<div class="empty">지적 사항을 계산하는 중…</div>'; const r = await loadIssues(); S.issues = r.issues; S.issueTypes = r.types; }
  const all = S.issues.filter(i => IF.internal || i.type !== 'Extraction Review');
  const q = IF.q.toUpperCase().replace(/[^0-9A-Z]/g, '');
  const L = xfApply('iss', all.filter(i => (!IF.type || i.type === IF.type) && (!IF.sev || i.severity === IF.sev) && (!IF.st || i.status === IF.st) && (!IF.area || i.area_name === IF.area) && (!q || i.tag.includes(q))),
    ISSCOLS, () => renderIssues(true));
  const areas = [...new Set(all.map(i => i.area_name).filter(Boolean))].sort((a, b) => ({ North: 0, South: 1, Brownfield: 2, W15: 3 }[a] ?? 9) - ({ North: 0, South: 1, Brownfield: 2, W15: 3 }[b] ?? 9));
  const types = [...new Set(all.map(i => i.type))];
  const cnt = t => all.filter(i => i.type === t && i.status !== 'Dismissed').length;
  const keepY = $('.xg-wrap', el)?.scrollTop || 0;
  const D = IF.dg ? (await loadDigest(), digestRows(L)) : null; IF.D = D;
  const grpRow = g => {                                     // one Typical / block comment (a single finding keeps its own row)
    const e = g.e, i0 = g.ms[0], typ = e.kind === 'typical', blk = e.kind === 'block' || e.of_kind === 'block', op = IF.open.has(g.k);
    if (!typ && !blk) return issRow(i0);
    const tags = [...new Set(g.ms.map(i => i.tag))], st = new Set(g.ms.map(decShown));
    const sel = decSelect(`data-gst="${g.k}"`, st.size === 1 ? i0 : { status: '' }).replace('<option', st.size === 1 ? '<option' : '<option selected disabled>(섞임)</option><option');
    return `<tr data-g="${g.k}" class="grp ${op ? 'gop' : ''} ${G.selG === g.k ? 'sel' : ''}">
      <td class="fz" style="left:0"><b class="no ${e.color}">${g.k + 1}</b></td>
      <td class="fz fzl" style="left:34px" title="${esc(tags.join(', '))}">${typ ? `<b class="typ">Typical</b> <small>${tags.length} Tag</small>` : `<b>${esc(i0.tag)}</b>`}</td>
      <td>${typ ? `<small class="soft">${esc(tags.slice(0, 3).join(', '))}${tags.length > 3 ? ' …' : ''}</small>` : esc(i0.doc_no)}</td><td>${typ ? '' : esc(i0.rev)}</td>
      <td>${typ ? '' : `${i0.sheet || ''} of ${i0.of || ''}`}</td><td>${typ ? '' : (e.page || i0.page || '')}</td>
      <td title="${esc(e.field || '')}">${esc(e.field || '')}${blk ? ' <span class="blk">블럭</span>' : ''}</td><td>${blk ? '(blank)' : esc(i0.value || '(blank)')}</td>
      <td>${pill(e.type.replace(/[^A-Za-z]/g, ''), e.type)}</td>
      <td title="${esc(e.description)}">${descHTML(e)}<div><button class="ibtn dgo" data-gopen="1" title="묶인 지적을 낱개로 보기">${op ? '▾ 접기' : `▸ 상세 ${g.ms.length}건`}</button></div></td>
      <td title="${esc(e.expected || '')}">${esc(e.expected || '')}</td><td>${pill(e.severity || i0.severity)}</td><td>${sel}</td></tr>`;
  };
  const issRow = (i, sub) => `<tr data-i="${esc(i.ds_id + '|' + i.ikey)}" class="${sub ? 'gsub ' : ''}${G.selIss === i.ikey && G.selDs === i.ds_id ? 'sel' : ''}">
        <td class="fz" style="left:0"><b class="no ${i.color}">${i.no}</b></td><td class="fz fzl" style="left:34px"><b>${esc(i.tag)}</b></td><td>${esc(i.doc_no)}</td><td>${esc(i.rev)}</td><td>${i.sheet || ''} of ${i.of || ''}</td><td>${i.page || ''}</td>
        <td title="${esc(i.field)}">${esc(i.field)}${i.row ? ` <small>#${i.row}</small>` : ''}</td><td title="${esc(i.value)}">${esc(i.value || '(blank)')}</td>
        <td>${pill(i.type.replace(/[^A-Za-z]/g, ''), i.type)}${i.comment_id ? '' : ` <button class="ibtn" data-icmp="1" title="어디와 다른지 나란히">⇆</button><button class="ibtn" data-iedit="1" title="코멘트 고치기 · 보완">✎${i.edited ? '•' : ''}</button>`}</td><td title="${esc(i.description)}${i.evidence?.length ? '\n근거: ' + esc(i.evidence.map(x => `${x.doc || ''}${x.page ? ' p.' + x.page : ''} ${x.where || ''}: ${String(x.text || '').slice(0, 60)}`).join(' | ')) : ''}">${descHTML(i)}</td><td title="${esc(i.expected)}">${esc(i.expected)}</td>
        <td>${pill(i.severity)}</td><td>${decSelect(`data-ist="${esc(i.ds_id + '|' + i.ikey)}"`, i)}</td></tr>`;
  const __rows = D ? D.flatMap(g => [() => grpRow(g), ...(IF.open.has(g.k) ? g.ms.map(i => () => issRow(i, 1)) : [])]) : L.map(i => () => issRow(i)),
    __fb = '<tr><td colspan="13" class="empty">조건에 맞는 지적 사항이 없습니다</td></tr>';
  const cntTxt = D ? `코멘트 ${D.length} (지적 ${L.length} / ${all.length})` : `${L.length} / ${all.length}`;
  IF.L = L;
  if (rowsOnly && $('#ig tbody', el)) { chunkRows($('#ig tbody', el), __rows, 80, __fb); const c = $('#icnt', el); if (c) c.textContent = cntTxt; return; }
  el.innerHTML = `<div class="vh">${listTop()}<input type="search" id="iq" placeholder="Tag 검색" style="width:140px" value="${esc(IF.q)}">
      <select id="iar"><option value="">All Areas</option>${areas.map(a => `<option ${a === IF.area ? 'selected' : ''}>${esc(a)}</option>`).join('')}</select>
      <select id="it"><option value="">All Issue Types</option>${types.map(t => `<option ${t === IF.type ? 'selected' : ''} value="${esc(t)}">${esc(t)} (${cnt(t)})</option>`).join('')}</select>
      <select id="isv"><option value="">All Severity</option>${['Major', 'Minor', 'Info', 'Internal'].map(t => `<option ${t === IF.sev ? 'selected' : ''}>${t}</option>`).join('')}</select>
      <select id="ist"><option value="">All Status</option>${['Open', 'Confirmed', 'Dismissed', 'Resolved'].map(t => `<option ${t === IF.st ? 'selected' : ''}>${t}</option>`).join('')}</select>
      <label class="soft"><input type="checkbox" id="iint" ${IF.internal ? 'checked' : ''}> 추출 확인(내부)</label>
      <span class="segtab" title="정리 보기: 같은 쪽에 붙은 Data Missing 은 한 블럭 · 여러 Tag 에 같은 코멘트는 Typical 한 줄 (▸ 상세로 낱개)"><button data-dg="1" class="${IF.dg ? 'on' : ''}">정리 보기</button><button data-dg="0" class="${IF.dg ? '' : 'on'}">낱개 전체</button></span>
      <span class="soft" id="icnt">${cntTxt}</span><span class="sp"></span>
      <button id="ixl" title="지금 필터 그대로 · Dismissed 제외">⇩ Issue List Excel</button><button class="pri" id="ipdf" title="지금 필터 그대로 · 인쇄용 표시 + Issue Summary">⇩ Mark-up PDF</button></div>
    ${lpWrap(`<div class="xg-wrap"><table class="xg" id="ig" style="width:1500px"><colgroup>${[34, 110, 150, 40, 62, 46, 150, 150, 130, 330, 150, 64, 100].map(w => `<col style="width:${w}px">`).join('')}</colgroup>
      <thead><tr>${['No.', 'Tag Number', 'Doc. No.', 'Rev.', 'Sheet', 'Page', 'Field', 'Datasheet Value', 'Issue Type', 'Description', 'Required / Expected', 'Severity', 'Status'].map((h, n) => `<th ${n < 2 ? `class="fz ${n ? 'fzl' : ''}" style="left:${n ? 34 : 0}px"` : ''}>${h} ${xfBtn('iss', ISSKEYS[n])}</th>`).join('')}</tr></thead>
      <tbody></tbody></table></div>`)}`;
  $('.xg-wrap', el).scrollTop = keepY;
  $$('[data-lm]', el).forEach(b => b.onclick = () => { G.mode = b.dataset.lm; renderList(); });
  const re = () => renderIssues(true);                       // filters only redraw the rows (toolbar · focus stay)
  $('#iq').oninput = e => { IF.q = e.target.value; clearTimeout(IF.t); IF.t = setTimeout(re, 90); };
  $('#it').onchange = e => { IF.type = e.target.value; re(); }; $('#isv').onchange = e => { IF.sev = e.target.value; re(); }; $('#iar').onchange = e => { IF.area = e.target.value; re(); };
  $('#ist').onchange = e => { IF.st = e.target.value; re(); }; $('#iint').onchange = e => { IF.internal = e.target.checked; re(); };
  $$('[data-dg]', el).forEach(b => b.onclick = () => { IF.dg = +b.dataset.dg; LS.set('issdg', IF.dg); renderIssues(); });
  const qNow = () => IF.q.toUpperCase().replace(/[^0-9A-Z]/g, '');     // read at click time: filters redraw rows only
  const qs = () => new URLSearchParams({ types: IF.type || (IF.internal ? [...types].join(',') : ''), severity: IF.sev, tag: qNow() || xfActive('iss') ? [...new Set(IF.L.map(i => i.tag))].join(',') : '' }).toString();
  const pick = async what => { const t = await pickTypes(`${what} — 넣을 Issue Type`, { preset: IF.type ? [IF.type] : null,
      note: [IF.sev && `Severity ${IF.sev}`, qNow() && `검색 '${qNow()}' 에 걸린 Tag 만`].filter(Boolean).join(' · ') || '' });
    if (t == null) return null; const p = new URLSearchParams(qs()); p.set('types', t); return p.toString(); };
  $('#ixl').onclick = async () => { const p = await pick('Issue List Excel'); if (p == null) return;
    download(`/projects/${S.pid}/issues.xlsx?${p}`).then(r => toast(`Issue List ${r.headers.get('X-Count')}행 — 설계사에게 바로 보낼 수 있습니다`)).catch(e => toast(e.message, 1)); };
  $('#ipdf').onclick = async () => { const p = await pick('Mark-up PDF'); if (p == null) return;
    toast('Mark-up PDF 를 만드는 중… (Tag 수에 따라 수십 초)'); download(`/projects/${S.pid}/markup.pdf?${p}${pdfq()}`).then(() => toast('내려받음 — 표시와 코멘트가 쪽에 같이 인쇄됩니다')).catch(e => toast(e.message, 1)); };
  const tb = $('#ig tbody');
  chunkRows(tb, __rows, 80, __fb);
  tb.onclick = async e => {
    if (e.target.closest('select')) return;
    const gtr = e.target.closest('tr[data-g]');
    if (gtr) {                                             // valve35: a Typical / block row
      const g = (IF.D || []).find(x => x.k === +gtr.dataset.g); if (!g) return;
      if (e.target.closest('[data-gopen]')) { IF.open.has(g.k) ? IF.open.delete(g.k) : IF.open.add(g.k); re(); return; }
      G.selG = g.k; $$('tr.sel', tb).forEach(x => x.classList.remove('sel')); gtr.classList.add('sel');
      const i0 = g.ms[0], u = (g.e.units || []).find(x => x.ds_id === i0.ds_id) || g.e;
      const pages = (S.grid?.rows.find(r => r.id === i0.ds_id)?.pages) || (await api('GET', `/datasheets/${i0.ds_id}`)).pages;
      link({ t: 'iss', id: i0.ds_id, ikey: i0.ikey, near: [] });
      preview({ doc: i0.document_id, pages, page: u.page || i0.page, bbox: u.bbox || i0.bbox, ovs: await dsIssues(i0.ds_id),
        label: `${g.e.kind === 'typical' ? `Typical (${new Set(g.ms.map(i => i.tag)).size} Tag) · 첫 Tag ` : ''}${i0.tag} · ${g.e.type} · ${g.e.field || ''}` });
      return;
    }
    const cb = e.target.closest('[data-icmp], [data-iedit]');
    if (cb) {                                              // valve29: compare with the reference · edit the comment
      const tr0 = cb.closest('tr[data-i]'), dsId0 = +tr0.dataset.i.split('|')[0], ik0 = tr0.dataset.i.slice(tr0.dataset.i.indexOf('|') + 1);
      const i0 = S.issues.find(x => x.ds_id === dsId0 && x.ikey === ik0);
      if (cb.dataset.icmp) { const d0 = await api('GET', `/datasheets/${dsId0}`); compareIssue(d0, d0.issues.find(x => x.ikey === ik0) || i0); }
      else editIssueText(dsId0, i0, () => { S.issues = null; renderList(); });
      return;
    }
    const tr = e.target.closest('tr[data-i]'); if (!tr) return;
    const [dsId, ikey] = [+tr.dataset.i.split('|')[0], tr.dataset.i.slice(tr.dataset.i.indexOf('|') + 1)];
    const i = S.issues.find(x => x.ds_id === dsId && x.ikey === ikey);
    G.selIss = ikey; G.selDs = dsId; $$('tr.sel', tb).forEach(x => x.classList.remove('sel')); tr.classList.add('sel');
    const LL = IF.L || L, at = LL.findIndex(x => x.ds_id === dsId && x.ikey === ikey), near = [...new Set(LL.slice(at + 1, at + 40).map(x => x.ds_id))].filter(x => x !== dsId).slice(0, 2);
    link({ t: 'iss', id: dsId, ikey, near });
    const pages = (S.grid?.rows.find(r => r.id === dsId)?.pages) || (await api('GET', `/datasheets/${dsId}`)).pages;
    preview({ doc: i.document_id, pages, page: i.page, bbox: i.bbox, ovs: await dsIssues(dsId), label: `${i.tag} · #${i.no} ${i.type} · ${i.field}` });
  };
  tb.ondblclick = e => { const tr = e.target.closest('tr[data-i]'); if (tr) openDs(+tr.dataset.i.split('|')[0]); };
  tb.onchange = async e => {
    const gs = e.target.closest('[data-gst]');
    if (gs) {                                              // valve35: one decision for every finding in the Typical / block
      const g = (IF.D || []).find(x => x.k === +gs.dataset.gst); if (!g) return;
      const body = await askDecision(gs.value, g.ms.length, g.ms[0]); if (!body) { re(); return; }
      for (const i of g.ms) {
        const r = await api('PUT', `/datasheets/${i.ds_id}/issues/${encodeURIComponent(i.ikey)}`, body);
        Object.assign(i, { status: r.status, decision: r.decision, note: body.note, reason_cat: body.reason_cat || '', conclusion: body.conclusion || '' });
      }
      if (body.decision === 'Modified') S.issues = null;
      toast(`→ ${gs.value} · ${g.ms.length}건 모두`); re(); return;
    }
    const sel = e.target.closest('[data-ist]'); if (!sel) return;
    const [dsId, ikey] = [+sel.dataset.ist.split('|')[0], sel.dataset.ist.slice(sel.dataset.ist.indexOf('|') + 1)];
    const i = S.issues.find(x => x.ds_id === dsId && x.ikey === ikey);
    const body = await askDecision(sel.value, 1, i); if (!body) { sel.value = decShown(i); return; }
    const r = await api('PUT', `/datasheets/${dsId}/issues/${encodeURIComponent(ikey)}`, body);
    Object.assign(i, { status: r.status, decision: r.decision, note: body.note, reason_cat: body.reason_cat || '', conclusion: body.conclusion || '' });
    if (body.decision === 'Modified') S.issues = null; toast(`→ ${sel.value}`);
  };
  mountPreview();
}
async function exportValveList() {
  toast('Valve List 를 만드는 중… (164 태그 기준 수 초)');
  try {
    const r = await download(`/projects/${S.pid}/valvelist.xlsx`);
    const rep = JSON.parse(decodeURIComponent(r.headers.get('X-Report') || '%7B%7D'));
    toast(`내려받음 — 갱신 ${rep.updated ?? 0} · 신규 ${rep.new ?? 0} · 바뀐 칸 ${rep.changes ?? 0} · 목록 값 유지 ${rep.kept ?? 0}`);
  } catch (e) { toast(e.message, 1); }
}

/* ── 4. Datasheet Review Workbench ────────────────────────────────────── */
const W = { grpOpen: new Set(), tab: LS.get('wtab', 'data'), q: '', type: '', st: '', viewer: null, selField: null, prevCmp: null, selCm: null,
  px: LS.get('wbpx', null), col: LS.get('wbc', null) };
const WB_MIN = { l: 180, r: 260, c: 480 }, WB_MAX = { l: 420, r: 560 };   // px — the PDF keeps at least WB_MIN.c
const TABS = [['iss', 'Issues'], ['chk', 'Checks'], ['sum', 'Summary'], ['data', 'Data'], ['proc', 'Process'], ['pms', 'PMS'], ['mat', 'Expert'], ['rev', 'Rev'], ['notes', 'Notes'], ['cmt', 'Comments'], ['hist', 'History']];
const PRE = new Map();                               // valve26: the next / previous tag is fetched while the engineer reads this one
function dsFetch(id) { const h = PRE.get(id); if (h) { PRE.delete(id); return h; } return api('GET', `/datasheets/${id}`); }
function prefetchNeighbours() {
  const idle = window.requestIdleCallback || (f => setTimeout(f, 120));
  idle(() => {
    const i = (W.list || []).findIndex(t => t.id === S.dsId); if (i < 0) return;
    for (const t of [W.list[i + 1], W.list[i - 1]].filter(Boolean)) {
      if (PRE.has(t.id) || PRE.size > 6) continue;
      const pr = api('GET', `/datasheets/${t.id}`).then(d => { (d.pages || []).slice(0, 2).forEach(pg => { const im = new Image(); im.src = `/api/valve/documents/${d.document_id}/page/${pg}.png?zoom=${W.viewer?.imgZoom() || 1.5}`; }); return d; });
      pr.catch(() => PRE.delete(t.id)); PRE.set(t.id, pr);
    }
  });
}
function openDs(id) { if (!id) return; S.dsId = id; LS.set('tag.' + S.pid, id); go('review'); }
function fitPanels() {                                // clamp the side panels so the viewer never gets squeezed (also on window resize)
  const wb = $('#v-review .wb'); if (!wb) return;
  const total = wb.clientWidth;
  let l = W.col.l ? 0 : Math.max(WB_MIN.l, Math.min(WB_MAX.l, W.px.l)), r = W.col.r ? 0 : Math.max(WB_MIN.r, Math.min(WB_MAX.r, W.px.r));
  const over = l + r + WB_MIN.c - total;
  if (over > 0) { const cut = Math.min(over, Math.max(0, r - WB_MIN.r)); r -= cut; l = Math.max(W.col.l ? 0 : WB_MIN.l, l - (over - cut)); }
  $('.wb-left', wb).style.width = l + 'px'; $('.wb-right', wb).style.width = r + 'px';
  wb.classList.toggle('lc', !!W.col.l); wb.classList.toggle('rc', !!W.col.r);
  W.viewer?.paintOv(); W.viewer?.paintMarks();
}
function togglePanel(side, on) { W.col[side] = on ?? !W.col[side]; LS.set('wbc', W.col); fitPanels(); }
function stepTag(d) { const list = W.list || [], i = list.findIndex(t => t.id === S.dsId), t = list[i + d]; t ? openDs(t.id) : toast(d < 0 ? '첫 Tag 입니다' : '마지막 Tag 입니다'); }
function wbLayout() {
  const el = $('#v-review'); el.classList.add('full', 'col');
  el.innerHTML = `<div class="whead" id="whead"></div><div class="wb">
    <div class="wb-left"><div class="pane-h"><div class="row ph"><b>Tag List</b><span class="soft" id="wcnt"></span><span class="sp"></span>
        <button data-nav="-1" title="이전 Tag (↑ / K)">▲</button><button data-nav="1" title="다음 Tag (↓ / J)">▼</button><button data-col="l" title="Tag List 접기 ( [ )">◀</button></div>
      <input type="search" id="wq" placeholder="Search Tag… (/)" value="${esc(W.q)}">
      <div class="row"><select id="wt" aria-label="Valve Type"><option value="">All Types</option></select><select id="ws" aria-label="Review Status"><option value="">All Status</option>${STATUSES.map(s => `<option ${s === W.st ? 'selected' : ''}>${s}</option>`).join('')}</select></div></div>
      <div class="taglist" id="wlist"></div><div class="revinfo" id="wrev"></div></div>
    <button class="rail l" data-col="l" title="Tag List 펼치기 ( [ )"><span>▶ Tag List</span></button>
    <div class="split" data-s="l" title="끌어 너비 조절"></div>
    <div class="wb-center" id="wview"></div>
    <div class="split" data-s="r" title="끌어 너비 조절"></div>
    <button class="rail r" data-col="r" title="Review Panel 펼치기 ( ] )"><span>◀ Review Panel</span></button>
    <div class="wb-right"><div class="tabs" id="wtabs">${TABS.map(([k, l]) => `<button data-t="${k}" class="${W.tab === k ? 'on' : ''}">${l}<span class="tb" hidden></span></button>`).join('')}
      <button class="fold" data-col="r" title="Review Panel 접기 ( ] )">▶</button></div><div class="rbody" id="wbody"></div></div></div>`;
  W.viewer = new Viewer($('#wview'), { tools: true,
    extra: `<button data-a2="popout" title="PDF 만 새 창으로 (두 번째 모니터) — 이 창과 연동">⧉</button><button data-a2="prevrev" title="이전 Revision">◁ Rev</button><button data-a2="nextrev" title="다음 Revision">Rev ▷</button><button data-a2="pdf" title="이 Tag 의 표시가 들어간 PDF 내보내기">⇩ PDF</button>`,
    onMark: addMark, onMarkChange: changeMark, onMarkErase: eraseMark, onMarkSelect: m => { if ((m?.id ?? null) === W.selCm) return; W.selCm = m?.id ?? null; if (W.tab === 'cmt') drawRight(); }, onMarkCmd: markCmd,
    onPagePoint: (page, [x, y]) => {                // valve29: PDF → field → its findings
      const hit = (S.ds?.fields || []).filter(f => f.page === page && f.bbox && x >= f.bbox[0] - 2 && x <= f.bbox[2] + 2 && y >= f.bbox[1] - 2 && y <= f.bbox[3] + 2)
        .sort((a, b) => (a.bbox[2] - a.bbox[0]) * (a.bbox[3] - a.bbox[1]) - (b.bbox[2] - b.bbox[0]) * (b.bbox[3] - b.bbox[1]))[0];
      if (!hit) return;
      if (W.tab !== 'data') setTab('data');
      selectField(hit.key); $(`#wbody [data-k="${CSS.escape(hit.key)}"]`)?.scrollIntoView({ block: 'nearest' });
    },
    onOverlay: o => { if (o.cmId) { W.selCm = o.cmId; setTab('cmt'); } else if (o.iss) { W.selIss = o.iss; setTab('iss'); } else if (o.key) selectField(o.key); } });
  $('#wview .tbar').addEventListener('click', e => {
    const a = e.target.closest('[data-a2]')?.dataset.a2; if (!a || !S.ds) return;
    if (a === 'popout') { popOut('pdf'); return; }
    const rv = S.ds.revisions, i = rv.findIndex(r => r.id === S.ds.id);
    if (a === 'prevrev') rv[i - 1] ? openDs(rv[i - 1].id) : toast('이전 Revision 이 없습니다');
    if (a === 'nextrev') rv[i + 1] ? openDs(rv[i + 1].id) : toast('다음 Revision 이 없습니다');
    if (a === 'pdf') exportMarkup();
  });
  $('#wtabs').onclick = e => { const b = e.target.closest('button[data-t]'); if (b) setTab(b.dataset.t); };
  $('#wq').oninput = e => { W.q = e.target.value; drawTagList(); };
  $('#wt').onchange = e => { W.type = e.target.value; drawTagList(); };
  $('#ws').onchange = e => { W.st = e.target.value; drawTagList(); };
  el.onclick = e => { const c = e.target.closest('[data-col]'); if (c) { togglePanel(c.dataset.col); return; } const n = e.target.closest('[data-nav]'); if (n) stepTag(+n.dataset.nav); };
  $$('.split', el).forEach(sp => sp.onmousedown = e => {
    e.preventDefault(); sp.classList.add('act');
    const box = $('.wb', el).getBoundingClientRect(), side = sp.dataset.s;
    const mv = ev => { W.px[side] = Math.round(side === 'l' ? ev.clientX - box.left : box.right - ev.clientX); fitPanels(); };
    const up = () => { sp.classList.remove('act'); LS.set('wbpx', W.px); removeEventListener('mousemove', mv); removeEventListener('mouseup', up); };
    addEventListener('mousemove', mv); addEventListener('mouseup', up);
  });
  const total = $('.wb', el).clientWidth || 1200;      // first run: panels sized from the window, tag list folded on narrow screens
  if (!W.px) W.px = { l: Math.round(Math.max(WB_MIN.l, Math.min(WB_MAX.l, total * 0.18))), r: Math.round(Math.max(WB_MIN.r, Math.min(WB_MAX.r, total * 0.27))) };
  if (!W.col) W.col = { l: total < 1250, r: false };
  if (!W.rz) { W.rz = true; addEventListener('resize', () => { if (S.view === 'review') fitPanels(); }); }
  fitPanels();
}
function tagRow(t) {
  return `<div class="ti ${t.id === S.dsId ? 'on' : ''}" data-id="${t.id}" tabindex="0">
      <div class="t1"><b>${esc(t.tag_key)}</b><span class="sp"></span>${t.problems ? `<span class="pill p-bad" title="설계사 전달 지적 ${t.problems}건 (오류 · 누락 · PMS · Revision)">${t.problems}</span>` : ''}${t.still ? `<span class="pill p-bad" title="이전 Revision 에서 Confirmed 했는데 그대로인 지적 ${t.still}건">✗${t.still}</span>` : ''}${t.issues ? `<span class="pill p-ReviewRequired" title="추출 확인 필요(내부) ${t.issues}칸">⚠${t.issues}</span>` : ''}</div>
      <div class="t2"><span class="ty">${esc(t.valve_type)}</span><span class="soft">Rev.${esc(t.revs.join('→'))}</span>${pill(t.review_status)}</div></div>`;
}
function selectTagRow() {                       // valve26: moving between tags only moves the highlight (no 1,000-row rebuild)
  const host = $('#wlist'); if (!host) return false;
  const was = $('.ti.on', host), now = $(`.ti[data-id="${S.dsId}"]`, host);
  if (!now) return false;
  was?.classList.remove('on'); now.classList.add('on');
  const i = W.list.findIndex(t => t.id === S.dsId); $('#wcnt').textContent = `${i >= 0 ? i + 1 : '–'} / ${W.list.length}`;
  const r = now.getBoundingClientRect(), h = host.getBoundingClientRect();
  if (r.top < h.top || r.bottom > h.bottom) now.scrollIntoView({ block: 'nearest' });
  return true;
}
function refreshTagRow(id) {                    // one tag's pills changed (status · counts): redraw that row only
  const host = $('#wlist'), t = S.sum.tags.find(t => t.id === id), el = host && $(`.ti[data-id="${id}"]`, host);
  if (!t || !el) return drawTagList();
  el.outerHTML = tagRow(t);
}
function drawTagList() {
  if (W.list && W.listKey === `${W.q}|${W.type}|${W.st}|${S.sumStamp}` && selectTagRow()) return;
  W.listKey = `${W.q}|${W.type}|${W.st}|${S.sumStamp}`;
  const types = [...new Set(S.sum.tags.map(t => t.valve_type))].sort();
  $('#wt').innerHTML = '<option value="">All Types</option>' + types.map(t => `<option ${t === W.type ? 'selected' : ''}>${esc(t)}</option>`).join('');
  const q = W.q.toUpperCase().replace(/[^0-9A-Z]/g, '');
  const list = S.sum.tags.filter(t => (!q || t.tag_key.includes(q)) && (!W.type || t.valve_type === W.type) && (!W.st || t.review_status === W.st));
  W.list = list;
  const i = list.findIndex(t => t.id === S.dsId);
  $('#wcnt').textContent = `${i >= 0 ? i + 1 : '–'} / ${list.length}`;
  chunkRows($('#wlist'), list.map(t => () => tagRow(t)), Math.max(60, i + 30), '<div class="empty">조건에 맞는 Tag 가 없습니다</div>');
  $('#wlist').onclick = e => { const it = e.target.closest('.ti'); if (it) openDs(+it.dataset.id); };
  $('#wlist .ti.on')?.scrollIntoView({ block: 'nearest' });
}
async function renderReview() {
  if (!S.sum.tags.length) { const el = $('#v-review'); el.classList.remove('full'); el.innerHTML = '<div class="empty">데이터시트가 없습니다 — Document Management 에서 올리세요.</div>'; return; }
  if (!$('#wlist')) wbLayout();
  if (!S.dsId || !S.sum.tags.some(t => t.id === S.dsId) && !(S.ds && S.ds.id === S.dsId)) {
    const any = S.dsId ? await api('GET', `/datasheets/${S.dsId}`).catch(() => null) : null;
    if (!any || any.project_id !== S.pid) S.dsId = S.sum.tags[0].id;
  }
  drawTagList();
  if (!S.ds || S.ds.id !== S.dsId) {
    S.ds = await dsFetch(S.dsId);
    link({ t: 'ds', id: S.ds.id });
    W.prevCmp = null; W.selField = null;
    const rv = S.ds.revisions, i = rv.findIndex(r => r.id === S.ds.id);
    if (i > 0) W.prevCmp = await api('GET', `/compare?prev=${rv[i - 1].id}&new=${S.ds.id}`).catch(() => null);
    await W.viewer.load(S.ds.document_id, S.ds.pages);
  }
  paintDsOverlays(); drawHead(); drawRight(); drawRevInfo(); prefetchNeighbours();
}
function drawHead() {                                  // one-line summary of the open tag (proposal: top strip)
  const d = S.ds, h = $('#whead'); if (!d || !h) return;
  const F = Object.fromEntries(d.fields.map(f => [f.key, f])), v = k => F[k] ? (F[k].edited_value ?? F[k].value) : '';
  const iss = (d.issues || []).filter(i => i.status !== 'Dismissed' && i.type !== 'Extraction Review');
  const pmsN = iss.filter(i => i.type.startsWith('PMS')).length, errN = iss.filter(i => i.color === 'error').length - pmsN, misN = iss.filter(i => i.color === 'missing').length;
  const revN = (W.prevCmp?.rows || []).filter(r => r.change !== 'Unchanged').length;
  const chip = (lab, n, cls, tab, tip) => `<button class="hchip ${cls} ${n ? '' : 'zero'}" data-tab="${tab}" title="${tip}">${lab} <b>${n}</b></button>`;
  h.innerHTML = `<div class="hk tag"><small>Tag Number</small><b>${esc(d.tag)}</b></div>
    ${[['Area · Unit', d.location ? `${d.location.area || '—'}${d.location.unit ? ' · U' + d.location.unit : ''}` : ''], ['Valve Type', d.valve_type], ['Size', v('body_size')], ['Rating · Class', [v('rating'), v('piping_class')].filter(Boolean).join(' · ')], ['Body Type', v('body_type') || v('instrument_type'), 1],
       ['Manufacturer', v('manufacturer'), 1], ['Revision', `Rev.${d.rev}${d.rev_date ? ' · ' + d.rev_date : ''}`]].map(([k, x, opt]) => `<div class="hk ${opt ? 'opt' : ''}"><small>${k}</small><b title="${esc(x)}">${esc(x || '—')}</b></div>`).join('')}
    <span class="sp"></span><span class="hnav"><button data-nav="-1" title="이전 Tag (↑ / K)">▲</button><button data-nav="1" title="다음 Tag (↓ / J)">▼</button></span>
    ${chip('Data Error', errN, 'err', 'iss', '빨강 — 데이터 오류 (Issues 탭)')}${chip('Missing', misN, 'mis', 'iss', '주황 — 누락 · HOLD/TBC')}${chip('PMS', pmsN, 'err', 'pms', 'PMS 부적합 · 확인 (PMS 탭)')}
    ${chip('Process', iss.filter(i => i.type === 'Process Mismatch').length, 'mis', 'proc', 'Process Data 와 다른 공정 항목 (Process 탭)')}
    ${chip('Expert', iss.filter(i => i.type === 'Material Review' || i.type === 'Valve Review').length, 'mat', 'mat', 'Ball Valve 엔지니어 검토 — 재질 · 설계 · 다른 데이터시트 대비 (Expert 탭)')}
    ${chip('Rev Change', revN, 'rev', 'rev', '이전 Revision 대비 바뀐 칸')}${d.rev_review ? `<button class="hchip rev ${d.rev_review.still_open ? 'err' : ''}" data-tab="rev" title="Rev ${esc(d.rev_review.prev_rev)} → ${esc(d.rev)}: 해결 · 미반영(Confirmed 였는데 그대로) · 새 지적">Rev ${esc(d.rev_review.prev_rev)}→${esc(d.rev)} <b>✓${d.rev_review.resolved}</b> <b class="${d.rev_review.still_open ? 'bad' : ''}">✗${d.rev_review.still_open}</b> <b>+${d.rev_review.new}</b></button>` : ''}${chip('Comments', d.comments.length, 'cmt', 'cmt', '검토자 의견 · Mark-up')}
    <label class="hst">Review Status <select id="wst">${STATUSES.map(s => `<option ${s === d.review_status ? 'selected' : ''}>${s}</option>`).join('')}</select></label>`;
  h.onclick = e => { const c = e.target.closest('[data-tab]'); if (c) setTab(c.dataset.tab); };
  $('#wst').onchange = async e => { S.ds = await api('PUT', `/datasheets/${d.id}/status`, { status: e.target.value });
    const t = S.sum.tags.find(t => t.id === d.id); if (t) t.review_status = e.target.value; refreshTagRow(d.id); toast(`${d.tag} → ${e.target.value}`); };
}
function paintDsOverlays() {
  const ov = [];
  const noOf = Object.fromEntries((S.ds.issues || []).filter(i => i.comment_id).map(i => [i.comment_id, i.no]));
  W.viewer.setMarks(S.ds.comments.filter(c => c.page && c.bbox).map(c => ({ id: c.id, page: c.page, bbox: c.bbox, kind: c.kind || 'rect',
    points: c.points, style: c.style || null, category: c.category || 'comment', text: c.text, by: c.by, no: noOf[c.id], editable: true, sel: W.selCm === c.id })));
  for (const i of S.ds.issues || []) {                // every issue in its colour, numbered like the exported PDF
    if (i.comment_id || !i.bbox || i.status === 'Dismissed' || (i.type === 'Extraction Review' && !W.showInternal)) continue;
    ov.push({ cat: i.color, page: i.page, bbox: i.bbox, key: i.key, no: i.no, title: `#${i.no} ${i.type} · ${i.field}`, text: descText(i) + (i.expected ? `\nRequired: ${i.expected}` : ''), iss: i.ikey, sel: W.selIss === i.ikey });
  }
  const sf = S.ds.fields.find(f => f.key === W.selField);
  if (sf?.bbox) ov.push({ cat: 'field', page: sf.page, bbox: sf.bbox, title: sf.display });
  W.viewer.setOverlays(ov);
}
function evLink(d, x) {                                  // valve28: one evidence item -> a link that opens the proof (PMS / Process Data / note / field)
  const t = esc(x.where || '') + (x.text ? ` <span class="soft">${esc(String(x.text).slice(0, 90))}</span>` : '');
  const doc = x.doc || '';
  if (doc === 'PMS' && x.page) return `<a href="#" data-pmsp="${x.page}" data-pmsb="${esc(JSON.stringify(x.bbox))}">PMS p.${x.page}</a> ${t}`;
  if (doc.startsWith('Process Data') && x.page) return `<a href="#" data-pdp="${x.page}" data-pdb="${esc(JSON.stringify(x.bbox))}">Process Data p.${x.page}</a> ${t}`;
  if (doc === 'Previous revision') return `<span class="soft">Rev. prev</span> ${t}`;
  if (/^(Note|HOLD|Gen Note) /.test(x.where || '')) return `<a href="#" data-src="${esc(x.where)}">${esc(x.where)}</a> <span class="soft">${esc(String(x.text || '').slice(0, 90))}</span>`;
  const f = (d.fields || []).find(f => x.where && x.where.endsWith(f.display || f.key) && f.bbox);
  return f ? `<a href="#" data-ek="${esc(f.key)}">${t}</a>` : t;
}
function drawRevInfo() {
  const d = S.ds;
  $('#wrev').innerHTML = `<b>Revision Info</b><div>Doc. ${esc(d.doc_no)}</div><div>Current Rev.: <b>${esc(d.rev)}</b> ${d.rev_date ? `<small>(${esc(d.rev_date)})</small>` : ''}</div>
    <div>Revisions: ${d.revisions.map(r => r.id === d.id ? `<b>${esc(r.rev)}</b>` : `<a href="#" data-r="${r.id}">${esc(r.rev)}</a>`).join(' → ')}</div>
    ${d.rev_history.map(h => `<div class="soft">${esc(h)}</div>`).join('')}`;
  $$('#wrev [data-r]').forEach(a => a.onclick = e => { e.preventDefault(); openDs(+a.dataset.r); });
}
addEventListener('unhandledrejection', e => { const m = e.reason?.message || String(e.reason || ''); if (m) toast(m, 1); });   // no silent failures
function hintsInit() {                                   // '?' in the top bar: show / hide the one-line explanations
  document.body.classList.toggle('hints', !!LS.get('hints', 0));
  const host = $('#top .topr'); if (!host || $('#hintbtn')) return;
  const b = document.createElement('button'); b.id = 'hintbtn'; b.title = '도움말 문장 보이기 / 숨기기'; b.textContent = '?';
  b.onclick = () => { const on = !LS.get('hints', 0); LS.set('hints', on ? 1 : 0); document.body.classList.toggle('hints', on); toast(on ? '도움말 문장을 보입니다' : '도움말 문장을 숨깁니다'); };
  host.prepend(b);
  const nw = document.createElement('button'); nw.id = 'newwin'; nw.title = '이 화면을 새 창으로 — 창끼리 Tag · 칸 · 지적 · 결정이 실시간 연동'; nw.textContent = '⧉ 새 창';
  nw.onclick = () => popOut('view');
  const ln = document.createElement('button'); ln.id = 'linkbtn'; ln.title = '연동: 다른 창에서 고른 Tag · 칸 · 지적을 따라가고 결정 · 수정을 바로 반영';
  const paintLn = () => { ln.textContent = linkOn() ? '🔗 연동' : '⛓ 연동 끔'; ln.classList.toggle('on', linkOn()); };
  ln.onclick = () => { LS.set('linkon', linkOn() ? 0 : 1); paintLn(); toast(linkOn() ? '창 연동을 켰습니다' : '창 연동을 껐습니다'); }; paintLn();
  const pw = document.createElement('button'); pw.id = 'newpdf'; pw.title = 'PDF 창 (두 번째 모니터) — 왼쪽 목록에서 고르면 오른쪽 창에 바로, 거기서 Mark-up 도'; pw.textContent = '⧉ PDF';
  pw.onclick = () => popOut('pdf');
  host.prepend(ln); host.prepend(pw); host.prepend(nw);
}
function setTab(t) { W.tab = t; LS.set('wtab', t); $$('#wtabs button').forEach(b => { b.classList.toggle('on', b.dataset.t === t); if (b.dataset.t === t) b.scrollIntoView({ inline: 'nearest', block: 'nearest' }); }); drawRight(); }
/* valve37 — a Control Valve sheet 2 (Form 101): process and sizing lines as one Max · Nor · Min table (click a cell = its place) */
function caseTable(d) {
  if (d.form !== '101') return '';
  const rows = {}, order = [];
  d.fields.forEach(f => { const m = f.key.match(/^(.*)\.(max|nor|min)$/); if (!m) return;
    if (!rows[m[1]]) { rows[m[1]] = { name: (f.display || f.label).replace(/ \((Max|Nor|Min)\)$/, ''), unit: f.unit, sec: f.section, c: {} }; order.push(m[1]); }
    rows[m[1]].c[m[2]] = f; if (f.unit) rows[m[1]].unit = f.unit; });
  if (!order.length) return '';
  const cell = f => f ? `<td class="click ${W.selField === f.key ? 'on' : ''}" data-k="${esc(f.key)}">${esc((f.edited_value ?? f.value) || '')}</td>` : '<td></td>';
  return `<div class="sect"><h4>Process / Sizing — Max · Nor · Min <span class="soft" style="font-weight:400">(sheet 2)</span></h4>
    <table class="t"><thead><tr><th>Item</th><th>Unit</th><th>Max</th><th>Nor</th><th>Min</th></tr></thead><tbody>
    ${order.map(k => { const r = rows[k]; return `<tr${r.sec === 'sizing' ? ' class="soft"' : ''}><td>${esc(r.name)}${r.sec === 'sizing' ? ' <small>sizing</small>' : ''}</td><td>${esc(r.unit || '')}</td>${cell(r.c.max)}${cell(r.c.nor)}${cell(r.c.min)}</tr>`; }).join('')}
    </tbody></table></div>`;
}
/* valve37 — a sheet put in another kind's menu: say so (it is kept and reviewed with this menu's rules) */
function kindBanner(d) {
  if (!d.family || !d.kind || d.family === d.kind) return '';
  if (d.kind === 'ball' && d.family === 'butterfly' && !['101', '701'].includes(d.form)) return '';
  return `<div class="banner info"><b>${esc(KIND_NAMES[d.family] || d.family)} 데이터시트</b> — 이 화면은 ${esc(KIND_NAMES[d.kind])} 메뉴입니다. 그 종류의 검토 규칙으로 보려면 ${esc(KIND_NAMES[d.family] || d.family)} 메뉴에 올려 주세요.</div>`;
}
function fieldLine(f) {
  const v = f.edited_value ?? f.value, ref = f.ref, part = partOf(f.key);
  const st = f.status === 'ok' ? '' : f.status === 'blank' ? pill('NotFound', 'Not Found') : f.status === 'review' ? pill('ReviewRequired', 'Review') : pill('placeholder', 'VTA/NA');
  return `<div class="fl ${W.selField === f.key ? 'on' : ''}" data-k="${esc(f.key)}" ${part ? `data-part="${part}" title="밸브 부위: ${PART_INFO[part][0]}"` : ''}><span class="k">${esc(f.display || f.label)}${f.row ? ` <small>#${f.row}</small>` : ''}</span>
    <span class="v ${f.edited_value != null ? 'ed' : ''}">${f.edited_value != null ? `<span class="was">${esc(f.value || '∅')}</span>` : ''}${esc(v)}${f.unit ? ` <small>${esc(f.unit)}</small>` : ''} ${st}
    ${ref?.text ? `<span class="ref">${ref.kind === 'general' ? 'General Note' : 'Note'} ${ref.no}: ${esc(ref.text.slice(0, 260))}${ref.text.length > 260 ? '…' : ''}</span>` : ''}
    ${f.edited_value != null ? `<small class="soft">✎ ${esc(f.edited_by)} ${esc((f.edited_at || '').replace('T', ' ').slice(0, 16))}</small>` : ''}</span>
    <span class="act"><button data-edit="${f.id}" title="고치기">✎</button></span></div>`;
}
/* ── valve part diagram: which part of the valve a datasheet field is about (user request) ── */
const PART_RULES = [
  [/^(body_|bodysize|body\/|typeofbonnet|corrosion|materialcorrosion|nace$|fire_safe|fireproofing|painting|weather|certificate)/, 'body'],
  [/^(ball_|plug\/ball|trimtype|trimconstruction|flowdirection|piggable)/, 'ball'],
  [/^(seat|leakage|tightness|max_dp|max\.shutoff)/, 'seat'],
  [/^(seal_|gasketmaterial)/, 'seal'], [/^(stem)/, 'stem'], [/^(packing)/, 'packing'], [/^(bolting)/, 'bolting'],
  [/^(connections|conn\.type|rating|class$|flangefacefinish|facetofface|schedule)/, 'flange'],
  [/^(act_spring|fail_position|air_failure|failureaction|power_failure)/, 'spring'],
  [/^(act_|typeofactuator|handwheel$|yoke|strokespeed|stroke_time)/, 'actuator'],
  [/^(sov|coil_|power_supply|powersupply|elec_|cable_gland|ingress|manual_reset|ratedpower)/, 'sov'],
  [/^(afr|tubing|fitting|buffer_vessel|vessel_min)/, 'afr'],
  [/^(limit|ls_|stroke_closed|stroke_open|positiontransmitter|sil$)/, 'ls'],
  [/^(line_|lineno|linesize|pipe_|piping_class|insulation)/, 'pipe'],
  [/^(fluid|op_|design|corrosive|erosive|toxic|sour_service|service$|flow|inlet_|outlet_|density|viscosity|vapor|critical|cp_cv|z_factor|mol_weight)/, 'bore'],
];
const PART_GROUP = { actuator: ['actuator', 'spring', 'yoke'], bolting: ['bolting', 'seal'], afr: ['afr', 'tube'], ls: ['ls'], pipe: ['pipe', 'flange'] };
const PART_INFO = { body: ['Body / Bonnet (몸통)', '압력을 가두는 바깥 몸체 — 재질 · 형식 · 도장 · NACE 가 여기'], ball: ['Ball (볼)', '구멍 뚫린 공 — 돌려서 열고 닫는 부품 (Trim 의 하나)'],
  seat: ['Seat (시트)', '볼이 닿아 밀봉하는 링 — 누설 등급 · 차단 압력이 여기 걸림'], seal: ['Body Seal / Gasket (몸통 밀봉)', '몸통 이음부(보닛)의 개스킷'],
  stem: ['Stem (스템)', '볼을 돌리는 축 — 액추에이터와 볼을 잇는다'], packing: ['Stem Packing (패킹)', '스템이 나오는 자리의 밀봉 — 외부 누설 방지'],
  bolting: ['Bolting (볼트 · 너트)', '몸통 · 플랜지를 조이는 스터드 볼트와 너트 · 개스킷'], flange: ['End Connection (플랜지)', '배관과 잇는 끝단 — 플랜지 규격 · 압력 등급 · 면 마감'],
  actuator: ['Actuator (액추에이터)', '밸브를 여닫는 구동기 — 형식 · 토크 · 작동 시간'], spring: ['Fail-safe Spring (스프링)', '공기 · 전원이 끊기면 밸브를 안전 위치로 보내는 스프링'],
  sov: ['Solenoid Valve (솔레노이드)', '전기 신호로 액추에이터 공기를 넣고 빼는 밸브 — 전원 · 방폭 · 케이블'], afr: ['Air Filter Regulator · Tubing', '공기 공급 조절기와 배관 · 피팅'],
  ls: ['Limit Switch / Position Transmitter', '열림 · 닫힘 위치 신호 — 리밋 스위치 · 위치 발신기'], pipe: ['Pipe / Line (배관)', '밸브가 설치되는 배관 — 라인 번호 · 크기 · 재질 · 보온'],
  bore: ['Flow Path (유로)', '공정 유체가 지나는 길 — 유체 · 압력 · 온도 · 유량 조건'] };
function partOf(key) { const k = (key || '').toLowerCase(); for (const [re, p] of PART_RULES) if (re.test(k)) return p; return null; }
/* valve36 — the valve model is drawn the Anatomy way (session 7 '3D 계측제어 도구' engine: isometric, four-tone shading,
   painter's order, ink lines — anatomy.js, offline).  The model is built from this datasheet (size · class · bore · operator);
   the field → part link is the same PART_RULES as before.  Dimensions are reference values: the model shows WHERE, not how big. */
const ANAT_IDS = { pipe: ['pipe'], flange: ['bolting_in', 'bolting_out', 'flange_gaskets'], body: ['body', 'body_connector', 'mounting_pad'],
  bore: ['ball', 'pipe'], seat: ['seats'], ball: ['ball', 'trunnion'], seal: ['body_connector', 'body_bolting'], bolting: ['body_bolting', 'bolting_in', 'bolting_out'],
  packing: ['stem_seal'], stem: ['stem', 'thrust_washer'], yoke: ['bracket', 'coupling', 'thrust_base'],
  actuator: ['actuator', 'end_cap_l', 'end_cap_r', 'gearcase', 'motor', 'control_unit', 'gearbox', 'lever', 'lever_head', 'input_shaft'],
  spring: ['end_cap_l', 'end_cap_r'], handwheel: ['handwheel', 'hw_shaft', 'declutch'], sov: ['solenoid'], afr: [], tube: [],
  ls: ['positioner', 'indicator', 'control_unit', 'gear_indicator'] };
const ANAT = { el: null, key: '', model: null, note: '', pick: null };
function anatInputs(d) {
  const F = Object.fromEntries((d?.fields || []).map(f => [f.key, f])), v = k => String(F[k] ? (F[k].edited_value ?? F[k].value) ?? '' : '');
  const sz = v('body_size').replace(/(\d+)\s+(\d)\/(\d)/, (m, a, b, c) => String(+a + b / c)).match(/(\d+(?:\.\d+)?)/);
  const nps = sz ? +sz[1] : null, rt = (v('rating').match(/(\d{3,4})/) || [])[1] || '', bt = (v('body_type') + ' ' + v('bore')).toLowerCase();
  const at = (v('act_type') + ' ' + v('typeofactuator') + ' ' + (d?.valve_type || '') + ' ' + (d?.tag || '')).toLowerCase();
  const op = /electric|motor|\bmov\b|mov\d|^\d*mov/.test(at) ? 'electric' : /gear/.test(at) ? 'gear' : /lever|manual|hand/.test(at) && !/pneum|spring/.test(at) ? 'lever' : 'pneumatic_rotary';
  const cls = rt === '150' || rt === '300' ? rt : '300', notes = [];
  if (!nps) notes.push('Size 없음 → 4" 모양');
  if (rt && cls !== rt) notes.push(`CL${rt} 치수표 없음 → CL300 모양`);
  return { inputs: { body: 'ball', operator: op, service: 'on_off', nps: nps ? Math.min(24, Math.max(0.5, nps)) : 4, cls,
    bore: /reduc|\brb\b|r\.?p\b/.test(bt) ? 'reduced' : 'full', positioner: op !== 'electric' }, note: notes.join(' · ') };
}
function anatMount() {                                  // one canvas for the whole session; the Data tab re-parents it
  const slot = $('#vanat'); if (typeof AnatomyViewer === 'undefined') return false;
  if (!slot) { if (!ANAT.el || !document.contains(ANAT.el)) return false; }
  else if (!ANAT.el) {
    ANAT.el = document.createElement('div'); ANAT.el.className = 'anat';
    slot.replaceWith(ANAT.el);
    AnatomyViewer.setOption('labels', 'off'); AnatomyViewer.setOption('autoExplode', false);
    AnatomyViewer.init(ANAT.el, { onPick: id => { ANAT.pick = id; paintPart(true); } });
  } else slot.replaceWith(ANAT.el);
  const { inputs, note } = anatInputs(S.ds), key = (S.ds?.id || '') + JSON.stringify(inputs);
  if (key !== ANAT.key) {
    ANAT.key = key; ANAT.note = note;
    try { ANAT.model = Anatomy.build({ type: 'valve', inputs }); AnatomyViewer.show(ANAT.model); AnatomyViewer.setView?.('iso'); AnatomyViewer.fit(); }
    catch (e) { ANAT.model = null; console.warn('anatomy', e); }
  }
  return true;
}
function paintPart(fromModel) {
  const cap = $('#vpcap'); if (!cap) return;
  if (!anatMount()) { cap.innerHTML = '<div class="soft">밸브 모형을 불러오지 못했습니다</div>'; return; }
  const have = new Set((ANAT.model?.parts || []).map(x => x.id)), info = id => (ANAT.model?.parts || []).find(x => x.id === id);
  if (fromModel && ANAT.pick) {                         // model → fields: which datasheet rows talk about this part
    const ours = Object.keys(ANAT_IDS).filter(k => ANAT_IDS[k].includes(ANAT.pick)), pt = info(ANAT.pick);
    const fs = (S.ds?.fields || []).filter(f => { const q = partOf(f.key); return q && (ours.includes(q) || (PART_GROUP[q] || []).some(x => ours.includes(x))); });
    AnatomyViewer.select([ANAT.pick]);
    cap.innerHTML = `<b>${esc(pt?.name || ANAT.pick)}</b>${pt?.fn ? `<div class="soft">${esc(pt.fn)}</div>` : ''}
      <div class="achips">${fs.length ? fs.map(f => `<span class="fchip" data-afield="${esc(f.key)}">${esc(f.display)}: <b>${esc((f.edited_value ?? f.value) || '—')}</b></span>`).join('') : '<span class="soft">이 부품을 다루는 칸이 없습니다</span>'}</div>`;
    $$('[data-afield]', cap).forEach(c => c.onclick = () => { selectField(c.dataset.afield); $(`#wbody [data-k="${CSS.escape(c.dataset.afield)}"]`)?.scrollIntoView({ block: 'nearest' }); });
    return;
  }
  ANAT.pick = null;
  const f = S.ds?.fields.find(x => x.key === W.selField), p = f ? partOf(f.key) : null, parts = p ? (PART_GROUP[p] || [p]) : [];
  const ids = [...new Set(parts.flatMap(x => ANAT_IDS[x] || []))].filter(x => have.has(x));
  AnatomyViewer.select(ids);
  const miss = p && !ids.length ? '<div class="soft">이 모형에는 그려지지 않은 부위입니다 (예: AFR · 튜빙)</div>' : '';
  cap.innerHTML = (p ? `<b>${PART_INFO[p][0]}</b><div class="soft">${PART_INFO[p][1]}</div>${miss}<div><small>${esc(f.display)}: <b>${esc((f.edited_value ?? f.value) || '—')}</b></small></div>`
    : f ? `<b>${esc(f.display)}</b><div class="soft">밸브 부위가 아닌 항목(식별 · 문서 · 수량)</div>` : '<div class="soft">칸을 누르면 그 부위가 모형에서 주황색으로 · 모형의 부품을 누르면 관련 칸 · 휠 = 분해 / 확대 · 끌기 = 돌려 보기</div>')
    + (ANAT.note ? `<div class="soft" style="font-size:10.5px">모형: ${esc(ANAT.note)}</div>` : '');
}
function drawRight() {
  const d = S.ds, b = $('#wbody'); if (!d || !b) return;
  const F = Object.fromEntries(d.fields.map(f => [f.key, f])), val = k => F[k] ? (F[k].edited_value ?? F[k].value) : '';
  const cnt = s => d.fields.filter(f => f.status === s && f.edited_value == null).length;
  let h = '';
  if (W.tab === 'iss') {
    const L = (d.issues || []).filter(i => i.type !== 'Extraction Review' || W.showInternal);
    const card = i => `<div class="iss ${i.color} ${W.selIss === i.ikey ? 'on' : ''} ${i.status === 'Dismissed' ? 'dis' : ''}" data-iss="${esc(i.ikey)}">
        <div class="ih"><b class="no ${i.color}">${i.no}</b><b>${esc(i.type)}</b><span class="soft">${esc(i.field)}${i.row ? ' #' + i.row : ''} · p.${i.page || ''}</span><span class="sp"></span>
        ${i.comment_id ? '' : `<button class="ibtn" data-icmp="${esc(i.ikey)}" title="어디와 다른지 — Datasheet 칸과 기준 문서(PMS · Process Data · 이전 판) 나란히">⇆</button><button class="ibtn" data-iedit="${esc(i.ikey)}" title="코멘트 고치기 · 보완${i.edited ? ' (고침)' : ''}">✎${i.edited ? '•' : ''}</button>`}${decSelect(`data-ist="${esc(i.ikey)}"`, i)}</div>
        <div>${descHTML(i)}</div>${i.expected ? `<div class="soft">Required: <b>${esc(i.expected)}</b></div>` : ''}${i.op && i.expected ? `<div class="soft" style="font-size:11px" title="Actual · 비교 · Reference${i.tol ? ' · 허용오차' : ''} · Result">${esc(i.value || '(blank)')} <b>${esc(i.op)}</b> ${esc(i.expected)}${i.tol ? ` (±${esc(i.tol)})` : ''} → ${esc(i.result || '')}</div>` : ''}${i.evidence?.length ? `<div class="soft" style="font-size:11px">근거: ${i.evidence.map(x => evLink(d, x)).join(' · ')}${i.basis ? ` <span class="soft" title="${esc(i.basis)}">[${esc(i.check || '')}]</span>` : ''}</div>` : ''}${i.note ? `<div class="soft">Note: ${esc(i.note)}</div>` : ''}</div>`;
    // same type + same reason → one card with the fields as chips (13 'no value; ref. Process DS' cards become one)
    const sig = i => i.type === 'Data Missing' ? 'Data Missing|' + i.description.replace(/^[^:]+:\s*/, '') : i.type === 'Open Item' && !i.key.startsWith('note.') ? 'Open Item|hold' : null;
    const groups = {}; L.forEach(i => { const k = sig(i); if (k) (groups[k] ||= []).push(i); });
    const grouped = new Set(Object.values(groups).filter(g => g.length >= 3).flat().map(i => i.ikey));
    const items = [];
    L.forEach(i => { if (!grouped.has(i.ikey)) { items.push(card(i)); return; }
      const k = sig(i), g = groups[k]; if (g[0] !== i) return;
      const open = W.grpOpen.has(k), first = g[0], st = [...new Set(g.map(x => x.status))];
      items.push(`<div class="iss ${first.color} grp ${open ? 'open' : ''}" data-grp="${esc(k)}">
        <div class="ih"><b class="no ${first.color}">${first.no}–${g[g.length - 1].no}</b><b>${esc(first.type)}</b><span class="soft">${g.length}건 · ${st.length === 1 ? st[0] : st.length + ' statuses'}</span><span class="sp"></span>
          <select data-istg="${esc(k)}" aria-label="decision all"><option value="">일괄 결정…</option>${DECIDE.filter(x => x !== 'Modified').map(x => `<option>${x}</option>`).join('')}</select>
          <button data-grpx="${esc(k)}" title="${open ? '접기' : '펼치기'}">${open ? '▾' : '▸'}</button></div>
        <div>${first.type === 'Open Item' ? esc('HOLD / TBC — release and give the value.') + (clang() !== 'en' ? '<div class="dko">HOLD / TBC — 확정 값을 기입 바랍니다.</div>' : '')
          : descHTML({ description: first.description.replace(/^[^:]+:\s*/, ''), description_ko: (first.description_ko || '').replace(/^[^:]+:\s*/, '') || null })}</div>
        <div class="chips">${g.map(x => `<span class="fchip ${x.status === 'Dismissed' ? 'dis' : ''} ${W.selIss === x.ikey ? 'on' : ''}" data-iss="${esc(x.ikey)}" title="${esc(descText(x))}">${x.no} ${esc(x.field)}${x.expected && first.type === 'Data Missing' ? ` <i>→ ${esc(x.expected)}</i>` : ''}</span>`).join('')}</div>
        ${open ? `<div class="grpbody">${g.map(card).join('')}</div>` : ''}</div>`); });
    h = `<div class="sect" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">${['error', 'missing', 'process', 'material', 'revision', 'comment'].map(c => {
        const n = L.filter(i => i.color === c).length; return n ? `<span class="pill p-${{ error: 'bad', missing: 'ReviewRequired', process: 'ProcessMismatch', material: 'soft', revision: 'Modified', comment: 'Commented' }[c]}">${{ error: 'Error', missing: 'Missing', process: 'Process', material: 'Expert', revision: 'Rev', comment: 'Reviewer' }[c]} ${n}</span>` : ''; }).join('')}
        <label class="soft" style="margin-left:auto"><input type="checkbox" id="wint" ${W.showInternal ? 'checked' : ''}> 내부 ${(d.issues || []).filter(i => i.type === 'Extraction Review').length}</label></div>
      ${items.join('') || '<div class="empty">이 데이터시트에는 지적 사항이 없습니다</div>'}
      <p class="soft hint">Dismissed 는 설계사 전달본(Excel · Mark-up PDF)에서 빠집니다. 상태를 바꾸면 이유를 묻고 감사 기록에 남깁니다.</p>`;
  } else if (W.tab === 'chk') {                          // valve28: the engine's own report for this tag
    const V = d.verification; const ic = { pass: '✓', fail: '✗', 'n/a': '–' };
    if (!V) h = '<div class="empty">검증 보고가 없습니다</div>';
    else {
      const groups = [...new Set(V.checks.map(c => c.group))];
      h = `<div class="chk-sum"><b>${V.summary.total}</b> 항목 검사 · <span class="ok">✓ ${V.summary.pass}</span> · <span class="bad">✗ ${V.summary.fail}</span> · <span class="soft">– ${V.summary.na} 평가 불가</span></div>
        <p class="soft hint">✗ 는 Issues 탭의 지적과 같은 번호입니다. – 는 자료가 없어 판단하지 않은 항목이고 이유를 적습니다 — 통과로 치지 않습니다.</p>`
        + groups.map(g => `<div class="chk-g"><b>${esc(g)}</b>${V.checks.filter(c => c.group === g).map(c => `<div class="chk ${c.status === 'fail' ? 'bad' : c.status === 'n/a' ? 'na' : 'ok'}" ${c.status === 'fail' ? `data-chk="${esc(c.id)}" title="Issues 탭에서 보기"` : ''}>
          <span class="st">${ic[c.status]}</span><span class="id">${esc(c.id)}</span><span>${esc(c.title)}</span><span class="sp"></span>${c.findings ? `<b>${c.findings}</b>` : ''}${c.reason ? `<span class="soft">${esc(c.reason)}</span>` : ''}</div>`).join('')}</div>`).join('');
    }
  } else if (W.tab === 'sum') {
    h = `<div class="sect"><h4>Datasheet</h4><table class="t"><tbody>
      ${[['Tag Number', d.tag], ['Valve Type', d.valve_type], ['Form', d.title + (d.form ? ` (${d.form})` : '')], ['Document No.', d.doc_no], ['Revision', `${d.rev} ${d.rev_date ? '· ' + d.rev_date : ''}`],
        ['File', `${d.filename} · p.${d.pages.join(', ')}`], ['Service', val('service')], ['P&ID No.', val('pid_no')], ['Line No.', val('line_no')], ['Piping Class', val('piping_class')],
        ['Valve Size / Rating', `${val('body_size')} / ${val('rating')}`], ['Body Type', val('body_type') || val('instrument_type')]]
        .map(([k, v]) => `<tr><td class="soft" style="width:38%">${k}</td><td>${esc(v)}</td></tr>`).join('')}</tbody></table></div>
      <div class="sect"><h4>Special Requirements — Notes · General Notes · 칸</h4>${reqList(d)}</div>
      <div class="sect"><h4>Extraction</h4>${pill('ok', `읽음 ${cnt('ok')}`)} ${pill('placeholder', `VTA/NA ${cnt('placeholder')}`)} ${pill('NotFound', `Not Found ${cnt('blank')}`)} ${pill('ReviewRequired', `Review Required ${cnt('review')}`)}
        <p class="soft hint">PDF 글자층에서 직접 읽어 신뢰도는 칸마다 '읽음/없음/검토 필요' 로 표시합니다 (추정하지 않음). 스캔 쪽은 읽지 않습니다.</p></div>
      <div class="sect"><h4>Review Required</h4>${d.fields.filter(f => f.status === 'review' && f.edited_value == null).map(fieldLine).join('') || '<div class="soft">없음</div>'}</div>`;
  } else if (W.tab === 'data') {
    const secs = {};
    d.fields.forEach(f => { if ((f.section === 'process' || f.section === 'sizing') && /\.(max|nor|min)$/.test(f.key)) return; (secs[f.section] ||= []).push(f); });
    h = `<div class="vpart ${LS.get('vpart', 1) ? '' : 'min'}" id="vpart"${(d.kind || 'ball') !== 'ball' ? ' style="display:none"' : ''}><div id="fsrc" class="fsrc"></div><div class="vph"><b>Valve Part</b><span class="soft">칸 ↔ 부위 · Anatomy</span><span class="sp"></span><button id="vfit" title="처음 모습 (조립 · 맞춤)">⟲</button><button id="vpt" title="그림 접기/펼치기">${LS.get('vpart', 1) ? '▾' : '▸'}</button></div><div id="vanat"></div><div class="vpcap" id="vpcap"></div></div>`
      + kindBanner(d) + caseTable(d)
      + Object.keys(SECTION_NAMES).filter(s => secs[s]).map(s => `<div class="sect"><h4>${SECTION_NAMES[s]}</h4>${secs[s].map(fieldLine).join('')}</div>`).join('');
  } else if (W.tab === 'proc') {
    const P = d.process, ex = ['body_size', 'rating', 'body_material', 'ball_material', 'seat_material', 'piping_class'].map(k => F[k]).filter(Boolean);
    const pf = d.fields.filter(f => f.section === 'process' && !NOT_PROCESS.has(f.key) && !f.key.includes('.'));
    h = !d.process_doc
      ? `<div class="banner info"><b>Not Evaluated</b> — Process Data 문서가 아직 없습니다. Document Management 에 Process Data PDF(Annexure 7 'Process Data for On-Off Valve' 표)를 올리면 Tag 로 연결해 공정 항목만 비교합니다.</div>
        <table class="t"><thead><tr><th>Parameter</th><th>Datasheet</th><th>Unit</th><th>Result</th><th>p.</th></tr></thead><tbody>
        ${pf.map(f => `<tr class="click" data-k="${esc(f.key)}"><td>${esc(f.display)}</td><td>${esc((f.edited_value ?? f.value) || 'Not Found')}</td><td>${esc(f.unit)}</td><td>${pill('NotEvaluated', 'Not Evaluated')}</td><td>${f.page}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">공정 항목 없음</td></tr>'}</tbody></table>`
      : `<p>Process Data <b>${esc(d.process_doc.filename)}</b> · Tag 로 연결${d.process_ref ? ` · <span class="soft">Datasheet 가 Process DS 를 참조 (${esc(d.process_ref.where)})</span>` : ''}</p>
        <table class="t proc"><thead><tr><th>Item</th><th>Datasheet</th><th>Process Data</th><th>Result</th></tr></thead><tbody>
        ${(P || []).map(r => `<tr class="click" data-k="${esc(r.ds_key || '')}" title="${esc(r.reason)}"><td>${esc(r.item)}${r.pd_page ? ` <a href="#" class="soft" data-pdp="${r.pd_page}" data-pdb="${esc(JSON.stringify(r.pd_bbox))}" title="Process Data 쪽 열기">p.${r.pd_page}</a>` : ''}</td>
          <td>${esc(r.ds || '—')} <small class="soft">${esc(r.ds_unit)}</small></td><td>${esc(r.pd || '—')} <small class="soft">${esc(r.pd_unit)}</small></td><td>${pill(r.result.replace(/[^A-Za-z]/g, ''), { Mismatch: '✖ Mismatch', 'Review Required': '? Review', 'Not in Process Data': '– Not in PD', 'Datasheet Blank': '– DS blank' }[r.result] || r.result)}</td></tr>
          ${['Mismatch', 'Review Required'].includes(r.result) ? `<tr class="why"><td colspan="4"><small>${esc(r.reason)}</small></td></tr>` : ''}`).join('') || '<tr><td colspan="4" class="empty">비교할 항목이 없습니다</td></tr>'}</tbody></table>
        <p class="soft hint">Match 허용 오차 1 % · 게이지/절대압 기준이 양쪽에 적혀 있을 때만 압력을 비교 · 단위가 불명확하면 Review Required (Pass/Fail 로 만들지 않음) · Referenced = Datasheet 가 Process DS 를 참조해 비워 둔 칸.</p>`;
    h += `<div class="sect" style="margin-top:10px"><h4>Excluded — not process data (spec §6.3)</h4>
      <table class="t"><tbody>${ex.map(f => `<tr class="click" data-k="${esc(f.key)}"><td>${esc(f.display)}</td><td>${esc(f.edited_value ?? f.value)}</td><td>${pill('Excluded', 'N/A (Excluded)')}</td></tr>`).join('')}</tbody></table>
      <p class="soft hint">Valve Size · Rating · Material · Piping Class 는 Process Data 검증에서 비교하지 않습니다 (Datasheet · PMS 기준으로 관리).</p></div>`;
  } else if (W.tab === 'pms') {
    h = !d.pms ? `<div class="empty">PMS 문서가 아직 없습니다 — Document Management 에 Piping Material Specification PDF 를 올리면<br>Piping Class 의 Rating · NACE · Trim · Body · Seat 를 이 데이터시트와 비교합니다.</div>`
      : `<p>Piping Class <b>${esc(val('piping_class') || 'Not Found')}</b> · PMS ${esc(d.area || '지역 미상')} · <span class="soft">${esc(d.pms_doc?.filename || '')}</span></p>
      <table class="t"><thead><tr><th>Item</th><th>PMS Requirement</th><th>Datasheet</th><th>Result</th><th>PMS p.</th></tr></thead><tbody>
      ${d.pms.map(r => `<tr class="click" data-k="${esc(r.key)}" title="${esc(r.reason)}"><td>${esc(r.item)}</td><td title="${esc(r.req)}">${esc(r.req)}</td><td title="${esc(r.ds)}">${esc(r.ds)}</td><td>${pill(r.result.replace(/[^A-Za-z]/g, ''), r.result)}<div class="soft" style="font-size:11px">${esc(r.reason)}</div></td><td>${r.pms_page ? `<a href="#" data-pmsp="${r.pms_page}" data-pmsb="${esc(JSON.stringify(r.pms_bbox))}">${r.pms_page}</a>` : ''}</td></tr>`).join('')}</tbody></table>
      <p class="soft hint">재질은 표기가 아니라 규격·등급으로 비교합니다 (A351 CF8M ⊂ 316/316L SS A351-CF8M/CF3M = Compliant). 같은 계열의 다른 등급은 Review Required.</p>`;
  } else if (W.tab === 'mat') {
    h = matList(d);
  } else if (W.tab === 'rev') {
    const c = W.prevCmp;
    h = c ? `<p>Rev.<b>${esc(c.prev.rev)}</b> → Rev.<b>${esc(c.new.rev)}</b> · ${['Modified', 'Added', 'Deleted'].map(k => pill(k, `${k} ${c.rows.filter(r => r.change === k).length}`)).join(' ')}</p>
      <table class="t"><thead><tr><th>Field</th><th>Previous</th><th>New</th><th>Type</th><th>p.</th></tr></thead><tbody>
      ${c.rows.filter(r => r.change !== 'Unchanged').map(r => `<tr class="click" data-k="${esc(r.key)}"><td>${esc(r.display)}</td><td class="chg-old">${esc(r.previous)}</td><td><b>${esc(r.new)}</b></td><td>${pill(r.change)}</td><td>${r.new_page || r.prev_page || ''}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">바뀐 칸이 없습니다</td></tr>'}</tbody></table>
      <p><button data-go="rev">Revision Comparison 화면에서 나란히 보기</button></p>`
      : `<div class="empty">이 Tag 는 Revision 이 하나뿐입니다 (Rev.${esc(d.rev)}).<br>새 Revision PDF 를 Document Management 에 올리면 여기서 이전 판과 칸별로 비교합니다.</div>`;
  } else if (W.tab === 'notes') {
    const gn = Object.entries(d.general_notes || {});
    h = `<div class="sect notes"><h4>Datasheet Notes (${d.notes.length})</h4>${d.notes.map(n => `<div class="n" data-np="${n.page}" data-nb="${esc(JSON.stringify(n.bbox))}"><b>${n.no}.</b>${esc(n.text)} <small class="soft">p.${n.page}</small></div>`).join('') || '<div class="soft">없음</div>'}</div>
      <div class="sect notes"><h4>General Notes — ${esc(d.doc_no)} (${gn.length})</h4>${gn.map(([no, t]) => `<div class="n"><b>${no}.</b>${esc(t)}</div>`).join('') || '<div class="soft">이 문서의 General Notes 를 찾지 못했습니다</div>'}</div>`;
  } else if (W.tab === 'cmt') {
    h = `<div class="sect"><textarea id="cmtx" rows="3" style="width:100%" placeholder="Review Comment (Engineering 의견)"></textarea>
        <div style="display:flex;gap:6px;margin-top:4px"><button class="pri" id="cmadd">의견 남기기</button><button id="cmdraw" title="PDF 위 Mark-up 도구 줄에서 다른 모양(구름 · 화살표 · 펜 · 글상자 …)도 고를 수 있습니다">▭ PDF 위에 표시하며 남기기</button></div></div>
      ${d.comments.map(c => `<div class="cm ${W.selCm === c.id ? 'sel' : ''}" data-cm="${c.id}"><div class="h"><i class="mkdot" style="background:${MKCOL[c.category] || MKCOL.comment}"></i><b>${esc(c.by)}</b>${c.origin ? `<span class="pill p-rev" title="이전 Revision 의 의견을 이어받음">${esc(c.origin)}</span>` : ''}${c.bbox ? `<span class="soft">${KIND_KO[c.kind || 'rect'] || ''}</span>` : ''}<span>${esc(c.at.replace('T', ' ').slice(0, 16))}</span>${c.page ? `<a href="#" data-cmgo="${c.id}">p.${c.page} ▭</a>` : ''}<span class="sp"></span>
        <button data-cmed="${c.id}" title="고치기">✎</button><button data-cmdel="${c.id}" title="지우기">✕</button></div><div class="ct">${esc(c.text) || '<span class="soft">(표시만)</span>'}</div></div>`).join('') || '<div class="soft">아직 의견이 없습니다</div>'}`;
  } else if (W.tab === 'hist') {
    h = `<table class="t"><thead><tr><th>When</th><th>Who</th><th>What</th></tr></thead><tbody>${d.history.map(a => `<tr><td class="mono">${esc(a.at.replace('T', ' ').slice(5, 16))}</td><td>${esc(a.by)}</td>
      <td>${esc(a.action)} ${a.field_key ? `<b>${esc(a.field_key)}</b>` : ''}${a.before != null ? ` <span class="chg-old">${esc(String(a.before).slice(0, 60))}</span>` : ''}${a.after != null ? ` → ${esc(String(a.after).slice(0, 80))}` : ''}${a.comment ? ` <small class="soft">(${esc(a.comment)})</small>` : ''}</td></tr>`).join('') || '<tr><td colspan="3" class="empty">기록 없음</td></tr>'}</tbody></table>`;
  }
  b.innerHTML = h;
  if (W.tab === 'data') { paintPart(); $('#vfit').onclick = () => { AnatomyViewer.setExplode?.(0); AnatomyViewer.focus?.(null); AnatomyViewer.fit(); }; $('#vpt').onclick = () => { const on = !LS.get('vpart', 1); LS.set('vpart', on ? 1 : 0); $('#vpart').classList.toggle('min', !on); $('#vpt').textContent = on ? '▾' : '▸'; }; }
  const tb = (t, n) => { const x = $(`#wtabs [data-t="${t}"] .tb`); if (x) { x.textContent = n; x.hidden = !n; } };
  tb('iss', (d.issues || []).filter(i => i.type !== 'Extraction Review' && i.status !== 'Dismissed').length); tb('cmt', d.comments.length);
  tb('rev', (W.prevCmp?.rows || []).filter(r => r.change !== 'Unchanged').length); tb('pms', (d.pms || []).filter(r => r.result !== 'Compliant').length);
  tb('proc', (d.process || []).filter(r => r.result === 'Mismatch').length); tb('mat', (d.material_review || []).filter(m => m.level !== 'Note').length);
  b.onclick = async e => {
    const ed = e.target.closest('[data-edit]'); if (ed) { editField(+ed.dataset.edit); return; }
    const np = e.target.closest('[data-np]'); if (np) { W.viewer.focus(+np.dataset.np, JSON.parse(np.dataset.nb || 'null'), 'Note'); return; }
    const sr = e.target.closest('[data-src]'); if (sr) { e.preventDefault(); const t = sr.dataset.src, m = t.match(/^(Note|HOLD) (\d+)/), r = t.match(/^row (\d+)/);
      if (m) { const n = d.notes.find(x => x.no === +m[2] && ((m[1] === 'HOLD') === ((x.section || '') === 'HOLD'))); if (n) W.viewer.focus(n.page, n.bbox, t); }
      else if (r) { const f = d.fields.find(x => x.row === +r[1] && t.includes(x.display || '')) || d.fields.find(x => x.row === +r[1]); if (f) selectField(f.key); }
      else { setTab('notes'); } return; }
    const cg = e.target.closest('[data-cmgo]'); if (cg) { e.preventDefault(); const c = d.comments.find(x => x.id === +cg.dataset.cmgo); W.selCm = c.id; paintDsOverlays(); W.viewer.goPage(c.page, c.bbox); drawRight(); return; }
    const ce = e.target.closest('[data-cmed]'); if (ce) { const c = d.comments.find(x => x.id === +ce.dataset.cmed);
      const r = await modal('의견 고치기', `<textarea name="text" rows="4">${esc(c.text)}</textarea>`, [['취소', null], ['저장', 'form', 1]]);
      if (r) await changeMark({ id: c.id }, { text: r.text }, { text: c.text }); return; }
    const cd = e.target.closest('[data-cmdel]'); if (cd) { if (await modal('의견 지우기', '이 의견(과 PDF 표시)을 지울까요? 기록은 History 에 남습니다.', [['취소', 0], ['지우기', 1, 1]])) {
      W.selCm = +cd.dataset.cmdel; await markCmd('del'); } return; }
    const pp = e.target.closest('[data-pmsp]'); if (pp) { e.preventDefault(); openPmsRef(+pp.dataset.pmsp, JSON.parse(pp.dataset.pmsb || 'null')); return; }
    const ek = e.target.closest('[data-ek]'); if (ek) { e.preventDefault(); selectField(ek.dataset.ek); return; }
    const cb = e.target.closest('[data-icmp], [data-iedit]');
    if (cb) { e.stopPropagation(); const i = (d.issues || []).find(x => x.ikey === (cb.dataset.icmp || cb.dataset.iedit));
      if (i) cb.dataset.icmp ? compareIssue(d, i) : editIssueText(d.id, i, async () => { S.ds = await api('GET', `/datasheets/${d.id}`); S.issues = null; paintDsOverlays(); drawRight(); }); return; }
    const ck = e.target.closest('[data-chk]'); if (ck) { const id = ck.dataset.chk, hit = (d.issues || []).find(i => (i.check || '').startsWith(id) && i.status !== 'Dismissed'); W.tab = 'iss'; LS.set('wtab', 'iss'); if (hit) W.selIss = hit.ikey; drawRight(); if (hit?.bbox) W.viewer.goPage(hit.page, hit.bbox); return; }
    const nt = e.target.closest('[data-notes]'); if (nt) { W.notesOpen = !W.notesOpen; drawRight(); return; }
    const pd = e.target.closest('[data-pdp]'); if (pd) { e.preventDefault(); openRef(d.process_doc, +pd.dataset.pdp, JSON.parse(pd.dataset.pdb || 'null'), 'Process Data'); return; }
    if (e.target.closest('select')) return;
    const gx = e.target.closest('[data-grpx]'); if (gx) { const k = gx.dataset.grpx; W.grpOpen.has(k) ? W.grpOpen.delete(k) : W.grpOpen.add(k); drawRight(); return; }
    const is = e.target.closest('[data-iss]'); if (is) { const i = d.issues.find(x => x.ikey === is.dataset.iss); W.selIss = i.ikey; link({ t: 'iss', id: d.id, ikey: i.ikey }); paintDsOverlays(); if (i.bbox) W.viewer.focus(i.page, i.bbox, i.field); $$('#wbody .iss').forEach(x => x.classList.toggle('on', x.dataset.iss === i.ikey)); return; }
    const k = e.target.closest('[data-k]'); if (k) selectField(k.dataset.k);
  };
  b.onchange = async e => {
    if (e.target.id === 'wint') { W.showInternal = e.target.checked; paintDsOverlays(); drawRight(); return; }
    const selg = e.target.closest('[data-istg]');
    if (selg) {                                              // one status for every issue of the group (sequential, audited each)
      const st = selg.value; if (!st) return;
      const keys = [...$$(`[data-grp="${CSS.escape(selg.dataset.istg)}"] [data-iss]`)].map(x => x.dataset.iss);
      const body = await askDecision(st, keys.length); if (!body) { selg.value = ''; return; }
      toast(`${keys.length}건 → ${st} …`);
      for (const k of keys) await api('PUT', `/datasheets/${d.id}/issues/${encodeURIComponent(k)}`, body);
      S.ds = await api('GET', `/datasheets/${d.id}`); S.issues = null; paintDsOverlays(); drawHead(); drawRight(); toast(`${keys.length}건 → ${st}`); return;
    }
    const sel = e.target.closest('[data-ist]'); if (!sel) return;
    const iss = (d.issues || []).find(i => i.ikey === sel.dataset.ist);
    const body = await askDecision(sel.value, 1, iss); if (!body) { sel.value = decShown(iss || {}); return; }
    await api('PUT', `/datasheets/${d.id}/issues/${encodeURIComponent(sel.dataset.ist)}`, body);
    S.ds = await api('GET', `/datasheets/${d.id}`); S.issues = null; paintDsOverlays(); drawHead(); drawRight(); toast(`→ ${sel.value}`);
  };
  $('#cmadd') && ($('#cmadd').onclick = async () => { const t = $('#cmtx').value.trim(); if (!t) return;
    S.ds = await api('POST', `/datasheets/${d.id}/comments`, { text: t }); drawRight(); toast('의견을 남겼습니다'); });
  $('#cmdraw') && ($('#cmdraw').onclick = () => { W.viewer.showMkbar(true); W.viewer.setTool('rect'); toast('PDF 위에서 끌어 그리세요 — Mark-up 줄에서 모양·분류를 고릅니다 (Esc: 선택 도구)'); });
}
const MAT_LV = { Action: ['bad', '조치 필요 — 문서 한계를 넘음'], Confirm: ['warn', '확인 필요 — 조건부 허용'], Note: ['soft', '참고 — 검토 기록'] };
function matList(d) {                                  // material review (matreview.py): rule · comment · basis · evidence
  const L = d.material_review || [];
  if ((d.kind || 'ball') !== 'ball' && !L.length) return `<div class="empty">${esc(KIND_NAMES[d.kind] || '')} 데이터시트에는 Ball Valve 전용 규칙(재질 MR · 설계 VR · 액세서리 AC · 다른 데이터시트 대비 PC · PMS Ball 품목)을 적용하지 않습니다.<br>필수 칸 · HOLD/TBC · 문서 안 모순 · Notes 참조 · Process Data · Revision 검토는 Ball 과 같습니다.</div>`;
  if (!L.length) return '<div class="empty">검토 의견이 없습니다 — 규칙에 필요한 값(재질 · 설계온도 · PMS Class …)이 문서에 있을 때만 의견을 냅니다.</div>';
  const grp = r => r.startsWith('MR') ? '재질' : r.startsWith('VR') ? '설계' : r.startsWith('TG') ? 'Tag 번호' : '다른 데이터시트 대비';
  const ev = x => { const t = esc(x.where) + (x.text ? ` <span class="soft">${esc(String(x.text).slice(0, 90))}</span>` : '');
    if (x.doc === 'PMS' && x.page) return `<a href="#" data-pmsp="${x.page}" data-pmsb="${esc(JSON.stringify(x.bbox))}">PMS p.${x.page}</a> ${t}`;
    if (x.doc === 'Process Data' && x.page) return `<a href="#" data-pdp="${x.page}" data-pdb="${esc(JSON.stringify(x.bbox))}">Process Data p.${x.page}</a> ${t}`;
    if (/^(Note|HOLD|Gen Note) /.test(x.where)) return `<a href="#" data-src="${esc(x.where)}">${esc(x.where)}</a> <span class="soft">${esc(String(x.text || '').slice(0, 90))}</span>`;
    const f = d.fields.find(f => x.where.endsWith(f.display || f.key) && f.bbox);
    return f ? `<a href="#" data-ek="${esc(f.key)}">${t}</a>` : t; };
  return ['Action', 'Confirm', 'Note'].map(lv => { const M = L.filter(m => m.level === lv); if (!M.length) return '';
    const fold = lv === 'Note' && !W.notesOpen;                               // reference notes stay folded: the reviewer opens them when needed
    return `<div class="sect"><h4 ${lv === 'Note' ? 'class="click" data-notes="1" style="cursor:pointer"' : ''}><span class="pill p-${MAT_LV[lv][0]}">${lv}</span> ${MAT_LV[lv][1]} (${M.length})${lv === 'Note' ? ` <span class="soft">${fold ? '▸ 펼치기' : '▾ 접기'}</span>` : ''}</h4>${fold ? '' : M.map(m => `<div class="mat ${lv}">
      <div><span class="soft" style="font-size:11px">${grp(m.rule)}</span> <b>${esc(m.rule)} · ${esc(m.title)}</b></div>${m.level !== 'Note' ? `<div class="mshort" title="설계사에게 가는 코멘트 (Issue List · Mark-up PDF · Valve List)">▸ ${esc(m.short || '')}</div>` : ''}<div>${esc(m.comment)}</div>
      <div class="soft" style="font-size:11px">근거: ${esc(m.basis)}</div>
      ${m.kb_text ? `<details class="kb"><summary>지식: ${esc(m.kb_title)}</summary>${esc(m.kb_text)}</details>` : ''}
      <div style="font-size:11px">${m.evidence.map(ev).join('<br>')}</div></div>`).join('')}</div>`; }).join('')
    + '<p class="soft hint">Ball Valve 엔지니어 관점의 규칙 기반 의견입니다 (추측 없음): 재질(MR) · 설계(VR) · 이 프로젝트의 다른 데이터시트 대비(PC). Action·Confirm 은 Issue List 에 Material / Valve Review 로 올라가고, Note 는 여기와 Valve List 에만 남습니다. 근거 문서·칸을 누르면 그 위치로 갑니다. 지식 전체: Settings › Ball Valve 지식.</p>';
}
function reqList(d) {                                  // special requirements (requirements.py): one line per kind, sources clickable
  const by = {}; (d.requirements || []).forEach(r => (by[r.key] ||= []).push(r));
  if (!Object.keys(by).length) return '<div class="soft">Notes · General Notes 에서 찾은 특수 요구사항이 없습니다</div>';
  return `<table class="t req"><tbody>${Object.values(by).map(L => { const lab = L.reduce((a, r) => r.label.length > a.length ? r.label : a, L[0].label), neg = L.filter(r => r.negative);
    return `<tr><td><b>${esc(lab)}</b>${neg.length ? ` <span class="pill p-NotEvaluated" title="${esc(neg.map(r => r.source + ': ' + r.text).join('\n'))}">datasheet: Not Required</span>` : ''}
      <div class="soft">${L.filter(r => !r.negative).map(r => `<a href="#" data-src="${esc(r.source)}" title="${esc(r.text)}">${esc(r.source)}</a>`).join(' · ')}</div></td></tr>`; }).join('')}</tbody></table>
    <p class="soft hint">글에 그 요구사항의 낱말이나 규격 번호가 있을 때만 적습니다 (추측 없음). 출처를 누르면 그 Note / 칸으로 갑니다.</p>`;
}
function fieldSource(f) {                            // valve29 — where a value came from (source traceability)
  const d = S.ds, how = f.edited_value != null ? `engineer correction (${f.edited_by || '?'} · ${(f.edited_at || '').slice(0, 10)})`
    : f.ref?.no ? `note reference → Note ${f.ref.no}` : f.status === 'review' ? 'text layer · pairing unsure (Review)' : 'text layer · ruled table';
  const iss = (d.issues || []).filter(i => i.key === f.key || (i.key || '').split('.')[0] === f.key.split('.')[0]);
  return `<b>${esc(f.display || f.key)}</b> <span class="soft">${esc(f.key)}</span> = <b>${esc(f.edited_value ?? f.value ?? '')}</b>${f.unit ? ' ' + esc(f.unit) : ''}
    <div class="soft">${esc(d.filename || '')} · Doc. ${esc(d.doc_no)} · Rev.${esc(d.rev)} · p.${f.page ?? '—'}${f.row ? ' · row ' + f.row : ''}${f.bbox ? ` · (${f.bbox.map(x => Math.round(x)).join(', ')})` : ''}
      · ${esc(how)} · reader ${esc(d.parser_version || 'valve28 이전')}</div>
    ${iss.length ? `<div>이 칸의 지적 ${iss.length}: ${iss.slice(0, 4).map(i => `<a href="#" data-gi="${esc(i.ikey)}">#${i.no} ${esc(i.type)}</a>`).join(' · ')}</div>` : '<div class="soft">이 칸의 지적 없음</div>'}`;
}
function selectField(key) {
  const f = S.ds.fields.find(x => x.key === key);
  const r = W.prevCmp?.rows.find(x => x.key === key);
  W.selField = key; paintDsOverlays(); link({ t: 'field', id: S.ds.id, key });
  const fs = $('#fsrc'); if (fs && f) { fs.innerHTML = fieldSource(f); fs.classList.add('on');
    fs.onclick = e => { const a = e.target.closest('[data-gi]'); if (!a) return; e.preventDefault(); W.selIss = a.dataset.gi; setTab('iss'); const i = S.ds.issues.find(x => x.ikey === a.dataset.gi); if (i?.bbox) W.viewer.goPage(i.page, i.bbox); }; }
  if (f?.bbox) W.viewer.focus(f.page, f.bbox, f.display);
  else if (r?.new_bbox) W.viewer.focus(r.new_page, r.new_bbox, r.display);
  $$('#wbody [data-k]').forEach(x => x.classList.toggle('on', x.dataset.k === key));
  paintPart();
}
async function editField(fid) {
  const f = S.ds.fields.find(x => x.id === fid);
  const r = await modal(`${f.display} 고치기`, `<p class="soft">PDF 에서 읽은 값: <b>${esc(f.value || '(빈칸)')}</b> · p.${f.page}<br>원래 값으로 되돌리려면 읽은 값과 똑같이 두세요.</p>
    <input name="value" value="${esc(f.edited_value ?? f.value)}"><input name="comment" placeholder="고친 이유 (감사 기록)" style="margin-top:6px">`, [['취소', null], ['저장', 'form', 1]]);
  if (!r) return;
  try { S.ds = await api('PUT', `/datasheets/${S.ds.id}/fields/${fid}`, { value: r.value, comment: r.comment }); S.grid = null; drawRight(); toast('저장 — 원래 읽은 값과 함께 남습니다'); }
  catch (e) { toast(e.message, 1); }
}
/* mark-up: every change is saved at once (comment rows); ↶/↷ replay the inverse request */
const KIND_KO = { rect: '사각형', cloud: '구름', ellipse: '원', highlight: '형광펜', underline: '밑줄', strike: '취소선', squiggle: '물결 밑줄', line: '선', arrow: '화살표', pen: '펜', text: '글상자', note: '메모', stamp: '스탬프', typewriter: '타자기', callout: '말풍선', polyline: '꺾은선', polygon: '다각형' };
const CAT_OPTS = sel => ['comment', 'error', 'missing', 'question'].map(c => `<option value="${c}" ${c === sel ? 'selected' : ''}>${{ comment: 'Comment — 의견 (파랑)', error: 'Error — 데이터 오류 (빨강)', missing: 'Missing — 데이터 누락 (주황)', question: 'Question — 질의 (파랑)' }[c]}</option>`).join('');
async function markText(title, kind, text, cat) {
  const need = ['text', 'note', 'typewriter', 'callout'].includes(kind);
  return modal(title, `<p class="soft">${KIND_KO[kind] || kind} · 분류에 따라 색과 Issue 종류(Comment / Data Error / Data Missing)가 정해지고, Issue List 와 Mark-up PDF 에 번호로 나갑니다.</p>
    <select name="category" style="width:100%;margin-bottom:6px">${CAT_OPTS(cat)}</select>
    <textarea name="text" rows="4" placeholder="${need ? '글 (필수)' : '설계사에게 전할 의견 (비워 두면 표시만 남습니다)'}">${esc(text || '')}</textarea>`, [['취소', null], ['저장', 'form', 1]]);
}
function pushUndo(op) { W.undo = (W.undo || []).concat(op).slice(-100); W.redo = []; }
async function addMark(g) {
  const needText = ['text', 'note', 'typewriter', 'callout'].includes(g.kind);
  const ask = needText || !W.viewer.quick;                                           // '바로' on: shapes · stamps go in without a dialog
  const r = ask ? await markText('Mark-up 의견', g.kind, '', W.viewer.mkCat) : { category: W.viewer.mkCat, text: '' };
  if (!r || (needText && !r.text.trim())) return;
  try {
    const out = await api('POST', `/datasheets/${S.ds.id}/comments`, { ...g, category: r.category, text: r.text });
    S.ds = out; S.issues = null; W.selCm = out.new_comment_id;
    pushUndo({ t: 'create', id: out.new_comment_id, ds: S.ds.id });
    paintDsOverlays(); if (W.tab === 'cmt') drawRight();
    toast('표시를 남겼습니다 — Ctrl+Z 되돌리기');
  } catch (e) { toast(e.message, 1); }
}
async function eraseMark(id) {
  const c = S.ds?.comments.find(x => x.id === id); if (!c) return;
  try { S.ds = await api('PUT', `/comments/${id}`, { delete: true }); S.issues = null; pushUndo({ t: 'delete', id, ds: S.ds.id }); if (W.selCm === id) W.selCm = null; }
  catch (e) { toast(e.message, 1); }
  paintDsOverlays(); if (W.tab === 'cmt') drawRight();
}
async function changeMark(m, after, before) {
  const c = S.ds.comments.find(x => x.id === m.id); if (!c) return;
  before = before || Object.fromEntries(Object.keys(after).map(k => [k, c[k]]));
  try { S.ds = await api('PUT', `/comments/${m.id}`, after); S.issues = null; pushUndo({ t: 'update', id: m.id, ds: S.ds.id, before, after }); }
  catch (e) { toast(e.message, 1); }
  paintDsOverlays(); if (W.tab === 'cmt') drawRight();
}
async function markCmd(cmd) {
  const c = S.ds?.comments.find(x => x.id === W.selCm);
  if (cmd === 'undo' || cmd === 'redo') {
    const from = cmd === 'undo' ? (W.undo ||= []) : (W.redo ||= []), to = cmd === 'undo' ? (W.redo ||= []) : (W.undo ||= []);
    const op = from.at(-1); if (!op) return toast(cmd === 'undo' ? '되돌릴 것이 없습니다' : '다시 할 것이 없습니다');
    if (op.ds !== S.ds.id) return toast('다른 Tag 에서 한 작업입니다 — 그 Tag 를 열고 되돌리세요', 1);
    from.pop();
    const body = op.t === 'update' ? (cmd === 'undo' ? op.before : op.after)
      : ((op.t === 'create') === (cmd === 'undo')) ? { delete: true } : { restore: true };
    try { S.ds = await api('PUT', `/comments/${op.id}`, body); S.issues = null; to.push(op); toast(cmd === 'undo' ? '되돌렸습니다' : '다시 했습니다'); }
    catch (e) { toast(e.message, 1); }
    paintDsOverlays(); drawRight(); return;
  }
  if (!c) return toast('먼저 표시를 선택하세요 (⬚ 선택 도구)');
  if (cmd === 'del') {
    try { S.ds = await api('PUT', `/comments/${c.id}`, { delete: true }); S.issues = null; pushUndo({ t: 'delete', id: c.id, ds: S.ds.id }); W.selCm = null; toast('지웠습니다 — Ctrl+Z 되돌리기'); }
    catch (e) { toast(e.message, 1); }
    paintDsOverlays(); drawRight();
  } else if (cmd === 'edit') {
    const r = await markText('Mark-up 의견 고치기', c.kind || 'rect', c.text, c.category || 'comment');
    if (!r) return;
    await changeMark({ id: c.id }, { text: r.text, category: r.category }, { text: c.text, category: c.category || 'comment' });
  }
}
async function exportMarkup() {
  const t = await pickTypes(`Mark-up PDF (${S.ds.tag}) — 넣을 Issue Type`, { tag: S.ds.tag_key }); if (t == null) return;
  toast('Mark-up PDF 를 만드는 중…');
  try { await download(`/projects/${S.pid}/markup.pdf?tag=${encodeURIComponent(S.ds.tag_key)}&types=${encodeURIComponent(t)}${pdfq()}`); toast('내려받음 — 원본은 그대로, 번호 표시 + 쪽 옆 코멘트 + Issue Summary 쪽'); }
  catch (e) { toast(e.message, 1); }
}
async function openPmsRef(page, bbox) { return openRef(S.ds?.pms_doc || S.pmsDoc, page, bbox, 'PMS'); }
async function openRef(doc, page, bbox, what) {        // a reference document page (PMS · Process Data) in a pop-up viewer
  if (!doc) return;
  placeModal('ref');
  $('#mTitle').textContent = `${what} ${doc.filename} · p.${page}`; $('#mAct').innerHTML = '<button>닫기</button>';
  $('#mBody').innerHTML = '<div id="pmsv" style="height:70vh;display:flex;flex-direction:column;background:#525a68"></div>';
  $('.mbox').style.width = 'min(1000px,94vw)'; $('#modal').hidden = false;
  $('#mAct button').onclick = () => { $('#modal').hidden = true; $('.mbox').style.width = ''; };
  const v = new Viewer($('#pmsv')); await v.load(doc.id, [page]); v.fit(); if (bbox) v.focus(page, bbox, what);
}
/* ── 5. Revision Comparison ───────────────────────────────────────────── */
const RC = { flt: LS.get('rcflt', { Modified: true, Added: true, Deleted: true, Unchanged: false }), hl: new Set(), mock: false, sync: LS.get('rcsync', true) };
async function renderRev() {
  const el = $('#v-rev'), multi = S.sum.tags.filter(t => t.revs.length > 1);
  if (!RC.mock && !multi.length) {
    el.classList.remove('full');
    el.innerHTML = `<div class="vh"><h2>Revision Comparison</h2></div><div class="card"><div class="empty">Revision 이 2개 이상인 Tag 가 아직 없습니다.<br>
      새 Revision Datasheet PDF 를 <b>Document Management</b> 에 올리면 같은 Tag 끼리 자동으로 연결해 칸별로 비교합니다 (Added · Deleted · Modified).<br><br>
      <button id="rcmock">${MOCK} 예시 화면 보기 (실제 비교 아님)</button></div></div>`;
    $('#rcmock').onclick = () => { RC.mock = true; renderRev(); };
    return;
  }
  el.classList.add('full');
  let prev, cur, rows;
  if (RC.mock && !multi.length) {
    const t = S.sum.tags.find(t => t.id === S.dsId) || S.sum.tags[0], d = await api('GET', `/datasheets/${t.id}`);
    const pick = ['body_size', 'rating', 'seat_material', 'fire_safe', 'nace'].map(k => d.fields.find(f => f.key === k)).filter(Boolean);
    rows = d.fields.map(f => ({ key: f.key, display: f.display, previous: f.value, new: f.value, unit: f.unit, change: 'Unchanged', prev_page: f.page, prev_bbox: f.bbox, new_page: f.page, new_bbox: f.bbox }));
    pick.forEach((f, i) => { const r = rows.find(r => r.key === f.key); r.previous = i === 0 ? String(f.value).replace(/\d+/, n => Math.max(1, n - 2)) : i === 3 ? '' : 'MOCK-OLD'; r.change = i === 3 ? 'Added' : 'Modified'; });
    prev = { ...d, rev: d.rev + ' (MOCK prev)' }; cur = d;
  } else {
    const t = multi.find(t => t.id === S.dsId) || multi[0];
    const revs = (await api('GET', `/datasheets/${t.id}`)).revisions;
    const ni = RC.newId && revs.some(r => r.id === RC.newId) ? RC.newId : revs.at(-1).id;
    const pi = RC.prevId && revs.some(r => r.id === RC.prevId) && RC.prevId !== ni ? RC.prevId : revs[revs.findIndex(r => r.id === ni) - 1]?.id ?? revs[0].id;
    const c = await api('GET', `/compare?prev=${pi}&new=${ni}`);
    prev = c.prev; cur = c.new; rows = c.rows; RC.revs = revs; RC.tag = t;
  }
  RC.rows = rows;
  if (!RC.hl.size) rows.forEach((r, i) => { if (r.change !== 'Unchanged') RC.hl.add(i); });
  el.innerHTML = `<div class="rc"><div class="rc-top"><div class="rc-side" id="rcL"></div><div class="rc-side" id="rcR"></div>
      <div class="rc-opts"><b>Highlight Options</b>${['Modified', 'Added', 'Deleted', 'Unchanged'].map(k => `<label><input type="checkbox" data-f="${k}" ${RC.flt[k] ? 'checked' : ''}> ${pill(k)}</label>`).join('')}
        <hr style="width:100%;border:0;border-top:1px solid var(--line)"><label title="한쪽을 넘기거나 확대하면 다른 쪽도 같은 비율로"><input type="checkbox" id="rcsync" ${RC.sync ? 'checked' : ''}> 두 PDF 같이 움직이기</label>
        <button class="pri" id="rcapply">Apply Highlight</button><button id="rcnone">Highlight 모두 끄기</button>
        <button id="rcpdf" title="HL 체크된 변경만 노란 표시로">⇩ 선택한 변경만 Mark-up PDF</button><button id="rcxl" title="Revision 이 둘 이상인 모든 Tag 의 바뀐 칸">⇩ Revision 비교 Excel</button>${RC.mock ? `<div class="banner" style="margin:0">${MOCK} 같은 PDF 의 값 몇 개를 바꿔 만든 <b>예시</b>입니다 — 실제 비교가 아닙니다.</div><button id="rcreal">예시 끄기</button>` : ''}</div></div>
    <div class="rc-bottom"><div class="hd"><b>Changes Summary</b>${RC.mock ? '' : `<select id="rctag">${multi.map(t => `<option value="${t.id}" ${t.id === RC.tag.id ? 'selected' : ''}>${esc(t.tag_key)}</option>`).join('')}</select>
      Prev <select id="rcp">${RC.revs.map(r => `<option value="${r.id}" ${r.id === prev.id ? 'selected' : ''}>Rev.${esc(r.rev)}</option>`).join('')}</select>
      New <select id="rcn">${RC.revs.map(r => `<option value="${r.id}" ${r.id === cur.id ? 'selected' : ''}>Rev.${esc(r.rev)}</option>`).join('')}</select>`}
      <span class="soft">${['Modified', 'Added', 'Deleted'].map(k => `${k} ${rows.filter(r => r.change === k).length}`).join(' · ')}</span></div>
      <div class="bd"><table class="t"><thead><tr><th style="width:30px">HL</th><th>Changed Field</th><th>Previous Value (Rev.${esc(prev.rev)})</th><th>New Value (Rev.${esc(cur.rev)})</th><th>Change Type</th><th>PDF Page</th><th>Review Status</th></tr></thead><tbody id="rcrows"></tbody></table></div></div></div>`;
  const L = new Viewer($('#rcL'), { extra: `<span class="lbl">Rev.${esc(prev.rev)}</span>` }), R = new Viewer($('#rcR'), { extra: `<span class="lbl">Rev.${esc(cur.rev)}</span>` });
  await Promise.all([L.load(prev.document_id, prev.pages), R.load(cur.document_id, cur.pages)]);
  RC.L = L; RC.R = R;
  let syncing = false;                                 // scroll · zoom of one side follows the other (proportionally — page counts may differ)
  const follow = (a, b) => { if (!RC.sync || syncing) return; syncing = true;
    b.stage.scrollTop = a.stage.scrollTop * ((b.stage.scrollHeight - b.stage.clientHeight) / Math.max(1, a.stage.scrollHeight - a.stage.clientHeight));
    b.stage.scrollLeft = a.stage.scrollLeft; syncing = false; };
  L.opts.onScroll = () => follow(L, R); R.opts.onScroll = () => follow(R, L);
  for (const [a, b2] of [[L, R], [R, L]]) { const z = a.setZoom.bind(a); a.setZoom = v => { z(v); if (RC.sync && Math.abs(b2.zoom - a.zoom) > 1e-6) b2.setZoom(a.zoom); }; }
  $('#rcsync').onchange = e => { RC.sync = e.target.checked; LS.set('rcsync', RC.sync); };
  const draw = () => {
    const vis = rows.map((r, i) => [r, i]).filter(([r]) => RC.flt[r.change]);
    $('#rcrows').innerHTML = vis.map(([r, i]) => `<tr class="click" data-i="${i}"><td><input type="checkbox" data-h="${i}" ${RC.hl.has(i) ? 'checked' : ''} aria-label="highlight"></td><td>${esc(r.display)}</td>
      <td class="${r.change !== 'Unchanged' ? 'chg-old' : ''}">${esc(r.previous)}</td><td>${r.change !== 'Unchanged' ? `<b>${esc(r.new)}</b>` : esc(r.new)}</td><td>${pill(r.change)}</td><td>${r.new_page || r.prev_page || ''}</td>
      <td>${pill(S.sum.tags.find(t => t.id === cur.id)?.review_status || 'Not Reviewed')}</td></tr>`).join('') || '<tr><td colspan="7" class="empty">조건에 맞는 칸이 없습니다</td></tr>';
    const mk = side => rows.map((r, i) => [r, i]).filter(([r, i]) => RC.hl.has(i) && RC.flt[r.change] && r.change !== 'Unchanged')
      .map(([r]) => ({ cat: 'revision', page: side === 'L' ? r.prev_page : r.new_page, bbox: side === 'L' ? r.prev_bbox : r.new_bbox, title: `${r.change}: ${r.display}`, text: `${r.previous} → ${r.new}` })).filter(o => o.bbox);
    L.setOverlays(mk('L')); R.setOverlays(mk('R'));
  };
  draw();
  $('#rcrows').onclick = e => {
    const h = e.target.closest('[data-h]'); if (h) { h.checked ? RC.hl.add(+h.dataset.h) : RC.hl.delete(+h.dataset.h); draw(); return; }
    const tr = e.target.closest('tr[data-i]'); if (!tr) return; const r = rows[+tr.dataset.i];
    if (r.prev_bbox) L.focus(r.prev_page, r.prev_bbox, r.display); if (r.new_bbox) R.focus(r.new_page, r.new_bbox, r.display);
  };
  $$('.rc-opts [data-f]').forEach(c => c.onchange = () => { RC.flt[c.dataset.f] = c.checked; LS.set('rcflt', RC.flt); draw(); });
  $('#rcapply').onclick = () => { rows.forEach((r, i) => { if (RC.flt[r.change] && r.change !== 'Unchanged') RC.hl.add(i); }); draw(); };
  $('#rcnone').onclick = () => { RC.hl.clear(); draw(); };
  $('#rcpdf').onclick = async () => {
    const items = R.ovs.filter(o => o.cat === 'revision').map(o => ({ ...o, category: 'revision', title: `Revision Change · ${o.title}` }));
    try { await download('/markup.pdf', 'POST', { document_id: cur.document_id, pages: cur.pages, items }); toast(`노란 표시 ${items.length}개 PDF`); } catch (e) { toast(e.message, 1); }
  };
  $('#rcreal') && ($('#rcreal').onclick = () => { RC.mock = false; RC.hl.clear(); renderRev(); });
  $('#rcxl').onclick = () => download(`/projects/${S.pid}/revisions.xlsx`).then(r => toast(`Revision 비교 Excel ${r.headers.get('X-Count')}행`)).catch(e => toast(e.message, 1));
  if (!RC.mock) {
    $('#rctag').onchange = e => { S.dsId = +e.target.value; RC.prevId = RC.newId = null; RC.hl.clear(); renderRev(); };
    $('#rcp').onchange = e => { RC.prevId = +e.target.value; RC.hl.clear(); renderRev(); };
    $('#rcn').onchange = e => { RC.newId = +e.target.value; RC.hl.clear(); renderRev(); };
  }
}

/* ── 6 · 7. Process Data / PMS (Phase 3 · 4 — MOCK reference values) ──── */
async function allFields(limit = 60) {
  return Promise.all(S.sum.tags.slice(0, limit).map(t => api('GET', `/datasheets/${t.id}`)));
}
const PROCCOLS = { tag: r => r.tag, item: r => r.item, ds: r => r.ds ? `${r.ds} ${r.ds_unit || ''}` : '', pd: r => r.pd ? `${r.pd} ${r.pd_unit || ''}` : '', result: r => r.result, reason: r => r.reason, pdp: r => r.pd_page, dsp: r => r.ds_page };
const PMSCOLS = { tag: r => r.tag, area: r => r.area || '?', class: r => r.class, item: r => r.item, req: r => r.req, ds: r => r.ds, result: r => r.result, reason: r => r.reason, pmsp: r => r.pms_page, dsp: r => r.ds_page };
const xfHeads = (key, heads) => heads.map(([t, k]) => `<th>${t} ${xfBtn(key, k)}</th>`).join('');
async function renderProc() {
  const el = $('#v-proc'); el.classList.add('full');
  if (!S.sum.has_process) {
    el.classList.remove('full');
    el.innerHTML = `<div class="vh"><h2>Process Data Verification</h2>${pill('NotEvaluated', 'Not Evaluated')}</div><div class="card"><div class="empty">Process Data PDF 가 없습니다 — Document Management 에 올리면 Tag 별로 공정 값을 비교합니다.<span class="hint soft"><br>공정 항목만(유체 · 상 · 압력 · 온도 · 차압 · 유량 · 작동 시간 · Fail 위치 · 기밀 · Line/P&amp;ID). Valve Size · Rating · Material · Piping Class 는 비교하지 않음. 단위 · 기준이 불명확하면 Review Required.</span></div></div>`;
    return;
  }
  if (!S.procRows) { el.innerHTML = '<div class="empty">Process Data 와 비교하는 중…</div>'; const r = await api('GET', `/projects/${S.pid}/process`); S.procRows = r.rows; S.procRows.forEach((x, n) => { x._n = n; }); S.procDoc = r.process_doc; }
  const P = S.procF ||= { res: '', q: '', item: '' };
  const q = P.q.toUpperCase().replace(/[^0-9A-Z]/g, '');
  const L = xfApply('proc', S.procRows.filter(r => (!P.res || r.result === P.res) && (!P.item || r.item === P.item) && (!q || r.tag.includes(q))), PROCCOLS, () => renderProc());
  const cnt = x => S.procRows.filter(r => r.result === x).length, tagsIn = new Set(S.procRows.filter(r => r.key !== 'tag').map(r => r.tag)).size;
  const RES = ['Mismatch', 'Review Required', 'Match', 'Referenced', 'Not in Process Data', 'Datasheet Blank'];
  const tip = { Mismatch: 'Datasheet 값이 Process Data 와 다름 — 설계사에게 지적', 'Review Required': '단위 · 기준 · 표현이 달라 자동으로 못 정함 — 엔지니어 확인 (불일치 아님)', Match: '같음 (1 % 허용)',
    Referenced: 'Datasheet 가 Process DS 를 참조해 비워 둔 칸 — Process Data 값을 보여 줌', 'Not in Process Data': 'Process Data 에 값이 없거나 Tag 가 없음', 'Datasheet Blank': 'Datasheet 가 비었고 참조도 없음 (누락 지적과 같음)' };
  el.innerHTML = `<div style="display:flex;flex-direction:column;width:100%;height:100%"><div style="padding:10px 14px 6px;background:var(--bg)"><div class="vh" style="margin:0">
      <h2>Process Data Verification</h2><span class="soft">${esc(S.procDoc?.filename || '')} · ${esc(S.procDoc?.doc_no || '')} · Process Data Tag ${S.procDoc?.tags ?? '?'}개 · Datasheet 와 연결 ${tagsIn}/${S.sum.kpi.tags}</span>
      ${RES.map(x => `<button data-pr="${x}" class="${P.res === x ? 'pri' : ''}" title="${tip[x]}">${pill(x.replace(/[^A-Za-z]/g, ''), x)} ${cnt(x)}</button>`).join('')}
      <select id="pi"><option value="">All Items</option>${[...new Set(S.procRows.map(r => r.item))].map(x => `<option ${x === P.item ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select>
      <input type="search" id="pq" placeholder="Tag 검색" value="${esc(P.q)}" style="width:140px"><span class="soft">${L.length}행</span></div>
      <div class="soft hint" style="margin-top:4px">공정 항목만 비교 (Valve Size · Rating · Material · Piping Class 제외) · 압력은 게이지/절대 기준이 양쪽에 적혀 있을 때만 · 단위가 불명확하면 Review Required · Match 허용 오차 1 %</div></div>
    <div class="vscroll" style="flex:1;min-height:0;overflow:auto;padding:0 14px"><table class="t" data-xfdata="1"><colgroup>${[130, 170, 160, 160, 150, 420, 72, 72].map(w => `<col style="width:${w}px">`).join('')}</colgroup><thead><tr>${xfHeads('proc', [['Tag Number', 'tag'], ['Item', 'item'], ['Datasheet Value', 'ds'], ['Process Data', 'pd'], ['Result', 'result'], ['Reason', 'reason'], ['PD p.', 'pdp'], ['DS p.', 'dsp']])}</tr></thead><tbody id="pdtb"></tbody></table></div>
    <div class="hsplit" title="끌어서 아래 미리보기 높이 조절"></div><div class="pvbot" style="height:${LS.get('pvh_' + 'pdL', 42)}%;min-height:120px;display:flex;position:relative"><div class="rc-side" id="pdL" style="flex:0 0 ${LS.get('pvw_' + 'pdL', 50)}%"></div><div class="vsplit" title="끌어서 두 미리보기 폭 조절"></div><div class="rc-side" id="pdR"></div>
      <div class="pmhint" id="pdhint">행을 누르면 Datasheet 칸 ↔ Process Data 칸이 나란히 열립니다.<span class="hint soft"> Review Required · Referenced · Not in Process Data 는 불일치가 아니라 확인할 것.</span></div></div></div>`;
  chunkRows($('#pdtb'), L.map(r => () => `<tr class="click" data-n="${r._n}"><td><b>${esc(r.tag)}</b></td><td>${esc(r.item)}</td><td>${esc(r.ds || '—')} <small class="soft">${esc(r.ds_unit)}</small></td><td>${esc(r.pd || '—')} <small class="soft">${esc(r.pd_unit)}</small></td>
        <td>${pill(r.result.replace(/[^A-Za-z]/g, ''), r.result)}</td><td class="soft" title="${esc(r.reason)}">${esc(r.reason)}</td><td>${r.pd_page || '—'}</td><td>${r.ds_page || ''}</td></tr>`), 80, '<tr><td colspan="8" class="empty">없음</td></tr>');   // valve29: every row (was capped)
  const L1 = new Viewer($('#pdL'), { extra: '<span class="lbl">Datasheet</span>' }), R1 = new Viewer($('#pdR'), { extra: '<span class="lbl">Process Data</span>' });
  splitPanes(el, 'pdL', [L1, R1]);
  $$('[data-pr]', el).forEach(b => b.onclick = () => { P.res = P.res === b.dataset.pr ? '' : b.dataset.pr; renderProc(); });
  $('#pi').onchange = e => { P.item = e.target.value; renderProc(); };
  $('#pq').oninput = e => { P.q = e.target.value; clearTimeout(P.t); P.t = setTimeout(() => { renderProc().then(() => { const f = $('#pq'); f.focus(); f.setSelectionRange(f.value.length, f.value.length); }); }, 300); };
  $('#pdtb').onclick = async e => { const tr = e.target.closest('tr[data-n]'); if (!tr) return;   // valve29: rows arrive in batches — one handler
    $$('tr.sel', el).forEach(x => x.classList.remove('sel')); tr.classList.add('sel'); $('#pdhint')?.remove();
    const r = S.procRows[+tr.dataset.n]; link({ t: 'field', id: r.ds_id, key: r.ds_key || r.key }); const pages = (await api('GET', `/datasheets/${r.ds_id}`)).pages;
    await L1.load(r.document_id, pages); L1.fit();
    L1.setOverlays(r.ds_bbox ? [{ cat: r.result === 'Mismatch' ? 'process' : 'comment', page: r.ds_page, bbox: r.ds_bbox, title: r.item }] : []);
    if (r.ds_bbox) L1.focus(r.ds_page, r.ds_bbox, r.item); else L1.goPage(r.ds_page || pages[0]);
    if (r.pd_page) { await R1.load(S.procDoc.id, [r.pd_page]); R1.fit(); R1.setOverlays([]); if (r.pd_bbox) R1.focus(r.pd_page, r.pd_bbox, 'Process Data'); }
  };
}
async function renderPms() {
  const el = $('#v-pms'); el.classList.add('full');
  if (!S.sum.has_pms) { el.classList.remove('full'); el.innerHTML = `<div class="vh"><h2>PMS Compliance</h2></div><div class="card"><div class="empty">PMS PDF 가 없습니다 — Document Management 에 올리면 모든 Tag 를 Piping Class 와 비교합니다.</div></div>`; return; }
  if (!S.pmsRows) { el.innerHTML = '<div class="empty">PMS 와 비교하는 중…</div>'; const r = await api('GET', `/projects/${S.pid}/pms`); S.pmsRows = r.rows; S.pmsRows.forEach((x, n) => { x._n = n; }); S.pmsDoc = r.pms_doc; }
  const P = S.pmsF ||= { res: '', q: '', item: '' };
  const q = P.q.toUpperCase().replace(/[^0-9A-Z]/g, '');
  const L = xfApply('pms', S.pmsRows.filter(r => (!P.res || r.result === P.res) && (!P.item || r.item === P.item) && (!q || r.tag.includes(q))), PMSCOLS, () => renderPms());
  const cnt = x => S.pmsRows.filter(r => r.result === x).length;
  el.innerHTML = `<div style="display:flex;flex-direction:column;width:100%;height:100%"><div style="padding:10px 14px 6px;background:var(--bg)"><div class="vh" style="margin:0">
      <h2>PMS Compliance</h2><span class="soft">${esc(S.pmsDoc?.filename || '')}</span>
      ${['Non-Compliant', 'Review Required', 'Not Defined in PMS', 'Compliant'].map(x => `<button data-pr="${x}" class="${P.res === x ? 'pri' : ''}" title="${{ 'Non-Compliant': '요구 재질 · 등급과 다름 — 설계사에게 지적', 'Review Required': '자동으로 못 정함 — 엔지니어 확인 (부적합 아님)', 'Not Defined in PMS': 'PMS 에 그 항목이 없음 (부적합 아님)', Compliant: '요구 사항 충족' }[x]}">${pill(x.replace(/[^A-Za-z]/g, ''), { 'Non-Compliant': '✖ ', 'Review Required': '? ', 'Not Defined in PMS': '– ', Compliant: '✔ ' }[x] + x)} ${cnt(x)}</button>`).join('')}
      <select id="pi"><option value="">All Items</option>${[...new Set(S.pmsRows.map(r => r.item))].map(x => `<option ${x === P.item ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select>
      <input type="search" id="pq" placeholder="Tag 검색" value="${esc(P.q)}" style="width:140px"><span class="soft">${L.length}행 · 재질은 규격·등급으로 비교 (표기 차이 무시)</span></div></div>
    <div class="vscroll" style="flex:1;min-height:0;overflow:auto;padding:0 14px"><table class="t" data-xfdata="1"><colgroup>${[130, 80, 160, 150, 220, 220, 150, 380, 110, 110].map(w => `<col style="width:${w}px">`).join('')}</colgroup><thead><tr>${xfHeads('pms', [['Tag Number', 'tag'], ['Area', 'area'], ['Piping Material Class', 'class'], ['Item', 'item'], ['PMS Requirement', 'req'], ['Datasheet Value', 'ds'], ['Compliance Result', 'result'], ['Reason', 'reason'], ['PMS Ref. Page', 'pmsp'], ['DS Ref. Page', 'dsp']])}</tr></thead><tbody id="pmtb"></tbody></table></div>
    <div class="hsplit" title="끌어서 아래 미리보기 높이 조절"></div><div class="pvbot" style="height:${LS.get('pvh_' + 'pmL', 42)}%;min-height:120px;display:flex;position:relative"><div class="rc-side" id="pmL" style="flex:0 0 ${LS.get('pvw_' + 'pmL', 50)}%"></div><div class="vsplit" title="끌어서 두 미리보기 폭 조절"></div><div class="rc-side" id="pmR"></div>
      <div class="pmhint" id="pmhint">행을 누르면 Datasheet 칸 ↔ PMS 근거 쪽이 나란히 열립니다.<span class="hint soft"> Review Required · Not Defined 는 부적합이 아니라 확인할 것.</span></div></div></div>`;
  chunkRows($('#pmtb'), L.map((r, n) => () => `<tr class="click" data-n="${r._n}"><td><b>${esc(r.tag)}</b></td><td>${esc(r.area || '?')}</td><td>${esc(r.class)}</td><td>${esc(r.item)}</td><td title="${esc(r.req)}">${esc(r.req)}</td><td title="${esc(r.ds)}">${esc(r.ds)}</td>
        <td>${pill(r.result.replace(/[^A-Za-z]/g, ''), r.result)}</td><td class="soft" title="${esc(r.reason)}">${esc(r.reason)}</td><td>${r.pms_page || '—'}</td><td>${r.ds_page || ''}</td></tr>`), 80, '<tr><td colspan="10" class="empty">없음</td></tr>');   // valve29: every row (was capped)
  const L1 = new Viewer($('#pmL'), { extra: '<span class="lbl">Datasheet</span>' }), R1 = new Viewer($('#pmR'), { extra: '<span class="lbl">PMS</span>' });
  splitPanes(el, 'pmL', [L1, R1]);
  $$('[data-pr]', el).forEach(b => b.onclick = () => { P.res = P.res === b.dataset.pr ? '' : b.dataset.pr; renderPms(); });
  $('#pi').onchange = e => { P.item = e.target.value; renderPms(); };
  $('#pq').oninput = e => { P.q = e.target.value; clearTimeout(P.t); P.t = setTimeout(() => { renderPms().then(() => { const f = $('#pq'); f.focus(); f.setSelectionRange(f.value.length, f.value.length); }); }, 300); };
  $('#pmtb').onclick = async e => { const tr = e.target.closest('tr[data-n]'); if (!tr) return;   // valve29: rows arrive in batches — one handler
    $$('tr.sel', el).forEach(x => x.classList.remove('sel')); tr.classList.add('sel'); $('#pmhint')?.remove();
    const r = S.pmsRows[+tr.dataset.n]; link({ t: 'field', id: r.ds_id, key: r.key }); const pages = (await api('GET', `/datasheets/${r.ds_id}`)).pages;
    await L1.load(r.document_id, pages); L1.fit();
    L1.setOverlays([{ cat: r.result === 'Non-Compliant' ? 'error' : r.result === 'Compliant' ? 'comment' : 'missing', page: r.ds_page, bbox: r.ds_bbox, title: r.item }]);
    if (r.ds_bbox) L1.focus(r.ds_page, r.ds_bbox, r.item);
    if (r.pms_page) { await R1.load(S.pmsDoc.id, [r.pms_page]); R1.fit(); R1.setOverlays([]); if (r.pms_bbox) R1.focus(r.pms_page, r.pms_bbox, 'PMS'); }
  };
}
/* ── 8. Reports & Export · 9. Settings ─────────────────────────────────── */
async function renderExport() {
  const el = $('#v-export'); el.classList.remove('full');
  const vl = S.sum.documents.find(d => d.kind === 'valvelist' && d.status === 'done'), k = S.sum.kpi, pname = S.sum.project.name;
  const issN = ['data_errors', 'data_missing', 'open_items', 'pms_noncompliant', 'pms_review', 'revision_changes'].reduce((a, x) => a + (k[x] || 0), 0);
  el.innerHTML = `<div class="vh"><h2>Reports &amp; Export</h2><span class="soft">${esc(pname)} · Tag ${k.tags} · 최신 Revision 기준 · 원본 파일은 바꾸지 않습니다</span><span class="sp"></span><span id="exstat" class="exstat"></span></div>
    <div class="exgrid">
    <div class="card exg"><h3>① Valve List <small>Excel</small></h3><p>${vl ? `회사 양식 <b>${esc(vl.filename)}</b> + Summary · All Valves` : '회사 양식 없음 — 도구 양식으로'}</p>
      <ul class="soft hint"><li>같은 Tag: 바뀐 칸만 덮고 노랑 + 'Previous:' 메모 · 새 Tag 는 시트 끝에 추가</li><li>Vendor 행(AMPO · OMS · NEWAY …)은 지우고 Tag 마다 Requirement 한 줄</li><li>모든 칸에 출처 메모 · 도구로 여는 링크 · 'Datasheet Notes' 시트</li></ul>
      <div class="exbtn"><button class="pri" data-ex="vl">⇩ Valve List Excel</button><button id="ex1p">미리 보기 (바뀔 칸)</button></div><div id="ex1r"></div></div>
    <div class="card exg"><h3>② Issue List <small>Excel · 설계사 전달</small></h3><p>설계사에게 보낼 지적 목록 (Issue Type 선택 · Area/Unit 필터 · Summary)</p>
      <p class="soft hint">지금 지적 ${issN}건(Dismissed 제외). 종류 · 심각도로 걸러 내보내려면 Issue List 화면에서.</p>
      <div class="exbtn"><button class="pri" data-ex="iss">⇩ Issue List Excel</button><button data-go="list:issues">Issue List 화면에서 거르기</button></div></div>
    <div class="card exg"><h3>③ Mark-up PDF <small>인쇄용</small></h3><p>지적 상자 · Mark-up · 쪽 옆 코멘트 — 인쇄하면 화면 그대로</p>
      <p class="soft hint">색: <b style="color:var(--pms)">빨강</b> 오류/PMS · <b style="color:var(--proc)">주황</b> 누락/HOLD · <b style="color:#b38f00">노랑</b> Revision · <b style="color:var(--usr)">파랑</b> 검토자. 전체는 Tag 수에 따라 1분 안팎.</p>
      <div class="exbtn"><button class="pri" data-ex="pdf">⇩ Mark-up PDF (전체 Tag)</button><button data-go="review">한 Tag 만 → Datasheet Review</button><button data-go="rev">선택한 변경만 → Revision Comparison</button></div></div>
    <div class="card exg"><h3>④ CSV <small>데이터 · 이력</small></h3><p>추출 칸 전체 · 감사 기록 · Revision 비교.</p>
      <div class="exbtn"><button data-ex="csv">⇩ Extracted Fields CSV</button><button data-ex="audit">⇩ Audit Trail CSV</button><button data-ex="revx">⇩ Revision 비교 Excel</button></div></div>
    <div class="card exg"><h3>⑤ Review Feedback <small>개발 쪽으로</small></h3><p>검토 결과를 개발 쪽에 보내 규칙을 다듬습니다</p><p class="soft hint">Confirmed / Dismissed · 고친 값 · 직접 그린 표시. 판정 규칙은 이 파일을 읽지 않습니다. 고객 값이 들어 있으니 사내 경로로만.</p>
      <div class="exbtn"><button data-ex="fb">⇩ Review Feedback (json)</button></div></div>
    <div class="card exg"><h3>분석할 때 자동으로 만든 파일</h3><div id="exl" class="soft">불러오는 중…</div></div></div>`;
  api('GET', `/projects/${S.pid}/exports`).then(r => { const row = f => `<div><a href="${f.url}" download>${esc(f.name)}</a> <span class="soft">${(f.size / 1024).toFixed(0)} KB · ${esc(f.at.replace('T', ' ').slice(5, 16))}</span></div>`;
    const L = r.files, more = L.length > 4;
    $('#exl').innerHTML = (L.slice(0, 4).map(row).join('') + (more ? `<details><summary class="soft">이전 파일 ${L.length - 4}개</summary>${L.slice(4).map(row).join('')}</details>` : '')) || '아직 없습니다 — Datasheet PDF 를 분석하면 Valve List · Issue List 가 함께 만들어집니다'; });
  $('#ex1p').onclick = async () => {
    $('#ex1r').innerHTML = '<p class="soft">계산 중…</p>';
    try { const p = await api('GET', `/projects/${S.pid}/valvelist/preview`), r = p.report;
      $('#ex1r').innerHTML = `<p>갱신 ${r.updated.length} · 신규 ${r.new.length} · 변화 없음 ${r.unchanged.length} · 데이터시트 없음 ${r.not_in_datasheets.length} · 바뀐 칸 <b>${r.changes.length}</b> · 목록 값 유지 ${r.kept.length}</p>
        <div style="max-height:280px;overflow:auto"><table class="t"><thead><tr><th>Tag</th><th>Column</th><th>Previous</th><th>New</th></tr></thead><tbody>
        ${r.changes.slice(0, 400).map(c => `<tr><td>${esc(c.tag)}</td><td>${esc(c.column)}</td><td class="chg-old">${esc(c.previous.slice(0, 80))}</td><td>${esc(String(c.new).slice(0, 80))}</td></tr>`).join('')}</tbody></table></div>`; }
    catch (e) { $('#ex1r').innerHTML = `<p class="soft" style="color:var(--bad)">미리 보기 실패: ${esc(e.message)}</p>`; }
  };
  const EX = {                                             // kind → [label, filename hint, scope lines, runner]
    vl: ['Valve List Excel', (vl ? vl.filename.replace(/\.xlsx?$/i, '') : 'Valve_List') + '_<날짜>.xlsx', [`Tag ${k.tags}개 (최신 Revision)`, '\'All Valves\' 시트 = 전체 Valve 한 줄씩 · Area · Site · Unit 필터', 'Vendor 행 삭제 · 바뀐 칸 노랑 · 밸브 종류 시트도 Area · Unit 열 + 필터'], () => download(`/projects/${S.pid}/valvelist.xlsx`)],
    iss: ['Issue List Excel', 'Issue_List_<날짜>.xlsx', [`지적 ${issN}건 · Dismissed 제외`, 'Area · Site · Unit 열 (Excel 필터로 North / South / Brownfield / W15 · Unit 별)', '시트: Issue List · Summary by Tag · Info'], t => download(`/projects/${S.pid}/issues.xlsx?types=${encodeURIComponent(t)}`)],
    pdf: ['Mark-up PDF (전체 Tag)', 'Markup_<프로젝트>_<날짜>.pdf', [`지적이 있는 Tag 만 (${S.sum.tags.filter(t => t.problems).length}개)`, '표지 · 쪽 옆 코멘트 · 마크업 고정 · Issue Summary 쪽 · 책갈피 · 1분 안팎'], t => download(`/projects/${S.pid}/markup.pdf?types=${encodeURIComponent(t)}${pdfq()}`)],
    csv: ['Extracted Fields CSV', 'extracted_fields.csv', [`Tag ${k.tags}개 모든 칸`], () => download(`/projects/${S.pid}/extracted.csv`)],
    revx: ['Revision 비교 Excel', 'Revision_Comparison_<날짜>.xlsx', [`Revision 이 둘 이상인 Tag ${k.revision_changes}개 · 바뀐 칸(Added · Deleted · Modified)`], () => download(`/projects/${S.pid}/revisions.xlsx`)],
    fb: ['Review Feedback (json)', 'valve_feedback_<프로젝트>_<날짜>.json', ['Confirmed / Dismissed · 고친 값 · 직접 그린 Error/Missing', '고객 값 포함 — 사내 경로로만'], () => download(`/projects/${S.pid}/feedback.json`)],
    audit: ['Audit Trail CSV', 'audit_trail.csv', ['감사 기록 최근 2,000줄'], async () => {
      const a = (await api('GET', `/projects/${S.pid}/audit`)).audit;
      const csv = '﻿' + [['When', 'Who', 'Tag', 'Rev', 'Action', 'Field', 'Before', 'After', 'Comment']].concat(a.map(x => [x.at, x.by, x.tag, x.rev, x.action, x.field_key, x.before, x.after, x.comment]))
        .map(r => r.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n');
      const u = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })), l = document.createElement('a'); l.href = u; l.download = 'audit_trail.csv'; l.click(); setTimeout(() => URL.revokeObjectURL(u), 3000);
      return { filename: 'audit_trail.csv' }; }],
  };
  const stat = (cls, msg) => { const x = $('#exstat'); if (x) { x.className = 'exstat ' + cls; x.innerHTML = msg; } };
  $$('[data-ex]', el).forEach(b => b.onclick = async () => {
    const [label, fn, scope, run0] = EX[b.dataset.ex];
    let run = run0;
    if (b.dataset.ex === 'iss' || b.dataset.ex === 'pdf') {          // contractor outputs: choose the issue types (replaces the confirm box)
      const t = await pickTypes(`${label} — 넣을 Issue Type`, { note: `${pname} · ${fn}` }); if (t == null) return;
      run = () => run0(t);
    }
    const ok = run !== run0 ? 1 : await modal(`${label} 만들기`, `<table class="t"><tbody><tr><td class="soft">프로젝트</td><td><b>${esc(pname)}</b></td></tr><tr><td class="soft">파일</td><td class="mono">${esc(fn)}</td></tr>
      ${scope.map(x => `<tr><td class="soft">범위</td><td>${esc(x)}</td></tr>`).join('')}</tbody></table>`, [['취소', 0], ['만들기', 1, 1]]);
    if (!ok) return;
    b.disabled = true; stat('busy', `⏳ ${esc(label)} 만드는 중…`);
    try { const r = await run(); stat('ok', `✔ ${esc(label)} 완료 — ${esc(r.filename || '')} <small class="soft">${new Date().toLocaleTimeString()}</small> · 내려받기 폴더를 확인하세요`); }
    catch (e) { stat('bad', `✖ ${esc(label)} 실패 — ${esc(e.message)} · 다시 시도하거나 서버 로그를 확인하세요`); }
    b.disabled = false;
  });
}
/* valve29 — Rule Performance: how engineers decided each rule's findings · decision log · rule change records.
   Statistics only: nothing here changes a rule. */
const RP = { rule: null, ch: null };
const pct = x => x == null ? '—' : Math.round(x * 100) + '%';
async function renderRules() {
  const el = $('#v-rules');
  el.innerHTML = '<div class="empty">불러오는 중…</div>';
  const [P, C] = await Promise.all([api('GET', `/projects/${S.pid}/rules/performance`), api('GET', `/projects/${S.pid}/rule-changes`)]);
  const st = P.settings, act = P.rules.filter(r => r.total || r.decided);
  const trend = r => P.months.map(m => { const c = r.trend?.[m] || {}; const n = Object.values(c).reduce((a, b) => a + b, 0);
    return `<span class="tr" title="${m}: ${Object.entries(c).map(([k, v]) => k + ' ' + v).join(' · ') || '결정 없음'}">${n || '·'}</span>`; }).join('');
  el.innerHTML = `<div class="vh"><h2>Rule Performance</h2><span class="soft">규칙별 지적 수와 엔지니어 결정 — 통계만, 규칙을 바꾸지 않습니다</span><span class="sp"></span>
      <label class="soft" title="도구 기본값: ${st.defaults.rp_min_n}건 · ${Math.round(st.defaults.rp_dismiss_rate * 100)}% — 프로젝트에 맞게 바꾸세요">검토 권고: 결정 ≥ <input id="rpn" type="number" min="1" value="${st.rp_min_n}" style="width:56px">건 이고 Dismissed ≥ <input id="rpr" type="number" min="1" max="100" value="${Math.round(st.rp_dismiss_rate * 100)}" style="width:52px">%</label><button id="rpsave">저장</button></div>
    <p class="soft hint">Dismissal Rate 는 오탐률이 아닙니다 — 프로젝트 예외 · Vendor 회신 · 중복 등으로도 Dismiss 합니다. '도구 원인' 은 사유 분류가 Incorrect Rule Logic / Incorrect Data Extraction 인 건수입니다.
      Confirmed 계열 = Confirmed + Modified + Resolved. Deferred 는 판정에 넣지 않습니다.</p>
    <div class="card" style="padding:0;overflow:auto"><table class="t rp"><thead><tr><th>Rule</th><th>내용</th><th>Ver.</th><th>출처</th><th>지적</th><th>Confirmed</th><th>Modified</th><th>Resolved</th><th>Dismissed</th><th>N/A</th><th>Deferred</th><th>미결정</th>
      <th>Confirm %</th><th>Dismiss %</th><th title="Incorrect Rule Logic + Incorrect Data Extraction">도구 원인</th><th title="${P.months.join(' · ')}">3개월</th><th></th></tr></thead><tbody>
      ${act.map(r => `<tr data-rule="${esc(r.rule)}" class="${RP.rule === r.rule ? 'on' : ''} ${r.review_suggested ? 'warn' : ''}"><td><b>${esc(r.rule)}</b></td><td>${esc(r.title)}</td><td>${esc(r.version)}</td><td class="soft">${r.source === 'General Engineering Check' ? 'General' : esc(r.source)}</td>
        <td>${r.total}</td><td>${r.confirmed || ''}</td><td>${r.modified || ''}</td><td>${r.resolved || ''}</td><td>${r.dismissed || ''}</td><td>${r.not_applicable || ''}</td><td>${r.deferred || ''}</td><td class="soft">${r.undecided || ''}</td>
        <td>${pct(r.confirmation_rate)}</td><td>${pct(r.dismissal_rate)}</td><td>${r.tool_cause || ''}</td><td class="trend">${trend(r)}</td><td>${r.review_suggested ? '<span class="pill p-bad">검토 권고</span>' : ''}</td></tr>`).join('') || '<tr><td colspan="17" class="empty">지적이 없습니다</td></tr>'}
      </tbody></table></div>
    <div id="rpdet"></div>
    <div class="card"><h3>Rule 변경 기록 <small class="soft">제안 → Regression · Simulation → 승인 → 적용 (코드는 개발 쪽이 바꾸고 버전을 올림)</small></h3>
      <table class="t"><thead><tr><th>#</th><th>Rule</th><th>버전</th><th>상태</th><th>이유</th><th>Regression</th><th>Simulation</th><th>승인</th><th></th></tr></thead><tbody>
      ${C.rows.map(c => `<tr><td>${c.id}</td><td><b>${esc(c.rule)}</b></td><td>${esc(c.from_ver)} → ${esc(c.to_ver)}</td><td>${pill(c.status === 'Approved' || c.status === 'Applied' ? 'Accepted' : c.status === 'Rejected' ? 'Rejected' : 'UnderReview', c.status)}</td>
        <td title="${esc(c.reason)}">${esc(c.reason.slice(0, 60))}</td><td>${c.regression ? '✓' : '—'}</td><td>${c.simulation ? '✓' : '—'}</td><td class="soft">${esc(c.approved_by || '')} ${esc((c.approved_at || '').slice(0, 10))}</td>
        <td><button data-rc="${c.id}">열기</button></td></tr>`).join('') || '<tr><td colspan="9" class="empty">변경 기록이 없습니다 — 규칙을 누르고 \'변경 제안\'</td></tr>'}</tbody></table></div>`;
  $('#rpsave').onclick = async () => { await api('PUT', `/projects/${S.pid}/settings`, { rp_min_n: $('#rpn').value, rp_dismiss_rate: (+$('#rpr').value || 0) / 100 }); toast('저장했습니다'); renderRules(); };
  $(".rp tbody").onclick = e => { const tr = e.target.closest('tr[data-rule]'); if (!tr) return; RP.rule = tr.dataset.rule; $$('.rp tr.on').forEach(x => x.classList.remove('on')); tr.classList.add('on'); ruleDetail(P.rules.find(r => r.rule === RP.rule)); };
  el.onclick = async e => { const b = e.target.closest('[data-rc]'); if (b) ruleChangeEdit(C.rows.find(c => c.id === +b.dataset.rc)); };
  if (RP.rule) ruleDetail(P.rules.find(r => r.rule === RP.rule));
}
async function ruleDetail(r) {
  const host = $('#rpdet'); if (!r || !host) return;
  const L = (await api('GET', `/projects/${S.pid}/rules/decisions?rule=${encodeURIComponent(r.rule)}&limit=200`)).rows;
  host.innerHTML = `<div class="card"><h3>${esc(r.rule)} · ${esc(r.title)} <small class="soft">v${esc(r.version)} · ${esc(r.source)}</small><span class="sp"></span><button id="rcnew" class="pri">변경 제안</button></h3>
    ${Object.keys(r.reasons || {}).length ? `<div class="soft">사유 분류: ${Object.entries(r.reasons).map(([k, n]) => `${esc(k)} <b>${n}</b>`).join(' · ')}</div>` : ''}
    <table class="t"><thead><tr><th>시각</th><th>Tag</th><th>Rev</th><th>결정</th><th>사유 분류</th><th>사유</th><th>결론</th><th>지적 (당시)</th><th>검토자</th></tr></thead><tbody>
    ${L.map(x => `<tr><td class="soft">${esc(x.at.replace('T', ' ').slice(0, 16))}</td><td>${esc(x.tag)}</td><td>${esc(x.rev)}</td><td>${esc(x.decision)}</td><td>${esc(x.reason_cat || '')}</td><td>${esc(x.reason || '')}</td><td>${esc(x.conclusion || '')}</td>
      <td title="${esc(x.finding)}">${esc((x.finding || '').slice(0, 70))}</td><td>${esc(x.by || '')}</td></tr>`).join('') || '<tr><td colspan="9" class="empty">이 규칙에 대한 결정이 아직 없습니다</td></tr>'}</tbody></table></div>`;
  $('#rcnew').onclick = () => ruleChangeEdit({ rule: r.rule, from_ver: r.version, status: '' });
}
async function ruleChangeEdit(c) {
  const ro = c.status === 'Applied' || c.status === 'Rejected';
  const f = (k, lab, rows = 3) => `<label class="dfl"><span>${lab}</span><textarea name="${k}" rows="${rows}" ${ro ? 'readonly' : ''}>${esc(c[k] || '')}</textarea></label>`;
  const nxt = { '': [['제안 저장', 'Proposed']], Proposed: [['Regression · Simulation 결과 저장 → Tested', 'Tested'], ['반려', 'Rejected']], Tested: [['승인', 'Approved'], ['반려', 'Rejected']], Approved: [['적용 표시 (코드 버전 확인)', 'Applied'], ['반려', 'Rejected']] }[c.status] || [];
  const r = await modal(`${c.rule} 변경 ${c.id ? '#' + c.id + ' · ' + c.status : '제안'}`, f('current_logic', '① 기존 규칙') + f('proposed_logic', '① 변경안') + f('reason', '② 변경 이유 (Rule Performance 근거)')
    + f('regression', '③ 실자료 Regression 결과 (valve_eval --check · snapshot_diff)') + f('simulation', '④ Simulation 결과 (valve_sim · mutate · rev_sim)')
    + '<p class="soft">⑤ 승인은 Tested 뒤에만 · ⑥ 적용 표시는 개발 쪽이 코드의 규칙 버전을 올린 뒤에만 됩니다. 이 기록이 규칙을 바꾸지는 않습니다.</p>',
    [['닫기', null]].concat(ro ? [] : [['저장만', 'save']].filter(() => !!c.id), nxt.map(([l, v]) => [l, v, 1])));
  if (!r) return;
  const body = Object.fromEntries($$('#mBody [name]').map(i => [i.name, i.value]));
  try {
    if (!c.id) await api('POST', `/projects/${S.pid}/rule-changes`, { rule: c.rule, ...body });
    else await api('PUT', `/rule-changes/${c.id}`, r === 'save' ? body : { ...body, status: r });
    toast('저장했습니다'); renderRules();
  } catch (e) { toast(e.message, 1); }
}
function renderSettings() {
  const el = $('#v-settings'); el.classList.remove('full');
  el.innerHTML = `<div class="vh"><h2>Settings</h2></div><div class="grid2"><div class="card"><h3>사용자 · 화면</h3>
      <p>이름: <b>${esc(USER || '(없음 — 대시보드에서 열면 로그인 이름이 자동으로 넘어옵니다)')}</b></p>
      ${Q.get('user') ? '' : `<p><input id="sname" placeholder="이름 (대시보드 밖에서 열 때만)" value="${esc(LS.get('user', ''))}"> <button id="ssave">저장</button></p>`}
      <p>코멘트 표시 언어 <select id="sclang">${LANGS.map(([k, l]) => `<option value="${k}" ${clang() === k ? 'selected' : ''}>${l}</option>`).join('')}</select></p>
      <p><label><input type="checkbox" id="sd3" ${document.body.classList.contains('d3') ? 'checked' : ''}> 입체 화면 (끄면 평면 — 아주 오래된 PC 에서 더 가볍게)</label></p>
      <p><button id="sreset">패널 너비 · 열 순서 · 확대 처음대로</button></p></div>
    <div class="card"><h3>단축키</h3><table class="t"><tbody>
      ${[['1 … 9', '왼쪽 메뉴 이동'], ['↑ / ↓ 또는 K / J', '(Review) 이전 / 다음 Tag · (목록) 행 이동 · Enter 열기'], ['PgUp / PgDn', '이전 / 다음 쪽'], ['+ / −', '확대 / 축소'], ['/', 'Tag 검색'], ['F', 'PDF 검색'],
        ['[ · ]', 'Tag List · Review Panel 접기/펼치기'], ['M', 'Mark-up 도구 줄 보이기/숨기기'], ['V R C E H L W P T N', 'Mark-up: 선택 · 사각형 · 구름 · 원 · 형광펜 · 선 · 화살표 · 펜 · 글상자 · 메모'],
        ['Ctrl+Z / Ctrl+Y', 'Mark-up 되돌리기 / 다시'], ['Delete · Enter', '선택한 Mark-up 지우기 · 의견 고치기'], ['Esc', '선택 도구 · 창 닫기']]
        .map(([k, v]) => `<tr><td><kbd>${k}</kbd></td><td>${v}</td></tr>`).join('')}</tbody></table></div>
    <div class="card hint"><h3>원칙</h3><ul class="soft"><li>Tag Number 가 모든 문서의 연결 키입니다 (공백 · 하이픈 무시: 00XV 921 = 00XV-921 = 00XV921).</li>
      <li>추출은 PDF 글자층과 표 괘선만으로 합니다 (OCR · AI 추정 없음). 짝이 불확실한 칸은 Review Required.</li>
      <li>원본 파일은 덮어쓰지 않고, 수정은 읽은 값 옆에 수정자 · 시각과 함께 남습니다.</li><li>최종 판정 · 승인은 사용자가 합니다.</li></ul></div>
    <div class="card" style="grid-column:1/-1"><h3>Tag Numbering — 이 프로젝트의 Tag 에서 배운 Area · Unit 별 규칙</h3><div id="tgl" class="soft">불러오는 중…</div></div>
    <div class="card" style="grid-column:1/-1"><h3>Ball Valve 지식 — 검토 규칙의 근거</h3><div id="kbl" class="soft">불러오는 중…</div></div>
    <div class="card"><h3>정보</h3><p>Ball Valve Datasheet Review · <b id="verinfo">…</b><br>서버: P&amp;ID 서버 /valve · 데이터: <span id="datadir">pid_data/valve/</span> (매일 첫 실행 때 backups/ 에 복사)</p>
      <p><button id="hchk">진단</button> <span id="hres" class="soft"></span></p></div></div>`;
  $('#hchk').onclick = async () => { const h = await api('GET', '/health'); const bad = Object.entries(h.checks).filter(([k, v]) => v && typeof v === 'object' && v.ok === false).map(([k]) => k);
    $('#hres').innerHTML = h.ok ? `<b style="color:var(--ok, #1aa35a)">정상</b> · DB ${h.checks.db?.datasheets ?? '?'} DS · 디스크 여유 ${h.checks.disk?.free_mb ?? '?'} MB · 백업 ${esc(h.checks.last_backup || '없음')} · 캐시 ${h.checks.review_cache}` : `<b style="color:var(--bad)">문제: ${esc(bad.join(', '))}</b> — 개발 쪽에 이 화면을 보내 주세요`; };
  api('GET', '/version').then(v => { $('#verinfo').textContent = v.version; $('#datadir').textContent = v.data_dir; }).catch(() => {});
  const rng = L => { const n = L.map(x => (x.match(/(\d+)\s*$/) || [])[1]).filter(Boolean); if (!n.length) return L.slice(0, 2).join(', ');
    const pre = L[0].replace(/\d+\s*$/, ''); const a = n.reduce((m, x) => +x < +m ? x : m), b = n.reduce((m, x) => +x > +m ? x : m);
    return a === b ? `${pre}${a}` : `${pre}${a} ~ ${b}${L.length > 2 ? ` (${L.length}+)` : ''}`; };
  if (S.pid) api('GET', `/projects/${S.pid}/tagging`).then(T => { $('#tgl').innerHTML = `<table class="t"><thead><tr><th>Area</th><th>Site</th><th>Unit</th><th>Tag 수</th><th>형식</th>
      <th>접두 = </th><th>기능 코드</th><th>번호</th><th>계열 → P&amp;ID</th><th>예</th></tr></thead><tbody>${T.groups.map(g => `<tr><td><b>${esc(g.area || '—')}</b></td><td>${esc(g.site)}</td><td>${esc(g.unit)}</td>
      <td>${g.n}</td><td class="mono">${esc(g.format)}</td><td>${esc(g.prefix_source || '(정해지지 않음)')}</td><td>${g.functions.map(([f, n]) => `${esc(f)} ${n}`).join(' · ')}</td>
      <td>${g.number_len ? `${g.number_len}자리${g.number_lead ? ` · '${esc(g.number_lead)}' 로 시작` : ''}` : '(일정하지 않음)'}${g.suffixes.length ? ` · 끝 ${esc(g.suffixes.join('/'))}` : ''} · 구분 ${g.sep === ' ' ? '공백' : g.sep === '-' ? "'-'" : '없음'}</td>
      <td style="font-size:11px">${Object.entries(g.series).map(([k, L]) => `<b>${esc(k)}</b> → ${esc(rng(L))}`).join('<br>') || '—'}</td><td class="mono" style="font-size:11px">${g.examples.map(esc).join('<br>')}</td></tr>`).join('')}</tbody></table>
      <p class="soft hint" style="margin:6px 0 0">Tag 절차서 없이 올린 데이터시트의 Tag 에서 배운 것입니다 (Area · Site · Unit 별, 80 % 이상이 따르는 규칙만). 규칙을 벗어난 Tag · 같은 Tag 중복 · 기능 코드와 Fail 동작 불일치(ESDV/SDV 는 보통 Fail Close, BDV 는 Fail Open)는 Expert 탭 'Tag 번호' 의견과 Issue 'Valve Review' 로 나옵니다.
      ${Object.keys(T.duplicates).length ? `<br><b style="color:var(--bad)">두 문서에 같은 Tag: ${Object.entries(T.duplicates).map(([t, d]) => `${esc(t)} (${esc(d.join(', '))})`).join(' · ')}</b>` : ''}</p>`; })
    .catch(() => { $('#tgl').textContent = '불러오지 못했습니다'; });
  api('GET', '/knowledge').then(L => { $('#kbl').innerHTML = L.map(k => `<details class="kb"><summary><b>${esc(k.title)}</b> <small class="soft">${esc(k.ref)}</small></summary>
    <p>${esc(k.text)}</p><p class="soft">데이터시트에서 볼 것: ${esc(k.check)}</p></details>`).join(''); }).catch(() => { $('#kbl').textContent = '불러오지 못했습니다'; });
  $('#ssave') && ($('#ssave').onclick = () => { LS.set('user', $('#sname').value.trim()); location.reload(); });
  $('#sclang').onchange = e => { LS.set('clang', e.target.value); toast('코멘트 표시 언어를 바꿨습니다'); };
  $('#sd3').onchange = e => { document.body.classList.toggle('d3', e.target.checked); LS.set('flat', !e.target.checked); };
  $('#sreset').onclick = () => { ['wbw', 'wbpx', 'wbc', 'gorder', 'gw', 'zoom', 'mkbar', 'vpart', 'rcsync', 'wtab'].forEach(k => LS.set(k, null)); toast('처음대로 — 화면을 다시 엽니다'); setTimeout(() => location.reload(), 600); };
}
const RENDER = { dash: renderDash, docs: renderDocs, list: renderList, review: renderReview, rev: renderRev, proc: renderProc, pms: renderPms, rules: renderRules, export: renderExport, settings: renderSettings };
for (const k of Object.keys(RENDER)) { const f = RENDER[k]; RENDER[k] = () => { if (!S.sum) return; Promise.resolve(f()).catch(e => { console.error(e); toast(e.message, 1); }); }; }

/* ── keyboard ─────────────────────────────────────────────────────────── */
addEventListener('keydown', e => {
  if (e.key === 'Escape') { $('#modal').hidden = true; W.viewer?.setTool('select'); return; }
  if (e.target.closest?.('input, textarea, select') || !$('#modal').hidden || e.altKey) return;
  if (POP === 'pdf' && !e.ctrlKey && !e.metaKey && ['j', 'k', 'ArrowDown', 'ArrowUp'].includes(e.key)) {   // the PDF window steps the main window's list
    e.preventDefault(); link({ t: 'nav', d: e.key === 'j' || e.key === 'ArrowDown' ? 1 : -1 }); return; }
  if (S.view === 'review' && W.viewer && (e.ctrlKey || e.metaKey)) {
    const k = e.key.toLowerCase();
    if (k === 'z' && !e.shiftKey) { e.preventDefault(); markCmd('undo'); } else if (k === 'y' || (k === 'z' && e.shiftKey)) { e.preventDefault(); markCmd('redo'); }
    return;
  }
  if (e.ctrlKey || e.metaKey) return;
  const MKKEY = { v: 'select', r: 'rect', c: 'cloud', e: 'ellipse', h: 'highlight', u: 'underline', s: 'strike', g: 'squiggle', l: 'line', w: 'arrow', p: 'pen', t: 'text', n: 'note', i: 'stamp', x: 'eraser', y: 'typewriter', b: 'callout', o: 'polyline', q: 'polygon', a: 'rect' };
  if (S.view === 'review' && W.viewer && (e.key === '[' || e.key === ']')) { togglePanel(e.key === '[' ? 'l' : 'r'); return; }
  if (S.view === 'review' && W.viewer && e.key === 'm') { W.viewer.showMkbar(!LS.get('mkbar', 1)); return; }
  if (S.view === 'review' && W.viewer && MKKEY[e.key]) { W.viewer.showMkbar(true); W.viewer.setTool(MKKEY[e.key]); return; }
  if (S.view === 'review' && W.viewer && W.selCm && (e.key === 'Delete' || e.key === 'Backspace')) { e.preventDefault(); markCmd('del'); return; }
  if (S.view === 'review' && W.viewer && W.selCm && e.key === 'Enter') { e.preventDefault(); markCmd('edit'); return; }
  if (/^[1-9]$/.test(e.key)) { go(VIEWS[+e.key - 1]); return; }
  if (S.view === 'list' && (e.key === 'ArrowDown' || e.key === 'ArrowUp' || e.key === 'Enter')) {   // Valve List · Issue List rows
    const trs = $$('#v-list .xg tbody tr[data-id], #v-list .xg tbody tr[data-i]'); if (!trs.length) return;
    const cur = trs.findIndex(t => t.classList.contains('sel'));
    if (e.key === 'Enter') { if (cur >= 0) { const t = trs[cur]; openDs(+(t.dataset.id || t.dataset.i.split('|')[0])); } return; }
    e.preventDefault(); const nx = trs[Math.max(0, Math.min(trs.length - 1, (cur < 0 ? (e.key === 'ArrowDown' ? -1 : 0) : cur) + (e.key === 'ArrowDown' ? 1 : -1)))];
    nx.scrollIntoView({ block: 'nearest' }); nx.click(); return;
  }
  if (S.view !== 'review' || !W.viewer) return;
  const list = W.list || [], i = list.findIndex(t => t.id === S.dsId);
  if (e.key === 'ArrowDown' || e.key === 'j') { e.preventDefault(); stepTag(1); }
  else if (e.key === 'ArrowUp' || e.key === 'k') { e.preventDefault(); stepTag(-1); }
  else if (e.key === 'PageDown') { e.preventDefault(); W.viewer.step(1); }
  else if (e.key === 'PageUp') { e.preventDefault(); W.viewer.step(-1); }
  else if (e.key === '+' || e.key === '=') W.viewer.setZoom(W.viewer.zoom * 1.2);
  else if (e.key === '-') W.viewer.setZoom(W.viewer.zoom / 1.2);
  else if (e.key === '/') { e.preventDefault(); $('#wq').focus(); }
  else if (e.key === 'f') { e.preventDefault(); $('#wview .q').focus(); }
});

/* valve29 — the engineer edits / supplements the tool's comment (decision and status unchanged; the tool's text is kept) */
async function editIssueText(dsId, i, after) {
  const orig = i.original_description || i.description, origExp = i.original_expected ?? i.expected ?? '';
  const r = await modal(`코멘트 고치기 · 보완 — ${i.type} · ${i.field}`, `${i.edited ? `<p class="soft">도구 원문: ${esc(orig)}${origExp ? ` · Required: ${esc(origExp)}` : ''}</p>` : ''}
    <label class="dfl grow"><span>설계사에게 가는 코멘트</span><textarea name="text" rows="4">${esc(i.description || '')}</textarea></label>
    <label class="dfl"><span>Required / Expected</span><input name="expected" value="${esc(i.expected || '')}"></label>
    <p class="soft hint">고친 문구가 Issue List Excel · Mark-up PDF 에 나갑니다. 결정(Confirmed 등)은 그대로입니다. 도구 원문은 기록에 남습니다.</p>`,
    [['취소', null], ...(i.edited ? [['도구 원문으로', 'reset']] : []), ['저장', 'form', 1]], 'edit');
  if (!r) return;
  const body = r === 'reset' ? { text: '', expected: '' } : { text: r.text.trim() === orig.trim() ? '' : r.text, expected: (r.expected || '').trim() === (origExp || '').trim() ? '' : r.expected };
  try { await api('PUT', `/datasheets/${dsId}/issues-text/${encodeURIComponent(i.ikey)}`, body); toast(r === 'reset' ? '도구 원문으로 되돌렸습니다' : '코멘트를 고쳤습니다'); after && after(); }
  catch (e) { toast(e.message, 1); }
}
/* valve29 — "where does it disagree": the datasheet cell beside the reference page (PMS · Process Data · previous revision · other cell) */
function refDocOf(d, ev) {
  const doc = ev.doc || '';
  if (doc.startsWith('PMS')) return d.pms_doc ? { ...d.pms_doc, what: 'PMS', pages: [ev.page] } : null;
  if (doc.startsWith('Process Data')) return d.process_doc ? { ...d.process_doc, what: 'Process Data', pages: [ev.page] } : null;
  if (doc === 'Previous revision') { const rv = d.revisions || [], k = rv.findIndex(r => r.id === d.id); return k > 0 ? { prevDs: rv[k - 1].id, what: `Rev.${rv[k - 1].rev}`, pages: null } : null; }
  if (doc === 'Datasheet') return { id: d.document_id, filename: d.filename, what: 'Datasheet', pages: d.pages };
  return null;
}
async function renderCompare(host, d, i, opts = {}) {
  const evs = (i.evidence || []).filter(e => e && e.page && refDocOf(d, e));
  const sel = Math.min(opts.ev || 0, Math.max(0, evs.length - 1)), ev = evs[sel];
  const ref = ev ? refDocOf(d, ev) : null;
  const vh = x => x ? `<span class="soft">${esc(x)}</span>` : '';
  host.innerHTML = `<div class="cmp"><div class="cmph">
      <div class="cmpt"><b>${esc(d.tag)}</b> · ${esc(i.type)} · ${esc(i.field)} ${i.check ? vh('[' + i.check + ']') : ''}<span class="sp"></span>${opts.pop ? '' : '<button data-cmppop title="새 창으로 — 이 창과 연동">⧉ 새 창</button>'}</div>
      <table class="t"><tr><th style="width:110px"></th><th>값</th><th>문서 · 쪽</th></tr>
        <tr><td><b>Datasheet</b></td><td><b>${esc(i.value || '(blank)')}</b></td><td>${esc(d.filename || '')} · Doc. ${esc(d.doc_no)} · Rev.${esc(d.rev)} · p.${i.page ?? '—'}</td></tr>
        ${evs.map((e, k) => { const r = refDocOf(d, e); return `<tr class="${k === sel ? 'on' : ''} click" data-cev="${k}"><td><b>${esc(r.what)}</b></td><td><b>${esc(String(e.text || '').slice(0, 120))}</b></td>
          <td>${esc(r.filename || '')}${r.uploaded_at ? ` · 올린 날 ${esc(r.uploaded_at.slice(0, 10))} (최신판)` : ''} · ${esc(e.where || '')} · p.${e.page}${r.earlier?.length ? `<br><span class="soft">이전 판: ${r.earlier.map(x => esc(x.filename) + ' (' + esc((x.uploaded_at || '').slice(0, 10)) + ')').join(', ')} — 검토는 최신판 기준</span>` : ''}</td></tr>`; }).join('')
          || `<tr><td colspan="3" class="soft">이 지적은 다른 문서와 맞대어 본 것이 아닙니다 (빈칸 · HOLD 등) — 왼쪽 칸만 봅니다</td></tr>`}
      </table>
      <div class="soft" style="margin-top:4px">${descHTML(i)}${i.expected ? ` · Required: <b>${esc(i.expected)}</b>` : ''}${i.op ? ` · 비교: ${esc(i.op)}${i.tol ? ' ±' + esc(i.tol) : ''} → ${esc(i.result || '')}` : ''}</div></div>
    <div class="cmpv"><div class="cmpL"></div><div class="cmpR">${ref ? '' : '<div class="empty" style="color:#d6dbe5">기준 문서 쪽 없음</div>'}</div></div></div>`;
  const L = new Viewer($('.cmpL', host), { extra: '<span class="lbl">Datasheet</span>' });
  await new Promise(r => requestAnimationFrame(r));                 // let the two halves take their width before 'fit'
  await L.load(d.document_id, d.pages); L.fit();
  L.setOverlays(i.bbox ? [{ cat: i.color || 'error', page: i.page, bbox: i.bbox, title: i.field }] : []);
  if (i.bbox) L.focus(i.page, i.bbox, i.field); else if (i.page) L.goPage(i.page);
  if (ref) {
    let doc = ref, pages = ref.pages;
    if (ref.prevDs) { const p = await api('GET', `/datasheets/${ref.prevDs}`); doc = { id: p.document_id }; pages = p.pages; }
    const R = new Viewer($('.cmpR', host), { extra: `<span class="lbl">${esc(ref.what)}</span>` });
    await R.load(doc.id, pages); R.fit(); if (ev.bbox && R.zoom < 0.9) R.setZoom(0.9);   // a wide table page: readable around the cell
    R.setOverlays(ev.bbox ? [{ cat: 'field', page: ev.page, bbox: ev.bbox, title: ev.where || ref.what }] : []);
    if (ev.bbox) R.focus(ev.page, ev.bbox, ev.where || ref.what); else R.goPage(ev.page);
  }
  host.onclick = e => { const r = e.target.closest('[data-cev]'); if (r) { renderCompare(host, d, i, { ...opts, ev: +r.dataset.cev }); return; }
    if (e.target.closest('[data-cmppop]')) { const u = new URL(location.href); u.hash = ''; u.searchParams.set('pop', 'cmp'); u.searchParams.set('ds', d.id); u.searchParams.set('ikey', i.ikey);
      const w = window.open(u.toString(), 'valve-pop-cmp', 'popup=yes,width=1500,height=950'); if (!w) toast('새 창이 막혔습니다 — 팝업 허용을 켜 주세요', 1); else { w.focus(); $('#modal').hidden = true; $('.mbox').style.width = ''; } } };
}
async function compareIssue(d, i) {
  placeModal('compare');
  $('#mTitle').textContent = '어디와 다른가 — 나란히 보기'; $('#mAct').innerHTML = '<button>닫기</button>';
  $('#mBody').innerHTML = '<div id="cmphost" style="height:100%;min-height:60vh"></div>';
  if (!$('.mbox').style.height) { $('.mbox').style.width = 'min(1600px,97vw)'; $('.mbox').style.height = '88vh'; } $('#modal').hidden = false;
  $('#mAct button').onclick = () => { $('#modal').hidden = true; $('.mbox').style.width = $('.mbox').style.height = ''; };
  await renderCompare($('#cmphost'), d, i);
  link({ t: 'iss', id: d.id, ikey: i.ikey });
}
async function popCmp() {                                  // the compare view in its own window, following the selected finding
  document.body.className = 'pop';
  document.body.innerHTML = `<div class="popbar"><b>어디와 다른가</b><span class="soft" id="pinfo">메인 창에서 지적을 고르세요</span><span class="sp"></span>
    <label class="soft"><input type="checkbox" id="plink" ${linkOn() ? 'checked' : ''}> 연동</label></div><div id="cmphost" style="flex:1;min-height:0;background:#fff"></div><div id="toast"></div>
    <div id="modal" hidden><div class="mbox"><h3 id="mTitle"></h3><div id="mBody"></div><div class="mact" id="mAct"></div></div></div>`;
  $('#plink').onchange = e => LS.set('linkon', e.target.checked ? 1 : 0); modalDrag();
  S.projects = (await api('GET', '/projects')).projects;
  const want = wantProject(), p = (want && S.projects.find(x => x.name === want)) || S.projects.find(x => x.id === LS.get('pid')) || S.projects[0];
  S.pid = p?.id;
  let cur = { id: +Q.get('ds'), ikey: Q.get('ikey') };
  const show = async () => {
    if (!cur.id) return;
    const d = await dsFetch(cur.id); S.ds = d;
    const i = d.issues.find(x => x.ikey === cur.ikey) || d.issues.find(x => !x.comment_id && x.evidence?.length) || d.issues[0];
    if (!i) return;
    $('#pinfo').textContent = `${d.tag} · #${i.no} ${i.type}`; document.title = `비교 · ${d.tag}`;
    await renderCompare($('#cmphost'), d, i, { pop: true });
  };
  if (BUS) BUS.onmessage = async e => {
    const m = e.data; if (m.from === WIN_ID || m.pid !== S.pid || !linkOn()) return;
    if (m.t === 'iss') { cur = { id: m.id, ikey: m.ikey }; await show(); }
    else if (m.t === 'ds' && m.id !== cur.id) { cur = { id: m.id, ikey: null }; await show(); }
    else if (m.t === 'changed' && m.id === cur.id) { PRE.delete(cur.id); await show(); }
  };
  await show();
}

/* valve29 — live link: what another window says */
let CHG_T = 0;
async function onLink(m) {
  if (!linkOn()) return;
  LINKING = true;
  try {
    if (m.t === 'changed') {                               // a decision / edit elsewhere: refresh what shows it (coalesced)
      S.issues = null; S.grid = null; S.reqs = null; PRE.clear();
      clearTimeout(CHG_T); CHG_T = setTimeout(async () => {
        if (S.view === 'review' && S.ds && (!m.id || m.id === S.ds.id)) { S.ds = await api('GET', `/datasheets/${S.ds.id}`); paintDsOverlays(); drawHead(); drawRight(); }
        else if (S.view === 'list') renderList();
      }, 250);
      return;
    }
    if (m.t === 'nav') {                                   // ▲ ▼ / J K in the PDF window: next row of this window's list or next tag
      if (S.view === 'review') stepTag(m.d);
      else if (S.view === 'list') dispatchEvent(new KeyboardEvent('keydown', { key: m.d > 0 ? 'ArrowDown' : 'ArrowUp' }));
      return;
    }
    if (S.view !== 'review') return;                       // following happens in the Datasheet Review window
    if (m.id && m.id !== S.dsId) { openDs(m.id); for (let n = 0; n < 40 && !(S.ds && S.ds.id === m.id); n++) await new Promise(r => setTimeout(r, 75)); }
    if (!S.ds || S.ds.id !== m.id) return;
    if (m.t === 'field' && W.selField !== m.key) { if (W.tab !== 'data') setTab('data'); selectField(m.key); }
    if (m.t === 'iss' && W.selIss !== m.ikey) { const i = S.ds.issues.find(x => x.ikey === m.ikey); if (!i) return; W.selIss = i.ikey; setTab('iss'); paintDsOverlays(); if (i.bbox) W.viewer.focus(i.page, i.bbox, i.field); }
  } finally { LINKING = false; }
}
if (BUS && !POP) BUS.onmessage = e => { const m = e.data; if (m.from !== WIN_ID && m.pid === S.pid) onLink(m); };

async function popPdf() {                                  // the light PDF window (second monitor) — mark-up tools included
  document.body.className = 'pop';
  document.body.innerHTML = `<div class="popbar"><b id="ptag">PDF</b><span class="soft" id="pinfo">메인 창에서 Tag 를 고르세요 (목록 · 작업대)</span><span class="sp"></span>
    <button id="pprev" title="이전 Tag (K) — 메인 창의 목록 순서">▲</button><button id="pnext" title="다음 Tag (J)">▼</button>
    <label class="soft" title="메인 창의 Tag · 칸 · 지적을 따라가고, 여기서 누른 것을 메인 창에 보냅니다"><input type="checkbox" id="plink" ${linkOn() ? 'checked' : ''}> 연동</label></div>
    <div id="popv"></div><div id="toast"></div>
    <div id="modal" hidden><div class="mbox"><h3 id="mTitle"></h3><div id="mBody"></div><div class="mact" id="mAct"></div></div></div>`;
  $('#plink').onchange = e => LS.set('linkon', e.target.checked ? 1 : 0); modalDrag();
  $('#pprev').onclick = () => link({ t: 'nav', d: -1 }); $('#pnext').onclick = () => link({ t: 'nav', d: 1 });
  S.projects = (await api('GET', '/projects')).projects;
  const want = wantProject(), p = (want && S.projects.find(x => x.name === want)) || S.projects.find(x => x.id === LS.get('pid')) || S.projects[0];
  S.pid = p?.id; S.view = 'review'; W.tab = 'pop';                  // the workbench's mark-up functions work here unchanged
  const V = W.viewer = new Viewer($('#popv'), { tools: true,
    onMark: addMark, onMarkChange: changeMark, onMarkErase: eraseMark, onMarkCmd: markCmd,
    onMarkSelect: m => { W.selCm = m?.id ?? null; },
    onOverlay: o => { if (o.iss) { W.selIss = o.iss; W.selField = null; paintDsOverlays(); link({ t: 'iss', id: S.ds.id, ikey: o.iss }); }
                      else if (o.key) { W.selField = o.key; W.selIss = null; paintDsOverlays(); link({ t: 'field', id: S.ds.id, key: o.key }); } },
    onPagePoint: (page, [x, y]) => {
      const inb = b => b && x >= b[0] - 2 && x <= b[2] + 2 && y >= b[1] - 2 && y <= b[3] + 2;
      const iss = (S.ds?.issues || []).find(i => i.page === page && !i.comment_id && i.status !== 'Dismissed' && i.type !== 'Extraction Review' && inb(i.bbox));
      if (iss) { W.selIss = iss.ikey; W.selField = null; paintDsOverlays(); link({ t: 'iss', id: S.ds.id, ikey: iss.ikey }); return; }   // a finding box first
      const f = (S.ds?.fields || []).filter(f => f.page === page && inb(f.bbox))
        .sort((a, b) => (a.bbox[2] - a.bbox[0]) * (a.bbox[3] - a.bbox[1]) - (b.bbox[2] - b.bbox[0]) * (b.bbox[3] - b.bbox[1]))[0];
      if (f) { W.selField = f.key; W.selIss = null; paintDsOverlays(); link({ t: 'field', id: S.ds.id, key: f.key }); }
    } });
  const show = async id => {
    if (!S.ds || S.ds.id !== id) {
      const d = await dsFetch(id); if (S.ds && S.ds.id === id) return;         // a newer message already showed it
      S.ds = d; S.dsId = id; W.selIss = W.selField = W.selCm = null;
      await V.load(S.ds.document_id, S.ds.pages);
      $('#ptag').textContent = S.ds.tag; $('#pinfo').textContent = `Doc. ${S.ds.doc_no} · Rev.${S.ds.rev} · ${S.ds.pages.length}쪽`; document.title = `PDF · ${S.ds.tag}`;
    }
    paintDsOverlays();
  };
  if (BUS) BUS.onmessage = async e => {
    const m = e.data; if (m.from === WIN_ID || m.pid !== S.pid || !linkOn() || m.t === 'nav') return;
    if (m.t === 'changed') { if (S.ds && m.id === S.ds.id) { S.ds = await api('GET', `/datasheets/${S.ds.id}`); paintDsOverlays(); } return; }
    if (!m.id) return;
    await show(m.id);
    for (const nid of m.near || []) if (!PRE.has(nid) && nid !== S.ds.id) {      // the next rows of the list: ready before they are clicked
      const pr = api('GET', `/datasheets/${nid}`).then(d => { (d.pages || []).slice(0, 2).forEach(pg => { const im = new Image(); im.src = `/api/valve/documents/${d.document_id}/page/${pg}.png?zoom=${V.imgZoom()}`; }); return d; });
      pr.catch(() => PRE.delete(nid)); PRE.set(nid, pr);
    }
    if (PRE.size > 12) [...PRE.keys()].slice(0, PRE.size - 12).forEach(k => PRE.delete(k));
    if (m.t === 'field') { W.selField = m.key; W.selIss = null; paintDsOverlays(); const f = S.ds.fields.find(x => x.key === m.key); if (f?.bbox) V.focus(f.page, f.bbox, f.display); }
    if (m.t === 'iss') { W.selIss = m.ikey; W.selField = null; paintDsOverlays(); const i = S.ds.issues.find(x => x.ikey === m.ikey); if (i?.bbox) V.goPage(i.page, i.bbox); }
  };
  if (+Q.get('ds')) await show(+Q.get('ds'));
}

/* ── start ────────────────────────────────────────────────────────────── */
if (POP === 'pdf' || POP === 'cmp') { (POP === 'pdf' ? popPdf() : popCmp()).catch(e => { document.body.innerHTML = `<div class="empty" style="color:var(--bad)">${esc(e.message)}</div>`; }); }
else {
if (EMBED) document.body.classList.add('embed');
if (!LS.get('flat', false)) document.body.classList.add('d3');     // valve29: depth look (Settings › 평면 화면 to turn off)
$('#who').innerHTML = `<b>${esc((USER || '?').slice(0, 1))}</b>${esc(USER || '이름 없음')}`;
loadProjects().then(async () => {
  hintsInit();                                         // top-bar buttons (? · ⧉ 새 창 · 🔗 연동) also on deep links
  const ds = +Q.get('ds');                              // deep link from the Excel lists: ?ds=…&key=…&page=…#review
  if (ds) {
    S.dsId = ds; LS.set('tag.' + S.pid, ds); go('review', false);
    const key = Q.get('key'), page = +Q.get('page');
    for (let n = 0; n < 40 && !(S.ds && S.ds.id === ds); n++) await new Promise(r => setTimeout(r, 150));
    if (key && S.ds?.fields.some(f => f.key === key)) selectField(key);
    else if (key && S.ds?.issues?.some(i => i.key === key)) { const i = S.ds.issues.find(x => x.key === key); W.selIss = i.ikey; setTab('iss'); paintDsOverlays(); if (i.bbox) W.viewer.focus(i.page, i.bbox, i.field); }
    else if (page) W.viewer?.goPage(page);
    return;
  }
  go((location.hash.slice(1) || LS.get('view', 'dash')).split('?')[0], false);
})
  .catch(e => { document.querySelector('#views').innerHTML = `<div class="empty" style="color:var(--bad)">${esc(e.message)}</div>`; });
}
})();
