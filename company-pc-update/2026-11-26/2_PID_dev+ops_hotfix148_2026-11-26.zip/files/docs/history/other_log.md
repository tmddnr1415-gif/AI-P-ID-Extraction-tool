# other 회차 기록 (2026-10-30 부터 · 옛 기록은 같은 폴더의 CLAUDE_archive_*.md)

새 회차를 **끝에** 5~15줄로 덧붙인다.  이 파일은 자동으로 읽히지 않으니 길어져도 된다.

## 2026-10-31 · VALVE 세션 시작 — valve01 (브랜치 ccr-efbe7e75-n915ze)
- 새 모듈 Valve Datasheet 검토: P&ID 서버 `/valve` (app/valve · app/static/valve), 대시보드 메뉴 실행 프로젝트 › CO2 PJT › Datasheet › Ball Valve (APP 2026-10-31.2).
- 참조 자료(EGG 분할) 분석: Datasheet 456쪽 = 164 데이터시트(On/Off 140 · MOV 24), TBE 5개 Appendix 시트 164 Tag(164/164 일치), Process Data 61쪽, PMS 374쪽(Class 37종). → docs/valve/DESIGN.md
- Phase 1 + Revision 비교 기본. Process/PMS 는 화면 틀(Not Evaluated · MOCK 은 버튼으로만).
- spike/pack_delta.py 에 `--only` (모듈 꾸러미: 딱지 · 기준 파일 안 건드림). config/release_sources.json 에 VALVE.
- 시험 tests/test_valve.py 7개 · 전체 1,836 통과.

## 2026-10-31 · valve02 — 지적 사항 · 설계사 전달물 · 실제 PMS (브랜치 ccr-efbe7e75-n915ze)
- 요청: 잘못되거나 없는 Data 를 PDF 에 표시해 같이 출력 · Excel(Tag · Doc · Sheet · Page · 무엇이 문제) 로 설계사에게 · 분석 끝나면 Excel 도 · Excel 칸 → PDF 그 자리 · 재질 표기 차이를 같게.
- issues.py(규칙) · exports.py(Issue List xlsx · 인쇄 플래그 Mark-up PDF + Issue Summary 쪽) · material.py(규격·등급 비교) · pms.py(실제 PMS · 지역 QN/QS).
- 화면: Valve List / Issue List + PDF 미리보기 실시간 연동, Issues 탭, 실제 PMS 화면(데이터시트 · PMS 나란히), 분석 끝 자동 내려받기, ?ds=&key=&page= 바로 열기.
- 실자료: Data Error 3 (없는 General Note 46) · PMS 재질 Non-Compliant 0 · Body Review 32→15 · Valve List 실제 차이 571→539.
- 시험 21개 · 전체 1,850 통과.

## 2026-10-31 · valve03 — 실패 원인 분석 · 성능 · 사용자 Mark-up (브랜치 ccr-efbe7e75-n915ze)
- 요청: 시간이 걸려도 실패 원인을 분석해 상용 수준으로 · 사용자가 직접 마크업.
- 평가 도구 spike/valve_eval.py(실자료 · 기준값은 개수만) 로 재고 고침: 짝 실패 69→1 · 오독 11→0 · Data Missing 오탐 748→0(Process DS 참조 데이터시트) ·
  PMS Review 113→75 · TBE 비교 가능 칸 일치 92.9 % · 잘못된 Note 참조 2건 새로 잡음 (DESIGN §10.1).
- 강건성: A3 등 크기 다른 쪽 정규화 · 회전 쪽 · 암호/손상 PDF 안내. 속도: 13 ms/쪽 · 지적 캐시 · Mark-up PDF 314→40 KB/데이터시트.
- Mark-up 도구 10종(선택 · 사각형 · 구름 · 원 · 형광펜 · 선 · 화살표 · 펜 · 글상자 · 메모), 분류 → Issue 종류(Error=Data Error …), 옮기기 · 크기 · 지우기 ·
  되돌리기/다시, PDF 주석 종류 그대로 내보냄 (DESIGN §10.3).
- 시험 30개 · 전체 1,860 통과. 꾸러미 valve03.

## 2026-10-31 · valve04 — P&ID · LOGIC 개발 원리 차용 (브랜치 ccr-efbe7e75-n915ze)
- 요청: PID 분석 · LOGIC 분석 개발 원리에서 빌릴 것이 있으면 참조.
- 지문 게이트(`valve_eval.py --check`, 17,207칸) · 이중 괘선 문턱을 상수로 빼고 빈 띠 실측(틈 5~7 · 칸 21+ pt) · 'TBE 와 다름'을 쪽 글자로 독립 확인 ·
  사전 밖 라벨 1,920칸 = MOV 항목(버려지지 않음) 확인.
- 검토 피드백(VOC): `/api/valve/projects/{pid}/feedback.json` + Reports 버튼 · `spike/valve_voc.py` 채점(규칙별 정밀도 · 다시 돌리기) · 판정 모듈이 안 읽음을 AST 시험.
- 차등 시뮬레이션 `spike/valve_diff_sim.py`: 140장 12,470칸 불일치 0. 화면 자기검증 `spike/valve_ui_audit.cjs` 22/22.
- DESIGN §11 (차용표 · 단일 판정 자리). 시험 33개.

## 2026-10-31 · valve05 — 456쪽 전수 눈 대조, 오류율 3.54 % → 0.009 % (브랜치 ccr-efbe7e75-n915ze)
- 요청: 모든 쪽을 눈으로 본 것과 프로그램 분석의 오차를 재고 5 % 미만(가능하면 100 %)으로.
- 방법: 쪽 그림 + 읽은 것 꾸러미(`spike/valve_visual_pack.py`) → 검토 에이전트 46묶음이 항목별 판정(오류는 PDF 글자 층으로 확인) → 채점(`valve_visual_score.py`) → 고침 → 바뀐 1,324줄 재판정.
- 1차 21,482항목 760오류(3.54 %) → 2차 오류 0 + 남은 2(도면 Doc. No. 오타, Data Error 로 지적) = 0.009 %.
- 고친 원인: 숨은 글자(그리기 순서) · 겹친 같은 글자 · 3pt 줄 묶기 · Notes 바닥글 · Form 102 단일 열 · 번호 없는 오른쪽 열 · 단위만 있는 칸 · 'Sheet|3|of|3' · 제목 줄바꿈 · ATTACHMENT · HOLD 목록.
- 새 지적: sheet 2 Doc. No. 불일치 · 반복 머리(Tag/PID/Service/Line) 불일치 — 실자료 3건. 시험 36개. 기준값 지문 541753c612ed.

## 2026-10-31 · valve06 — Valve List Excel 에서 Vendor 행 삭제 (브랜치 ccr-efbe7e75-n915ze)
- 요청: 엑셀에서 AMPO · OMS · NEWAY 행을 다 삭제.
- `tbe._drop_vendor_rows`: 기준 TBE 양식을 읽자마자 Tag 블록마다 Requirement 행만 남김(값 · 서식 · 메모 · 행 높이를 한 번에 올리고 병합 재설정 — openpyxl delete_rows 는 병합 · 높이를 안 옮김). `build(vendor_rows=True)` 면 유지.
- 실자료: 164 Tag 모두 한 줄씩, Vendor 칸 0, 링크 · 메모 유지. 시험 36개 통과.

## 2026-10-31 · valve07 — UI/UX 개선 패키지 + Phase 3 Process Data (브랜치 ccr-efbe7e75-n915ze)
- 요청: 개선 패키지(CLAUDE_CODE_UI_IMPROVEMENT_PROMPT · 목표 그림 · 캡처 31장)대로 감사 → P0~P6 구현 · 데이터시트 칸을 누르면 밸브 부위 그림 · 남은 일 전부.
- 감사 `docs/valve/UI_UX_AUDIT.md`(해상도 실측: 1366 에서 도구줄 124 px · PDF 646 px · 탭 3줄) → 변경 `UI_UX_CHANGELOG.md`.
- P0: 머리 띠 · 접이식 px 패널 · 한 줄 도구줄(36 px) · 레이어 칩 · Mark-up 줄 접기 · Tag 목록 2줄 · 탭 배지 · 밸브 부위 SVG(1366 PDF 835 px).
- P1~P6: 대시보드 5×2 + Issues by Category + KPI 필터 이동 · 목록 ↑/↓/Enter · Revision 같이 움직이기 + 비교 Excel · PMS 안내 · 내보내기 묶음/확인/상태 · Settings 단축키.
- P5 실제: `app/valve/process.py`(괘선 열 띠 · 단위 · 기준 규칙) — 68 Tag · Mismatch 42 · 지적 'Process Mismatch'. MOCK 제거.
- 회귀: pytest 38 · 전체 통과 · eval --check 불변 · diff_sim 0 · ui_audit 22/22 · 1920/1600/1366 캡처(out/ui_before · ui_after, 저장소 밖).

## 2026-10-31 · valve08 — 빈 Process Data 항목 전부 지적 (브랜치 ccr-efbe7e75-n915ze)
- 요청: Process Data 가 없는 것은 전부 표기. (valve03 의 'Process DS 참조면 제외' 를 사용자가 뒤집음)
- issues.py: PROCESS DATA 블록 전 항목(section process + Sour/Corrosive/Erosive/Toxic/Stroke) · Max/Nor/Min 은 셋 다 비면 한 건 · 참조 문서 명시 · Process Data 값을 Expected 로.
- 실자료 Data Missing 0 → 2,529 (164 Tag). 읽기 지문 불변(바뀐 칸 0). 시험 38개(옛 'skips' 시험을 새 규칙으로 바꿈). 기준값 다시 저장.

## 2026-10-31 · valve09 — HOLD / TBC 전부 지적 (브랜치 ccr-efbe7e75-n915ze)
- 요청: HOLD 도 comment — 빨리 HOLD release 하고 값을 입력하게.
- 전: 필수 18칸 · 값이 HOLD 로 시작할 때만 → 실자료 0건. 후: 모든 칸 · Note, 값 어디에 있어도(HOLD (…) · Hold-1 → HOLD 목록 글) · Major · 약어 설명 줄 제외.
- 실자료 Open Item 84 (Area classification 14 · Fire Safe 11 · SOV Tag Hold-1 48 · Typical TBC 7 · Note 4). 읽기 지문 불변. 시험 39개.

## 2026-10-31 · valve10 — PMS 대조 점검 · 특수 요구사항 · 재질 검토 의견 (브랜치 ccr-efbe7e75-n915ze)
- 요청: PMS 기준 검토가 맞는지 학습 · 재질 검토 의견을 전문적으로 · Note 의 Special Requirement(PFP · Fugitive …) 가 Excel 에 잘 나오는지.
- PMS: PDF 와 대조 — Trim/Stem 을 Class 머리 Trim(1A1A '13CR/HF', Gate/Globe 용)과 비교하던 오류 → Ball 품목 '316 SS BALL/STEM' 우선. Review 16 → 0. 남은 지적은 실제 PMS 공백(3R1B3 Ball 없음 · 6C0K8 10" · XC0K8 22" …).
- PMS 머리에서 P-T 표 · Service · Class Notes · Item Notes 도 읽음(READER_VERSION 2, 옛 json 자동 재읽기).
- 특수 요구사항 `requirements.py` 15종 → Valve List 'Special Requirements (Notes)' 열 · Summary 탭. 164 Tag 모두 나옴.
- 재질 검토 `matreview.py` MR-01~15 (시트 온도 · P-T · 저온 본체 · CO2 탄소강 · NACE 316/CS/17-4PH/볼트 · HF · Dual grade · RGD · Fire-safe · Service). 실자료 Action 5 · Confirm 29 → Issue 'Material Review'. Material 탭 · Valve List 열.
- 시험 41 · eval --check: 바뀐 것은 Trim/Stem 16(원인 위) + 새 F 절, 읽기 지문 불변 → 기준값 저장 · diff_sim 0 · ui_audit 22/22.

## 2026-10-31 · valve11 — Ball Valve 엔지니어로서 검토 (브랜치 ccr-efbe7e75-n915ze)
- 요청: 전달한 Datasheet · PMS 를 디테일하게 학습하고 Ball Valve 전문 지식을 기본으로 전문 엔지니어로서 검토.
- LLM 없이(원칙 §4.3): 지식표 `knowledge.py` 28항목(API 6D · ISO 17292 · B16.34 · B16.5/47 · 누설 · Fire · ISO 15848 · NACE · SIL · 설계 · 재질) → BALL_VALVE_KNOWLEDGE.md 생성.
- 설계 규칙 `expert.py` VR-01~15 + 학습 PC-01(같은 Piping Class 데이터시트 다수 값, 5개 이상 80 %). 참조 칸('Note 2')은 Note 글까지 읽음.
- 실자료: VR Action 3(2″ 에 B16.47-B) · Confirm 44 · PC-01 6. 웹으로 17-4PH · 316 한계 · Floating 관행 확인(관행 값은 '회사 사양 우선' 으로 표기).
- 화면: Expert 탭 · Settings › Ball Valve 지식 · Issue 'Valve Review' · Excel 'Expert Review (Tool)'. 시험 42 · eval 은 F 절만 이동(읽기 · PMS 불변) · diff_sim 0.

## 2026-10-31 · valve12 — 설계사 코멘트는 핵심만 (브랜치 ccr-efbe7e75-n915ze)
- 요청: 설계사 주기 위한 코멘트는 핵심만 간결하게.
- MR/VR/PC 규칙마다 `short` 한 줄(문제 · 값 · 할 일, ≤120자 시험) → Issue List · Mark-up PDF · Valve List. 긴 설명 · 근거 · 지식은 Expert 탭만.
- Data Missing · Open Item · Note 참조 오류 · Revision 문구 줄임(`issues._cut` 낱말 단위 자르기).
- 평균 길이 Material/Valve 350→68 · Data Missing 136→80 · Open Item 93→56. eval 기준값 불변 · 시험 42 · 전체 1,872 · ui_audit 22/22.

## 2026-10-31 · valve13 — 설계사용 출력 때 Issue Type 고르기 (브랜치 ccr-efbe7e75-n915ze)
- 요청: PDF 에 설계사 코멘트 · Excel 출력 시 어떤 issue type 을 리스트업할지 선택.
- valve.js `pickTypes`: 종류별 건수 · 한글 설명 · 전체/모두 끄기/설계사용 기본 · 선택 기억(LS valve.xtypes). 출력 단추 5곳 모두 거침. 서버는 기존 `types=`.
- 확인: Material+Valve Review 만 → Excel 89행(그 두 종류만) · PDF 548 → 199쪽. 시험 43 · ui_audit 22/22.

## 2026-10-31 · valve14 — Issue List · 전체 Valve List 를 Area · Unit 별로 (브랜치 ccr-efbe7e75-n915ze)
- 요청: 설계사용 Issue List 와 전체 Valve List 를 Excel 로, Area(North · South · Brownfield) · Unit 별 Excel 필터.
- `location.py`: 제목 NORTH/SOUTH/W15, '(SYSTEM xx – UNIT yy)' = Brownfield(Note 의 'South Brownfield System 19' 근거), Unit = 제목 → P&ID → Tag. 표지/장 번호 불일치 · 표지 없는 Rev 보완.
- Issue List: Area · Site · Unit 맨 앞 + 필터, Summary by Tag 같은 열 + Material/Valve Review. Valve List: 'All Valves' 시트(164행) + 종류 시트 Area/Site/Unit 열 + 필터.
- 실자료 North 74 · South 69 · Brownfield 14 · W15 7. 시험 44 · 전체 1,874 · ui_audit 22/22.

## 2026-10-31 · valve15 — Area · Unit 별 Tag 번호 규칙 학습 (브랜치 ccr-efbe7e75-n915ze)
- 요청: Area 별 Unit 별 Tag numbering procedure 를 학습. 받은 파일에 절차서 문서 없음 → 프로젝트 Tag(데이터시트 164 · Process Data 68)에서 배움.
- `tagrules.py`: 구조 · 접두 출처(Unit / 제목 System / P&ID System) · 번호 자릿수 · 고정 앞자리 · 구분 · A/B · 계열↔P&ID. Brownfield North U84(08SDV) 와 South U84(84XV) 는 Site 로 나눔.
- 결과: North 98+기능+␣980nnn(계열 1~4 = P&ID 띠) · South 98+기능-nnn · W15 315+기능␣980nnn · Brownfield 접두 = 제목 SYSTEM(North) / UNIT(South).
- 검사 TG-01~05 → 실자료 TG-05 4건(ESDV Fail Open). Settings › Tag Numbering 표 · All Valves 에 Tag 부분 열. 시험 45 · 전체 1,875 · eval 불변 · ui_audit 22/22.

## 2026-10-31 · valve16 — No. 열과 Summary 시트 (브랜치 ccr-efbe7e75-n915ze)
- 요청: 앞에 No. 가 있어야 하고 Summary 도 있어야 한다.
- Issue List: 'Summary' 시트(Area · Site · Unit × Issue Type, Major · Minor · Tags, By Area) · Summary by Tag 에 No. · Area 순 정렬.
- Valve List: 'Summary' 시트(Area · Site · Unit × Valve Type, Open Issues · Tags with Action · New/Updated) · All Valves · Datasheet Notes 에 No.
- 실자료 확인(164 Tag · 2,823 지적), 시험 45 · 전체 1,875 · ui_audit 22/22.

## 2026-10-31 · valve17 — Issue List Area 순 · All Valves 요구사항 열 (브랜치 ccr-efbe7e75-n915ze)
- 요청: Issue List 시트도 Area 별 정렬 · Valve List All Tag 에 Note 의 중요 내용(PFP · fugitive class 등)을 각 열로.
- exports: Area → Site → Unit → Tag 정렬(Tag 안 순서 유지). requirements.columns: 종류별 열, 데이터시트 줄 답 우선(PFP 줄 Not Required 면 그 답), 세부(Class A · SIL 2 · 3.2), 출처.
- hardness 세부 'HB 160' 형도 읽음. 시험 46 · 전체 1,876 · ui_audit 22/22.

## 2026-10-31 · valve18 — Issue List 'Summary by Area' 시트 (브랜치 ccr-efbe7e75-n915ze)
- 요청: Issue List 에도 Area 별 Summary 시트 추가.
- exports._area_sheet: Area 한 줄씩(Units · Tags · Total · Major/Minor · 종류별 · Status별) + Area × 종류 × Severity 표. 시트 순서 Issue List · Summary · Summary by Area · Summary by Tag · Info.
- 시험 46 · 전체 1,876 · ui_audit 22/22.

## 2026-10-31 · valve19 — Valve List 'Summary by Area' 시트 (브랜치 ccr-efbe7e75-n915ze)
- 요청: Valve List 에도 Area 별 Summary 시트 추가.
- tbe._area_sheet: Area 한 줄씩(Units · Tags · 종류별 · Open Issues · Action · PFP Required · SIL · Fire Safe HOLD · New/Updated) + Area × Valve Type(Size · Rating). Summary 와 All Valves 사이.
- 시험 46 · 전체 1,876 · ui_audit 22/22.

## 2026-10-31 · valve20 — 상용 수준: 속도 · 간결한 UI · 시뮬레이션 (브랜치 ccr-efbe7e75-n915ze)
- 요청: 가볍게 · 끊김 없이 · 글 적게 · UI 개선 · 수천 번 시뮬레이션 · 상업 판매 수준.
- 속도: 데이터시트별 검토 캐시(메모리 + 디스크) · 프로젝트 판 키 · 워밍 · `_json()` · grid 캐시 → issues 250→30 ms · PMS 784→21 · 냉간 3.9 s→0.2 s · 990 DS 재시작 36 s→0.23 s.
- UI: 그룹 이슈 카드 · 한 줄 탭 · '?' 도움말 · 8 타일 · idle 표 렌더(Issue List 6.1→2.2 s @990) · 오류 토스트 · 버전 · DB 백업.
- 시뮬레이션 `spike/valve_sim.py`: 3,000건 recall .955/precision .906 → 10,000건 1.000/1.000 · 퍼즈 0 예외. 결함 6건 수정(R-PTFE · METAL/NYLON · LTCS · MR-03 · MR-13 · VR-09). 실자료 VR-09 2→20(진짜).
- 시험 48 · ui_audit 22/22 · 기준값 저장.

## 2026-10-31 · valve21 — 실자료 변이 재생 · 캐시 결함 · Area/Unit 화면 (브랜치 ccr-efbe7e75-n915ze)
- 시뮬레이션 2차: oracle 55 규칙 · `valve_mutate.py` 실자료 164 × 14 변이 87.8 % → 100 %. 결함: PMS Fire Safe 'HOLD(API 607)' Compliant → Review · 동료 다수 표기 분열 · NACE NA → Review.
- 화면: Grid 캐시 Response 재사용 → gzip 헤더 변조로 Valve List 멈춤(실제 결함) 수정 + 시험. Area/Unit 열·필터·머리·By Area 카드. Expert Note 접힘. 다시 시도 단추.
- 실측: 다음 Tag 55 ms · 쪽 130 ms. eval: PMS Fire Safe 10 Compliant→Review(의도) · 지문 불변 · 기준값 저장. 시험 50+1 · ui_audit 22/22.

## 2026-10-31 · valve22 — 진단 · 가벼운 목록 · 사용 설명서 · 추출 견고성 (브랜치 ccr-efbe7e75-n915ze)
- `/api/valve/health` + Settings 진단 · Issue List 필터 행만 재렌더(0.6→0.35 s) · 캐시 이력 제외(990 DS RSS 489→457 MB) · USER_GUIDE.md.
- 추출 시뮬레이션 `valve_sim_pdf.py` 380장 0.833→0.992(기울기 · Max/Nor/Min 경로 · Note 번호 표기 · NOTES 줄 · 괘선 위 낱말). 실자료 지문 불변 · diff_sim 0.
- 합성 10,000건 seed 23 재확인 1.000/1.000. 시험 53 · ui_audit 22/22.

## 2026-10-31 · valve23 — PDF 주석기 수준 Mark-up (브랜치 ccr-efbe7e75-n915ze)
- 요청: PDF Annotator 같은 주석 기능 · 매우 가볍게.
- 도구 15(밑줄·취소선·물결·스탬프 13종+직접·지우개 추가) · 색 7+분류색 · 굵기 4단 · 즐겨찾기 · '바로'. `comment.style` 열(검증) · PDF 주석 Underline/StrikeOut/Squiggly · 스탬프 Square+FreeText · ✓✗ Ink.
- 가벼움: 그리는 표시만 임시 SVG(rAF) · 펜 곡선. 시험 markup23 · 54 통과 · ui_audit 22/22.

## 2026-11-01 · valve24 — 주석 도구 완성 · 메뉴별/시연별 화면 (브랜치 ccr-efbe7e75-n915ze)
- 요청: PDF 주석기 목록(Stamp · Sticky Note · Typewriter · Text Box · Callout · Highlight · Cross Out · Underline · Arrow · Line · Rectangle · Oval · Polygon Line · Polygon) 전부 + 메뉴별 · 시연별 화면 한 장씩.
- 추가: 타자기 · 말풍선(callout 선 + 화살표) · 꺾은선 · 다각형 · DRAFT. PDF 주석 PolyLine/Polygon/Callout FreeText.
- 결함 3 수정: 화면 style 누락 · 팔레트가 직전 표시 재칠 · 꺾은선 Enter 가 편집 창까지. 시험 markup23 확장 · ui_audit 25/25.
- 화면 55장(메뉴·기능 31 + Mark-up 시연 24, 내보낸 PDF 포함) — 저장소 밖 zip.

## 2026-11-01 · valve25 — PDF 에 마크업 · 코멘트 그대로 · 공정 값 출처 문구 (브랜치 ccr-efbe7e75-n915ze)
- 요청: PDF 출력 시 마크업과 프로그램 코멘트가 PDF 위에 그대로 · 공정 값 의견은 "Datasheet 상 … 기준 / Ref. Process Data [문서] 기준 …" 으로.
- Mark-up PDF: 쪽 오른쪽 250pt 여백에 번호별 코멘트(넘치면 이어지는 쪽) + `bake()` 로 마크업 고정(기본). 선택 창에 두 옵션(기억).
- `matreview.proc_value`: Process Data 행 우선, 없으면 데이터시트 값 — MR-01·02·03·07·14 · VR-09·10 문구 "Based on Ref. Process Data <Doc> (p.N) …". Process Mismatch · Data Missing Required 에 문서 번호.
- 글 없는 마크업은 "Stamp 'APPROVED' on the PDF" 처럼. 리뷰 디스크 캐시 키에 VERSION. short 상한 120→160.
- 기준값 불변 · diff_sim 0 · sim 3,000 · mutate · sim_pdf 190 · ui_audit 25/25 · 시험 86(valve).

## 2026-11-01 · valve26 — 코멘트 말투 'shall be reviewed' (브랜치 ccr-efbe7e75-n915ze)
- 요청: "Revise 보단 설계사가 다시 검토할 수 있도록 shall be reviewed 느낌으로".
- 한 줄 코멘트의 'Revise.'(8곳) · '— correct.' → '… shall be reviewed.' MR-01·02 는 160자 안에 들도록 괄호로 줄임.
- 기준값 불변 · sim 3,000 · mutate · 시험 86(valve) 통과.

## 2026-11-01 · valve27 — 물 흐르듯 · 글자 줄임 · Rev B/C/D 자동 이어받기 (브랜치 ccr-efbe7e75-n915ze)
- 실측: 서버 ≤ 63 ms. 브라우저 990 DS Tag 이동 74~277 ms → 4~19 ms(Tag 목록 재생성 제거 · scrollIntoView 조건부). 필터 긴 작업 193 → 60~90 ms(chunk 80 · 게으른 행 · Collator). prefetch · decoding=async.
- 글자: 항상 보이던 긴 안내문을 한 줄로, 설명은 `?` 로.
- `revisions.py`: Dismissed/Confirmed 이어받기 · 'Not addressed since Rev A' · 칸 의견 복사 · rev_review(해결/미반영/새것). 화면 칩 · 목록 ✗N · 대시보드 '미반영'. `tests/test_valve_revision.py`.
- `spike/valve_rev_sim.py` 1,506 점검 1.000(발견: Dismissed 였던 지적을 새것으로 세던 것 수정). 실자료 00XV921 A→B 해결 5 · 새 3.

## 2026-11-01 · valve28 — Verification Engine: 모든 지적에 근거 · 48 항목 검증 보고 (브랜치 ccr-efbe7e75-n915ze)
- 방향(사용자): 엔진이 핵심, UI 는 신뢰·검증 수단. 실측: 지적 행에 맞대어 본 쪽 근거 0 % → `issues.add(evidence, basis, check)` 로 전 종류에 붙임.
- Excel Evidence/Basis 열 · PDF 코멘트 Evidence 줄 · Issues 카드 근거 링크. `checks.py` 레지스트리 48 → Checks 탭 · 대시보드 Coverage · Excel Verification 시트(n/a 이유 표).
- 실자료 164 × 48 = 7,872 (✓6,806 ✗426 –640). 시험 `test_valve_verification.py`. Revision 시뮬 1,500×3 = 55,223 점검 1.000.

## 2026-11-01 · valve29 — Phase 1 운영 신뢰성 (지시서 "Engineering Intelligence Upgrade") (브랜치 ccr-efbe7e75-n915ze)
- 계획 `docs/valve/PHASE1_PLAN.md` → 결정 5종 + 사유 분류(status 옆) · decision_log · Rule Performance · 규칙 버전/출처 · 변경 절차(자동 변경 없음) · 근거 추적.
- 판정 불변: `valve_snapshot_diff.py` 실자료 2,887 지적 차이 0 · eval 지문 불변.
- 성능 측정(`valve_perf.py`, 164/500/990 · cold/warm · 화면)이 찾은 것: Issue Excel 500 DS 105 → 6 s · Valve List 28 → 5.6 s · Mark-up PDF 2차 증가 182 → 42 s · 목록 화면 6,000행 상한(결함) 제거.
- 보고서 다섯 `docs/valve/valve29/`. 시험 99(valve).

## 2026-11-01 · valve29 — 특수 요구사항 한눈에 + Excel (사용자 요청)
- Valve List › **Special Req.** 탭: Area 합계(숫자 누르면 거름) + Tag × 요구사항 표(● / Not Req., 원문은 툴팁) + Excel(거른 그대로).
- API `/requirements` · `/requirements.xlsx` (Summary by Area · by Unit · By Tag · Info). 계산은 Valve List 와 같은 함수 — 수 일치 확인.
- 시험 +1 (전체 1,901 통과) · UI 25/25 · LINK OK.


## 2026-11-01 · valve29 — 메뉴별 화면 캡처 + 새 설치 첫 실행 결함 수정
- `spike/valve_menu_shots.cjs`: 빈 서버에 실자료 4종 Import → 메뉴 16화면 캡처 (out/valve29/menus, 저장소 제외).
- 결함: **새 설치의 첫 요청이 500** — 서버 준비 스레드와 첫 화면 요청이 빈 DB 에 같은 열을 동시에 추가(duplicate column: since). `store.connect` 첫 준비를 잠금 + 중복 열 무시. 시험 +1.

## 2026-11-01 · valve29 — "모든 동작이 빠르게" (사용자 요청)
- 측정 도구 `spike/valve_speed.cjs`: 동작 60여 개(메뉴 · 탭 · 검색 · 행 클릭 · Tag 넘기기 · 비교 창 · 확대)를 클릭→화면 안정 · 최장 멈춤으로 잼.
- 서버: 화면 답(summary · PMS · Process · 특수요구 · Rule Performance · Tag 규칙)을 **쓰기 전까지 재사용**(store.WRITES 커밋 카운터 + DB 최신 행 키) · 서버 켤 때 전부 미리 계산.
  990 DS 첫 진입 Rule Performance 1.5 s → 0.1 s · Settings 2.4 s → 0.1 s · summary 0.25 s → 0.005 s.
- 화면: Valve List 검색 · 필터는 행만 다시 그림(머리줄 · 미리보기 유지) · 입력 대기 200–250 → 90 ms · 가상 행 여백 축소 · 행 높이 기억 · 목록 둘을 한가할 때 미리 받음.
  990 DS Valve List 검색 0.5 s(멈춤 0.21 s) → 0.2 s(멈춤 0) · 탭 전환 멈춤 0.27 → 0.08 s.
- 숨은 결함: Issue List 에서 검색을 바꾼 뒤 Excel/PDF 를 받으면 **이전 검색어**가 적용되던 것 → 누를 때의 검색어로.
- 시험 +1(캐시가 결정 · 상태 변경 직후 바로 갱신) · 전체 1,903 통과 · UI 25/25 · LINK OK · 판정 스냅샷 차이 0.

## 2026-11-01 · valve29 — 입체 화면(시안 A) + 대시보드 카드 크게 보기 (사용자 선택)
- 시안 3종(A Soft Depth · B Glass · C Control Panel) 캡처 → 사용자가 A 선택. `body.d3` CSS 로 적용, Settings 에서 끌 수 있음.
- 대시보드 카드 제목/빈 곳 클릭 → 큰 화면(Esc · 바깥 · ✕), Review Status Table 은 전체 Tag. 큰 화면 행 클릭 → 그 데이터시트.
- 색 버튼(.on/.pri/레이어) 덮지 않게 범위 제한. UI 25/25 · LINK OK · 동작 측정 최장 멈춤 156 ms(전과 같은 범위).

## 2026-11-01 · valve29 — Excel 같은 열 필터를 모든 목록에 (사용자 요청)
- ▾ 팝업(정렬 · 검색 · 값 체크 · 건수 · 모두 선택 · 지우기). 큰 목록 5개는 데이터 단위, 나머지 표는 자동 장착(xfDom).
- 실자료 확인: Issue Type=Data Error 7 · Process Mismatch 42 · North 74 Tag — KPI 와 일치. 메뉴 이동 후 필터 유지.
- 990 DS 필터 ≈ 0.2 s. 정렬을 값 순위 방식으로(17k 행 JS 25 ms) · 가상 행 높이 재측정 생략.
- UI 25/25 · LINK OK · valve 시험 105 통과. `spike/valve_filter_check.cjs`.

## 2026-11-01 · valve29 — Accessory 지식 · 규칙 AC-01~05 (사용자 요청: Ball valve · DVC6200 · PT · SOL · ASCO 2oo2 · PST)
- 실자료 노트/GN 조사: GN15 Fisher DVC · GN13/7 PST+온라인 SOV 시험(DVC 경유) · GN20 PT 기본·Limit Switch 금지·안전계통 PT SIL2 · GN11/12/37 SOV de-energize-to-trip·Class H·potted.
- 지식 5개 추가(knowledge.KB acc.*) — 공개 제조사 문서 · IEC 61508/61511 근거, 값은 '현행 bulletin 확인' 명시. emerson.com 직접 열기는 세션 네트워크에서 막힘(검색 요약만 사용).
- 규칙 AC-01~05(데이터시트 + 자체 GN 만 비교). 실자료: AC-05 48(SOV 2~3개, 표결 미기재) · AC-03 49(Note) · 나머지 0. 기존 지적 변경 0.
- 검토 캐시 키에 규칙 코드 지문(`_RULES_FP`) 추가 — 규칙이 바뀐 꾸러미는 VERSION 그대로여도 다시 계산(옛 캐시가 새 지적을 가리는 일 방지).
- 시험 +1 · valve 106 · eval baseline 갱신(AC 두 줄만) · sim 1.000 · mutate 100% · rev_sim 7,175/7,175.

## 2026-11-01 · valve29 — 검증 + 가볍게 (사용자 요청)
- 검증: pytest 1,904 통과 · UI 25/25 · LINK OK · 판정 스냅샷(기존 2,887 변경 0) · 필터 점검 · 동작 60개 속도(최장 멈춤 0.37 s = Valve List 재진입, 나머지 ≤ 0.14 s).
- 가볍게: Process/PMS 가상 행(990 DS DOM 22만 → 3만) · 정적 파일 해시 캐시 + 화면 답 gzip 보관 + ETag 304(재방문 229 KB → 2 KB) · 서버 메모리 −12 %(990 DS). 자세히 DESIGN §34-5.
- 측정 도구: /tmp 의 weight2.cjs(전송량) · nodes.cjs(요소 수) 는 임시 — 필요하면 spike 로 옮길 것.

## 2026-11-01 · valve29 — 첫 화면 기준 문서 Rev · 날짜 + 대시보드 Globe/Butterfly/PSV 메뉴 (사용자 요청)
- `app/valve/docrev.py`: PDF 머리(Doc. No. · Rev.)와 개정표(같은 줄의 Rev 토큰 + 날짜, 가장 늦은 날짜 행)를 글자층에서 읽음. Process Data 묶음 안의 PR-DTS 17종도 각각. 업로드마다 한 번 읽어 document.info['rev'] 에 보관.
- 실자료: PMS 98-98-PI-SPC-00001 Rev 0 · 20/Sep/2026 · Approved For Construction with Hold / Process CO2S-SSG-IN-REQ-00009 Rev 0, DS 17종(A 8 · B 9, 최신 08/09/2026) / Datasheet Rev 0 139 · A 13 · B 12, 최신 19/9/2026.
- 대시보드 dashboard.html: CO2 PJT › Datasheet 아래 Globe Valve · Butterfly Valve · PSV (준비 중 화면). APP_VERSION 2026-11-01.1, 변경 이력 기록. 대시보드 zip 은 DASHBOARD 세션이 병합해 냄.
- 시험 +2 (1,906 통과) · UI 25/25 · LINK OK.


## 2026-11-01 · valve29 — 회사 전달 꾸러미 3개 + 회사 Claude Code 인계 (사용자 요청)
- P&ID 서버: `out/PID_dev+ops_valve29_2026-11-01.zip` (pack_delta, 기준 9429f4f → e39cfda, 32 파일, 기준판 적용 충돌 0).
- 대시보드: `dashboard_patches/UPDATE_from_v16.51_VALVE2_menu.zip` (make_patch --any --mark, delivered.txt 기록).
- 회사 개발용: `out/VALVE_devkit_valve29_2026-11-01.zip` (docs/valve · handoff · other_log · spike/valve_* · CLAUDE.md 는 넣지 않음) — `C:\Claude\PID_dev` 에 풀기.
- 안내 · 첫 지시문: `docs/handoff/VALVE_COMPANY_START.md`. 인수인계 '지금 상태' 를 valve29 끝 기준으로 고쳐 씀.

## 2026-11-01 · 개발 담당 나눔 (사용자 결정)
- 대시보드 · P&ID · LOGIC · PANEL = 개인 Claude Code 개발 + zip 전달. Valve 분석 툴(Ball · Globe · Butterfly · PSV) = 회사 PC Claude Code 가 회사 PC 에서 개발.
- `config/release_sources.json`: VALVE 병합 대기 제거 · `company_owned` 경로 추가 → `spike/pack_delta.py` 가 개인 꾸러미에서 Valve 경로를 뺌(--only 로 명시할 때만 예외). CLAUDE.md §0 표 · §3, branches.md 갱신.
- 회사 운영 반영 도구 `spike/valve_deploy_to_ops.py` + `.bat`(시험 → 백업 → app/valve · app/static/valve 만 복사 → 8000 재시작) · `valve_rollback_ops.bat`. 시험 `tests/test_company_owned.py`.
- devkit 다시 만듦(위 도구 + restart_pid_server.py + 안내문 §5~7).

## 2026-11-02 · 회사 적용 확인 (사용자)
- valve29(P&ID 서버) · UPDATE_from_v16.51_VALVE2_menu(대시보드) · VALVE_devkit_valve29 · 안내문 — 모두 적용했다고 사용자 확인. 대시보드 기준점은 delivered.txt 마지막 줄(e39cfda).

## 2026-11-02 · valve30 — 회사 PC 사진 피드백 다섯 + 개발 위치 되돌림 (사용자)
- 사용자: "우선 여기 개인 클로드에서 개발을 이어서 진행한다" → CLAUDE.md 표 · §3, release_sources 설명, 인수인계 갱신 (hotfix 에 Valve 를 싣지 않는 규칙은 그대로).
- 고침: Mark-up/PDF 도구줄 흰 바탕 흰 글씨 · Ctrl+휠 확대 · PMS/Process 미리보기 높이/폭 끌기 · 미리보기 화질 · Bore 지적 문구(판정 동일, 28건 문구만).
- 점검: valve 시험 114 · eval baseline unchanged · 스냅샷 changed 28(문구만) → snapshot_valve30 저장 · UI 25/25 · LINK OK. VERSION valve30.

## 2026-11-02 · valve31 — 코멘트 한글 · 영어 + 출력 언어 선택 (사용자 요청)
- `app/valve/i18n.py`(규칙별 고정 한국어 틀) · `description_ko` · 화면 영어+한글 · Settings 표시 언어 · Excel/PDF 출력 창 언어(en/ko/both).
- 실자료 2,891건 한글 100 % · PDF 옆 코멘트 한글 글꼴 확인 · 스냅샷 변경 0 · eval unchanged · 전체 1,984 통과 · UI 25/25 · LINK OK. VERSION valve31.

## 2026-11-02 · valve32 — 올린 문서 지우기 · 휴지통 · 되돌리기 (사용자 요청)
- 🗑 → 함께 빠지는 것 확인 창 → 휴지통(JSON) · 되돌리기(같은 id) · 원본 파일 보존 · audit 'delete-doc'/'restore-doc'.
- 실화면(vt_ui 사본): 문서 7 → 6 → 되돌리기 7 · 시험 +1 (전체 1,985) · 스냅샷 변경 0 · UI 25/25 · LINK OK. VERSION valve32.

## 2026-11-02 · valve33 — 첫 화면 Valve Summary 표 (사용자 요청)
- API valve-summary + 대시보드 카드: 묶기 3종 · 색 농도 · 비율 · 특수요구 모두 · 숫자 → Tag 목록 → Valve/Issue List 걸러 열기 · Excel · 접기.
- 실자료 합계 = Valve List Excel Summary 와 같음. 시험 +1 (1,986) · 스냅샷 0 · UI 25/25 · LINK OK. VERSION valve33.

## 2026-11-02 · valve34 — FileDataError 반복(저장본 재사용) 고침 + 상태 창 닫기 (회사 PC 사진)
- 원인: 내용 해시 저장본이 깨져도 같은 내용 업로드마다 재사용. 업로드 시 크기 · 해시 검증 후 다시 씀, 처리 전 해시 확인, open_pdf 재시도 + 실제 이유 표시.
- 상태 창 ✕ · 모두 닫기 · 오류 시 자동 내려받기 안 함. 시험 +1 (1,987) · 스냅샷 0 · UI 25/25 · LINK OK. VERSION valve34.


## 2026-11-07 · valve35 — 코멘트 정리: Typical · 블럭 · 상세보기 (사용자 요청)
- `digest.py`: 한 쪽에 붙은 Data Missing(DM-01/02) 3개+ = 블럭 코멘트 하나 ('Process data missing — N items (…); ref. …') · 같은 코멘트 2 Tag+ = Typical 한 줄.
- Issue List '정리 보기 | 낱개 전체' · ▸ 상세 · 묶음 일괄 결정 · Excel 'Comments (Typical)' 시트 · Mark-up PDF 블럭 박스 (group=1, 기본 켬).
- 실자료 2,935 → 276. 판정 스냅샷 변경 0 · 시험 +2 (1,989) · UI 25/25 · 필터 · LINK OK. VERSION valve35.
- 같은 날 답: Fugitive 카운트 = 칸 · Note · General Note 의 fugitive/ISO 15848/TA-Luft (조건부 GN 미구분 — 사용자 결정 대기).

## 2026-11-07 · valve36 — 밸브 모형을 Anatomy 방식으로 (사용자 요청 "세션 7 참조")
- 세션 7 ic-3d-builder 엔진(af748c7: refdata · anatomy · viewer)을 `app/static/valve/anatomy.js` 한 파일로(`spike/mk_anatomy.py`) — 이름 AnatomyViewer · 여러 부품 강조 + 나머지 반투명.
- Data 탭 Valve Part: 데이터시트 크기 · CL · Bore · 구동기로 모형, 칸 → 부위 주황 · 부품 → 관련 칸. 평면 SVG 삭제.
- 시험 +1 · 판정 변경 없음. VERSION valve36. 꾸러미는 통합 방식(오케스트레이터) 사용자 확인 대기.

## 2026-11-11 · valve37 — 회사 PC 'HTTP 500' (PDF 새 창 ds=74)
- 여기 같은 자료로는 열림 → 회사 자료에서 그 Tag 검토 계산 예외로 추정. 검토 실패 Tag 도 PDF · 칸은 열리게(review_error), /valve 모든 예외 JSON + 로그 파일.
- 원인 확인은 회사 PC 로그(`valve\logs\errors_*.log`) 대기. VERSION valve37.

## 2026-11-11 · valve38 — 회사 PC PDF 안 뜸: 저장된 원본 PDF 를 열 수 없음 (오케스트레이터가 회사 server.log 전달)
- 원인 = `files\26c26a50aa4f1ab2.pdf`(여기 Datasheet.pdf 와 같은 해시) 를 pymupdf 가 못 엶 — 저장 뒤 내용이 바뀜(DRM 추정). valve37 의 '검토 규칙' 추정은 틀렸음.
- 저장본 .bin + filetype=pdf · 시작 때 옮김 · 다시 올리면 옛 문서 복구 · 409 stored_pdf 진단 · 뷰어 · 목록 표시 · Mark-up 은 그 Tag 만 뺌.
- 시험 +2 (1,993) · 스냅샷 0 · UI 25/25. zip 없음(오케스트레이터 hotfix 로 묶음).

## 2026-11-12 · valve39 — 첫 화면 Process Data 대조 · 문서 Rev · 구역 (사용자 요청, 회사 PC 사진)
- PDS 에 없는 Tag (norm_tag: 공백 · 하이픈 무시) · PDS 글에만 있음(표로 못 읽음) · 표에서 읽음 / 앞 0 차이는 '비슷한 번호'. 실자료 164: 없음 1(85XV114 ↔ PDS 85XV0114) · 글 97 · 표 66.
- 구역 North · South · North/South Brownfield · W15 (location.zone) · Datasheet 문서 · PDS(PR-DTS) 마다 Rev · 날짜 · 구역 · Tag.
- 시험 +1 · 판정 변경 없음. VERSION valve39.

## 2026-11-12 · valve40 1단계 — Instrument 양식 카드 14종 + 공통 번호칸 읽기기 (사용자 지시 · 기획안 v2)
- 빈 양식 14종 → `app/valve/forms/*.json` (번호 1..N 빠짐 0) · `app/valve/instrument.py` 양식 식별 · 하위칸 · 표제란 · 다중 Tag 분리.
- 시험 PDF 생성기 `spike/valve_make_test_ds.py` (TEST DATA 표시 · 원본은 저장소 밖). 실제 빈 양식 시험: 11종 100% · 3종 96~98%.
- 시험 +75 · 기존 Valve 판정 변경 없음. 다음: 2단계 (화면 · 업로드 · 필수칸 · PDS · PMS · Line List).

## 2026-11-12 · valve40 2~5단계 — Instrument 검토 화면 · PDS · PMS · Line List · List 대조
- 새 모듈: `instreview.py`(Rule IN-REQ-01 · IN-PDS-00/01 · IN-PMS-01/02 · IN-LL-00~05 · IN-ITM-01/02) · `linelist.py` · `instlists.py` · `inst_api.py` · 화면 `instrument.js`.
- 문서 관리에 칸 3개 (Instrument Datasheet · Process Line List · Instrument Index/IO List). 현황판 = 계기 Type 14종 카드 · 지적 수 · Rev · TEST 표시.
- 양식 80 카드: 한 줄에 라벨 둘(Operating Pressure | Design Pressure)인 행 28개에 칸 나눔 `pair_cells` (빈 양식의 세로 줄로 학습) → 실제 빈 양식 61/61.
- 오류 심은 시험(`spike/valve_inst_scenario.py`): 74/74 찾음 · 정상 Tag 지적 0 · List 29/29. Valve 스냅숏 2,935 변경 0 · UI 감사 25/25.
- (추가) Instrument Mark-up PDF: 지적 칸 음영 + 화살표 설명선(이유) 을 PDF 주석으로 — `app/valve/instmarkup.py` · 시험 1건.
- (추가) valve37 cherry-pick + `?kind=` 화면 나누기 (Valve 4종 ↔ Instrument 13종) · pytest 2,081 · 스냅숏 변경 0 · UI 25/25.
- (추가) Instrument 화면 가독성: 맨 위 한 줄 결론(지적 없는 Tag n/N · 진행 막대) · 상태 = 아이콘+글자+색 · 검토 결과는 지적 먼저, OK 는 접기('OK 항목 보기') · 표 줄 간격 · 줄무늬 · 고정 머리글.
- (추가) Item 페이지 메뉴 11개 (`/inst/findings` · `/inst/compare`) · List 대조에 Valve Tag 포함 (`valve_rows`) · 문서 · Revision 대장 `GET /api/valve/docreg?project=` (`app/valve/docreg.py`, 대시보드 '문서 · Revision 현황' 용, 읽기만).

## 2026-11-12 · valve40 — 엔지니어 검토 도구 보강 (웹 조사 + 엔지니어 관점)
- 조사: EPC Vendor 문서는 Review Code(예 1 Rejected … 5 Information) + CRS 로 돌려줌 · Bluebeam 식 지적마다 상태 · 흔한 Datasheet 오류(설계압을 운전압으로, Range 미포함, HOLD/TBA 잔존).
- 지적마다 엔지니어 결정(확인 · 문구 수정 · 무시+이유) → 수 · Mark-up PDF · CRS 에 반영, 같은 Tag 새 Rev 로 이어받음(Rev A 에서 이어받음 표시).
- Datasheet 마다 Review Code (프로젝트 설정, 남은 지적으로 제안 — 코드 뜻 글자로 맞춤) · CRS Excel (Vendor Reply · Close-out 빈 칸).
- 새 규칙 IN-OPN-01 (HOLD/TBA/TBC/TBD) · IN-UNIT-01 (게이지/절대 섞임). 14종 시나리오 74/74 · 오탐 0 그대로.
- 키보드 J/K · N/P · C/E/X · '/' 와 '지적만' 필터. 성능(1,450 DS): 현황판 0.53→0.03 s(재방문) · CRS 7→0.5 s · 검토 Excel 8.5→1.4 s.
- (추가) 다음 라운드: `instcalc.py` Control Valve IEC 60534-2-1 (Rated/계산 Cv · 기체 Cv 재계산 · Choked/공동현상/Flashing · 소음) · PSV API 526/520/521 · CRS 회신 올리기(Ref 열로 맞춤, 없으면 Tag+Rule+Field) · 주별 검토 진행 그래프.
- (추가) Area = Tag 앞 번호 규칙 (`arearule.py`): 프로젝트 Valve DS · PDS 표제의 Area 로 배움 → 실자료 근거 198건: 00·01·02·08·24·25 North Brownfield · 19·29·39·84·85 South Brownfield · 315 W15 · 98 은 North/South 둘 다 → 문서/P&ID 번호 '98-…' North · '999-…' South. 코드에 표를 박지 않음. `/inst/arearule` · 현황판 By Area 에 규칙 표시.

### 2026-11-13 VALVE — 공통 자료 (PDS · PMS · Line List · Instrument Index · IO List 한 곳 입력)
- 사용자: "PDS Line list io list inst list 는 한곳의 메뉴에서만 입력 · 모든 valve, inst type 별 검토에 공통".
- `api.ref_pid` / `family` / `_ref_doc` / `REF_KINDS`: 기준 프로젝트('<이름>' — ' · Globe Valve' 등 뗀 것)에 1벌 보관, 다른 kind 페이지에서 올려도 그리로 감.
  `_process_for` · `_pms_for` · `_doc_ref` · `_coverage` · `_summary`(shared 표시) · `_wver` · `_profile_ver` · `inst_api._docs` · `_ver` 가 기준 프로젝트 문서를 봄. 옛 업로드(자기 프로젝트)도 그대로 읽힘.
- 올린 뒤 `inst_api.invalidate_family()` + family 전체 warm.
- 화면: `?kind=refdocs` '공통 자료' 페이지(4칸) · 각 페이지 Document Management 는 자기 자료만(`window.DOC_KINDS`) + 공통 자료 카드(읽기 전용 · 링크) · 'Document Management 에 올리세요' 안내 → 공통 자료 링크. List 페이지의 Document Management 메뉴 뺌.
- 시험 `test_shared_reference_documents_one_place_for_the_family`. 스냅샷 2,935 · 변화 0 · UI 25/25.

### 2026-11-13 VALVE — Brownfield Tag 규칙으로 Area 재분류 · 학습
- 사용자 사진(회사 PC 분석): Brownfield QN/QS 접두어 → Area 컬럼 · Unit · Exhibit 6. 표 값은 저장소에 넣지 않음 — 프로젝트 설정으로 붙여 넣음.
- `arearule.py`: `parse_table`(묶음 줄 · 탭/|/두 칸 표 · 'XS: 98GTD- / …' 줄 · `X (17), Y (7)` 나뉨) · `classify`(규칙 표 → Index AREA → 문서 학습) · `check_table`(Index 대조 n/n) ·
  깊은 키(접두어+문자, +번호 앞 2자리, `98*98` 아무 문자) · `num_eq`('1' = '01') · 묶음 별칭(규칙 표 'Brownfield QN' = 문서 표제 'North Brownfield').
- 실자료: 98 은 Loop 번호 앞 두 자리로 갈림 (98-◦-98… North · 00/01/10/11/30/31… South). 업로드된 Instrument Index 는 빈 양식이라 Index AREA 학습은 시험 자료로만 확인.
- `inst_api`: PUT/GET `/inst/arearule`(text · table · index_rows) · `_brief` 에 `sub_area` · `area_note` · Unit(규칙 표). 화면: By Area 규칙 표 카드 · 붙여넣기 창 · Area 카드에 Sub-area 개수.
- 시험 `test_area_rule_table_and_index_area`. 스냅샷 2,935 · 변화 0 · UI 25/25.

### 2026-11-13 VALVE — 회사 PC 서버 재시작 반복 (MuPDF 네이티브 종료) 막기
- 오케스트레이터 전달: 시작 warm-up 이 프로젝트 5개를 동시에 돌며 손상된 보관 PDF 를 열다 MuPDF 단에서 프로세스가 죽음 (traceback 없음).
- `store.stored_good`: 파일 없음 · 0 B · '%PDF' 없음 · 올린 파일 해시와 다름 → **MuPDF 에 절대 넘기지 않음** (경로 · mtime · 크기로 캐시). `extract.open_pdf` 가 먼저 확인,
  직접 `pymupdf.open` 하던 docrev · pms · instrument · instlists 도 open_pdf 로.
- `extract.PDF_LOCK` (RLock) + `@pdf_locked`: 읽기 · 화면 렌더 · Mark-up · 업로드 확인 모두 한 줄로 (MuPDF 스레드 비안전).
- warm-up: 작업 스레드 1개가 프로젝트를 차례로 · 단계마다 `<자료>/valve/logs/warmup.log` 한 줄 · `VALVE_WARMUP=0` 이면 끔.
- `faulthandler` → `<자료>/valve/logs/crash_날짜.log` (네이티브 충돌 스택), 다음 시작 때 알림. 시작 보고: 'stored PDF check: n good · m damaged (not opened)' + 손상본 앞 32바이트.
- 손상 Process Data · PMS → '없음' 처리 (500 아님). 재현: 실자료 복사본 PDF 5개 중 3개 손상 → 서버 유지 · MuPDF 오류 0 · 화면 200 · PDF 쪽 409.
- 시험 `test_damaged_stored_copy_never_reaches_mupdf_and_warmup_is_safe`. 전체 2,089 통과 · 스냅샷 2,935/0 · UI 25/25.

### 2026-11-13 VALVE — Valve 화면 Area 규칙 · Datasheet JSON 저장 (오케스트레이터 전달 사용자 지시)
- Area: Valve Summary · 대시보드 By Area · Issue 행/Excel · Valve List · 특수요구사항 표에 family Area 규칙(`api._area_fn` → `inst_api.area_rule_cached`) 적용.
  문서 표제가 말한 Area 는 그대로, 없거나 'Brownfield' 만이면 규칙(규칙 표 → Index AREA → 학습)으로 채움 + `sub_area` · `area_basis`(출처). 검토 자체(동료 그룹 · 지적)는 문서 표제 그대로 → 스냅샷 2,935/0.
  학습이 '(not stated)' 를 Area 로 세던 것 고침.
- JSON: `dsjson.py` — `<자료>/valve/datasheets/<프로젝트>/<kind>/<Tag>__<Rev>.json` (칸 값 · 단위 · 쪽 · bbox · 상태 · 검토자 수정 · Notes · Rev 표 · 원본 이름 · sha256 · 올린 사람/때)
  + `_documents/<문서id>__<파일>.json`. 업로드 · 다시 읽기 때 씀, 서버 시작 때 빠진 것만 씀, `POST /projects/{pid}/export-json` 다시 씀, `GET /datasheets/{id}/json` · `/inst/sheets/{id}/json`.
  검토는 원래 DB · 파싱 JSON 으로 돎 — PDF 는 쪽 보기 · Mark-up 에만 (손상 PDF 여도 검토 200 확인).
- 시험 3개 추가 (Valve Area 규칙 · JSON · Instrument JSON). 전체 2,090 통과.
- (추가) 손상 저장본 = 예전 쪽 그림(`cache/<doc>_<page>_<zoom>.png`)으로 보기 + 안내 줄 '원본 손상 · 예전 쪽 그림 — 값 · 검토 그대로, 다시 올릴 필요 없음'.
  쪽 크기는 `document.info.page_sizes` 에 보관(없으면 그림 크기로 계산). 그림 없는 쪽만 409. 시험 `test_damaged_stored_copy_shown_from_earlier_page_pictures`. 전체 2,092.
- (추가 · 회사 사진 Butterfly: Tag 52 · 53 이 'North' · Unit 52/53) 원인: 규칙 표 없이, 표제가 'NORTH' 만 말하는 PDS 문서 번호 '52-…'/'53-…' 로 추정 → Greenfield 처럼 보임.
  고침: 그런 추정은 Site 만(North) + 'Brownfield 여부 근거 없음 (규칙 표로 정하기)'. 규칙 표가 있으면 52·53 → North Brownfield · QG3&4 · Unit 09.
  규칙 표 Unit 이 Tag 앞 번호로 짐작한 Unit 을 대신함 · 규칙으로 Area 를 채우면 Site 도 채움.
- (추가 · 사용자 '규칙 표를 기본값으로 미리 넣어둬라 · 편집 가능 · 새로고침하면 각 현황판 Area 반영') 기본 표 `app/valve/arearule_default.txt`
  (사용자 사진 그대로 · 잘린 첫 줄은 넣지 않음). family 에 고친 표가 없으면 기본값, 고치면 그 family 의 표(`inst.arearule.table`), '기본값으로 되돌리기'.
  편집: 공통 자료 페이지 'Area 규칙 표' 카드 + Instrument By Area — 줄 단위 표 편집(묶음 · 접두어 · Sub · Unit · 메모 · ＋줄 · ✕) / 글 붙여넣기.
  저장 → 감사 기록 → Valve · Instrument 캐시 버전이 바뀌어 새로고침 때 모든 현황판 Area 다시 라벨링. 시험 +1. 전체 2,093.
- (추가 · 사용자 'Area 는 우선 입력되는 Datasheet 기준, 식별 안 되면 Tag 규칙') Instrument: 읽을 때 첫 쪽 표제의 Area(`instrument.page_zone` —
  'QELNG NORTH/SOUTH' · W15 · 'SYSTEM nn – UNIT nn' · Brownfield, 엄격: 서비스명의 'NORTH' 는 안 셈)를 `title_block.zone` 에 보관, 옛 시트는 보관본이 멀쩡할 때 한 번 읽어 채움.
  `_brief`: Datasheet Area → 없을 때만 규칙(규칙 표 → Index AREA → 학습). 표제가 Site 만 말하면 Site 유지 + Brownfield 여부만 규칙 표에서 (Valve · Instrument 같음).
  Valve 는 규칙으로 채운 'North Brownfield' 를 화면 형식 Area 'Brownfield' + Site 'North' 로. 규칙 캐시 버전에 표 내용 포함. 시험 +1. 전체 통과.
- (추가 · 사용자 'DTS No. 98 · 999 · 315 → QN · QS · W15, 그 안에서 Brownfield Tag 면 QN 의 Brownfield N1 · QS · W15 는 Brownfield 없음')
  기본 규칙 표에 'DTS 98 | QN' · 'DTS 999 | QS' · 'DTS 315 | W15' 줄 (표에서 고칠 수 있음) · 사진의 'Brownfield QS' 묶음은 'QS'(Brownfield 없음)로.
  `arearule.resolve`: Site = DTS No. → 표제(North=QN … 문서 번호로 배움) → Tag 규칙 · Brownfield 는 표에 그 Site 의 Brownfield 묶음이 있을 때만 · Train = 메모 첫 낱말.
  실자료: QN 74 · QN Brownfield N1 2 · N2 2 · QN Brownfield(Train 미상: 00·08) 3 · QS 76(표제 'South Brownfield' 7개는 QS + 사유) · W15 7. 판정 변화 0.
  Area 정렬: QN → QS → W15 (`exports.AREA_ORDER`). 시험 +1.

- (추가 · 사용자 'PDF 를 넣으면 해당 도서의 Area 를 적게 · North 도서 → North 우선, Brownfield 규칙 Tag 는 North Brownfield, 아니면 Greenfield North ·
  South 는 Brownfield 없음 · North 를 넣어도 South 로 읽는 문제') Document Management 에 '이 도서의 Area' (문서에서 읽기 / 규칙 표 DTS 줄의 이름 North · South · W15)
  → `document.area` (새 칸) · 올린 뒤 표의 Area 칸에서 바꿈 (`PUT /documents/{id}/area`, 다시 올릴 필요 없음).
  `arearule.resolve`: 올린 도서의 Area → DTS No. → 표제 → 규칙 표 줄. **학습한 추정(Loop 번호 앞 두 자리 98-◦-00/01… = South)은 Site 를 정하지 않음** — 이것이
  North Tag 를 South 로 읽던 길. 라벨: Brownfield 묶음이 있는 Site 는 'QN Brownfield N1' / 'QN Greenfield', 없는 Site 는 'QS' · 'W15'.
  기본 표 DTS 줄에 이름 ('DTS 98 | QN | | North'). 실자료: QN Greenfield 74 · QN Brownfield N1 2 · N2 2 · (Train 미상) 3 · QS 76 · W15 7. 시험 +1 · 전체 2,096.
- (추가 · 오케스트레이터가 알린 가끔 실패) 새 DB 를 여러 스레드가 동시에 열 때 'database is locked': busy_timeout 을 먼저, WAL 전환은 첫 사용 잠금 안에서 1번
  (재현 40회 중 3회 → 0회 · 회사 첫 시작에도 해당). warm-up 대기열이 자료 폴더를 기억 — 폴더가 바뀌면(시험) 그 일을 건너뜀. 전체 2,096 두 번 통과.

### 2026-11-18 VALVE valve41 — South Control Valve · Regulator 도서가 안 읽히던 것 (ISA-20 'INSTRUMENT SPECIFICATION' 양식)
- 회사 사진(Globe Valve): 'QS (other) 1' · PCV 4개가 'South' 와 'QS' 로 따로. 사용자 첨부 2권(40쪽 Control Valve · 16쪽 Self-actuated Regulator)으로 재현:
  40쪽 도서가 **Tag 없는 Datasheet 1개**, Regulator 는 Tag 만 있고 값 거의 없음.
- 원인: 두 도서는 Valve 리더가 아는 양식(Form 101/102 = 'Label : value')이 아니라 ISA-20 식 양식 — 번호 줄 2열(1-55 · 56-83), 콜론 없음,
  라벨·값이 같은 글꼴, 칸마다 괘선, 표제는 아래. read_page_102 가 콜론 있는 줄 6개만 읽음.
- `app/valve/form_isa.py` (새 파일): 괘선으로 칸을 읽음 — 블록(1-30 전체 폭 · 31-55 · 56-83)의 라벨/값 경계 = 그 블록 줄 대부분을 지나는 세로선,
  칸 = 줄을 지나는 세로선 사이. 라벨은 (라벨, 블록 제목)으로 key (MFR · Model · Type 이 Body/Actuator/Positioner/Solenoid/Switches/Air set 마다 다름).
  'Ambient Temperature: | Min. | Max.' · 'Line Size and Schedule | Inlet | Outlet' = 제목 + 두 부분(값 공간 가운데 선으로 가름), 단위만 든 칸은 앞 값의 단위,
  공정 줄 = 'Units | @Max | @Norm | @Min' 머리줄 아래 4칸(flow.max …), '4 in 80' = Size + Schedule, 'RF,1500#' = Connection + Rating. 표제는 footer().
  `extract.read_page` 가 'Form No' 없고 번호 열 2개 + 표 아래 'INSTRUMENT SPECIFICATION' 이면 이 리더로. Sheet 2(Notes)는 기존 read_continuation.
  PARSER_VERSION extract-v41 · VERSION valve41.
- 결과(첨부 2권): 15 + 4 = 19 Tag (FV 1 · LV 8 · PV 5 · TV 1 · PCV 4), Tag 당 120여 칸, 모르는 라벨 0, Area QS. 지적 148 = 공정 값 빈칸 144(도서 Hold 1 과 일치) ·
  Valve Size 빈칸 2(Hold 3 의 98FV-010 · 98PV-025B) · Note 9 HOLD 2.
- 다시 올리지 않게: 서버 시작 때 **Tag 없는 Datasheet 를 남긴 문서**를 새 리더로 한 번 다시 읽음(`_auto_reread`, 보관본 멀쩡할 때 · 리더 판마다 1번 · `document.info.reader`).
  다시 읽을 때 같은 파일의 옛 읽기가 남긴 것(Tag 없음 · 같은 Tag 다른 Rev)은 검토자가 손대지 않았으면 지움.
- Area: 표제의 'South' ↔ 규칙 표 'QS' 를 잇는 학습이 '999-…' 문서에 South 와 South Brownfield 가 섞이면 실패 → 첫 낱말로 배움 (사진의 'South' 4 · 'QS' 5 가 한 줄로).
- 검토: PURCHASE 칸(PO 번호 · 가격 · Serial 'TBC')은 Open Item 아님 · 상(phase)에 따라 빈칸인 물성(Z · 점도 · 비열비 · 증기압)은 'Data Missing' 아님(Form 101 과 같음).
- 시험 `tests/test_valve_form_isa.py` (가짜 값으로 그린 양식 2개). Ball 456쪽 읽기 결과 옛 코드와 동일(17,471 칸) · 판정 2,935/0 · UI 25/25 · 전체 2,098.
- (추가 · 사용자 '이런 문제가 다른 타입에는 없나?') 확인: Instrument 로 모르는 양식을 올리면 초록 'done' · Tag 0 · 작은 글씨 '알아본 양식 없음' 뿐 — 같은 약점.
  안전망(모든 타입): ① `extract.unread_pages` — 번호 줄 양식 쪽인데 읽힌 줄이 40% 미만(정상 92~100% · 못 읽은 South 8%) · Tag 없는 DS · 리더가 안 잡은 양식 쪽
  ② `extract.index_tags` / `index_check` — 도서의 'INDEX (LIST OF TAGS)' 와 읽은 Tag 대조 (실 Ball 164/164 · South 15/15 · 4/4) ③ Instrument: 카드가 모르는 번호 줄 양식 쪽 + INDEX 대조.
  결과는 작업 창 경고(여러 경고 이어 붙임 `_job_warn`) + `document.info.unread_pages` · `.index` + Document Management 빨간 '일부 못 읽음' / '✓ INDEX n Tag 모두 읽음'.
  아직 확인 못 한 것: Instrument 14종은 빈 양식만 봤음(채운 실물 0) · Butterfly/PSV 의 South 도서. 시험 +2 · 전체 2,100.

### 2026-11-19 VALVE — 인수인계 문서 다시 씀 (오케스트레이터 전달 1번)
- `docs/handoff/valve.md` 14,994 B → 8,422 B: '지금 상태' 한 절 + 다음 할 일. 끝난 규약 문구(valveNN 꾸러미 절차 · 'valve40 zip 아직') 삭제, 꾸러미 = 오케스트레이터.
- 오케스트레이터 전달 2~5번(List 대조 보강 · IN-ITM-03/04 · anatomy.js 다시 만들기 · Valve 화면 instcalc)은 '다음에 할 일'에 순서대로 적음 — 아직 시작 안 함.

### 2026-11-20 VALVE valve42 — 프로젝트 Valve Specification(On/Off · MOV · Control Valve) 대비 코멘트
- 사용자: Spec 3권을 학습해 이를 기반으로 코멘트. Spec 은 공통 자료의 새 종류 'Valve Specification'(vspec)으로 올림 — 원본은 저장소에 없음.
- `app/valve/vspec.py`: read_spec = 번호 조항으로 나눔(표지 · 목차 · 쪽 머리 빼고, 줄에 혼자 있는 번호 · 글머리표 처리) — 실물 On/Off 159 · MOV 172 · CV 634 조항.
  검사 SP-01~15 = 조항을 문구로 찾아 **그 조항의 값**(Rate · Class · 초 · 배수 · 온도 · dBA · IP)으로 Datasheet 와 견줌. 조항이 없는 Spec 이면 그 검사는 안 함.
  적용: Form 101/ISA20 · CV Tag → CV Spec · MOV/Form 102 → MOV Spec · Ball/ESDV/SDV/BDV/XV → On/Off Spec. 지적 종류 'Spec Compliance' · 근거 = Spec 번호 §조항 · 쪽 · 해당 문장 · 한글 코멘트.
- 실자료(Ball 164 + On/Off Spec): 기존 2,935 변화 0 · 추가 5 (fire safe 미기재 3 · ISO 5208 Rate B 2). South CV 19 + CV Spec: 0. MOV 24 + MOV Spec: 0.
- 시험 `tests/test_valve_spec.py`(가짜 조항으로 그린 Spec) · i18n 3줄. 전체 2,106 통과 · UI 25/25. VERSION valve42.

## 2026-11-26 · VALVE valve43 — PDS Rev. 비교 Excel (사용자: "같은 PDS 명의 수정 PDS 를 넣으면 Excel 과 같이 출력")
- 원인 먼저: PDS 표 읽기가 칸마다 끊어 그린 세로 괘선을 못 이어 2~5쪽을 0줄로 읽음(98 Rev.0 84 Tag 중 24) · 여러 줄 Location 이 윗 줄 Tag 로 샘.
  `process._bands` 가 같은 x 의 조각을 합치고, `_rebox` 가 가로 괘선 사이 단어만 그 줄에 → 98: 74→84 · 999: 69→65 · 315: 7→1 (예시와 같음).
- 새 `app/valve/pdsrev.py`: compare(상태 · 중요도 · 2% 보정 · 따옴표/구분기호 무시 · 한쪽 Rev. 에만 있는 열 제외 · MOV 섹션 없음 → Delete 사유) + workbook(예시 양식).
  Tag 변경 의심 = 같은 Line(번호+Size) 에 앉은 새 Tag, 또는 접미 문자 추가(305 → 305A · 305B). 재사용 의심 = 같은 번호가 다른 P&ID 의 다른 Line(Size 다름/서비스 다름).
- 사용자 예시 Excel 과 대조: 3문서 182 Tag 의 상태 · 칸별 중요도 · Summary 와 Sizing 시트 숫자 전부 같음(LibreOffice 재계산).
- API: 업로드 때 같은 문서 번호의 앞 Rev. 과 비교 → info.revcompare · 작업 문구 · 버튼 'PDS Rev. 비교 Excel' · `GET /projects/{pid}/pds_revcompare.xlsx`.
  `_process_for` 는 문서 번호마다 최신 Rev. 을 합쳐 씀(예전: 가장 새 PDF 1권만 — North · South · W15 를 같이 올리면 둘이 빠졌음).
- 스냅숏(Ball 164): 2,935 → 3,091. 없어진 것 0 · 심각도 변화 0 · 새 지적 156(87 Tag, 예전에 못 읽은 PDS 쪽) · Data Missing 781건 expected 에 PDS 값 ·
  Valve Review 8건 근거가 PDS 로. 무작위 6건 PDF 원문과 대조 — 모두 PDF 값 그대로. 새 기준 `out/valve29/snapshot_valve43.json`.
- 시험 `tests/test_valve_pdsrev.py`(가짜 PDS: 조각 괘선 · 3줄 Location · MOV 섹션 · 새 열) 5개. pytest 2,111 · UI 25/25.
